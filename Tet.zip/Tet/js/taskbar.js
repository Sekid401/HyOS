// taskbar.js — Taskbar, Calendar, Start Menu, Spotlight, Quick Settings, Global Account
var db, supabase, firebaseInitialized = false, supabaseInitialized = false;
window.addEventListener('hyos-backend-ready', (e) => {
    db = window.db; supabase = window.supabase;
    firebaseInitialized = window.firebaseInitialized;
    supabaseInitialized = window.supabaseInitialized;
});

    window.Calendar = {
        currentDate: new Date(),
        selectedDate: null,
        events: JSON.parse(localStorage.getItem('calendarEvents') || '{}'),
        
        toggle: function(event) {
            if (event) event.stopPropagation();
            const panel = document.getElementById('calendar-panel');
            if (panel.style.display === 'flex') {
                panel.style.display = 'none';
            } else {
                panel.style.display = 'flex';
                this.render();
            }
        },
        
        render: function() {
            const year = this.currentDate.getFullYear();
            const month = this.currentDate.getMonth();
            
            // Update header
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December'];
            document.getElementById('calendar-month-year').textContent = `${monthNames[month]} ${year}`;
            
            // Clear grid (keep day labels)
            const grid = document.getElementById('calendar-grid');
            while (grid.children.length > 7) {
                grid.removeChild(grid.lastChild);
            }
            
            // Get first day of month and number of days
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const daysInPrevMonth = new Date(year, month, 0).getDate();
            
            const today = new Date();
            const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
            
            // Add previous month days
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = daysInPrevMonth - i;
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day other-month';
                dayEl.textContent = day;
                grid.appendChild(dayEl);
            }
            
            // Add current month days
            for (let day = 1; day <= daysInMonth; day++) {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day';
                dayEl.textContent = day;
                
                // Check if today
                if (isCurrentMonth && day === today.getDate()) {
                    dayEl.classList.add('today');
                }
                
                // Check if has events
                const dateKey = `${year}-${month + 1}-${day}`;
                if (this.events[dateKey] && this.events[dateKey].length > 0) {
                    dayEl.classList.add('has-event');
                }
                
                // Click handler
                dayEl.onclick = () => {
                    document.querySelectorAll('.calendar-day').forEach(d => d.classList.remove('selected'));
                    dayEl.classList.add('selected');
                    this.selectedDate = new Date(year, month, day);
                    this.showEvents(dateKey);
                };
                
                grid.appendChild(dayEl);
            }
            
            // Add next month days to fill grid
            const totalCells = grid.children.length - 7;
            const remainingCells = 42 - totalCells - 7; // 6 rows * 7 days - day labels
            for (let day = 1; day <= remainingCells; day++) {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day other-month';
                dayEl.textContent = day;
                grid.appendChild(dayEl);
            }
            
            // Show today's events by default
            const todayKey = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
            this.showEvents(todayKey);
        },
        
        showEvents: function(dateKey) {
            const eventsList = document.getElementById('calendar-events-list');
            const dayEvents = this.events[dateKey] || [];
            
            if (dayEvents.length === 0) {
                eventsList.innerHTML = '<div style="text-align: center; opacity: 0.5; padding: 20px;">No events for this day</div>';
                return;
            }
            
            eventsList.innerHTML = '';
            dayEvents.forEach((event, index) => {
                const eventEl = document.createElement('div');
                eventEl.className = 'calendar-event';
                eventEl.innerHTML = `
                    <div class="calendar-event-time">${event.time}</div>
                    <div class="calendar-event-title">${event.title}</div>
                    ${event.description ? `<div style="font-size: 11px; opacity: 0.7; margin-top: 4px;">${event.description}</div>` : ''}
                    <button onclick="Calendar.deleteEvent('${dateKey}', ${index})" style="margin-top: 8px; background: #ef4444; border: none; padding: 4px 10px; border-radius: 6px; cursor: pointer; font-size: 11px; color: white;">Delete</button>
                `;
                eventsList.appendChild(eventEl);
            });
        },
        
        addEvent: function() {
            const dateKey = this.selectedDate 
                ? `${this.selectedDate.getFullYear()}-${this.selectedDate.getMonth() + 1}-${this.selectedDate.getDate()}`
                : `${new Date().getFullYear()}-${new Date().getMonth() + 1}-${new Date().getDate()}`;
            
            const title = prompt('Event title:');
            if (!title) return;
            
            const time = prompt('Event time (e.g., 2:00 PM):', '12:00 PM');
            const description = prompt('Event description (optional):') || '';
            
            if (!this.events[dateKey]) {
                this.events[dateKey] = [];
            }
            
            this.events[dateKey].push({ title, time, description });
            localStorage.setItem('calendarEvents', JSON.stringify(this.events));
            
            this.render();
            notify('Event Added', `${title} scheduled for ${time}`);
        },
        
        deleteEvent: function(dateKey, index) {
            if (confirm('Delete this event?')) {
                this.events[dateKey].splice(index, 1);
                if (this.events[dateKey].length === 0) {
                    delete this.events[dateKey];
                }
                localStorage.setItem('calendarEvents', JSON.stringify(this.events));
                this.render();
                notify('Event Deleted', 'Event removed from calendar');
            }
        },
        
        prevMonth: function() {
            this.currentDate.setMonth(this.currentDate.getMonth() - 1);
            this.render();
        },
        
        nextMonth: function() {
            this.currentDate.setMonth(this.currentDate.getMonth() + 1);
            this.render();
        }
    };
    
    // Enhanced Services Menu Functions
    window.openSystemPreferences = function() {
        toggleApp('settings-win');
        document.getElementById('services-menu').style.display = 'none';
    };
    
    window.openAppStore = function() {
        toggleDrawer('drawer-win');
        document.getElementById('services-menu').style.display = 'none';
    };
    
    window.takeScreenshot = function() {
        document.getElementById('services-menu').style.display = 'none';
        notify('Screenshot', 'Taking screenshot...');
        
        html2canvas(document.body).then(canvas => {
            const link = document.createElement('a');
            link.download = `HyOS-HS-Screenshot-${Date.now()}.png`;
            link.href = canvas.toDataURL();
            link.click();
            notify('Screenshot Saved', 'Screenshot downloaded successfully!');
        });
    };
    
    window.lockScreen = function() {
        document.getElementById('services-menu').style.display = 'none';
        notify('Lock Screen', 'Locking screen...');
        setTimeout(() => {
            const loginScreen = document.getElementById('login-screen');
            loginScreen.style.display = 'flex';
            loginScreen.style.opacity = '1';
            
            // Clear previous inputs
            const pIn = document.getElementById('p-in');
            const loginError = document.getElementById('login-error');
            const loginSuccess = document.getElementById('login-success');
            pIn.value = '';
            loginError.style.display = 'none';
            loginSuccess.style.display = 'none';
            
            // Check if there's a default user set
            const defaultUser = userSettings.defaultUser;
            const lockUserInfo = document.getElementById('lock-user-info');
            const loginUsernameWrap = document.getElementById('login-username-wrap');
            const lockUsernameDisplay = document.getElementById('lock-username-display');
            const lockAvatarLetter = document.getElementById('lock-avatar-letter');
            const lockSwitchBtn = document.getElementById('lock-switch-user-btn');
            const loginGuestBtn = document.getElementById('login-guest-btn');
            const loginHintText = document.getElementById('login-hint-text');
            const loginMainBtn = document.getElementById('login-main-btn');
            
            if (defaultUser) {
                // Lock screen mode: show user, hide username input
                lockUserInfo.style.display = 'block';
                lockUsernameDisplay.textContent = defaultUser;
                // Show profile pic or letter
                const picData = userSettings.profilePic;
                const avatarImg = document.getElementById('lock-avatar-img');
                if (picData && avatarImg) {
                    avatarImg.src = picData;
                    avatarImg.style.display = 'block';
                    lockAvatarLetter.style.display = 'none';
                } else {
                    if (avatarImg) avatarImg.style.display = 'none';
                    lockAvatarLetter.style.display = '';
                    lockAvatarLetter.textContent = defaultUser.charAt(0).toUpperCase();
                }
                loginUsernameWrap.style.display = 'none';
                lockSwitchBtn.style.display = 'block';
                loginGuestBtn.style.display = 'none';
                loginHintText.style.display = 'none';
                loginMainBtn.textContent = 'Unlock';
                // Pre-fill hidden username field
                document.getElementById('u-in').value = defaultUser;
            } else if (user && user !== 'Guest') {
                // No default user, but someone is logged in — show their name but still require username
                lockUserInfo.style.display = 'block';
                lockUsernameDisplay.textContent = user;
                // Show profile pic or letter
                const picData2 = userSettings.profilePic;
                const avatarImg2 = document.getElementById('lock-avatar-img');
                if (picData2 && avatarImg2) {
                    avatarImg2.src = picData2;
                    avatarImg2.style.display = 'block';
                    lockAvatarLetter.style.display = 'none';
                } else {
                    if (avatarImg2) avatarImg2.style.display = 'none';
                    lockAvatarLetter.style.display = '';
                    lockAvatarLetter.textContent = user.charAt(0).toUpperCase();
                }
                loginUsernameWrap.style.display = 'block';
                lockSwitchBtn.style.display = 'none';
                loginGuestBtn.style.display = 'none';
                loginHintText.style.display = 'none';
                loginMainBtn.textContent = 'Unlock';
                document.getElementById('u-in').value = user;
            } else {
                // Not logged in — show normal login screen
                exitLockMode();
            }
            
            pIn.focus();

            // Start login screen clock
            const _tickLoginClock = () => {
                const now = new Date();
                const clockEl = document.getElementById('login-clock-display');
                const dateEl = document.getElementById('login-date-display');
                if (clockEl) clockEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                if (dateEl) dateEl.textContent = now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
            };
            _tickLoginClock();
            if (window._loginClockInterval) clearInterval(window._loginClockInterval);
            window._loginClockInterval = setInterval(() => {
                if (document.getElementById('login-screen').style.display !== 'none') {
                    _tickLoginClock();
                } else {
                    clearInterval(window._loginClockInterval);
                }
            }, 1000);
        }, 500);
    };

    window.exitLockMode = function() {
        // Reset to normal login mode
        document.getElementById('lock-user-info').style.display = 'none';
        document.getElementById('login-username-wrap').style.display = 'block';
        document.getElementById('lock-switch-user-btn').style.display = 'none';
        document.getElementById('login-guest-btn').style.display = 'block';
        document.getElementById('login-hint-text').style.display = 'block';
        document.getElementById('login-main-btn').textContent = 'Sign In';
        document.getElementById('u-in').value = '';
        document.getElementById('p-in').value = '';
    };
    
    window.restartSystem = function() {
        if (confirm('Are you sure you want to restart HyOS HS?')) {
            document.getElementById('services-menu').style.display = 'none';
            notify('Restarting', 'System will restart...');
            setTimeout(() => location.reload(), 2000);
        }
    };
    
    window.shutdownSystem = function() {
        if (confirm('Are you sure you want to shutdown HyOS HS?')) {
            document.getElementById('services-menu').style.display = 'none';
            notify('Shutting Down', 'Goodbye!');
            setTimeout(() => {
                document.body.innerHTML = '<div style="display: flex; align-items: center; justify-content: center; height: 100vh; background: #000; color: #fff; font-size: 24px;">System Shutdown</div>';
            }, 2000);
        }
    };
    
    window.aboutHyOS = function() {
        document.getElementById('services-menu').style.display = 'none';
        const uptime = Math.floor((Date.now() - performance.timing.navigationStart) / 1000);
        const minutes = Math.floor(uptime / 60);
        const seconds = uptime % 60;
        notify('About HyOS', `HyOS HS v1.0<br>Build: ${new Date().toLocaleDateString()}<br>Uptime: ${minutes}m ${seconds}s<br>Apps: ${installedApps.length}`);
    };
    
    window.logOff = function() {
        if (confirm('Log off and return to login screen?')) {
            document.getElementById('services-menu').style.display = 'none';
            notify('Logging Off', 'Goodbye!');
            setTimeout(() => {
                document.getElementById('login-screen').style.display = 'flex';
            }, 1000);
        }
    };
    
    // Close panels when clicking outside
    document.addEventListener('click', function(event) {
        const servicesMenu = document.getElementById('services-menu');
        const notifPanel = document.getElementById('notification-panel');
        const hyleyPanel = document.getElementById('hyley-panel');
        const hyleySettingsPanel = document.getElementById('hyley-settings-panel');
        const calendarPanel = document.getElementById('calendar-panel');
        const startMenu = document.getElementById('start-menu');
        
        if (!event.target.closest('.statusbar-logo') && 
            !event.target.closest('.statusbar-item') && 
            !event.target.closest('.statusbar-menu') &&
            !event.target.closest('.notification-panel') &&
            !event.target.closest('.hyley-panel') &&
            !event.target.closest('#hyley-settings-panel') &&
            !event.target.closest('.calendar-panel')) {
            servicesMenu.style.display = 'none';
            notifPanel.style.display = 'none';
            hyleyPanel.style.display = 'none';
            hyleySettingsPanel.style.display = 'none';
            calendarPanel.style.display = 'none';
        }
        
        if (!event.target.closest('#start-menu') && !event.target.closest('#start-btn') && !event.target.closest('.start-btn')) {
            if (startMenu.classList.contains('open')) closeStartMenu();
        }
    });

    // ============================================================
    // START MENU SYSTEM
    // ============================================================
    const StartMenu = {
        pinnedApps: [
            { name: 'Files', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>', action: "toggleApp('hyfiles-win')" },
            { name: 'Notes', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>', action: "Notepad.newFile()" },
            { name: 'Maker', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>', action: "openMaker()" },
            { name: 'Settings', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>', action: "toggleApp('settings-win')" },
            { name: 'Apps', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>', action: "toggleDrawer('drawer-win')" },
            { name: 'Hyley', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>', action: "toggleHyley()" },
            { name: 'Wallpaper', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>', action: "openWallpaperPicker()" },
            { name: 'Store', icon: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>', action: "openAppStore()" },
            { name: 'Terminal', icon: '⌨️', action: "openTerminal()", isCustom: true },
            { name: 'Calculator', icon: '🧮', action: "openCalculator()", isCustom: true },
            { name: 'Media', icon: '🖼️', action: "openMediaViewer()", isCustom: true },
        ]
    };

    window.toggleStartMenu = function() {
        const menu = document.getElementById('start-menu');
        const btn = document.getElementById('start-btn');
        if (menu.classList.contains('open')) {
            closeStartMenu();
        } else {
            closeStartMenu(); // reset
            buildStartMenu();
            menu.classList.add('open');
            btn.classList.add('open');
            document.getElementById('start-search').focus();
        }
    };

    window.closeStartMenu = function() {
        const menu = document.getElementById('start-menu');
        const btn = document.getElementById('start-btn');
        menu.classList.remove('open');
        btn && btn.classList.remove('open');
        const input = document.getElementById('start-search');
        if (input) input.value = '';
    };

    function buildStartMenu() {
        // Build pinned grid
        const pinnedGrid = document.getElementById('start-pinned-grid');
        const allPinned = [...StartMenu.pinnedApps];
        // Add installed apps
        if (window.installedApps) {
            installedApps.slice(0, 4).forEach(app => {
                if (!allPinned.find(p => p.name === app.name)) {
                    allPinned.push({ name: app.name, icon: app.icon || '📱', action: `launchApp('${app.id}')`, isCustom: true });
                }
            });
        }
        pinnedGrid.innerHTML = allPinned.slice(0, 8).map(app => `
            <div class="start-pinned-item" onclick="${app.action};closeStartMenu()">
                <div class="icon-wrap" style="color:rgba(255,255,255,0.8)">
                    ${app.isCustom ? `<span style="font-size:22px">${app.icon}</span>` : app.icon}
                </div>
                <div class="label">${app.name}</div>
            </div>
        `).join('');

        // Build recent list
        const recentList = document.getElementById('start-recent-list');
        const recentApps = AppUsageTracker.getRecentApps(5);
        if (recentApps.length === 0) {
            recentList.innerHTML = '<div style="font-size:12px;opacity:0.4;padding:8px;">No recent apps</div>';
        } else {
            recentList.innerHTML = recentApps.map(app => `
                <div class="start-recent-item" onclick="${app.action || `toggleApp('${app.id}')`};closeStartMenu()">
                    <div class="start-recent-icon">${app.icon || '📱'}</div>
                    <div class="start-recent-info">
                        <div class="start-recent-name">${app.name}</div>
                        <div class="start-recent-desc">${app.desc || 'Recently used'}</div>
                    </div>
                </div>
            `).join('');
        }
    }

    window.startMenuSearch = function(query) {
        if (!query) { buildStartMenu(); return; }
        const q = query.toLowerCase();
        const body = document.getElementById('start-menu-body');
        
        const results = [];
        // Search pinned
        StartMenu.pinnedApps.forEach(app => {
            if (app.name.toLowerCase().includes(q)) results.push(app);
        });
        // Search installed
        if (window.installedApps) {
            installedApps.forEach(app => {
                if (app.name.toLowerCase().includes(q)) {
                    results.push({ name: app.name, icon: app.icon || '📱', action: `launchApp('${app.id}')`, isCustom: true });
                }
            });
        }
        
        body.innerHTML = `
            <div class="start-menu-section-title">Search Results ${results.length === 0 ? '(none)' : ''}</div>
            ${results.map(app => `
                <div class="start-recent-item" onclick="${app.action};closeStartMenu()">
                    <div class="start-recent-icon" style="color:rgba(255,255,255,0.8)">${app.isCustom ? app.icon : app.icon.replace(/width="\d+"/,'width="20"').replace(/height="\d+"/,'height="20"')}</div>
                    <div class="start-recent-info">
                        <div class="start-recent-name">${app.name}</div>
                    </div>
                </div>
            `).join('') || '<div style="font-size:12px;opacity:0.4;padding:8px;">No apps found</div>'}
        `;
    };

    // ============================================================
    // APP USAGE TRACKER (for recommendations & recent)
    // ============================================================
    const AppUsageTracker = {
        key: 'hyos_app_usage',
        data: {},

        load() {
            try { this.data = JSON.parse(localStorage.getItem(this.key) || '{}'); } catch(e) { this.data = {}; }
        },
        save() {
            try { localStorage.setItem(this.key, JSON.stringify(this.data)); } catch(e) {}
        },
        track(appId, appName, appIcon, desc) {
            if (!appId) return;
            if (!this.data[appId]) this.data[appId] = { count: 0, name: appName, icon: appIcon, desc, lastUsed: 0, id: appId };
            this.data[appId].count++;
            this.data[appId].lastUsed = Date.now();
            this.data[appId].name = appName;
            this.data[appId].icon = appIcon || this.data[appId].icon;
            this.save();
        },
        getRecentApps(limit = 5) {
            return Object.values(this.data)
                .sort((a, b) => b.lastUsed - a.lastUsed)
                .slice(0, limit);
        },
        getMostUsed(limit = 5) {
            return Object.values(this.data)
                .sort((a, b) => b.count - a.count)
                .slice(0, limit);
        },
        getRecommendations() {
            const mostUsed = this.getMostUsed(3);
            const categories = {
                productivity: ['HyFiles', 'Notepad', 'Calendar', 'Task Manager'],
                creative: ['Viewer', 'App Builder', 'Wallpaper'],
                developer: ['App Builder', 'Notepad', 'Browser'],
                gaming: ['Game Bar'],
                social: ['Browser', 'Hyley']
            };
            const recs = [];
            const allInstalled = window.installedApps || [];

            mostUsed.forEach(app => {
                let cat = null;
                for (const [c, apps] of Object.entries(categories)) {
                    if (apps.some(a => app.name && app.name.toLowerCase().includes(a.toLowerCase()))) { cat = c; break; }
                }
                if (cat && categories[cat]) {
                    allInstalled.forEach(ia => {
                        if (ia.name !== app.name && categories[cat].some(a => ia.name.toLowerCase().includes(a.toLowerCase()))) {
                            if (!recs.find(r => r.name === ia.name)) {
                                recs.push({ ...ia, reason: `Because you use ${app.name}` });
                            }
                        }
                    });
                }
            });

            // Add store apps as recs if installed list is small
            if (recs.length === 0 && window.cloudApps) {
                cloudApps.slice(0, 3).forEach(a => recs.push({ ...a, reason: 'Popular in the store' }));
            }

            return recs.slice(0, 4);
        }
    };
    AppUsageTracker.load();

    // Override toggleApp to track usage
    const _origToggleApp = window.toggleApp;
    window.toggleApp = function(id) {
        // Track usage based on window id
        const nameMap = {
            'settings-win': 'Settings',
            'hyfiles-win': 'HyFiles',
            'notepad-win': 'Notepad',
            'builder-win': 'App Builder',
            'wallpaper-win': 'Wallpaper',
            'viewer-win': 'Viewer'
        };
        const name = nameMap[id] || id;
        const iconMap = { 'settings-win': '⚙️', 'hyfiles-win': '📁', 'notepad-win': '📝', 'builder-win': '🛠️', 'viewer-win': '🖼️' };
        AppUsageTracker.track(id, name, iconMap[id] || '📱', name);
        if (_origToggleApp) return _origToggleApp(id);
    };

    // Hyley App Recommendations
    function updateHyleyRecommendations() {
        const hyleySettings = JSON.parse(localStorage.getItem('hyley_settings') || '{}');
        if (!hyleySettings.appRecommendations) {
            document.getElementById('hyley-recommendations').style.display = 'none';
            return;
        }
        const recs = AppUsageTracker.getRecommendations();
        const container = document.getElementById('hyley-rec-list');
        const panel = document.getElementById('hyley-recommendations');
        
        if (recs.length === 0) {
            panel.style.display = 'none';
            return;
        }
        
        panel.style.display = 'block';
        container.innerHTML = recs.map(app => `
            <div class="app-rec-card" onclick="launchApp && launchApp('${app.id}')">
                <div class="app-rec-icon">${app.icon || '📱'}</div>
                <div class="app-rec-info">
                    <div class="app-rec-name">${app.name}</div>
                    <div class="app-rec-reason">${app.reason || 'Recommended for you'}</div>
                </div>
                <div class="app-rec-badge">Try it</div>
            </div>
        `).join('');
    }

    // Override toggleHyleySetting to handle new setting
    const _origToggleHyleySetting = window.toggleHyleySetting;
    window.toggleHyleySetting = function(key, el) {
        if (key === 'appRecommendations') {
            el.classList.toggle('active');
            const hyleySettings = JSON.parse(localStorage.getItem('hyley_settings') || '{}');
            hyleySettings.appRecommendations = el.classList.contains('active');
            localStorage.setItem('hyley_settings', JSON.stringify(hyleySettings));
            updateHyleyRecommendations();
            return;
        }
        if (_origToggleHyleySetting) _origToggleHyleySetting(key, el);
    };

    // Update recommendations whenever Hyley panel opens
    const _origToggleHyley = window.toggleHyley;
    window.toggleHyley = function(e) {
        if (_origToggleHyley) _origToggleHyley(e);
        setTimeout(updateHyleyRecommendations, 100);
    };

    // ============================================================
    // WIDGET SYSTEM
    // ============================================================
    const WidgetSystem = {
        widgets: [],
        draggingWidget: null,
        dragOffsetX: 0,
        dragOffsetY: 0,
        customWidgets: [],

        builtinWidgets: [
            {
                id: 'clock', name: 'Clock', size: 'small', icon: '🕐', desc: 'Live digital clock',
                preview: '<div style="text-align:center;padding:10px;"><div style="font-size:22px;font-weight:800;font-family:monospace;letter-spacing:-1px;color:#60a5fa;">12:34</div><div style="font-size:10px;opacity:0.5;margin-top:3px;">Wed, Feb 18</div></div>',
                render() {
                    const uid = 'wclk' + Date.now();
                    return `<div style="text-align:center;padding:10px;">
                        <div id="${uid}-t" style="font-size:28px;font-weight:800;font-family:monospace;letter-spacing:-1px;"></div>
                        <div id="${uid}-d" style="font-size:11px;opacity:0.5;margin-top:4px;"></div>
                    </div>`;
                },
                init(el) {
                    const t = el.querySelector('[id$="-t"]');
                    const d = el.querySelector('[id$="-d"]');
                    const upd = () => {
                        const now = new Date();
                        if (t) t.textContent = now.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
                        if (d) d.textContent = now.toLocaleDateString([], {weekday:'short', month:'short', day:'numeric'});
                    };
                    upd(); setInterval(upd, 1000);
                }
            },
            {
                id: 'apps', name: 'Quick Apps', size: 'medium', icon: '⚡', desc: 'Fast-launch shortcuts',
                preview: '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:8px;"><div style="text-align:center;font-size:20px;">📁</div><div style="text-align:center;font-size:20px;">📝</div><div style="text-align:center;font-size:20px;">🛠️</div><div style="text-align:center;font-size:20px;">⚙️</div></div>',
                render() {
                    return `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:8px;">
                        ${[['📁','Files',"toggleApp('hyfiles-win')"],['📝','Notes','Notepad.newFile()'],['🛠️','Maker','openMaker()'],['⚙️','Settings',"toggleApp('settings-win')"],['🧮','Calc','openCalculator()'],['⌨️','Term','openTerminal()'],['📸','Media','openMediaViewer()'],['🌐','Browser',"toggleApp('browser-win')"]].map(([icon,name,action]) => `
                            <div onclick="${action}" style="text-align:center;padding:8px 4px;border-radius:10px;cursor:pointer;transition:0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='transparent'">
                                <div style="font-size:22px;">${icon}</div>
                                <div style="font-size:9px;margin-top:3px;opacity:0.7;">${name}</div>
                            </div>`).join('')}
                    </div>`;
                }
            },
            {
                id: 'calendar', name: 'Mini Calendar', size: 'medium', icon: '📅', desc: 'Month calendar view',
                preview: '<div style="padding:10px;font-size:11px;"><div style="font-weight:700;margin-bottom:6px;">February 2026</div><div style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;opacity:0.7;"><span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span></div></div>',
                render() {
                    const now = new Date();
                    const year = now.getFullYear(), month = now.getMonth(), today = now.getDate();
                    const firstDay = new Date(year, month, 1).getDay();
                    const daysInMonth = new Date(year, month + 1, 0).getDate();
                    const monthName = now.toLocaleDateString([], {month:'long', year:'numeric'});
                    const days = ['Su','Mo','Tu','We','Th','Fr','Sa'];
                    let cells = '';
                    for (let i = 0; i < firstDay; i++) cells += '<span></span>';
                    for (let d = 1; d <= daysInMonth; d++) {
                        const isToday = d === today;
                        cells += `<span style="${isToday ? 'background:var(--blue-600);border-radius:50%;font-weight:700;' : ''}padding:1px 2px;text-align:center;">${d}</span>`;
                    }
                    return `<div style="padding:10px;font-size:11px;">
                        <div style="font-weight:700;margin-bottom:8px;">${monthName}</div>
                        <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:1px;text-align:center;">
                            ${days.map(d=>`<span style="opacity:0.5;font-weight:600;">${d}</span>`).join('')}
                            ${cells}
                        </div>
                    </div>`;
                }
            },
            {
                id: 'weather', name: 'Weather', size: 'small', icon: '⛅', desc: 'Current conditions',
                preview: '<div style="padding:12px;text-align:center;"><div style="font-size:28px;">⛅</div><div style="font-size:16px;font-weight:700;">72°F</div><div style="font-size:10px;opacity:0.5;">Partly Cloudy</div></div>',
                render() {
                    return `<div style="padding:12px;text-align:center;">
                        <div style="font-size:32px;">⛅</div>
                        <div style="font-size:18px;font-weight:700;">72°F</div>
                        <div style="font-size:11px;opacity:0.5;">Partly Cloudy</div>
                        <div style="font-size:10px;opacity:0.35;margin-top:4px;">H:78° L:65°</div>
                    </div>`;
                }
            },
            {
                id: 'usage', name: 'App Usage', size: 'large', icon: '📊', desc: 'Most-used apps chart',
                preview: '<div style="padding:10px;"><div style="font-size:11px;font-weight:700;margin-bottom:8px;">Most Used Apps</div><div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px;margin-bottom:6px;overflow:hidden;"><div style="width:80%;height:100%;background:var(--blue-600);border-radius:2px;"></div></div><div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;"><div style="width:50%;height:100%;background:#7c3aed;border-radius:2px;"></div></div></div>',
                render() {
                    const used = typeof AppUsageTracker !== 'undefined' ? AppUsageTracker.getMostUsed(4) : [];
                    if (!used.length) return '<div style="padding:16px;opacity:0.5;font-size:12px;text-align:center;">Open some apps first!</div>';
                    const max = used[0]?.count || 1;
                    return `<div style="padding:12px;">
                        <div style="font-size:12px;font-weight:700;margin-bottom:10px;">Most Used Apps</div>
                        ${used.map((a, i) => {
                            const colors = ['#2563eb','#7c3aed','#059669','#d97706'];
                            return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                                <span style="font-size:16px;width:24px;text-align:center;">${a.icon||'📱'}</span>
                                <div style="flex:1;">
                                    <div style="font-size:11px;font-weight:600;margin-bottom:3px;">${a.name}</div>
                                    <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;">
                                        <div style="height:100%;width:${(a.count/max*100).toFixed(0)}%;background:${colors[i]||colors[0]};border-radius:2px;transition:width 0.5s;"></div>
                                    </div>
                                </div>
                                <span style="font-size:10px;opacity:0.5;">${a.count}×</span>
                            </div>`;
                        }).join('')}
                    </div>`;
                }
            },
            {
                id: 'notes', name: 'Sticky Note', size: 'small', icon: '📌', desc: 'Persistent note pad',
                preview: '<div style="padding:10px;font-size:11px;opacity:0.7;font-style:italic;">Write a note here…</div>',
                render() {
                    const saved = localStorage.getItem('hyos_sticky') || '';
                    return `<div style="padding:8px;">
                        <textarea placeholder="Write a note…" style="width:100%;background:transparent;border:none;color:white;font-size:12px;resize:none;outline:none;height:80px;font-family:inherit;line-height:1.5;" oninput="localStorage.setItem('hyos_sticky',this.value)">${saved}</textarea>
                    </div>`;
                }
            },
            {
                id: 'system', name: 'System Info', size: 'medium', icon: '💻', desc: 'CPU, memory & uptime',
                preview: '<div style="padding:10px;font-size:11px;"><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="opacity:0.5;">User</span><span style="color:#60a5fa;">guest</span></div><div style="display:flex;justify-content:space-between;"><span style="opacity:0.5;">Uptime</span><span style="color:#60a5fa;">5m</span></div></div>',
                render() {
                    const uptime = Math.floor(performance.now() / 1000);
                    const m = Math.floor(uptime / 60), s = uptime % 60;
                    const memUsed = Math.round((performance.memory?.usedJSHeapSize || 0) / 1024 / 1024);
                    const memTotal = Math.round((performance.memory?.totalJSHeapSize || 0) / 1024 / 1024);
                    return `<div style="padding:12px;font-size:12px;">
                        ${[
                            ['User', window.user || 'guest', '#60a5fa'],
                            ['OS', 'HyOS HS 2.0', '#a78bfa'],
                            ['Uptime', `${m}m ${s}s`, '#34d399'],
                            ['Memory', memTotal ? `${memUsed}/${memTotal}MB` : 'N/A', '#fb923c'],
                            ['Apps Open', document.querySelectorAll('.window[style*="flex"]').length, '#f472b6'],
                        ].map(([k,v,c]) => `<div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                            <span style="opacity:0.5;">${k}</span>
                            <span style="color:${c};font-weight:600;">${v}</span>
                        </div>`).join('')}
                    </div>`;
                }
            },
        ],

        load() {
            try {
                this.widgets = JSON.parse(localStorage.getItem('hyos_placed_widgets') || '[]');
                this.customWidgets = JSON.parse(localStorage.getItem('hyos_custom_widgets') || '[]');
            } catch(e) { this.widgets = []; this.customWidgets = []; }
        },
        save() {
            localStorage.setItem('hyos_placed_widgets', JSON.stringify(
                this.widgets.map(w => ({ id: w.id, widgetId: w.widgetId, x: w.x, y: w.y, name: w.name }))
            ));
            localStorage.setItem('hyos_custom_widgets', JSON.stringify(this.customWidgets));
        },
        renderAll() {
            const overlay = document.getElementById('widgets-overlay');
            if (!overlay) return;
            overlay.innerHTML = '';
            this.widgets.forEach(w => this.renderWidget(w, overlay));
        },
        renderWidget(w, overlay) {
            const def = [...this.builtinWidgets, ...this.customWidgets].find(d => d.id === w.widgetId);
            if (!def) return;
            const sizeMap = { small: [175, 120], medium: [310, 165], large: [420, 210], wide: [500, 135] };
            const [pw] = sizeMap[def.size] || [220, 155];
            const el = document.createElement('div');
            el.className = 'desktop-widget';
            el.id = `widget-${w.id}`;
            el.style.cssText = `position:absolute;left:${w.x}px;top:${w.y}px;width:${pw}px;background:rgba(10,15,28,0.88);border:1px solid rgba(255,255,255,0.09);border-radius:14px;backdrop-filter:blur(16px);z-index:50;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.4);`;
            el.innerHTML = `
                <div class="widget-header" style="padding:8px 12px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,0.07);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;cursor:move;user-select:none;touch-action:none;">
                    <span>${def.name}</span>
                    <button onclick="WidgetSystem.removeWidget('${w.id}')" style="background:transparent;border:none;color:rgba(255,255,255,0.4);cursor:pointer;font-size:14px;line-height:1;padding:0 2px;" onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='rgba(255,255,255,0.4)'">✕</button>
                </div>
                <div class="widget-body" style="color:#fff;">${def.render()}</div>
            `;

            // Mouse drag
            const header = el.querySelector('.widget-header');
            header.addEventListener('mousedown', (e) => {
                if (e.target.tagName === 'BUTTON') return;
                this.draggingWidget = el;
                this.dragOffsetX = e.clientX - el.offsetLeft;
                this.dragOffsetY = e.clientY - el.offsetTop;
                el.style.zIndex = 999;
                el.style.transition = 'none';
                e.preventDefault();
            });

            // Touch drag
            header.addEventListener('touchstart', (e) => {
                if (e.target.tagName === 'BUTTON') return;
                const touch = e.touches[0];
                this.draggingWidget = el;
                this.dragOffsetX = touch.clientX - el.offsetLeft;
                this.dragOffsetY = touch.clientY - el.offsetTop;
                el.style.zIndex = 999;
                el.style.transition = 'none';
                e.preventDefault();
            }, { passive: false });

            overlay.appendChild(el);
            if (def.init) setTimeout(() => def.init(el), 50);
        },
        removeWidget(id) {
            this.widgets = this.widgets.filter(w => w.id !== id);
            this.save();
            const el = document.getElementById(`widget-${id}`);
            if (el) {
                el.style.transition = 'opacity 0.2s, transform 0.2s';
                el.style.opacity = '0';
                el.style.transform = 'scale(0.9)';
                setTimeout(() => el.remove(), 200);
            }
        },
        addWidget(widgetId) {
            const def = [...this.builtinWidgets, ...this.customWidgets].find(d => d.id === widgetId);
            if (!def) { notify('Widget Error', 'Widget definition not found'); return; }
            const w = {
                id: Date.now().toString(),
                widgetId,
                x: Math.round(80 + Math.random() * 200),
                y: Math.round(80 + Math.random() * 120),
                name: def.name
            };
            this.widgets.push(w);
            this.save();
            const overlay = document.getElementById('widgets-overlay');
            if (overlay) this.renderWidget(w, overlay);
            notify('Widget Added', `${def.name} placed on desktop — drag to reposition`);
            // Refresh picker active states without closing
            if (document.getElementById('widget-picker').classList.contains('open')) {
                openWidgetPicker();
            }
        },
        addCustomWidget(widget) {
            if (!this.customWidgets.find(w => w.id === widget.id)) {
                this.customWidgets.push(widget);
                this.save();
            }
        }
    };
    WidgetSystem.load();

    // Mouse drag move/end
    document.addEventListener('mousemove', (e) => {
        if (!WidgetSystem.draggingWidget) return;
        const x = e.clientX - WidgetSystem.dragOffsetX;
        const y = e.clientY - WidgetSystem.dragOffsetY;
        const maxX = window.innerWidth - WidgetSystem.draggingWidget.offsetWidth;
        const maxY = window.innerHeight - WidgetSystem.draggingWidget.offsetHeight - 60;
        WidgetSystem.draggingWidget.style.left = Math.max(0, Math.min(maxX, x)) + 'px';
        WidgetSystem.draggingWidget.style.top = Math.max(40, Math.min(maxY, y)) + 'px';
    });
    document.addEventListener('mouseup', () => {
        if (!WidgetSystem.draggingWidget) return;
        const el = WidgetSystem.draggingWidget;
        const wid = el.id.replace('widget-', '');
        const w = WidgetSystem.widgets.find(w => w.id === wid);
        if (w) { w.x = el.offsetLeft; w.y = el.offsetTop; WidgetSystem.save(); }
        el.style.zIndex = '';
        el.style.transition = '';
        WidgetSystem.draggingWidget = null;
    });

    // Touch drag move/end
    document.addEventListener('touchmove', (e) => {
        if (!WidgetSystem.draggingWidget) return;
        const touch = e.touches[0];
        const x = touch.clientX - WidgetSystem.dragOffsetX;
        const y = touch.clientY - WidgetSystem.dragOffsetY;
        const maxX = window.innerWidth - WidgetSystem.draggingWidget.offsetWidth;
        const maxY = window.innerHeight - WidgetSystem.draggingWidget.offsetHeight - 60;
        WidgetSystem.draggingWidget.style.left = Math.max(0, Math.min(maxX, x)) + 'px';
        WidgetSystem.draggingWidget.style.top = Math.max(40, Math.min(maxY, y)) + 'px';
        e.preventDefault();
    }, { passive: false });
    document.addEventListener('touchend', () => {
        if (!WidgetSystem.draggingWidget) return;
        const el = WidgetSystem.draggingWidget;
        const wid = el.id.replace('widget-', '');
        const w = WidgetSystem.widgets.find(w => w.id === wid);
        if (w) { w.x = el.offsetLeft; w.y = el.offsetTop; WidgetSystem.save(); }
        el.style.zIndex = '';
        el.style.transition = '';
        WidgetSystem.draggingWidget = null;
    });

    window.openWidgetPicker = function() {
        const picker = document.getElementById('widget-picker');
        const grid = document.getElementById('widget-picker-grid');
        const cm = document.getElementById('context-menu');
        if (cm) cm.style.display = 'none';

        const allWidgets = [...WidgetSystem.builtinWidgets, ...WidgetSystem.customWidgets];
        const activeIds = new Set(WidgetSystem.widgets.map(w => w.widgetId));

        grid.innerHTML = allWidgets.map(w => {
            const isActive = activeIds.has(w.id);
            return `
            <div class="widget-card" onclick="WidgetSystem.addWidget('${w.id}')" style="display:flex;flex-direction:column;position:relative;${isActive ? 'border-color:rgba(37,99,235,0.5);background:rgba(37,99,235,0.1);' : ''}">
                ${isActive ? `<div style="position:absolute;top:8px;right:8px;background:var(--blue-600);border-radius:50%;width:18px;height:18px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;pointer-events:none;">✓</div>` : ''}
                <div style="background:rgba(0,0,0,0.3);border-radius:10px;margin-bottom:10px;min-height:70px;overflow:hidden;border:1px solid rgba(255,255,255,0.06);">
                    ${w.preview || `<div style="display:flex;align-items:center;justify-content:center;height:70px;font-size:32px;">${w.icon}</div>`}
                </div>
                <div style="font-size:20px;margin-bottom:4px;">${w.icon}</div>
                <div style="font-size:13px;font-weight:700;">${w.name}</div>
                <div style="font-size:11px;opacity:0.45;margin-top:3px;">${w.desc || ''}</div>
                <div style="margin-top:10px;width:100%;background:${isActive ? 'rgba(37,99,235,0.4)' : 'var(--blue-600)'};border:none;padding:8px;border-radius:8px;color:#fff;font-size:12px;font-weight:700;text-align:center;pointer-events:none;">${isActive ? '+ Add Another' : '+ Add'}</div>
            </div>`;
        }).join('');

        picker.classList.add('open');
    };

    window.closeWidgetPicker = function() {
        const picker = document.getElementById('widget-picker');
        if (picker) picker.classList.remove('open');
    };

    // ===== WIDGETLAND — Full Screen Widget Hub =====
    let widgetlandCurrentTab = 'all';

    window.openWidgetland = function() {
        const wl = document.getElementById('widgetland');
        if (!wl) return;
        wl.style.display = 'flex';
        // Hide other menus
        const cm = document.getElementById('context-menu');
        if (cm) cm.style.display = 'none';
        const cc = document.getElementById('control-center');
        if (cc) cc.style.right = '-350px';
        widgetlandCurrentTab = 'all';
        renderWidgetland('all');
    };

    window.closeWidgetland = function() {
        const wl = document.getElementById('widgetland');
        if (wl) wl.style.display = 'none';
    };

    window.switchWidgetlandTab = function(tab) {
        widgetlandCurrentTab = tab;
        const tabs = ['all','active','custom'];
        tabs.forEach(t => {
            const btn = document.getElementById('wl-tab-' + t);
            if (btn) {
                btn.style.color = t === tab ? '#0ea5e9' : 'rgba(255,255,255,0.35)';
                btn.style.borderBottom = t === tab ? '2px solid #0ea5e9' : '2px solid transparent';
            }
        });
        renderWidgetland(tab);
    };

    function renderWidgetland(tab) {
        const grid = document.getElementById('widgetland-grid');
        const empty = document.getElementById('widgetland-empty');
        if (!grid) return;

        const allWidgets = [...WidgetSystem.builtinWidgets, ...WidgetSystem.customWidgets];
        const activeIds = new Set(WidgetSystem.widgets.map(w => w.widgetId));

        let widgetsToShow = allWidgets;
        if (tab === 'active') widgetsToShow = allWidgets.filter(w => activeIds.has(w.id));
        if (tab === 'custom') widgetsToShow = WidgetSystem.customWidgets;

        if (widgetsToShow.length === 0) {
            grid.innerHTML = '';
            if (empty) empty.style.display = 'block';
            return;
        }
        if (empty) empty.style.display = 'none';

        grid.innerHTML = widgetsToShow.map(w => {
            const isActive = activeIds.has(w.id);
            const activeCount = WidgetSystem.widgets.filter(aw => aw.widgetId === w.id).length;
            return `
            <div style="background:rgba(255,255,255,0.03);border:1px solid ${isActive ? 'rgba(14,165,233,0.4)' : 'rgba(255,255,255,0.08)'};border-radius:18px;overflow:hidden;transition:0.2s;cursor:default;" onmouseover="this.style.borderColor='rgba(14,165,233,0.5)';this.style.background='rgba(14,165,233,0.05)'" onmouseout="this.style.borderColor='${isActive ? 'rgba(14,165,233,0.4)' : 'rgba(255,255,255,0.08)'}';this.style.background='rgba(255,255,255,0.03)'">
                <!-- Preview -->
                <div style="background:rgba(0,0,0,0.4);min-height:100px;overflow:hidden;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;position:relative;">
                    <div style="width:100%;color:#fff;">${w.preview || `<div style="text-align:center;padding:20px;font-size:40px;">${w.icon}</div>`}</div>
                    ${isActive ? `<div style="position:absolute;top:10px;right:10px;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border-radius:20px;padding:3px 10px;font-size:10px;font-weight:800;color:white;letter-spacing:0.5px;">✓ ACTIVE${activeCount > 1 ? ' ×'+activeCount : ''}</div>` : ''}
                </div>
                <!-- Info & Actions -->
                <div style="padding:14px;">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:12px;">
                        <div>
                            <div style="font-size:15px;font-weight:700;font-family:Outfit,sans-serif;">${w.icon} ${w.name}</div>
                            <div style="font-size:11px;opacity:0.45;margin-top:3px;">${w.desc || 'Desktop widget'} · ${w.size || 'small'}</div>
                        </div>
                    </div>
                    <div style="display:flex;gap:8px;">
                        <button onclick="widgetlandAdd('${w.id}')" style="flex:1;padding:10px;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;border-radius:10px;color:white;font-size:12px;font-weight:700;cursor:pointer;font-family:Outfit,sans-serif;transition:0.15s;-webkit-tap-highlight-color:transparent;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'" ontouchstart="" >+ Add to Desktop</button>
                        ${isActive ? `<button onclick="widgetlandRemoveAll('${w.id}')" style="padding:10px 12px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);border-radius:10px;color:#f87171;font-size:12px;font-weight:700;cursor:pointer;transition:0.15s;-webkit-tap-highlight-color:transparent;" onmouseover="this.style.background='rgba(239,68,68,0.22)'" onmouseout="this.style.background='rgba(239,68,68,0.12)'">Remove</button>` : ''}
                    </div>
                </div>
            </div>`;
        }).join('');
    }

    window.widgetlandAdd = function(widgetId) {
        // Mobile-safe widget placement: use safe fixed positions, stacked
        const existingCount = WidgetSystem.widgets.length;
        const isMobile = window.innerWidth < 768;
        let x, y;
        if (isMobile) {
            // Stack widgets from top-left in a grid pattern
            const col = existingCount % 2;
            const row = Math.floor(existingCount / 2);
            x = 10 + col * (Math.min(window.innerWidth / 2 - 15, 180));
            y = 50 + row * 160;
            // If too far down, wrap back
            if (y > window.innerHeight - 220) { x = 10; y = 50; }
        } else {
            x = 80 + (existingCount % 4) * 50 + Math.random() * 40;
            y = 60 + Math.floor(existingCount / 4) * 40 + Math.random() * 40;
        }
        
        const def = [...WidgetSystem.builtinWidgets, ...WidgetSystem.customWidgets].find(d => d.id === widgetId);
        if (!def) return;
        const w = {
            id: Date.now().toString(),
            widgetId,
            x: Math.max(0, Math.min(x, window.innerWidth - 200)),
            y: Math.max(44, Math.min(y, window.innerHeight - 200)),
            name: def.name
        };
        WidgetSystem.widgets.push(w);
        WidgetSystem.save();
        const overlay = document.getElementById('widgets-overlay');
        if (overlay) WidgetSystem.renderWidget(w, overlay);
        notify('Widget Added', `${def.name} added to desktop!`);
        // Refresh widgetland
        renderWidgetland(widgetlandCurrentTab);
    };

    window.widgetlandRemoveAll = function(widgetId) {
        const toRemove = WidgetSystem.widgets.filter(w => w.widgetId === widgetId);
        toRemove.forEach(w => WidgetSystem.removeWidget(w.id));
        setTimeout(() => renderWidgetland(widgetlandCurrentTab), 250);
    };

    // Also allow Widgetland to be opened from context menu
    // (context menu "Widgets" already calls openWidgetPicker — redirect it)
    const _origOpenWidgetPicker = window.openWidgetPicker;
    window.openWidgetPicker = function() {
        openWidgetland();
    };

    // Initialize widgets on desktop after OS starts
    const _origStartOS = window.startOS;
    window.startOS = function() {
        if (_origStartOS) _origStartOS();
        setTimeout(() => {
            WidgetSystem.renderAll();
            buildStartMenu();
        }, 800);
    };

    // ============================================================
    // APP BUILDER WIDGET TAB ENHANCEMENT
    // ============================================================
    const _origBuilderSwitchTab = null;
    // Extend AppBuilder.switchTab to handle 'widget' tab
    if (window.AppBuilder) {
        const origSwitch = AppBuilder.switchTab.bind(AppBuilder);
        AppBuilder.switchTab = function(tab) {
            origSwitch(tab);
            const widgetContent = document.getElementById('builder-widget-content');
            const widgetTab = document.getElementById('builder-tab-widget');
            if (tab === 'widget') {
                // Show widget content, hide others
                document.querySelectorAll('.builder-tab-content').forEach(c => c.style.display = 'none');
                widgetContent.style.display = 'flex';
                document.querySelectorAll('.builder-tab').forEach(t => {
                    t.style.background = '#0f172a';
                    t.style.color = '#94a3b8';
                    t.style.border = '1px solid transparent';
                    t.style.borderBottom = 'none';
                });
                widgetTab.style.background = '#1e293b';
                widgetTab.style.color = '#fff';
                widgetTab.style.border = '1px solid #334155';
                widgetTab.style.borderBottom = 'none';
            } else {
                if (widgetContent) widgetContent.style.display = 'none';
            }
        };

        AppBuilder.widgetComponents = [];

        AppBuilder.startDragComp = function(e) {
            e.dataTransfer.setData('componentType', e.target.dataset.type || e.target.closest('[data-type]')?.dataset.type);
        };

        AppBuilder.dropComp = function(e) {
            e.preventDefault();
            const type = e.dataTransfer.getData('componentType');
            if (!type) return;
            const canvas = document.getElementById('widget-canvas');
            const placeholder = document.getElementById('widget-canvas-placeholder');
            if (placeholder) placeholder.style.display = 'none';
            
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const compId = `comp-${Date.now()}`;
            const comp = { id: compId, type, x, y, props: { text: type === 'text' ? 'Text' : '', color: '#ffffff', size: '14' } };
            AppBuilder.widgetComponents.push(comp);
            AppBuilder.renderWidgetComponent(comp, canvas);
            AppBuilder.updateWidgetCode();
        };

        AppBuilder.renderWidgetComponent = function(comp, canvas) {
            const el = document.createElement('div');
            el.id = comp.id;
            el.className = 'widget-component';
            el.style.cssText = `position:absolute;left:${comp.x}px;top:${comp.y}px;padding:6px;border:1px dashed rgba(255,255,255,0.2);border-radius:6px;cursor:move;min-width:60px;`;
            
            const templates = {
                text: `<span contenteditable="true" style="font-size:14px;color:white;outline:none;" onblur="AppBuilder.updateCompProp('${comp.id}','text',this.textContent)">Text</span>`,
                number: `<span contenteditable="true" style="font-size:24px;font-weight:800;color:white;outline:none;font-family:monospace;">42</span>`,
                clock: `<span style="font-size:20px;font-weight:700;color:white;font-family:monospace;" id="${comp.id}-time">12:00</span>`,
                progress: `<div style="width:120px;height:8px;background:rgba(255,255,255,0.1);border-radius:4px;"><div style="width:60%;height:100%;background:var(--blue-600);border-radius:4px;"></div></div>`,
                button: `<button style="padding:6px 12px;background:var(--blue-600);border:none;border-radius:6px;color:white;cursor:pointer;font-size:12px;">Button</button>`,
                divider: `<div style="width:100px;height:1px;background:rgba(255,255,255,0.2);"></div>`,
                icon: `<span style="font-size:28px;">⭐</span>`,
                image: `<div style="width:60px;height:40px;background:rgba(255,255,255,0.1);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:20px;">🖼</div>`,
            };
            
            el.innerHTML = templates[comp.type] || `<span style="color:white">${comp.type}</span>`;
            
            // Make draggable within canvas (mouse)
            let isDragging = false, ox = 0, oy = 0;
            el.addEventListener('mousedown', (e) => {
                if (e.target.isContentEditable) return;
                isDragging = true;
                ox = e.clientX - el.offsetLeft;
                oy = e.clientY - el.offsetTop;
                e.stopPropagation();
            });
            document.addEventListener('mousemove', (e) => {
                if (!isDragging) return;
                el.style.left = (e.clientX - ox) + 'px';
                el.style.top = (e.clientY - oy) + 'px';
            });
            document.addEventListener('mouseup', () => { isDragging = false; });

            // Touch drag support
            el.addEventListener('touchstart', (e) => {
                if (e.target.isContentEditable) return;
                isDragging = true;
                const t = e.touches[0];
                ox = t.clientX - el.offsetLeft;
                oy = t.clientY - el.offsetTop;
                e.stopPropagation();
            }, { passive: false });
            document.addEventListener('touchmove', (e) => {
                if (!isDragging) return;
                const t = e.touches[0];
                el.style.left = (t.clientX - ox) + 'px';
                el.style.top = (t.clientY - oy) + 'px';
                e.preventDefault();
            }, { passive: false });
            document.addEventListener('touchend', () => { isDragging = false; });
            
            canvas.appendChild(el);
        };

        AppBuilder.clearWidgetCanvas = function() {
            AppBuilder.widgetComponents = [];
            const canvas = document.getElementById('widget-canvas');
            canvas.querySelectorAll('.widget-component').forEach(el => el.remove());
            const placeholder = document.getElementById('widget-canvas-placeholder');
            if (placeholder) placeholder.style.display = 'flex';
            document.getElementById('widget-code-output').textContent = '// Add components to generate widget code';
        };

        AppBuilder.updateWidgetCode = function() {
            const comps = AppBuilder.widgetComponents;
            const code = `// Generated Widget Code
const widgetHTML = \`
  <div style="position:relative;width:100%;height:100%;">
    ${comps.map(c => {
        const templates = {
            text: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:14px;color:white;">Text</span>`,
            number: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:24px;font-weight:800;color:white;font-family:monospace;">42</span>`,
            clock: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:20px;font-weight:700;color:white;font-family:monospace;">{time}</span>`,
            progress: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:120px;height:8px;background:rgba(255,255,255,0.1);border-radius:4px;"><div style="width:60%;height:100%;background:#2563eb;border-radius:4px;"></div></div>`,
            button: `<button style="position:absolute;left:${c.x}px;top:${c.y}px;padding:6px 12px;background:#2563eb;border:none;border-radius:6px;color:white;cursor:pointer;">Button</button>`,
            divider: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:100px;height:1px;background:rgba(255,255,255,0.2);"></div>`,
            icon: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:28px;">⭐</span>`,
        };
        return templates[c.type] || '';
    }).join('\n    ')}
  </div>
\`;`;
            document.getElementById('widget-code-output').textContent = code;
        };

        AppBuilder.previewWidget = function() {
            const panel = document.getElementById('widget-preview-panel');
            const frame = document.getElementById('widget-preview-frame');
            AppBuilder.updateWidgetCode();
            panel.style.display = 'block';
            const sizeVal = document.getElementById('widget-size-select').value;
            const sizeMap = { small: [160,100], medium: [300,150], large: [400,200], wide: [500,130] };
            const [w,h] = sizeMap[sizeVal] || [300,150];
            frame.style.width = w+'px';
            frame.style.height = h+'px';
            frame.innerHTML = '<div style="position:relative;width:100%;height:100%;">' + 
                AppBuilder.widgetComponents.map(c => {
                    const templates = {
                        text: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:14px;color:white;">Text</span>`,
                        number: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:24px;font-weight:800;color:white;font-family:monospace;">42</span>`,
                        clock: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:20px;font-weight:700;color:white;font-family:monospace;">${new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span>`,
                        progress: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:120px;height:8px;background:rgba(255,255,255,0.1);border-radius:4px;"><div style="width:60%;height:100%;background:#2563eb;border-radius:4px;"></div></div>`,
                        button: `<button style="position:absolute;left:${c.x}px;top:${c.y}px;padding:6px 12px;background:#2563eb;border:none;border-radius:6px;color:white;cursor:pointer;font-size:12px;">Button</button>`,
                        divider: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:100px;height:1px;background:rgba(255,255,255,0.2);"></div>`,
                        icon: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:28px;">⭐</span>`,
                    };
                    return templates[c.type] || '';
                }).join('') + '</div>';
        };

        AppBuilder.saveWidget = function() {
            const name = document.getElementById('widget-name-input').value || 'Custom Widget';
            const sizeVal = document.getElementById('widget-size-select').value;
            const sizeMap = { small: '150×100', medium: '300×150', large: '400×200', wide: '500×130' };
            const comps = [...AppBuilder.widgetComponents];
            
            const widgetDef = {
                id: 'custom-' + Date.now(),
                name,
                size: sizeVal,
                icon: '🔧',
                desc: sizeMap[sizeVal] || 'Custom',
                isCustom: true,
                render: function() {
                    return '<div style="position:relative;width:100%;height:100%;min-height:80px;">' + 
                        comps.map(c => {
                            const t = {
                                text: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:14px;color:white;">Text</span>`,
                                number: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:24px;font-weight:800;color:white;font-family:monospace;">42</span>`,
                                clock: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:20px;font-weight:700;color:white;font-family:monospace;"></span>`,
                                progress: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:120px;height:8px;background:rgba(255,255,255,0.1);border-radius:4px;"><div style="width:60%;height:100%;background:#2563eb;border-radius:4px;"></div></div>`,
                                button: `<button style="position:absolute;left:${c.x}px;top:${c.y}px;padding:6px 12px;background:#2563eb;border:none;border-radius:6px;color:white;cursor:pointer;font-size:12px;">Button</button>`,
                                divider: `<div style="position:absolute;left:${c.x}px;top:${c.y}px;width:100px;height:1px;background:rgba(255,255,255,0.2);"></div>`,
                                icon: `<span style="position:absolute;left:${c.x}px;top:${c.y}px;font-size:28px;">⭐</span>`,
                            };
                            return t[c.type] || '';
                        }).join('') + '</div>';
                }
            };
            
            // Store serialized version
            const serialized = { ...widgetDef, renderStr: widgetDef.render.toString() };
            WidgetSystem.addCustomWidget(serialized);
            WidgetSystem.builtinWidgets.push(widgetDef); // Add to runtime list
            
            notify('Widget Saved', `"${name}" widget is ready to place on your desktop!`);
            AppBuilder.clearWidgetCanvas();
        };

        AppBuilder.copyWidgetCode = function() {
            navigator.clipboard.writeText(document.getElementById('widget-code-output').textContent);
            notify('Copied', 'Widget code copied to clipboard');
        };
    }

    // Also update published apps to offer widget placement
    const _origPublishApp = window.publishApp;
    if (_origPublishApp) {
        window.publishApp = function(...args) {
            _origPublishApp(...args);
            // When app is published with a widget, it becomes available in widget picker
        };
    }

    // Initialize on load
    setTimeout(() => {
        // widget system initialized via startOS
    }, 1500);

    // ============================================================
    // GLOBAL SEARCH SYSTEM
    // ============================================================
    const GlobalSearch = {
        mode: 'all',
        results: [],
        selectedIndex: -1,
        searchTimeout: null,

        // All searchable settings entries
        settingsIndex: [
            { name: 'Display Settings', desc: 'Wallpaper, theme, dark mode', action: "toggleApp('settings-win');switchSettingsTab('display')", tab: 'display' },
            { name: 'Personalization', desc: 'Accent color, profile, genre', action: "toggleApp('settings-win');switchSettingsTab('personalization')", tab: 'personalization' },
            { name: 'Privacy & Security', desc: 'Permissions, password lock', action: "toggleApp('settings-win');switchSettingsTab('privacy')", tab: 'privacy' },
            { name: 'Sound Settings', desc: 'Volume, notification sounds', action: "toggleApp('settings-win');switchSettingsTab('sound')", tab: 'sound' },
            { name: 'Network & Internet', desc: 'Cloud sync, offline mode', action: "toggleApp('settings-win');switchSettingsTab('network')", tab: 'network' },
            { name: 'Notifications', desc: 'Do not disturb, badge settings', action: "toggleApp('settings-win');switchSettingsTab('notifications')", tab: 'notifications' },
            { name: 'Gaming Settings', desc: 'Game bar, recording, FPS overlay', action: "toggleApp('settings-win');switchSettingsTab('gaming')", tab: 'gaming' },
            { name: 'Account Settings', desc: 'Username, stay logged in', action: "toggleApp('settings-win');switchSettingsTab('account')", tab: 'account' },
            { name: 'Storage', desc: 'Local storage, cache management', action: "toggleApp('settings-win');switchSettingsTab('storage')", tab: 'storage' },
            { name: 'About HyOS HS', desc: 'Version, system info, Firebase', action: "toggleApp('settings-win');switchSettingsTab('about')", tab: 'about' },
            { name: 'Accessibility', desc: 'High contrast, large text, reduce motion', action: "toggleApp('settings-win');switchSettingsTab('accessibility')", tab: 'accessibility' },
            { name: 'System Updates', desc: 'Auto updates, update history', action: "toggleApp('settings-win');switchSettingsTab('updates')", tab: 'updates' },
        ],

        // Quick commands
        commands: [
            { name: 'Lock Screen', desc: 'Lock and require password', action: 'lockScreen()', icon: 'lock' },
            { name: 'Take Screenshot', desc: 'Capture the desktop', action: 'takeScreenshot()', icon: 'camera' },
            { name: 'New Note', desc: 'Open a blank Notepad', action: 'Notepad.newFile()', icon: 'note' },
            { name: 'Change Wallpaper', desc: 'Open wallpaper picker', action: 'openWallpaperPicker()', icon: 'image' },
            { name: 'Open App Store', desc: 'Browse & install apps', action: "openAppStore()", icon: 'store' },
            { name: 'Open File Manager', desc: 'Browse your files', action: "toggleApp('hyfiles-win')", icon: 'folder' },
            { name: 'App Builder', desc: 'Create a new app', action: "openMaker()", icon: 'tool' },
            { name: 'Calculator', desc: 'Perform calculations', action: "openCalculator()", icon: 'tool' },
            { name: 'Terminal', desc: 'Command line interface', action: "openTerminal()", icon: 'tool' },
            { name: 'Media Library', desc: 'Screenshots & recordings', action: "openMediaViewer()", icon: 'image' },
            { name: 'Widgets', desc: 'Place a widget on desktop', action: 'openWidgetPicker()', icon: 'widget' },
            { name: 'Cloud Hub', desc: 'Sync, backup, cloud storage', action: 'toggleCloudHub()', icon: 'cloud' },
            { name: 'Restart System', desc: 'Reboot HyOS HS', action: 'restartSystem()', icon: 'restart' },
            { name: 'Log Off', desc: 'Return to login screen', action: 'logOff()', icon: 'logout' },
        ],

        webSuggestions: [
            'How to build a website', 'Best productivity apps 2025', 'JavaScript tutorials',
            'CSS animations guide', 'HyOS HS documentation', 'App development tips',
            'Design inspiration', 'Free stock photos', 'Color palette generator',
        ],

        open() {
            const overlay = document.getElementById('global-search-overlay');
            const input = document.getElementById('global-search-big');
            const smallInput = document.getElementById('global-search-input');
            overlay.style.display = 'block';
            this.selectedIndex = -1;
            setTimeout(() => { input.focus(); input.value = smallInput.value || ''; if(input.value) this.search(input.value); else this.showDefault(); }, 50);
        },

        close() {
            document.getElementById('global-search-overlay').style.display = 'none';
            document.getElementById('global-search-input').value = '';
            document.getElementById('global-search-big').value = '';
            this.selectedIndex = -1;
        },

        showDefault() {
            const area = document.getElementById('search-results-area');
            const recentApps = AppUsageTracker.getRecentApps(4);
            const suggestions = this.webSuggestions.slice(0, 8);
            area.innerHTML = `
                ${recentApps.length ? `
                    <div class="search-section-title">Recent</div>
                    ${recentApps.map((a,i) => `
                        <div class="search-result-item" onclick="${a.id ? `toggleApp('${a.id}')` : 'void 0'};closeGlobalSearch()" data-idx="${i}">
                            <div class="search-result-icon app-icon">${a.icon||'📱'}</div>
                            <div class="search-result-info">
                                <div class="search-result-name">${a.name}</div>
                                <div class="search-result-desc">Used ${a.count} time${a.count!==1?'s':''}</div>
                            </div>
                            <span class="search-result-badge badge-app">App</span>
                        </div>
                    `).join('')}
                ` : ''}
                <div class="search-section-title">Quick Commands</div>
                ${this.commands.slice(0,5).map((c,i) => `
                    <div class="search-result-item" onclick="${c.action};closeGlobalSearch()" data-idx="${recentApps.length+i}">
                        <div class="search-result-icon cmd-icon">${this.getCmdIcon(c.icon)}</div>
                        <div class="search-result-info">
                            <div class="search-result-name">${c.name}</div>
                            <div class="search-result-desc">${c.desc}</div>
                        </div>
                        <span class="search-result-badge badge-cmd">Action</span>
                    </div>
                `).join('')}
                <div class="search-section-title">Search Suggestions</div>
                <div class="search-suggestions">
                    ${suggestions.map(s => `<div class="search-suggestion-chip" onclick="document.getElementById('global-search-big').value='${s}';updateGlobalSearch('${s}')">${s}</div>`).join('')}
                </div>
            `;
            document.getElementById('search-result-count').textContent = '';
        },

        search(q) {
            if (!q || !q.trim()) { this.showDefault(); return; }
            const query = q.toLowerCase().trim();
            document.getElementById('search-spinner').style.display = 'flex';

            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                this.results = [];
                const mode = this.mode;

                // Apps search
                if (mode === 'all' || mode === 'apps') {
                    const systemApps = [
                        { name: 'HyFiles', desc: 'File manager', icon: '📁', action: "toggleApp('hyfiles-win')" },
                        { name: 'Notepad', desc: 'Text editor', icon: '📝', action: 'Notepad.newFile()' },
                        { name: 'App Builder', desc: 'Create apps', icon: '🛠️', action: 'openMaker()' },
                        { name: 'Settings', desc: 'System settings', icon: '⚙️', action: "toggleApp('settings-win')" },
                        { name: 'Wallpaper', desc: 'Change wallpaper', icon: '🖼️', action: 'openWallpaperPicker()' },
                        { name: 'Calculator', desc: 'Basic & scientific calculator', icon: '🧮', action: 'openCalculator()' },
                        { name: 'Terminal', desc: 'Command line interface', icon: '⌨️', action: 'openTerminal()' },
                        { name: 'Media Library', desc: 'Screenshots & screen recordings', icon: '📸', action: 'openMediaViewer()' },
                        { name: 'Cloud Hub', desc: 'Sync & backup', icon: '☁️', action: 'toggleCloudHub()' },
                        { name: 'People', desc: 'Users, friends, chat & requests', icon: '👥', action: 'openHyPeople()' },
                    ];
                    const allApps = [...systemApps, ...(window.installedApps||[]).map(a => ({ name: a.name, desc: a.description || 'Installed app', icon: a.icon || '📱', action: `launchApp && launchApp('${a.id}')` }))];
                    allApps.filter(a => a.name.toLowerCase().includes(query) || (a.desc||'').toLowerCase().includes(query))
                        .forEach(a => this.results.push({ type: 'app', ...a }));
                }

                // Settings search
                if (mode === 'all' || mode === 'settings') {
                    this.settingsIndex.filter(s => s.name.toLowerCase().includes(query) || s.desc.toLowerCase().includes(query))
                        .forEach(s => this.results.push({ type: 'setting', ...s }));
                }

                // Commands search
                if (mode === 'all' || mode === 'apps') {
                    this.commands.filter(c => c.name.toLowerCase().includes(query) || c.desc.toLowerCase().includes(query))
                        .forEach(c => this.results.push({ type: 'cmd', ...c }));
                }

                // Files search (localStorage-based)
                if (mode === 'all' || mode === 'files') {
                    try {
                        const files = JSON.parse(localStorage.getItem('hyfiles_data') || '{}');
                        Object.values(files).filter(f => f && f.name && f.name.toLowerCase().includes(query))
                            .slice(0, 5).forEach(f => this.results.push({ type: 'file', name: f.name, desc: f.type || 'File', icon: '📄', action: "toggleApp('hyfiles-win')" }));
                    } catch(e) {}
                    // Also search notepad saves
                    try {
                        const notes = JSON.parse(localStorage.getItem('hyos_notepad_files') || '[]');
                        notes.filter(n => n.name && n.name.toLowerCase().includes(query))
                            .forEach(n => this.results.push({ type: 'file', name: n.name, desc: 'Note', icon: '📝', action: "toggleApp('notepad-win')" }));
                    } catch(e) {}
                }

                // Cloud search
                if (mode === 'all' || mode === 'cloud') {
                    const cloudItems = CloudHub.getSearchableItems().filter(i => i.name.toLowerCase().includes(query));
                    cloudItems.forEach(i => this.results.push({ type: 'cloud', ...i }));
                }

                // Web suggestions (always include unless mode=apps/files/settings)
                if (mode === 'all' || mode === 'web') {
                    const webResults = this.generateWebResults(q);
                    webResults.forEach(r => this.results.push({ type: 'web', ...r }));
                }

                document.getElementById('search-spinner').style.display = 'none';
                this.render(q);
            }, 150);
        },

        generateWebResults(q) {
            // Simulated web results - structured like a real search
            const categories = [
                { keyword: ['how', 'what', 'why', 'when', 'where'], prefix: 'Answer: ' },
                { keyword: ['tutorial', 'guide', 'learn'], prefix: 'Tutorial: ' },
                { keyword: ['best', 'top', 'list'], prefix: 'Article: ' },
            ];
            const base = [
                { name: `Search "${q}" on the web`, desc: 'Open browser and search', url: `https://search.brave.com/search?q=${encodeURIComponent(q)}`, action: `openBrowserWithSearch('${q.replace(/'/g,"\\'")}')` },
                { name: `${q} — Wikipedia`, desc: 'en.wikipedia.org', url: `https://en.wikipedia.org/wiki/${encodeURIComponent(q)}`, action: `openBrowserWithSearch('${q.replace(/'/g,"\\'")} wikipedia')` },
                { name: `${q} — YouTube`, desc: 'Find videos on YouTube', url: `https://youtube.com/results?search_query=${encodeURIComponent(q)}`, action: `openBrowserWithSearch('${q.replace(/'/g,"\\'")} youtube')` },
            ];
            return base;
        },

        render(q) {
            const area = document.getElementById('search-results-area');
            const count = document.getElementById('search-result-count');
            
            if (this.results.length === 0 && this.mode !== 'web') {
                area.innerHTML = `
                    <div class="search-empty">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                        <div style="font-size:14px;font-weight:600;margin-bottom:6px;">No results for "${q}"</div>
                        <div style="font-size:12px;">Try searching the web instead</div>
                        <button onclick="setSearchMode('web');updateGlobalSearch(document.getElementById('global-search-big').value)" style="margin-top:12px;padding:8px 16px;background:var(--blue-600);border:none;border-radius:8px;color:white;cursor:pointer;font-size:12px;font-weight:600;">Search the Web</button>
                    </div>
                `;
                count.textContent = '0 results';
                return;
            }

            const byType = {};
            this.results.forEach(r => { if (!byType[r.type]) byType[r.type] = []; byType[r.type].push(r); });
            
            let html = '';
            let idx = 0;

            const typeConfig = {
                app: { label: 'Apps', badge: 'badge-app', badgeText: 'App', iconClass: 'app-icon' },
                cmd: { label: 'Actions', badge: 'badge-cmd', badgeText: 'Action', iconClass: 'cmd-icon' },
                setting: { label: 'Settings', badge: 'badge-setting', badgeText: 'Setting', iconClass: 'settings-icon' },
                file: { label: 'Files', badge: 'badge-file', badgeText: 'File', iconClass: 'file-icon' },
                cloud: { label: 'Cloud', badge: 'badge-cloud', badgeText: 'Cloud', iconClass: 'app-icon' },
                web: { label: 'Web', badge: 'badge-web', badgeText: 'Web', iconClass: 'web-icon' },
            };

            for (const [type, items] of Object.entries(byType)) {
                const cfg = typeConfig[type] || { label: type, badge: 'badge-app', badgeText: type, iconClass: 'app-icon' };
                if (type !== 'web') {
                    html += `<div class="search-section-title">${cfg.label}</div>`;
                    items.slice(0, 6).forEach(item => {
                        const iconHtml = type === 'cmd' ? `<div class="search-result-icon ${cfg.iconClass}">${this.getCmdIcon(item.icon)}</div>`
                            : `<div class="search-result-icon ${cfg.iconClass}">${item.icon || '📱'}</div>`;
                        html += `
                            <div class="search-result-item" onclick="${item.action};closeGlobalSearch()" data-idx="${idx}">
                                ${iconHtml}
                                <div class="search-result-info">
                                    <div class="search-result-name">${this.highlight(item.name, q)}</div>
                                    <div class="search-result-desc">${item.desc||''}</div>
                                </div>
                                <span class="search-result-badge ${cfg.badge}">${cfg.badgeText}</span>
                            </div>
                        `;
                        idx++;
                    });
                } else {
                    // Web results — special card style
                    html += `<div class="search-section-title">Web Results</div>`;
                    items.forEach(item => {
                        html += `
                            <div class="search-web-result" onclick="${item.action};closeGlobalSearch()">
                                <div class="search-web-title">${item.name}</div>
                                ${item.url ? `<div class="search-web-url">${item.url}</div>` : ''}
                                ${item.desc ? `<div class="search-web-desc">${item.desc}</div>` : ''}
                            </div>
                        `;
                    });
                }
            }

            area.innerHTML = html;
            count.textContent = `${this.results.length} result${this.results.length !== 1 ? 's' : ''}`;
            this.selectedIndex = -1;
        },

        highlight(text, q) {
            if (!q) return text;
            return text.replace(new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi'), '<mark style="background:rgba(37,99,235,0.3);color:#fff;border-radius:2px;padding:0 1px;">$1</mark>');
        },

        navigate(dir) {
            const items = document.querySelectorAll('.search-result-item');
            if (!items.length) return;
            items.forEach(el => el.classList.remove('selected'));
            this.selectedIndex = Math.max(0, Math.min(items.length - 1, this.selectedIndex + dir));
            items[this.selectedIndex]?.classList.add('selected');
            items[this.selectedIndex]?.scrollIntoView({ block: 'nearest' });
        },

        executeSelected() {
            const selected = document.querySelector('.search-result-item.selected');
            if (selected) { selected.click(); return true; }
            // If no selection and there's a query, trigger web search
            const q = document.getElementById('global-search-big').value;
            if (q) { openBrowserWithSearch(q); closeGlobalSearch(); return true; }
            return false;
        },

        getCmdIcon(type) {
            const icons = {
                lock: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
                camera: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
                note: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
                image: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
                store: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>',
                folder: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
                tool: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
                widget: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>',
                desktop: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="9" height="7" rx="1"/><rect x="13" y="3" width="9" height="7" rx="1"/><rect x="2" y="14" width="9" height="7" rx="1"/><rect x="13" y="14" width="9" height="7" rx="1"/></svg>',
                cloud: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>',
                restart: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
                logout: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
            };
            return icons[type] || icons.folder;
        }
    };

    window.openGlobalSearch = function() { GlobalSearch.open(); };
    window.closeGlobalSearch = function() { GlobalSearch.close(); };
    window.updateGlobalSearch = function(q) {
        // Sync both inputs
        document.getElementById('global-search-input').value = q;
        document.getElementById('global-search-big').value = q;
        GlobalSearch.search(q);
    };
    window.globalSearchKeydown = function(e) {
        if (e.key === 'Escape') { closeGlobalSearch(); e.preventDefault(); }
        else if (e.key === 'ArrowDown') { GlobalSearch.navigate(1); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { GlobalSearch.navigate(-1); e.preventDefault(); }
        else if (e.key === 'Enter') { if (!GlobalSearch.executeSelected()) { const q = document.getElementById('global-search-big').value; if(q) { openBrowserWithSearch(q); closeGlobalSearch(); } } e.preventDefault(); }
    };
    window.setSearchMode = function(mode) {
        GlobalSearch.mode = mode;
        document.querySelectorAll('.srch-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
        const q = document.getElementById('global-search-big').value;
        if (q) GlobalSearch.search(q); else GlobalSearch.showDefault();
    };

    // Open browser with a search query (hooks into existing browser app if present)
    window.openBrowserWithSearch = function(q) {
        // Try to find browser window
        const browserWin = document.getElementById('browser-win');
        if (browserWin) {
            toggleApp('browser-win');
            setTimeout(() => {
                const urlBar = document.getElementById('browser-url');
                if (urlBar) { urlBar.value = `https://search.brave.com/search?q=${encodeURIComponent(q)}`; urlBar.dispatchEvent(new KeyboardEvent('keypress',{key:'Enter',bubbles:true})); }
            }, 200);
        } else {
            // Fallback: open via installed browser app
            const browserApp = (window.installedApps||[]).find(a => a.name.toLowerCase().includes('browser'));
            if (browserApp) launchApp && launchApp(browserApp.id);
            else notify('Search', `Searching for: ${q}`);
        }
    };

    // Keyboard shortcut: Ctrl+K or Cmd+K to open search
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openGlobalSearch(); }
        if (e.key === 'F3') { e.preventDefault(); openGlobalSearch(); }
    });

    // ============================================================
    // CLOUD HUB (HyService Cloud)
    // ============================================================
    const CloudHub = {
        isSyncing: false,
        lastSync: null,
        activityLog: [],

        syncItems: [
            { id: 'apps', label: 'Installed Apps', icon: '📦', status: 'synced' },
            { id: 'settings', label: 'System Settings', icon: '⚙️', status: 'synced' },
            { id: 'desktop', label: 'Desktop Layout', icon: '🖥️', status: 'synced' },
            { id: 'notes', label: 'Notepad Files', icon: '📝', status: 'synced' },
            { id: 'widgets', label: 'Widget Positions', icon: '🧩', status: 'synced' },
            { id: 'calendar', label: 'Calendar Events', icon: '📅', status: 'synced' },
        ],

        init() {
            this.lastSync = new Date();
            this.activityLog = JSON.parse(localStorage.getItem('hyos_cloud_activity') || '[]');
            if (this.activityLog.length === 0) {
                this.activityLog = [
                    { icon: '✅', text: 'Sync completed', time: 'Just now', color: '#22c55e' },
                    { icon: '☁️', text: 'Settings backed up', time: '2m ago', color: '#60a5fa' },
                    { icon: '📦', text: 'App list synced', time: '5m ago', color: '#60a5fa' },
                    { icon: '🔐', text: 'Secure login verified', time: '10m ago', color: '#a78bfa' },
                ];
            }
        },

        getStorageUsed() {
            let total = 0;
            try {
                for (let key in localStorage) {
                    if (localStorage.hasOwnProperty(key)) total += localStorage[key].length * 2;
                }
            } catch(e) {}
            return total;
        },

        getStorageBreakdown() {
            const items = [
                { label: 'Apps & Settings', key: ['hyos_settings','hyos_installed_apps','hyos_published','hyos_cloud_apps'], color: '#3b82f6' },
                { label: 'Notes & Files', key: ['hyos_notepad_files','hyfiles_data'], color: '#10b981' },
                { label: 'Widgets & Desktop', key: ['hyos_placed_widgets','hyos_desktops','hyos_custom_widgets'], color: '#f59e0b' },
                { label: 'App Usage & Other', key: ['hyos_app_usage','hyos_calendar_events','hyos_cloud_activity'], color: '#8b5cf6' },
            ];
            return items.map(item => {
                let size = 0;
                item.key.forEach(k => { try { size += (localStorage.getItem(k)||'').length * 2; } catch(e) {} });
                return { ...item, size };
            });
        },

        getSearchableItems() {
            return [
                { name: 'Cloud Sync Settings', desc: 'Manage what syncs', icon: '☁️', action: 'toggleCloudHub()' },
                { name: 'Cloud Backup', desc: 'Backup your data', icon: '💾', action: "toggleCloudHub();setTimeout(()=>switchCloudTab('backup'),200)" },
                { name: 'Cloud Storage', desc: 'View storage usage', icon: '📊', action: "toggleCloudHub();setTimeout(()=>switchCloudTab('storage'),200)" },
            ];
        },

        syncNow() {
            if (this.isSyncing) return;
            this.isSyncing = true;
            document.getElementById('cloud-statusbar-dot')?.classList.add('syncing');
            
            this.syncItems.forEach(item => item.status = 'syncing');
            this.renderSyncItems();
            notify('HyService Cloud', 'Syncing your data…');

            let done = 0;
            this.syncItems.forEach((item, i) => {
                setTimeout(() => {
                    item.status = 'synced';
                    done++;
                    this.renderSyncItems();
                    if (done === this.syncItems.length) {
                        this.isSyncing = false;
                        this.lastSync = new Date();
                        document.getElementById('cloud-statusbar-dot')?.classList.remove('syncing');
                        document.getElementById('cloud-last-sync').textContent = 'just now';
                        this.addActivity('✅', 'Sync completed', '#22c55e');
                        notify('HyService Cloud', 'All data synced successfully!');
                    }
                }, 400 + i * 300);
            });
        },

        createBackup() {
            notify('HyService Cloud', 'Creating backup…');
            setTimeout(() => {
                const backup = {
                    timestamp: new Date().toISOString(),
                    settings: localStorage.getItem('hyos_settings'),
                    apps: localStorage.getItem('hyos_installed_apps'),
                    desktop: localStorage.getItem('hyos_desktops'),
                    notes: localStorage.getItem('hyos_notepad_files'),
                };
                const existing = JSON.parse(localStorage.getItem('hyos_backups') || '[]');
                existing.unshift({ id: Date.now(), date: new Date().toLocaleString(), size: JSON.stringify(backup).length });
                if (existing.length > 5) existing.length = 5;
                localStorage.setItem('hyos_backups', JSON.stringify(existing));
                this.addActivity('💾', 'Full backup created', '#60a5fa');
                notify('HyService Cloud', 'Backup created successfully!');
                this.renderBackups();
            }, 1500);
        },

        addActivity(icon, text, color) {
            this.activityLog.unshift({ icon, text, time: 'just now', color });
            if (this.activityLog.length > 20) this.activityLog.length = 20;
            localStorage.setItem('hyos_cloud_activity', JSON.stringify(this.activityLog));
            this.renderActivity();
        },

        renderSyncItems() {
            const container = document.getElementById('cloud-sync-items');
            if (!container) return;
            container.innerHTML = this.syncItems.map(item => `
                <div class="cloud-sync-item">
                    <div class="cloud-sync-item-dot ${item.status}"></div>
                    <span style="font-size:16px;width:20px;">${item.icon}</span>
                    <div style="flex:1;">
                        <div style="font-size:13px;font-weight:600;">${item.label}</div>
                        <div style="font-size:11px;opacity:0.45;">${item.status === 'synced' ? 'Up to date' : item.status === 'syncing' ? 'Syncing…' : 'Paused'}</div>
                    </div>
                    <button onclick="CloudHub.toggleSyncItem('${item.id}')" style="font-size:10px;padding:3px 8px;border-radius:6px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.6);cursor:pointer;">${item.status === 'paused' ? 'Resume' : 'Pause'}</button>
                </div>
            `).join('');
        },

        toggleSyncItem(id) {
            const item = this.syncItems.find(i => i.id === id);
            if (item) { item.status = item.status === 'paused' ? 'synced' : 'paused'; this.renderSyncItems(); }
        },

        renderBackups() {
            const container = document.getElementById('cloud-backups-list');
            if (!container) return;
            const backups = JSON.parse(localStorage.getItem('hyos_backups') || '[]');
            if (backups.length === 0) {
                container.innerHTML = '<div style="text-align:center;opacity:0.4;font-size:12px;padding:10px;">No backups yet</div>';
                return;
            }
            container.innerHTML = backups.map((b, i) => `
                <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:12px;margin-bottom:8px;display:flex;align-items:center;gap:10px;">
                    <div style="font-size:20px;">💾</div>
                    <div style="flex:1;">
                        <div style="font-size:12px;font-weight:600;">Backup ${i === 0 ? '(Latest)' : '#' + (i+1)}</div>
                        <div style="font-size:11px;opacity:0.5;">${b.date} • ${formatBytes(b.size||0)}</div>
                    </div>
                    <button onclick="CloudHub.restoreBackup(${i})" style="font-size:11px;padding:5px 10px;border-radius:7px;background:rgba(37,99,235,0.15);border:1px solid rgba(37,99,235,0.3);color:#93c5fd;cursor:pointer;font-weight:600;">Restore</button>
                </div>
            `).join('');
        },

        restoreBackup(index) {
            if (!confirm('Restore this backup? Current data may be overwritten.')) return;
            notify('HyService Cloud', 'Restoring backup…');
            setTimeout(() => {
                notify('HyService Cloud', 'Backup restored! Reloading…');
                setTimeout(() => location.reload(), 1500);
            }, 2000);
        },

        renderStorage() {
            const used = this.getStorageUsed();
            const max = 100 * 1024; // 100KB cap (localStorage limit is ~5MB but we show as "100MB cloud")
            const percent = Math.min(100, (used / (5 * 1024 * 1024)) * 100);
            const cloudPercent = Math.min(100, (used / (100 * 1024 * 1024)) * 100);
            
            const usedEl = document.getElementById('cloud-storage-used');
            const barEl = document.getElementById('cloud-storage-bar');
            if (usedEl) usedEl.textContent = formatBytes(used);
            if (barEl) { barEl.style.width = '0%'; setTimeout(() => barEl.style.width = Math.max(1, cloudPercent) + '%', 100); }

            const breakdown = this.getStorageBreakdown();
            const total = breakdown.reduce((s, i) => s + i.size, 0) || 1;
            const container = document.getElementById('cloud-storage-breakdown');
            if (container) {
                container.innerHTML = breakdown.map(item => `
                    <div class="cloud-storage-item">
                        <div style="width:8px;height:8px;border-radius:50%;background:${item.color};flex-shrink:0;"></div>
                        <div style="flex:1;min-width:0;">
                            <div style="font-size:12px;font-weight:600;margin-bottom:4px;">${item.label}</div>
                            <div class="cloud-storage-item-bar"><div class="cloud-storage-item-fill" style="background:${item.color};width:${Math.max(2,(item.size/total*100)).toFixed(0)}%;"></div></div>
                        </div>
                        <div style="font-size:11px;opacity:0.5;margin-left:8px;">${formatBytes(item.size)}</div>
                    </div>
                `).join('');
            }
        },

        renderActivity() {
            const container = document.getElementById('cloud-activity-list');
            if (!container) return;
            if (!this.activityLog.length) {
                container.innerHTML = '<div style="text-align:center;opacity:0.4;font-size:12px;">No recent activity</div>';
                return;
            }
            container.innerHTML = this.activityLog.slice(0, 15).map(item => `
                <div class="cloud-activity-item">
                    <div style="width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">${item.icon}</div>
                    <div style="flex:1;">
                        <div style="font-size:12px;font-weight:600;">${item.text}</div>
                        <div style="font-size:10px;opacity:0.4;">${item.time}</div>
                    </div>
                </div>
            `).join('');
        }
    };
    CloudHub.init();

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    // =====================================================================
    // CALCULATOR APP
    // =====================================================================
    let calcExpr = '';
    let calcResult = '';
    let calcJustEvaled = false;
    let calcMode = 'basic';

    window.setCalcMode = function(mode) {
        calcMode = mode;
        document.getElementById('calc-mode-basic').style.background = mode === 'basic' ? 'rgba(37,99,235,0.2)' : 'transparent';
        document.getElementById('calc-mode-basic').style.color = mode === 'basic' ? '#fff' : 'rgba(255,255,255,0.4)';
        document.getElementById('calc-mode-basic').style.borderBottomColor = mode === 'basic' ? '#2563eb' : 'transparent';
        document.getElementById('calc-mode-sci').style.background = mode === 'sci' ? 'rgba(37,99,235,0.2)' : 'transparent';
        document.getElementById('calc-mode-sci').style.color = mode === 'sci' ? '#fff' : 'rgba(255,255,255,0.4)';
        document.getElementById('calc-mode-sci').style.borderBottomColor = mode === 'sci' ? '#2563eb' : 'transparent';
        const sciPad = document.getElementById('calc-sci-pad');
        if (sciPad) sciPad.style.display = mode === 'sci' ? 'grid' : 'none';
    };

    window.calcInput = function(val) {
        if (calcJustEvaled && /\d/.test(val)) { calcExpr = ''; calcJustEvaled = false; }
        else if (calcJustEvaled) { calcExpr = calcResult; calcJustEvaled = false; }
        calcExpr += val;
        updateCalcDisplay();
    };

    window.calcSci = function(fn) {
        calcExpr = fn + '(' + (calcExpr || '0') + ')';
        updateCalcDisplay();
    };

    window.calcClear = function() {
        calcExpr = ''; calcResult = ''; calcJustEvaled = false;
        document.getElementById('calc-display').textContent = '0';
        document.getElementById('calc-expr').textContent = '';
    };

    window.calcEquals = function() {
        try {
            const safeExpr = calcExpr
                .replace(/÷/g, '/')
                .replace(/×/g, '*')
                .replace(/−/g, '-')
                .replace(/Math\.PI/g, Math.PI)
                .replace(/Math\.E/g, Math.E);
            const result = Function('"use strict"; return (' + safeExpr + ')')();
            calcResult = String(parseFloat(result.toFixed(10)));
            document.getElementById('calc-expr').textContent = calcExpr + ' =';
            document.getElementById('calc-display').textContent = calcResult;
            calcJustEvaled = true;
        } catch(e) {
            document.getElementById('calc-display').textContent = 'Error';
            document.getElementById('calc-display').style.color = '#ef4444';
            setTimeout(() => { document.getElementById('calc-display').style.color = '#fff'; calcClear(); }, 1200);
        }
    };

    function updateCalcDisplay() {
        const el = document.getElementById('calc-display');
        if (!el) return;
        let display = calcExpr || '0';
        if (display.length > 14) { el.style.fontSize = '28px'; } 
        else if (display.length > 10) { el.style.fontSize = '36px'; }
        else { el.style.fontSize = '42px'; }
        el.textContent = display;
        document.getElementById('calc-expr').textContent = '';
    }

    window.openCalculator = function() { toggleApp('calculator-win'); };

    // =====================================================================
    // TERMINAL APP
    // =====================================================================
    const TerminalApp = {
        history: [],
        histIndex: -1,
        cwd: '~',
        env: {},
        
        init() {
            this.print('<span style="color:#22c55e;font-weight:bold;">HyOS Terminal v2.0</span>');
            this.print('<span style="opacity:0.5;">Type <span style="color:#60a5fa">help</span> for available commands. Type <span style="color:#60a5fa">clear</span> to clear screen.</span>');
            this.print('');
        },

        print(html) {
            const out = document.getElementById('terminal-out');
            if (!out) return;
            const line = document.createElement('div');
            line.innerHTML = html;
            out.appendChild(line);
            out.scrollTop = out.scrollHeight;
        },

        printPrompt(cmd) {
            this.print(`<span style="color:#22c55e">user@hyos:${this.cwd}$</span> <span style="color:#c9d1d9">${this.escapeHtml(cmd)}</span>`);
        },

        escapeHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); },

        run(cmd) {
            if (!cmd.trim()) return;
            this.history.unshift(cmd);
            this.histIndex = -1;
            this.printPrompt(cmd);
            this.execute(cmd.trim());
        },

        execute(cmd) {
            const args = cmd.split(/\s+/);
            const c = args[0].toLowerCase();
            const rest = args.slice(1).join(' ');

            switch(c) {
                case 'help':
                    this.print('Available commands:');
                    const cmds = [
                        ['ls','List directory contents'],['cd &lt;dir&gt;','Change directory'],
                        ['pwd','Print working directory'],['echo &lt;text&gt;','Print text'],
                        ['date','Show current date/time'],['whoami','Print current user'],
                        ['uname','System information'],['clear','Clear terminal'],
                        ['calc &lt;expr&gt;','Calculate expression'],['apps','List installed apps'],
                        ['open &lt;app&gt;','Open an app'],['neofetch','System info'],
                        ['uptime','System uptime'],['env','Environment variables'],
                        ['history','Command history'],['exit','Close terminal'],
                        ['pkg &lt;sub&gt; [arg]','Package manager (search/install/remove/list)'],
                        ['sudo hp start / stop','HyProgress desktop Easter egg 📊'],
                    ];
                    cmds.forEach(([n,d]) => this.print(`  <span style="color:#60a5fa;min-width:140px;display:inline-block">${n}</span><span style="opacity:0.5">${d}</span>`));
                    break;
                case 'clear': document.getElementById('terminal-out').innerHTML = ''; break;
                case 'ls': this.print(this.getLs()); break;
                case 'pwd': this.print(this.cwd === '~' ? '/home/' + (window.user || 'user') : this.cwd); break;
                case 'cd':
                    this.cwd = rest || '~';
                    document.getElementById('term-prompt').innerHTML = `user@hyos:${this.cwd}$&nbsp;`;
                    break;
                case 'echo': this.print(this.escapeHtml(rest)); break;
                case 'date': this.print(new Date().toString()); break;
                case 'whoami': this.print(window.user || 'user'); break;
                case 'uname': this.print('HyOS HS 2.0 (HyService Edition) x86_64'); break;
                case 'neofetch': this.neofetch(); break;
                case 'uptime': {
                    const s = Math.floor(performance.now()/1000);
                    this.print(`up ${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m ${s%60}s`);
                    break;
                }
                case 'calc': {
                    try { const r = Function('"use strict";return(' + rest + ')')(); this.print(`<span style="color:#22c55e">${r}</span>`); }
                    catch(e) { this.print('<span style="color:#ef4444">Error: invalid expression</span>'); }
                    break;
                }
                case 'apps':
                    if (window.installedApps && installedApps.length) {
                        installedApps.forEach(a => this.print(`  <span style="color:#60a5fa">${a.name}</span> — ${a.desc || 'No description'}`));
                    } else { this.print('No apps installed'); }
                    break;
                case 'open': {
                    const appMatch = window.installedApps ? installedApps.find(a => a.name.toLowerCase() === rest.toLowerCase()) : null;
                    if (appMatch) { launchApp(appMatch); this.print(`Opening ${appMatch.name}...`); }
                    else if (rest === 'files') { toggleApp('hyfiles-win'); this.print('Opening Files...'); }
                    else if (rest === 'settings') { toggleApp('settings-win'); this.print('Opening Settings...'); }
                    else { this.print(`<span style="color:#ef4444">App "${rest}" not found</span>`); }
                    break;
                }
                case 'history':
                    this.history.forEach((h, i) => this.print(`${String(i+1).padStart(3,'  ')}  ${this.escapeHtml(h)}`));
                    break;
                case 'env':
                    this.print(`USER=${window.user || 'user'}`);
                    this.print(`HOME=/home/${window.user || 'user'}`);
                    this.print(`SHELL=/bin/bash`);
                    this.print(`TERM=xterm-256color`);
                    break;
                case 'exit': closeApp('terminal-win'); break;

                case 'pkg': {
                    const sub = args[1]?.toLowerCase();
                    const pkgArg = args.slice(2).join(' ').trim() || args[1];
                    if (sub === 'run') {
                        // pkg run <name> [-- arg1 arg2 ...]
                        const sep = args.indexOf('--');
                        const runName = args[2];
                        const runArgs = sep !== -1 ? args.slice(sep + 1) : [];
                        PkgManager.run('run', runName, this, runArgs);
                    } else {
                        PkgManager.run(sub, pkgArg, this);
                    }
                    break;
                }
                case 'sudo': {
                    const sub = args.slice(1).join(' ').trim().toLowerCase();
                    if (sub === 'hp start') {
                        if (window._hpRunning) {
                            this.print('<span style="color:#fbbf24">⚠ HyProgress is already running. Type <span style="color:#0ea5e9">sudo hp stop</span> to end it.</span>');
                            break;
                        }
                        this.print('<span style="color:#0ea5e9">📊 HyProgress starting on desktop...</span>');
                        setTimeout(() => window._hyProgressStart(), 200);
                    } else if (sub === 'hp stop') {
                        if (!window._hpRunning) { this.print('<span style="color:#ef4444">hp: not running</span>'); break; }
                        window._hyProgressStop();
                        this.print('<span style="color:#4ade80">📊 HyProgress stopped.</span>');
                    } else {
                        this.print(`<span style="color:#ef4444">sudo: ${this.escapeHtml(sub)}: command not found</span>`);
                    }
                    break;
                }
                default:
                    this.print(`<span style="color:#ef4444">bash: ${this.escapeHtml(c)}: command not found</span>`);
            }
        },

        getLs() {
            const dirs = ['Documents', 'Downloads', 'Images', 'Videos'];
            return dirs.map(d => `<span style="color:#60a5fa">📁 ${d}</span>`).join('  ');
        },

        neofetch() {
            const lines = [
                '        .#@@@@#.        ',
                '      #@@@@@@@@@@#      ',
                '    .@@@@@@@@@@@@@@.    ',
                '   .@@@@@.   .@@@@@.   ',
                '   @@@@@@@   @@@@@@@   ',
                '   @@@@@@@   @@@@@@@   ',
                '   .@@@@@.   .@@@@@.   ',
                '    .@@@@@@@@@@@@@@.   ',
                '      #@@@@@@@@@@#      ',
                '        .#@@@@#.        ',
            ];
            const info = [
                `<span style="color:#fff;font-weight:bold">${window.user || 'user'}@hyos</span>`,
                '──────────────────',
                `<span style="color:#60a5fa">OS:</span> HyOS HS 2.0`,
                `<span style="color:#60a5fa">Kernel:</span> HyKernel 5.0`,
                `<span style="color:#60a5fa">Shell:</span> bash`,
                `<span style="color:#60a5fa">Resolution:</span> ${window.innerWidth}×${window.innerHeight}`,
                `<span style="color:#60a5fa">Apps:</span> ${window.installedApps ? installedApps.length : 0} installed`,
                `<span style="color:#60a5fa">Memory:</span> ${Math.round(performance.memory?.usedJSHeapSize/1024/1024||0)}MB used`,
                `<span style="color:#60a5fa">Uptime:</span> ${Math.floor(performance.now()/60000)}m`,
                `<span style="color:#60a5fa">User:</span> ${window.user || 'guest'}`,
            ];
            const maxH = Math.max(lines.length, info.length);
            for (let i = 0; i < maxH; i++) {
                const l = lines[i] ? `<span style="color:#2563eb">${lines[i]}</span>` : '                       ';
                const r = info[i] || '';
                this.print(`${l}  ${r}`);
            }
            this.print('');
        }
    };

    // =====================================================================
    // PACKAGE MANAGER — pkg install / search / remove / list / info / run
    // Uses Wasmer SDK (window.WasmerSDK) for registry lookup + execution.
    // Package index: localStorage hyos_packages
    // Package format: "namespace/name" e.g. "python/python", "cowsay/cowsay"
    // =====================================================================
    const PkgManager = {
        STORAGE_KEY: 'hyos_packages',

        _db()     { try { return JSON.parse(localStorage.getItem(this.STORAGE_KEY) || '{}'); } catch(e) { return {}; } },
        _save(db) { localStorage.setItem(this.STORAGE_KEY, JSON.stringify(db)); },

        _sdk() {
            if (!window.WasmerSDK) return null;
            return window.WasmerSDK;
        },

        run(sub, arg, term, extraArgs) {
            switch(sub) {
                case 'install':  this._install(arg, term);               break;
                case 'run':      this._runPkg(arg, extraArgs||[], term); break;
                case 'remove':
                case 'uninstall':
                case 'rm':       this._remove(arg, term);                break;
                case 'list':
                case 'ls':       this._list(term);                       break;
                case 'search':   this._search(arg, term);                break;
                default:
                    term.print('<span style="opacity:.5">pkg — HyOS package manager (Wasmer registry)</span>');
                    term.print('');
                    [
                        ['pkg install &lt;ns/name&gt;',        'Install a package  e.g. pkg install python/python'],
                        ['pkg run &lt;ns/name&gt; [-- args]',  'Run an installed package'],
                        ['pkg remove &lt;ns/name&gt;',         'Uninstall a package'],
                        ['pkg list',                          'List installed packages'],
                        ['pkg search &lt;name&gt;',            'Search registry (requires Wasmer SDK)'],
                    ].forEach(([c,d]) => term.print(`  <span style="color:#60a5fa;display:inline-block;min-width:230px">${c}</span><span style="opacity:.5">${d}</span>`));
                    term.print('');
                    term.print('<span style="opacity:.35">Tip: packages use namespace/name format — e.g. python/python, cowsay/cowsay, sharrattj/bash</span>');
            }
        },

        // ── search ──────────────────────────────────────────────────────
        async _search(query, term) {
            if (!query) { term.print('<span style="color:#ef4444">Usage: pkg search &lt;query&gt;</span>'); return; }
            const sdk = this._sdk();
            if (!sdk) { term.print('<span style="color:#ef4444">Wasmer SDK not loaded — cannot search.</span>'); return; }
            term.print(`<span style="opacity:.5">Searching for "<span style="color:#60a5fa">${term.escapeHtml(query)}</span>"…</span>`);
            try {
                const results = await sdk.Wasmer.search(query);
                if (!results?.length) {
                    term.print('No results. Try a namespace/name directly: <span style="color:#60a5fa">pkg install python/python</span>');
                    return;
                }
                term.print('');
                const db = this._db();
                results.slice(0,8).forEach(p => {
                    const full = p.name || p.packageName || String(p);
                    const tag  = db[full] ? ' <span style="color:#22c55e;font-size:10px">[installed]</span>' : '';
                    term.print(`  <span style="color:#e2e8f0;font-weight:bold">${term.escapeHtml(full)}</span>${tag}`);
                    if (p.description) term.print(`  <span style="opacity:.4">${term.escapeHtml(p.description.slice(0,100))}</span>`);
                    term.print('');
                });
            } catch(e) {
                // SDK search may not be supported — fall back to helpful message
                term.print(`<span style="color:#facc15">SDK search unavailable.</span>`);
                term.print(`Try installing directly: <span style="color:#60a5fa">pkg install ${term.escapeHtml(query)}/${term.escapeHtml(query)}</span>`);
                term.print('<span style="opacity:.4">Common packages: python/python, cowsay/cowsay, sharrattj/bash, wasmer/busybox</span>');
            }
        },

        // ── install ─────────────────────────────────────────────────────
        async _install(name, term) {
            if (!name) {
                term.print('<span style="color:#ef4444">Usage: pkg install &lt;namespace/name&gt;</span>');
                term.print('<span style="opacity:.4">Examples: pkg install python/python   pkg install cowsay/cowsay</span>');
                return;
            }
            const sdk = this._sdk();
            if (!sdk) { term.print('<span style="color:#ef4444">Wasmer SDK not loaded.</span>'); return; }

            const db = this._db();
            if (db[name]) { term.print(`<span style="color:#facc15">⚠ ${term.escapeHtml(name)} already installed (v${db[name].version || '?'})</span>`); return; }

            // Enforce namespace/name format
            if (!name.includes('/')) {
                term.print(`<span style="color:#facc15">Packages need a namespace: try <span style="color:#60a5fa">pkg install ${term.escapeHtml(name)}/${term.escapeHtml(name)}</span></span>`);
                return;
            }

            term.print(`<span style="opacity:.5">Fetching <span style="color:#60a5fa">${term.escapeHtml(name)}</span> from registry…</span>`);
            try {
                const pkg = await sdk.Wasmer.fromRegistry(name);
                await this._fakeProgress(term, `Installing ${term.escapeHtml(name)}`, 600);
                db[name] = { version: pkg.version || 'latest', installedAt: new Date().toISOString() };
                this._save(db);
                term.print(`<span style="color:#22c55e">✓ Installed <b>${term.escapeHtml(name)}</b></span>`);
                term.print(`<span style="opacity:.4">Run: <span style="color:#60a5fa">pkg run ${term.escapeHtml(name)}</span></span>`);
            } catch(e) {
                term.print(`<span style="color:#ef4444">Install failed: ${term.escapeHtml(e.message)}</span>`);
                if (e.message?.includes('Unable to find')) {
                    term.print(`<span style="opacity:.4">Check the name at <span style="color:#60a5fa">wasmer.io/explore</span></span>`);
                }
            }
        },

        // ── run ─────────────────────────────────────────────────────────
        async _runPkg(name, args, term) {
            if (!name) { term.print('<span style="color:#ef4444">Usage: pkg run &lt;namespace/name&gt; [-- arg1 arg2 …]</span>'); return; }
            const sdk = this._sdk();
            if (!sdk) {
                term.print('<span style="color:#ef4444">Wasmer SDK not loaded.</span>');
                term.print('<span style="opacity:.4">Ensure COOP/COEP headers are set and the SDK file loaded.</span>');
                return;
            }

            const db = this._db();
            const key = Object.keys(db).find(k => k === name || k.endsWith('/'+name));
            if (!key) {
                term.print(`<span style="color:#ef4444">"${term.escapeHtml(name)}" is not installed.</span>`);
                term.print(`<span style="opacity:.4">Run: <span style="color:#60a5fa">pkg install ${term.escapeHtml(name)}</span></span>`);
                return;
            }

            term.print(`<span style="opacity:.5">▶ ${term.escapeHtml(key)}${args.length ? ' ' + term.escapeHtml(args.join(' ')) : ''}</span>`);
            try {
                const pkg = await sdk.Wasmer.fromRegistry(key);
                if (!pkg.entrypoint) {
                    term.print(`<span style="color:#ef4444">"${term.escapeHtml(key)}" has no entrypoint (library package, not executable).</span>`);
                    return;
                }
                const instance = await pkg.entrypoint.run({ args });
                const decoder = new TextDecoder();
                const pipeOut = async () => {
                    const reader = instance.stdout.getReader();
                    try { while(true) { const {done,value} = await reader.read(); if(done) break; decoder.decode(value).split('\n').forEach(l => { if(l) term.print(term.escapeHtml(l)); }); } }
                    finally { reader.releaseLock(); }
                };
                const pipeErr = async () => {
                    const reader = instance.stderr.getReader();
                    try { while(true) { const {done,value} = await reader.read(); if(done) break; decoder.decode(value).split('\n').forEach(l => { if(l) term.print(`<span style="color:#f87171">${term.escapeHtml(l)}</span>`); }); } }
                    finally { reader.releaseLock(); }
                };
                await Promise.all([pipeOut(), pipeErr(), instance.wait()]);
                const result = await instance.wait();
                if (result?.code !== undefined && result.code !== 0) {
                    term.print(`<span style="color:#f87171">exited ${result.code}</span>`);
                }
            } catch(e) {
                if (e.message?.includes('SharedArrayBuffer') || e.message?.includes('cross-origin')) {
                    term.print(`<span style="color:#ef4444">Needs SharedArrayBuffer. Add to server headers:</span>`);
                    term.print('  <span style="color:#60a5fa">Cross-Origin-Opener-Policy: same-origin</span>');
                    term.print('  <span style="color:#60a5fa">Cross-Origin-Embedder-Policy: credentialless</span>');
                } else {
                    term.print(`<span style="color:#ef4444">Run failed: ${term.escapeHtml(e.message)}</span>`);
                }
            }
        },

        // ── remove ───────────────────────────────────────────────────────
        _remove(name, term) {
            if (!name) { term.print('<span style="color:#ef4444">Usage: pkg remove &lt;namespace/name&gt;</span>'); return; }
            const db = this._db();
            const key = Object.keys(db).find(k => k === name || k.endsWith('/'+name));
            if (!key) { term.print(`<span style="color:#ef4444">"${term.escapeHtml(name)}" is not installed.</span>`); return; }
            delete db[key];
            this._save(db);
            term.print(`<span style="color:#22c55e">✓ Removed <b>${term.escapeHtml(key)}</b></span>`);
        },

        // ── list ─────────────────────────────────────────────────────────
        _list(term) {
            const db = this._db();
            const keys = Object.keys(db);
            if (!keys.length) {
                term.print('No packages installed.');
                term.print('<span style="opacity:.4">Try: <span style="color:#60a5fa">pkg install cowsay/cowsay</span></span>');
                return;
            }
            term.print(`<span style="opacity:.4">${keys.length} package(s):</span>`);
            term.print('');
            keys.forEach(k => {
                const p = db[k];
                term.print(`  <span style="color:#e2e8f0">${term.escapeHtml(k)}</span> <span style="opacity:.35">installed ${new Date(p.installedAt).toLocaleDateString()}</span>`);
            });
        },

        // ── helpers ──────────────────────────────────────────────────────
        async _fakeProgress(term, label, ms) {
            const steps = 14;
            for (let i = 1; i <= steps; i++) {
                const bar = '█'.repeat(i) + '░'.repeat(steps-i);
                const pct = Math.round(i/steps*100);
                const out = document.getElementById('terminal-out');
                if (out?.lastChild) out.removeChild(out.lastChild);
                term.print(`  ${term.escapeHtml(label)} [<span style="color:#60a5fa">${bar}</span>] ${pct}%`);
                await new Promise(r => setTimeout(r, ms/steps));
            }
        }
    };

    window.openTerminal = function() { 
        toggleApp('terminal-win');
        setTimeout(() => {
            const out = document.getElementById('terminal-out');
            if (out && out.children.length === 0) TerminalApp.init();
            const input = document.getElementById('terminal-cmd');
            if (input) input.focus();
        }, 100);
    };

    window.newTerminalTab = function() { notify('Terminal', 'Multi-tab support coming soon!'); };

    window.handleTerminalKey = function(e) {
        const input = document.getElementById('terminal-cmd');
        if (e.key === 'Enter') {
            const cmd = input.value;
            input.value = '';
            TerminalApp.run(cmd);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (TerminalApp.histIndex < TerminalApp.history.length - 1) {
                TerminalApp.histIndex++;
                input.value = TerminalApp.history[TerminalApp.histIndex] || '';
            }
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (TerminalApp.histIndex > 0) {
                TerminalApp.histIndex--;
                input.value = TerminalApp.history[TerminalApp.histIndex] || '';
            } else { TerminalApp.histIndex = -1; input.value = ''; }
        } else if (e.key === 'Tab') {
            e.preventDefault();
            // Basic tab completion
            const val = input.value;
            const cmds = ['help','clear','ls','cd','pwd','echo','date','whoami','uname','neofetch','uptime','calc','apps','open','history','env','exit'];
            const match = cmds.find(c => c.startsWith(val));
            if (match) input.value = match;
        } else if (e.ctrlKey && e.key === 'c') {
            e.preventDefault();
            TerminalApp.printPrompt(input.value + '^C');
            input.value = '';
        } else if (e.ctrlKey && e.key === 'l') {
            e.preventDefault();
            document.getElementById('terminal-out').innerHTML = '';
        }
    };

    // =====================================================================
    // MEDIA VIEWER
    // =====================================================================
    window.loadMediaViewer = function() {
        const grid = document.getElementById('media-grid');
        const countEl = document.getElementById('media-count');
        if (!grid) return;

        const activeTab = document.querySelector('#media-viewer-win .media-tab-active')?.dataset?.tab || 'screenshots';
        const items = activeTab === 'recordings' ? (mediaLibrary?.recordings || []) : (mediaLibrary?.screenshots || []);
        
        if (countEl) countEl.textContent = items.length + ' item' + (items.length !== 1 ? 's' : '');

        if (!items.length) {
            grid.innerHTML = `<div style="grid-column:1/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;height:200px;opacity:0.35;">
                <div style="font-size:48px;margin-bottom:12px;">📭</div>
                <div style="font-size:14px;font-weight:600;">No media yet</div>
                <div style="font-size:12px;margin-top:6px;">Take a screenshot or record your screen</div>
            </div>`;
            return;
        }

        grid.innerHTML = items.slice().reverse().map(item => {
            const isVideo = item.type === 'recording';
            const thumb = isVideo ? '🎬' : item.dataUrl;
            return `<div style="background:#1e293b;border-radius:12px;overflow:hidden;border:1px solid #334155;cursor:pointer;transition:0.2s;" onmouseover="this.style.borderColor='#2563eb'" onmouseout="this.style.borderColor='#334155'">
                ${isVideo ? 
                    `<div style="height:110px;background:#0f172a;display:flex;align-items:center;justify-content:center;font-size:48px;">🎬</div>` :
                    `<img src="${thumb}" style="width:100%;height:110px;object-fit:cover;display:block;" onerror="this.style.display='none'">`
                }
                <div style="padding:10px;">
                    <div style="font-size:11px;font-weight:600;opacity:0.9;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${item.name || 'Untitled'}</div>
                    <div style="font-size:10px;opacity:0.4;margin-top:3px;">${new Date(item.date||item.timestamp).toLocaleString()}</div>
                    ${isVideo && item.durationFormatted ? `<div style="font-size:10px;color:#60a5fa;margin-top:2px;">⏱ ${item.durationFormatted}</div>` : ''}
                    <div style="display:flex;gap:6px;margin-top:8px;">
                        <button onclick="exportMedia('${item.id}','${item.type}')" style="flex:1;background:#2563eb;border:none;padding:5px;border-radius:6px;color:#fff;font-size:10px;cursor:pointer;font-weight:600;">Export</button>
                        <button onclick="deleteMedia('${item.id}','${item.type}')" style="background:#ef4444;border:none;padding:5px 8px;border-radius:6px;color:#fff;font-size:10px;cursor:pointer;">✕</button>
                    </div>
                </div>
            </div>`;
        }).join('');
    };

    window.switchMediaTab = function(tab) {
        document.getElementById('media-tab-screenshots').style.background = tab === 'screenshots' ? 'rgba(37,99,235,0.15)' : 'transparent';
        document.getElementById('media-tab-screenshots').style.borderBottomColor = tab === 'screenshots' ? '#2563eb' : 'transparent';
        document.getElementById('media-tab-screenshots').style.color = tab === 'screenshots' ? '#fff' : 'rgba(255,255,255,0.4)';
        document.getElementById('media-tab-recordings').style.background = tab === 'recordings' ? 'rgba(37,99,235,0.15)' : 'transparent';
        document.getElementById('media-tab-recordings').style.borderBottomColor = tab === 'recordings' ? '#2563eb' : 'transparent';
        document.getElementById('media-tab-recordings').style.color = tab === 'recordings' ? '#fff' : 'rgba(255,255,255,0.4)';
        loadMediaViewer();
    };

    window.openMediaViewer = function() {
        toggleApp('media-viewer-win');
        setTimeout(loadMediaViewer, 100);
    };

    // =====================================================================
    // WINDOW OPEN ANIMATION
    // =====================================================================
    const _origToggleAppBase = window.toggleApp;
    // Patch to add open animation
    (() => {
        const orig = window.toggleApp;
        window.toggleApp = function(id) {
            const win = document.getElementById(id);
            if (win && (win.style.display === 'none' || !win.style.display)) {
                orig(id);
                win.style.animation = 'windowOpen 0.18s ease-out';
                setTimeout(() => win.style.animation = '', 200);
            } else {
                orig(id);
            }
        };
    })();

    // =====================================================================
    // ENHANCED SEARCH - add calculator, terminal, media apps
    // =====================================================================
    (() => {
        const orig = window.updateGlobalSearch;
        window.updateGlobalSearch = function(q) {
            orig(q);
            // Extra: inject calculator, terminal, media into search
        };
    })();

    window.toggleCloudHub = function() {
        const panel = document.getElementById('cloud-hub');
        if (panel.style.display === 'none' || !panel.style.display) {
            panel.style.display = 'flex';
            CloudHub.renderSyncItems();
            CloudHub.renderActivity();
            CloudHub.renderStorage();
            CloudHub.renderBackups();
        } else {
            panel.style.display = 'none';
        }
        // Close other panels
        document.getElementById('notification-panel').style.display = 'none';
        document.getElementById('hyley-panel').style.display = 'none';
    };

    window.switchCloudTab = function(tab) {
        document.querySelectorAll('.cloud-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
        document.querySelectorAll('.cloud-tab-content').forEach(c => c.style.display = 'none');
        const content = document.getElementById('cloud-tab-' + tab);
        if (content) content.style.display = 'block';
        if (tab === 'storage') CloudHub.renderStorage();
        if (tab === 'activity') CloudHub.renderActivity();
        if (tab === 'backup') CloudHub.renderBackups();
        if (tab === 'sync') CloudHub.renderSyncItems();
    };

    // ============================================================
    // HYBROWSER ENGINE
    // ============================================================
    const HyBrowser = {
        tabs: [],
        activeTab: 0,
        bookmarks: [],
        history: [],

        quickLinks: [
            { title: 'Google', url: 'https://www.google.com', icon: '🔍' },
            { title: 'Wikipedia', url: 'https://en.wikipedia.org', icon: '📚' },
            { title: 'GitHub', url: 'https://github.com', icon: '💻' },
            { title: 'YouTube', url: 'https://youtube.com', icon: '▶️' },
            { title: 'MDN Docs', url: 'https://developer.mozilla.org', icon: '🧩' },
        ],

        init() {
            try {
                this.bookmarks = JSON.parse(localStorage.getItem('hyos_bookmarks') || '[]');
                this.history = JSON.parse(localStorage.getItem('hyos_browser_history') || '[]');
            } catch(e) { this.bookmarks = []; this.history = []; }
            this.tabs = [];
            this.newTab();
        },

        newTab(url) {
            const tab = {
                id: Date.now(),
                title: url ? 'Loading…' : 'New Tab',
                url: url || '',
                favicon: url ? '🌐' : '🏠',
                view: url ? 'web' : 'home'
            };
            this.tabs.push(tab);
            this.activeTab = this.tabs.length - 1;
            this.renderTabs();
            this.showTab(this.activeTab);
            if (url) this.navigate(url);
        },

        closeTab(idx) {
            this.tabs.splice(idx, 1);
            if (this.tabs.length === 0) this.newTab();
            else if (this.activeTab >= this.tabs.length) this.activeTab = this.tabs.length - 1;
            this.renderTabs();
            this.showTab(this.activeTab);
        },

        switchTab(idx) {
            this.activeTab = idx;
            this.renderTabs();
            this.showTab(idx);
        },

        renderTabs() {
            const container = document.getElementById('browser-tabs');
            if (!container) return;
            container.innerHTML = this.tabs.map((t, i) => `
                <div class="browser-tab ${i === this.activeTab ? 'active' : ''}" onclick="HyBrowser.switchTab(${i})" style="min-width:120px;max-width:200px;">
                    <span style="font-size:12px;">${t.favicon}</span>
                    <span style="flex:1;overflow:hidden;text-overflow:ellipsis;font-size:12px;">${t.title}</span>
                    ${this.tabs.length > 1 ? `<button onclick="event.stopPropagation();HyBrowser.closeTab(${i})" style="background:none;border:none;color:rgba(255,255,255,0.4);cursor:pointer;padding:0 0 0 4px;font-size:13px;line-height:1;" onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='rgba(255,255,255,0.4)'">×</button>` : ''}
                </div>
            `).join('');
        },

        showTab(idx) {
            const t = this.tabs[idx];
            if (!t) return;
            const urlBar = document.getElementById('browser-url');
            if (urlBar) urlBar.value = t.url || '';
            if (t.view === 'home') this.showHome();
            else if (t.view === 'webmaker') { /* WebMaker moved to HyInternet */ }
            else this.showIframe(t.url);
        },

        showHome() {
            document.getElementById('browser-home').style.display = 'flex';
            document.getElementById('browser-iframe').style.display = 'none';
            
            const urlBar = document.getElementById('browser-url');
            if (urlBar) urlBar.value = '';
            this.renderHome();
        },

        showIframe(url) {
            document.getElementById('browser-home').style.display = 'none';
            
            const iframe = document.getElementById('browser-iframe');
            iframe.style.display = 'block';
            if (iframe.src !== url) iframe.src = url;
        },

        renderHome() {
            // Quick links
            const ql = document.getElementById('browser-quick-links');
            if (ql) ql.innerHTML = this.quickLinks.map(l => `
                <div onclick="HyBrowser.navigate('${l.url}')" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:12px 8px;text-align:center;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(37,99,235,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                    <div style="font-size:22px;margin-bottom:5px;">${l.icon}</div>
                    <div style="font-size:11px;opacity:0.7;">${l.title}</div>
                </div>
            `).join('');

            // Bookmarks
            const bkSection = document.getElementById('browser-bookmarks-section');
            const bkList = document.getElementById('browser-bookmarks-list');
            if (this.bookmarks.length > 0 && bkSection && bkList) {
                bkSection.style.display = 'block';
                bkList.innerHTML = this.bookmarks.slice(0, 8).map(b => `
                    <div onclick="HyBrowser.navigate('${b.url}')" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:10px;cursor:pointer;transition:0.15s;display:flex;align-items:center;gap:8px;" onmouseover="this.style.background='rgba(37,99,235,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                        <span style="font-size:16px;">⭐</span>
                        <div style="overflow:hidden;">
                            <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${b.title}</div>
                            <div style="font-size:10px;opacity:0.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${b.url}</div>
                        </div>
                    </div>
                `).join('');
            }

            // History
            const hList = document.getElementById('browser-history-list');
            if (hList) {
                const recent = this.history.slice(-8).reverse();
                hList.innerHTML = recent.length ? recent.map(h => `
                    <div onclick="HyBrowser.navigate('${h.url}')" style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:10px;cursor:pointer;transition:0.15s;margin-bottom:4px;" onmouseover="this.style.background='rgba(255,255,255,0.06)'" onmouseout="this.style.background='transparent'">
                        <span style="font-size:14px;opacity:0.5;">🕐</span>
                        <div style="flex:1;min-width:0;">
                            <div style="font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${h.title || h.url}</div>
                            <div style="font-size:11px;opacity:0.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${h.url}</div>
                        </div>
                        <div style="font-size:11px;opacity:0.3;">${h.time || ''}</div>
                    </div>
                `).join('') : '<div style="opacity:0.35;font-size:13px;padding:12px 14px;">No browsing history yet</div>';
            }
        },

        navigate(input) {
            if (!input || !input.trim()) { this.showHome(); return; }
            let url = input.trim();

            // Determine if it's a URL or search query
            const isUrl = url.startsWith('http') || url.startsWith('//') || /^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/.test(url);
            if (!isUrl) {
                url = 'https://search.brave.com/search?q=' + encodeURIComponent(url);
            } else if (!url.startsWith('http')) {
                url = 'https://' + url;
            }

            const urlBar = document.getElementById('browser-url');
            if (urlBar) urlBar.value = url;

            // Get domain for display
            let domain = url;
            try { domain = new URL(url).hostname.replace('www.', ''); } catch(e) {}

            // Update tab
            const t = this.tabs[this.activeTab];
            if (t) {
                t.url = url;
                t.title = domain;
                t.favicon = '🌐';
                t.view = 'web';
            }
            this.renderTabs();

            // Show loading bar
            this.showLoadingBar();

            // Add to history
            this.history.push({ url, title: domain, time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) });
            if (this.history.length > 50) this.history.shift();
            localStorage.setItem('hyos_browser_history', JSON.stringify(this.history));

            // Try to load in iframe
            const iframe = document.getElementById('browser-iframe');
            document.getElementById('browser-home').style.display = 'none';
            
            iframe.style.display = 'block';
            iframe.src = url;
        },

        showLoadingBar() {
            const bar = document.getElementById('browser-loader');
            if (!bar) return;
            bar.style.display = 'block';
            bar.style.width = '20%';
            setTimeout(() => bar.style.width = '60%', 300);
            setTimeout(() => bar.style.width = '90%', 800);
            setTimeout(() => { bar.style.width = '100%'; setTimeout(() => bar.style.display = 'none', 300); }, 1500);
        },

        bookmark() {
            const t = this.tabs[this.activeTab];
            if (!t || !t.url) return;
            const existing = this.bookmarks.find(b => b.url === t.url);
            if (existing) {
                this.bookmarks = this.bookmarks.filter(b => b.url !== t.url);
                const btn = document.getElementById('browser-bookmark-btn');
                if (btn) btn.textContent = '☆';
                notify('HyBrowser', 'Bookmark removed');
            } else {
                this.bookmarks.push({ url: t.url, title: t.title || t.url });
                const btn = document.getElementById('browser-bookmark-btn');
                if (btn) btn.textContent = '⭐';
                notify('HyBrowser', 'Bookmarked!');
            }
            localStorage.setItem('hyos_bookmarks', JSON.stringify(this.bookmarks));
        },

        back() {
            const iframe = document.getElementById('browser-iframe');
            try { iframe.contentWindow.history.back(); } catch(e) {}
        },
        forward() {
            const iframe = document.getElementById('browser-iframe');
            try { iframe.contentWindow.history.forward(); } catch(e) {}
        },
        refresh() {
            const iframe = document.getElementById('browser-iframe');
            if (iframe.style.display !== 'none') {
                this.showLoadingBar();
                try { iframe.contentWindow.location.reload(); } catch(e) { iframe.src = iframe.src; }
            }
        }
    };

    window.openHyBrowser = function(url) {
        const win = document.getElementById('browser-win');
        if (!win) return;
        if (!HyBrowser.tabs || HyBrowser.tabs.length === 0) HyBrowser.init();
        if (win.style.display !== 'flex') {
            toggleApp('browser-win');
            setTimeout(() => { if (url) HyBrowser.navigate(url); }, 200);
        } else {
            win.style.zIndex = parseInt(win.style.zIndex || 100) + 1;
            if (url) HyBrowser.navigate(url);
        }
    };

    window.browserNavigate = (v) => HyBrowser.navigate(v);
    window.browserBack = () => HyBrowser.back();
    window.browserForward = () => HyBrowser.forward();
    window.browserRefresh = () => HyBrowser.refresh();
    window.browserHome = () => { const t = HyBrowser.tabs[HyBrowser.activeTab]; if(t){t.view='home';t.url='';} HyBrowser.showHome(); };
    window.browserNewTab = () => HyBrowser.newTab();
    window.browserBookmark = () => HyBrowser.bookmark();

    // Override openBrowserWithSearch to use HyBrowser
    window.openBrowserWithSearch = function(q) {
        openHyBrowser('https://search.brave.com/search?q=' + encodeURIComponent(q));
    };

    // ============================================================
    // HYBROWSER — WEB MAKER
    // ============================================================

    // Init HyBrowser when OS starts
    const _origStartOS2 = window.startOS;
    window.startOS = function() {
        if (_origStartOS2) _origStartOS2();
        setTimeout(() => HyBrowser.init(), 1000);
    };

    // ============================================================
    // ADVANCED HYLEY — PERSONALITY, APP SEARCH, SMART COMMANDS
    // ============================================================
    const HyleyAdvanced = {
        modes: ['Friendly', 'Focused', 'Fun', 'Formal'],
        currentMode: 0,
        cmdHistory: [],
        cmdHistoryIdx: -1,

        init() {
            try {
                const saved = JSON.parse(localStorage.getItem('hyley_advanced') || '{}');
                if (saved.mode !== undefined) this.currentMode = saved.mode;
            } catch(e) {}
            this.updateModeBadge();
        },

        save() {
            localStorage.setItem('hyley_advanced', JSON.stringify({ mode: this.currentMode }));
        },

        cycleMode() {
            this.currentMode = (this.currentMode + 1) % this.modes.length;
            this.save();
            this.updateModeBadge();
            notify('Hyley', `Mode: ${this.modes[this.currentMode]}`);
            const statusLine = document.getElementById('hyley-status-line');
            if (statusLine) statusLine.textContent = `AI Assistant · ${this.modes[this.currentMode]} Mode`;
        },

        updateModeBadge() {
            const badge = document.getElementById('hyley-mode-badge');
            const colors = { Friendly: '#93c5fd', Focused: '#86efac', Fun: '#f9a8d4', Formal: '#d4d4d8' };
            const bgs = { Friendly: 'rgba(37,99,235,0.2)', Focused: 'rgba(22,163,74,0.2)', Fun: 'rgba(219,39,119,0.2)', Formal: 'rgba(100,116,139,0.2)' };
            const mode = this.modes[this.currentMode];
            if (badge) { badge.textContent = mode; badge.style.color = colors[mode]; badge.style.background = bgs[mode]; }
        },

        // Show typing animation
        showTyping() {
            const t = document.getElementById('hyley-typing');
            if (t) t.style.display = 'block';
            const chat = document.getElementById('hyley-chat');
            if (chat) chat.scrollTop = chat.scrollHeight;
        },

        hideTyping() {
            const t = document.getElementById('hyley-typing');
            if (t) t.style.display = 'none';
        },

        // Add a message with animation
        addMessage(text, role) {
            const chat = document.getElementById('hyley-chat');
            if (!chat) return;
            const div = document.createElement('div');
            div.className = `hyley-message ${role}`;
            div.style.cssText = 'opacity:0;transform:translateY(8px);transition:opacity 0.25s,transform 0.25s;font-size:13px;line-height:1.6;';
            if (role === 'user') {
                div.innerHTML = `<div style="font-weight:600;margin-bottom:4px;font-size:10px;opacity:0.5;">YOU</div>${text}`;
            } else {
                div.innerHTML = text;
            }
            chat.appendChild(div);
            chat.scrollTop = chat.scrollHeight;
            requestAnimationFrame(() => { div.style.opacity = '1'; div.style.transform = 'translateY(0)'; });
        },

        // Compute context-aware prefix
        prefix(role) {
            const mode = this.modes[this.currentMode];
            if (role === 'friendly') {
                const greets = ['Sure!', 'Of course!', 'Got it!', 'Absolutely!', 'On it!'];
                return greets[Math.floor(Math.random() * greets.length)] + ' ';
            }
            if (mode === 'Formal') return '';
            if (mode === 'Fun') {
                const fun = ['✨ ', '🎉 ', '🚀 ', '💫 ', '⚡ '];
                return fun[Math.floor(Math.random() * fun.length)];
            }
            return '';
        },

        // All system apps list for search
        getAllApps() {
            const sysApps = [
                { name: 'HyFiles', icon: '📁', desc: 'File manager', action: () => toggleApp('hyfiles-win') },
                { name: 'Notepad', icon: '📝', desc: 'Text editor', action: () => { if(window.Notepad) Notepad.newFile(); else toggleApp('notepad-win'); } },
                { name: 'Calculator', icon: '🧮', desc: 'Calculator', action: () => { if(window.openCalculator) openCalculator(); else toggleApp('calculator-win'); } },
                { name: 'Terminal', icon: '⌨️', desc: 'Command line', action: () => { if(window.openTerminal) openTerminal(); else toggleApp('terminal-win'); } },
                { name: 'HyBrowser', icon: '🌐', desc: 'Web browser', action: () => openHyBrowser() },
                { name: 'Settings', icon: '⚙️', desc: 'System settings', action: () => toggleApp('settings-win') },
                { name: 'App Builder', icon: '🛠️', desc: 'Create apps', action: () => { if(window.openMaker) openMaker(); } },
                { name: 'Media Library', icon: '📸', desc: 'Screenshots & recordings', action: () => { if(window.openMediaViewer) openMediaViewer(); } },
                { name: 'Cloud Hub', icon: '☁️', desc: 'Cloud sync', action: () => { if(window.toggleCloudHub) toggleCloudHub(); } },
                { name: 'Wallpaper', icon: '🖼️', desc: 'Change wallpaper', action: () => { if(window.openWallpaperPicker) openWallpaperPicker(); } },
            ];
            const installed = (window.installedApps || []).map(a => ({
                name: a.name, icon: a.icon || '📱', desc: a.description || 'Installed app',
                action: () => { if(window.launchApp) launchApp(a.id || a); }
            }));
            return [...sysApps, ...installed];
        },

        // Advanced command processing
        processAdvanced(msg) {
            const lower = msg.toLowerCase().trim();

            // --- APP CONTROL ---
            // "open X" / "launch X" / "start X"
            const openMatch = lower.match(/^(?:open|launch|start|run)\s+(.+)$/);
            if (openMatch) {
                const appName = openMatch[1].replace(/^the\s+/i, '').trim();
                const allApps = this.getAllApps();
                const found = allApps.find(a => a.name.toLowerCase().includes(appName) || appName.includes(a.name.toLowerCase()));
                if (found) {
                    found.action();
                    return `${this.prefix('friendly')}Opening <strong>${found.name}</strong>!`;
                }
                return null; // let processHyleyMessage try
            }

            // "close X" / "quit X"
            const closeMatch = lower.match(/^(?:close|quit|hide|exit)\s+(.+)$/);
            if (closeMatch) {
                const name = closeMatch[1].trim();
                const wins = Array.from(document.querySelectorAll('.window'));
                const found = wins.find(w => {
                    const title = (w.querySelector('.win-title, [class*="win-title"]')?.textContent || w.id).toLowerCase();
                    return title.includes(name) || w.id.toLowerCase().includes(name.replace(/\s+/g, ''));
                });
                if (found) { found.style.display = 'none'; return `Closed!`; }
            }

            // --- BROWSER CONTROL ---
            if (lower.includes('browse') || lower.includes('go to') || lower.includes('visit') || lower.includes('search for')) {
                const urlMatch = lower.match(/(?:browse|go to|visit|open|navigate to)\s+(.+)/);
                const searchMatch = lower.match(/search (?:for\s+)?(.+)/);
                if (urlMatch) { openHyBrowser(); setTimeout(() => HyBrowser.navigate(urlMatch[1]), 300); return `${this.prefix('friendly')}Opening HyBrowser and navigating to <strong>${urlMatch[1]}</strong>!`; }
                if (searchMatch) { openBrowserWithSearch(searchMatch[1]); return `${this.prefix('friendly')}Searching for <strong>${searchMatch[1]}</strong>!`; }
            }

            // --- WIDGET CONTROL ---
            if (lower.includes('add widget') || lower.includes('show widget') || lower.includes('widget')) {
                if(window.openWidgetPicker) openWidgetPicker();
                return `${this.prefix('friendly')}Opening the widget picker!`;
            }

            // --- SYSTEM INFO ---
            if (lower.match(/how many apps|app count|installed apps/)) {
                const count = (window.installedApps || []).length;
                const sysCount = 9;
                return `You have <strong>${count}</strong> installed app${count!==1?'s':''} plus <strong>${sysCount}</strong> built-in system apps.`;
            }

            if (lower.match(/what(?:'s| is) (?:open|running)|open apps|running apps/)) {
                const open = Array.from(document.querySelectorAll('.window')).filter(w => w.style.display === 'flex').map(w => w.querySelector('.win-title, [class*="title"]')?.textContent.trim() || w.id);
                if (open.length === 0) return 'No apps are currently open.';
                return `Open apps: <strong>${open.join(', ')}</strong>`;
            }

            // --- SETTINGS SHORTCUTS ---
            if (lower.match(/change (?:my )?(?:theme|wallpaper|background)/)) {
                if(window.openWallpaperPicker) openWallpaperPicker();
                return `${this.prefix('friendly')}Opening wallpaper settings!`;
            }
            if (lower.match(/(?:toggle|enable|disable) dark mode|dark mode/)) {
                toggleApp('settings-win');
                return `Opened Settings. Navigate to Display to toggle dark mode.`;
            }

            // --- CREATION ---
            if (lower.match(/(?:make|create|build|new) (?:a |an )?website|web maker/)) {
                openHyBrowser();
                openHyInternet('webmaker');
                return `${this.prefix('friendly')}Opening Web Maker in HyInternet!`;
            }
            if (lower.match(/(?:make|create|build|new) (?:a |an )?(?:app|application)/)) {
                if(window.openMaker) openMaker();
                return `${this.prefix('friendly')}Opening App Builder!`;
            }
            if (lower.match(/(?:make|create|new) (?:a |an )?note|write (?:a |an )?note/)) {
                if(window.Notepad) { Notepad.newFile(); toggleApp && toggleApp('notepad-win'); }
                return `${this.prefix('friendly')}Opening a new note in Notepad!`;
            }

            // --- HYLEY SELF-AWARENESS ---
            if (lower.match(/what can you do|your (?:abilities|capabilities|features)|help me/)) {
                return `I can help you with lots of things! Here's what I do best:
                <br><br>
                <strong>🖥️ App Control</strong> — <em>"open calculator"</em>, <em>"close browser"</em>
                <br><strong>🌐 Web Browsing</strong> — <em>"search for cats"</em>, <em>"go to github.com"</em>
                <br><strong>✦ Web Maker</strong> — <em>"create a website"</em> (opens HyInternet)
                <br><strong>📱 Search Apps</strong> — tap the 🔍 icon above
                <br><strong>🗂️ Desktops</strong> — <em>"add a new desktop"</em>
                <br><strong>🧮 Math</strong> — <em>"what is 42 * 7"</em>
                <br><strong>📅 Calendar</strong> — <em>"add event tomorrow at 3pm"</em>
                <br><strong>💬 Conversation</strong> — ask me anything!
                `;
            }

            if (lower.match(/who (?:are you|made you|created you)|what are you/)) {
                return `I'm <strong>Hyley</strong> — the AI assistant built into HyOS. I live right here in your taskbar and I'm always ready to help. You can change my personality using the badge at the top! 😊`;
            }

            return null; // Fall through to old processHyleyMessage
        }
    };

    // Hook into existing sendToHyley
    const _origSendToHyley = window.sendToHyley;
    window.sendToHyley = function() {
        const input = document.getElementById('hyley-input');
        const message = (input.value || '').trim();
        if (!message) return;

        // Add to history
        HyleyAdvanced.cmdHistory.unshift(message);
        if (HyleyAdvanced.cmdHistory.length > 30) HyleyAdvanced.cmdHistory.pop();
        HyleyAdvanced.cmdHistoryIdx = -1;

        input.value = '';

        // Add user message with animation
        HyleyAdvanced.addMessage(message, 'user');

        // Show typing
        HyleyAdvanced.showTyping();
        document.getElementById('hyley-status-line').textContent = 'AI Assistant · Thinking…';

        const delay = 400 + Math.random() * 600;
        setTimeout(() => {
            HyleyAdvanced.hideTyping();
            document.getElementById('hyley-status-line').textContent = 'AI Assistant · Ready';

            // Try advanced handler first
            let response = HyleyAdvanced.processAdvanced(message);
            if (!response) {
                response = processHyleyMessage(message);
            }

            // If async (Claude API), skip the rest — reply injected directly
            if (response === '__HYLEY_ASYNC__') return;

            // Voice if enabled
            if (window.hyleySettings && hyleySettings.voice && window.speechSynthesis) {
                const stripped = response.replace(/<[^>]+>/g, '');
                const utt = new SpeechSynthesisUtterance(stripped.slice(0, 200));
                utt.rate = 0.95;
                speechSynthesis.speak(utt);
            }

            HyleyAdvanced.addMessage(response, 'assistant');
        }, delay);
    };

    // Quick chip sender
    window.hyleyQuickSend = function(text) {
        const input = document.getElementById('hyley-input');
        if (input) { input.value = text; sendToHyley(); }
    };

    // Command history navigation
    window.hyleyHistoryUp = function() {
        const input = document.getElementById('hyley-input');
        if (!input) return;
        HyleyAdvanced.cmdHistoryIdx = Math.min(HyleyAdvanced.cmdHistoryIdx + 1, HyleyAdvanced.cmdHistory.length - 1);
        input.value = HyleyAdvanced.cmdHistory[HyleyAdvanced.cmdHistoryIdx] || '';
    };

    // Cycle personality mode
    window.cycleHyleyMode = () => HyleyAdvanced.cycleMode();

    // App search panel toggle
    window.hyleyAppSearch = function() {
        const panel = document.getElementById('hyley-app-search-panel');
        if (!panel) return;
        const isOpen = panel.style.display !== 'none';
        panel.style.display = isOpen ? 'none' : 'block';
        if (!isOpen) {
            hyleyFilterApps('');
            setTimeout(() => document.getElementById('hyley-app-search-input').focus(), 50);
        }
    };

    window.hyleyFilterApps = function(query) {
        const container = document.getElementById('hyley-app-results');
        if (!container) return;
        const apps = HyleyAdvanced.getAllApps();
        const filtered = query ? apps.filter(a => a.name.toLowerCase().includes(query.toLowerCase()) || a.desc.toLowerCase().includes(query.toLowerCase())) : apps;
        container.innerHTML = filtered.slice(0, 12).map(a => `
            <div class="hyley-app-chip" onclick="HyleyAdvanced.getAllApps().find(x=>x.name===${JSON.stringify(a.name)})?.action();document.getElementById('hyley-app-search-panel').style.display='none'">
                <div style="font-size:20px;margin-bottom:3px;">${a.icon}</div>
                <div style="font-size:10px;font-weight:600;">${a.name}</div>
            </div>
        `).join('');
    };

    // Init advanced Hyley
    HyleyAdvanced.init();

    // Update search to include HyBrowser
    const _origSearchApps = GlobalSearch ? GlobalSearch.search.bind(GlobalSearch) : null;
    if (window.GlobalSearch) {
        const origSysApps = [
            { name: 'HyFiles', desc: 'File manager', icon: '📁', action: "toggleApp('hyfiles-win')" },
            { name: 'Notepad', desc: 'Text editor', icon: '📝', action: 'Notepad.newFile()' },
            { name: 'App Builder', desc: 'Create apps', icon: '🛠️', action: 'openMaker()' },
            { name: 'Settings', desc: 'System settings', icon: '⚙️', action: "toggleApp('settings-win')" },
            { name: 'HyBrowser', desc: 'Web browser — browse anything', icon: '🌐', action: 'openHyBrowser()' },
            { name: 'Web Maker', desc: 'Build and publish websites', icon: '✦', action: 'openHyInternet("webmaker")' },
            { name: 'Calculator', desc: 'Basic & scientific calculator', icon: '🧮', action: 'openCalculator()' },
            { name: 'Terminal', desc: 'Command line interface', icon: '⌨️', action: 'openTerminal()' },
            { name: 'Media Library', desc: 'Screenshots & screen recordings', icon: '📸', action: 'openMediaViewer()' },
            { name: 'Cloud Hub', desc: 'Sync & backup', icon: '☁️', action: 'toggleCloudHub()' },
        ];
        // Patch GlobalSearch to include HyBrowser in systemApps
        const _origGSSearch = GlobalSearch.search.bind(GlobalSearch);
        GlobalSearch.search = function(q) {
            _origGSSearch(q);
        };
        // Also add to commands
        GlobalSearch.commands.push(
            { name: 'Open HyBrowser', desc: 'Browse the web', action: 'openHyBrowser()', icon: 'tool' },
            { name: 'Web Maker', desc: 'Build and publish a website', action: 'openHyInternet("webmaker")', icon: 'tool' }
        );
    }



    // ╔══════════════════════════════════════════════════════════════╗
    // ║   HyOS HS — FEATURES BUNDLE 2.0 (25+ new features)          ║
    // ╚══════════════════════════════════════════════════════════════╝

    // ─── FEATURE 1: FOCUS / POMODORO TIMER ───────────────────────

// ── Spotlight, Quick Settings, Draw Wallpaper, Global Account ────────────
    window.openSpotlight = function() {
        const el = document.getElementById('spotlight-overlay');
        el.style.display = 'flex';
        setTimeout(() => document.getElementById('spotlight-input').focus(), 50);
        spotlightSearch('');
    };

    window.closeSpotlight = function() {
        document.getElementById('spotlight-overlay').style.display = 'none';
        document.getElementById('spotlight-input').value = '';
        spotlightSelected = -1;
    };

    const SPOTLIGHT_ITEMS = [
        { icon:'⚙️', label:'Settings', sub:'System preferences', action: ()=>toggleApp('settings-win') },
        { icon:'📷', label:'Camera', sub:'Take photos & video', action: ()=>openCameraApp() },
        { icon:'🌤️', label:'Weather', sub:'Live forecast', action: ()=>openWeatherApp() },
        { icon:'🎵', label:'Music', sub:'Local music player', action: ()=>openMusicApp() },
        { icon:'📁', label:'HyFiles', sub:'File manager', action: ()=>toggleApp('hyfiles-win') },
        { icon:'🧮', label:'Calculator', sub:'Math calculator', action: ()=>openCalculator() },
        { icon:'⌨️', label:'Terminal', sub:'Command line', action: ()=>openTerminal() },
        { icon:'📝', label:'Notepad', sub:'Text editor', action: ()=>Notepad?.newFile() },
        { icon:'🛠️', label:'App Maker', sub:'Build apps', action: ()=>openMaker() },
        { icon:'🔒', label:'Lock Screen', sub:'Lock & require PIN/password', action: ()=>lockScreen() },
        { icon:'🛡️', label:'Age Settings', sub:'Face verification & restrictions', action: ()=>{ toggleApp('settings-win'); switchSettingsTab('age'); } },
        { icon:'🔍', label:'Search Web', sub:'Open web search', action: (q)=>window.open(`https://google.com/search?q=${encodeURIComponent(q||'')}`) },
        { icon:'📌', label:'Set PIN', sub:'Configure lock screen PIN', action: ()=>setupPIN() },
    ];

    window.spotlightSearch = function(q) {
        spotlightSelected = -1;
        const res = document.getElementById('spotlight-results');
        const lower = q.trim().toLowerCase();

        // Installed apps match
        const appMatches = lower ? (installedApps||[]).filter(a => a.name?.toLowerCase().includes(lower)).slice(0,4) : [];

        // System items match
        const sysMatches = SPOTLIGHT_ITEMS.filter(item =>
            !lower || item.label.toLowerCase().includes(lower) || item.sub.toLowerCase().includes(lower)
        );

        if (!lower && !appMatches.length && !sysMatches.length) {
            res.innerHTML = '<div style="padding:20px;text-align:center;opacity:0.35;font-size:13px;">Type to search…</div>';
            return;
        }

        const allItems = [
            ...appMatches.map(a => ({
                icon: a.icon?.startsWith('data') ? `<img src="${a.icon}" style="width:24px;height:24px;border-radius:6px;">` : a.icon||'📦',
                label: a.name, sub: a.genre||'App',
                action: () => showInfo(a.id, 'installed'),
                isImg: a.icon?.startsWith('data'),
            })),
            ...sysMatches,
        ];

        if (!allItems.length) {
            res.innerHTML = `<div style="padding:20px;text-align:center;opacity:0.35;font-size:13px;">No results for "<strong>${q}</strong>"</div>`;
            return;
        }

        res.innerHTML = allItems.map((item, i) => `
            <div class="spotlight-item" data-idx="${i}" onclick="spotlightRun(${i})"
                style="display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:12px;cursor:pointer;transition:0.1s;">
                <div style="width:36px;height:36px;border-radius:10px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">${item.isImg ? item.icon : item.icon}</div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:13px;font-weight:700;">${item.label}</div>
                    <div style="font-size:11px;opacity:0.4;">${item.sub}</div>
                </div>
                <kbd style="font-size:10px;opacity:0.25;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:5px;padding:2px 6px;">↵</kbd>
            </div>`).join('');

        // Store for keyboard nav
        window._spotlightItems = allItems;
        window._spotlightQ = q;
        if (allItems.length) spotlightSetSelected(0);
    };

    window.spotlightRun = function(i) {
        const item = window._spotlightItems?.[i];
        if (!item) return;
        closeSpotlight();
        setTimeout(() => item.action(window._spotlightQ), 80);
    };

    function spotlightSetSelected(i) {
        document.querySelectorAll('.spotlight-item').forEach((el, idx) => {
            el.style.background = idx === i ? 'rgba(14,165,233,0.15)' : 'transparent';
        });
        spotlightSelected = i;
    }

    window.spotlightKey = function(e) {
        const items = document.querySelectorAll('.spotlight-item');
        if (e.key === 'ArrowDown') { e.preventDefault(); spotlightSetSelected(Math.min(spotlightSelected+1, items.length-1)); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); spotlightSetSelected(Math.max(spotlightSelected-1, 0)); }
        else if (e.key === 'Enter') { spotlightSelected >= 0 ? spotlightRun(spotlightSelected) : spotlightRun(0); }
        else if (e.key === 'Escape') { closeSpotlight(); }
    };

    // ================================================================
    // QUICK SETTINGS
    // ================================================================
    const qsState = { wifi:true, bt:false, dnd:false, dark:true, flight:false };

    window.toggleQuickSettings = function(e) {
        e?.stopPropagation();
        const panel = document.getElementById('quick-settings-panel');
        const isOpen = panel.style.display !== 'none';
        panel.style.display = isOpen ? 'none' : 'block';
        if (!isOpen) qsRefresh();
    };

    window.closeQuickSettings = function() {
        document.getElementById('quick-settings-panel').style.display = 'none';
    };

    document.addEventListener('click', e => {
        const panel = document.getElementById('quick-settings-panel');
        if (panel && panel.style.display !== 'none' && !panel.contains(e.target)) closeQuickSettings();
    });

    window.qsToggle = function(key) {
        qsState[key] = !qsState[key];
        const btn = document.getElementById('qs-' + key);
        if (btn) btn.classList.toggle('active', qsState[key]);

        if (key === 'dark') {
            document.body.style.filter = qsState.dark ? '' : 'invert(1) hue-rotate(180deg)';
        }
        if (key === 'dnd') {
            notify('Do Not Disturb', qsState.dnd ? 'Notifications muted' : 'Notifications on');
        }
        if (key === 'flight') {
            notify('Airplane Mode', qsState.flight ? 'Network disabled (simulated)' : 'Network enabled');
        }
    };

    window.qsBrightness = function(v) {
        document.documentElement.style.filter = `brightness(${v/100})`;
        document.getElementById('qs-bright-val').textContent = v + '%';
    };

    window.qsVolume = function(v) {
        document.getElementById('qs-vol-val').textContent = v + '%';
        if (musicAudio) musicAudio.volume = v / 100;
        const volSlider = document.getElementById('music-vol');
        if (volSlider) volSlider.value = v / 100;
    };

    function qsRefresh() {
        Object.entries(qsState).forEach(([k, v]) => {
            const btn = document.getElementById('qs-' + k);
            if (btn) btn.classList.toggle('active', v);
        });
    }

    console.log('✅ All HyOS features loaded');




    // ================================================================
    // DRAW YOUR OWN WALLPAPER
    // ================================================================
    (function() {
        let canvas, ctx, drawing = false, tool = 'pencil', color = '#0ea5e9', brushSize = 8;
        let history = [], redoStack = [], lastX, lastY;

        window.openDrawWallpaper = function() {
            if (window._globalAccount) { notify('🚫 Restricted', 'Drawing is disabled in the Global Account.'); return; }
            canvas = document.getElementById('draw-canvas');
            ctx = canvas.getContext('2d');
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            ctx.fillStyle = '#030508';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            history = [ctx.getImageData(0, 0, canvas.width, canvas.height)];
            redoStack = [];
            document.getElementById('draw-wallpaper-overlay').style.display = 'flex';
            closeApp('wallpaper-win');

            canvas.onmousedown = (e) => { drawing = true; lastX = e.clientX; lastY = e.clientY; saveDrawHistory(); };
            canvas.onmouseup = () => { drawing = false; };
            canvas.onmouseleave = () => { drawing = false; };
            canvas.onmousemove = drawMove;

            canvas.ontouchstart = (e) => { e.preventDefault(); const t=e.touches[0]; drawing=true; lastX=t.clientX; lastY=t.clientY; saveDrawHistory(); };
            canvas.ontouchend = () => { drawing = false; };
            canvas.ontouchmove = (e) => { e.preventDefault(); const t=e.touches[0]; drawMove({clientX:t.clientX,clientY:t.clientY}); };
        };

        function drawMove(e) {
            if (!drawing || !ctx) return;
            ctx.beginPath();
            ctx.lineWidth = brushSize;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            if (tool === 'eraser') {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.strokeStyle = 'rgba(0,0,0,1)';
            } else {
                ctx.globalCompositeOperation = 'source-over';
                ctx.strokeStyle = color;
            }
            ctx.moveTo(lastX, lastY);
            ctx.lineTo(e.clientX, e.clientY);
            ctx.stroke();
            lastX = e.clientX; lastY = e.clientY;
        }

        function saveDrawHistory() {
            if (!ctx) return;
            history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
            if (history.length > 40) history.shift();
            redoStack = [];
        }

        window.drawUndo = function() { if (history.length <= 1) return; redoStack.push(history.pop()); ctx.putImageData(history[history.length-1], 0, 0); };
        window.drawRedo = function() { if (!redoStack.length) return; const s=redoStack.pop(); history.push(s); ctx.putImageData(s, 0, 0); };
        window.setDrawTool = function(t) {
            tool = t;
            document.querySelectorAll('.draw-tool-btn').forEach(b => b.classList.remove('active'));
            document.getElementById('drawtool-' + t).classList.add('active');
        };
        window.setDrawColor = function(c) { color = c; document.getElementById('draw-color-btn').style.background = c; };
        window.setDrawSize = function(v) { brushSize = parseInt(v); };
        window.saveDrawWallpaper = function() {
            const dataURL = canvas.toDataURL('image/jpeg', 0.85);
            const bg = document.getElementById('desktop-bg');
            const cv = bg.querySelector('canvas');
            if (cv) { cv.remove(); if (window._threeRenderer) { window._threeRenderer.dispose(); window._threeRenderer = null; } }
            bg.style.backgroundImage = 'url(' + dataURL + ')';
            bg.style.backgroundSize = 'cover';
            bg.style.backgroundPosition = 'center';
            // Persist across refreshes
            userSettings.wallpaper = { type: 'drawn', dataURL };
            saveSettings();
            document.getElementById('draw-wallpaper-overlay').style.display = 'none';
            notify('🎨 Wallpaper', 'Your drawing is now your wallpaper!');
        };
        window.closeDrawWallpaper = function() { document.getElementById('draw-wallpaper-overlay').style.display = 'none'; };
    })();

    // ================================================================
    // GLOBAL ACCOUNT
    // ================================================================
    window._globalAccount = false;
    let _globalCDTimer = null;

    window.openGlobalWarn = function() {
        if (window._globalAccount) return;
        const modal = document.getElementById('global-warn-modal');
        modal.style.display = 'flex';
        const btn = document.getElementById('global-join-btn');
        const cd = document.getElementById('global-countdown');
        btn.classList.remove('ready');
        cd.textContent = 'Wait 12 seconds...';
        let secs = 12;
        clearInterval(_globalCDTimer);
        _globalCDTimer = setInterval(() => {
            secs--;
            if (secs > 0) {
                cd.textContent = 'Wait ' + secs + ' second' + (secs !== 1 ? 's' : '') + '...';
            } else {
                clearInterval(_globalCDTimer);
                cd.textContent = '';
                btn.classList.add('ready');
            }
        }, 1000);
    };

    window.closeGlobalWarn = function() {
        document.getElementById('global-warn-modal').style.display = 'none';
        clearInterval(_globalCDTimer);
    };

    window.enterGlobalAccount = function() {
        const btn = document.getElementById('global-join-btn');
        if (!btn.classList.contains('ready')) return;
        document.getElementById('global-warn-modal').style.display = 'none';
        clearInterval(_globalCDTimer);
        window._globalAccount = true;
        user = 'GlobalGuest';
        localStorage.setItem('hyos_user', 'GlobalGuest');
        notify('🌐 Global Account', 'Welcome to the Global Account. Restrictions apply.');

        // Swap UI
        const g = document.getElementById('global-statusbar-btn');
        if (g) g.style.display = 'none';
        const h = document.getElementById('global-exit-hint');
        if (h) h.style.display = 'flex';

        applyGlobalRestrictions();
    };

    window.applyGlobalRestrictions = function() {
        // Visually dim restricted buttons
        const restrictedIds = ['draw-wallpaper-btn'];
        restrictedIds.forEach(id => { const el = document.getElementById(id); if (el) el.classList.add('global-restricted'); });

        // Block functions
        const block = (name) => () => globalRestrict(name);
        window.toggleHyley = block('HyLey AI');
        window.openDrawWallpaper = block('Drawing backgrounds');
        window.setCustomImage = block('Custom wallpaper import');
        window.setCustomVideo = block('Custom wallpaper import');

        // Wrap wallpaper setters with cooldown
        const _origSetImage = window.setImageWall;
        const _origSet3D = window.set3DWall;
        window.setImageWall = (...a) => { if (globalCooldownOk()) _origSetImage(...a); };
        window.set3DWall = (...a) => { if (globalCooldownOk()) _origSet3D(...a); };

        window._globalLastAction = 0;
    };

    window.globalCooldownOk = function() {
        const now = Date.now();
        const elapsed = now - (window._globalLastAction || 0);
        if (elapsed < 10000) {
            notify('⏳ Cooldown', 'Wait ' + Math.ceil((10000 - elapsed) / 1000) + 's (Global Account).');
            return false;
        }
        window._globalLastAction = now;
        return true;
    };

    window.globalRestrict = function(feat) { notify('🚫 Restricted', feat + ' is disabled in the Global Account.'); };

    // ================================================================
    // HYLINK ENGINE  —  Hybrid HTML + JSON + System Actions
    // ================================================================
    window.HyLink = (function() {

        // ── SA (System Action) Permission Check ──────────────────────
        function checkSA(sa) {
            // sa = { sa: "firebase", read: "yes"/"no", write: "yes"/"no"/functionRef }
            // sa = { sa: "size", y: height, x: width, max: "no" }
            if (!sa) return { read: false, write: false };
            if (sa.sa === 'size') {
                return {
                    read: false, write: false,
                    size: true,
                    x: sa.x || null,
                    y: sa.y || null,
                    max: sa.max !== 'no'
                };
            }
            if (sa.sa !== 'firebase') return { read: false, write: false };
            return {
                read:  sa.read  === 'yes' || sa.read  === true,
                write: sa.write === 'yes' || sa.write === true || typeof sa.write === 'string'
            };
        }

        // ── Parse HyLink file (hybrid HTML + JSON) ───────────────────
        // Format options:
        //   1. Pure JSON:   { "sa": "firebase", "url": "...", ... }
        //   2. Pure HTML:   <!DOCTYPE html>...  or  <html>...
        //   3. Hybrid:      JSON block first, then HTML block separated by "---" or newline after JSON
        //   4. Commands:    new.collect(), read.collect(), new.doc(), etc.
        function parse(raw) {
            raw = raw.trim();
            let sa = null, html = null, url = null, commands = [];

            // Detect command-only mode (lines like new.collect(), rm.doc(), etc.)
            const commandPattern = /^(new|read|rm)\.(collect|doc)\s*\(/m;
            const isCommandFile = commandPattern.test(raw) && !raw.startsWith('<');

            if (isCommandFile) {
                commands = extractCommands(raw);
                return { sa, html, url, commands };
            }

            // Try to extract JSON header (if file starts with { or has a JSON block before HTML)
            if (raw.startsWith('{')) {
                const jsonEnd = findJsonEnd(raw);
                if (jsonEnd > 0) {
                    try {
                        sa = JSON.parse(raw.slice(0, jsonEnd + 1));
                        url  = sa.url || sa.link || sa.href || null;
                        const rest = raw.slice(jsonEnd + 1).trim();
                        if (rest) {
                            // Rest could be HTML or more commands
                            if (commandPattern.test(rest)) commands = extractCommands(rest);
                            else if (rest.startsWith('<') || rest.startsWith('<!')) html = rest;
                        }
                    } catch(e) { /* ignore */ }
                }
            } else if (raw.startsWith('<')) {
                html = raw;
            } else {
                // Plain URL
                url = raw;
            }

            return { sa, html, url, commands };
        }

        function findJsonEnd(str) {
            let depth = 0, inStr = false, escape = false;
            for (let i = 0; i < str.length; i++) {
                const c = str[i];
                if (escape) { escape = false; continue; }
                if (c === '\\' && inStr) { escape = true; continue; }
                if (c === '"' && !escape) { inStr = !inStr; continue; }
                if (inStr) continue;
                if (c === '{') depth++;
                if (c === '}') { depth--; if (depth === 0) return i; }
            }
            return -1;
        }

        function extractCommands(text) {
            const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
            const cmds = [];
            for (const line of lines) {
                const m = line.match(/^(new|read|rm)\.(collect|doc)\s*\(\s*([^)]*)\s*\)/);
                if (m) cmds.push({ action: m[1], target: m[2], arg: m[3].replace(/['"]/g, '').trim() });
            }
            return cmds;
        }

        // ── Execute Firebase Commands via appspace ────────────────────
        async function runCommands(commands, saPerms, appName) {
            if (!firebaseInitialized) {
                notify('HyLink', 'Firebase not available for commands.');
                return;
            }
            const scope = (appName || 'unknown').replace(/[^a-zA-Z0-9_-]/g, '_');
            const results = [];

            for (const cmd of commands) {
                const { action, target, arg } = cmd;
                const colPath = `appspace/${scope}/collections`;
                const docPath = `appspace/${scope}/docs`;

                try {
                    if (target === 'collect') {
                        if (action === 'new') {
                            if (!saPerms.write) { results.push('⛔ SA write denied for new.collect()'); continue; }
                            const colName = arg || ('col_' + Date.now());
                            await window._fb.setDoc(window._fb.doc(db, colPath, colName), { created: window._fb.serverTimestamp(), name: colName });
                            results.push('✅ Collection created: ' + colName);
                        } else if (action === 'read') {
                            if (!saPerms.read) { results.push('⛔ SA read denied for read.collect()'); continue; }
                            const snap = await window._fb.getDocs(window._fb.collection(db, colPath));
                            const names = snap.docs.map(d => d.id);
                            results.push('📁 Collections: ' + (names.length ? names.join(', ') : '(empty)'));
                        } else if (action === 'rm') {
                            if (!saPerms.write) { results.push('⛔ SA write denied for rm.collect()'); continue; }
                            const colName = arg;
                            if (!colName) { results.push('❌ rm.collect() requires a name argument'); continue; }
                            await window._fb.deleteDoc(window._fb.doc(db, colPath, colName));
                            results.push('🗑️ Collection removed: ' + colName);
                        }
                    } else if (target === 'doc') {
                        if (action === 'new') {
                            if (!saPerms.write) { results.push('⛔ SA write denied for new.doc()'); continue; }
                            const docName = arg || ('doc_' + Date.now());
                            await window._fb.setDoc(window._fb.doc(db, docPath, docName), { created: window._fb.serverTimestamp(), name: docName, data: {} });
                            results.push('✅ Document created: ' + docName);
                        } else if (action === 'read') {
                            if (!saPerms.read) { results.push('⛔ SA read denied for read.doc()'); continue; }
                            const snap = await window._fb.getDocs(window._fb.collection(db, docPath));
                            const names = snap.docs.map(d => d.id);
                            results.push('📄 Documents: ' + (names.length ? names.join(', ') : '(empty)'));
                        } else if (action === 'rm') {
                            if (!saPerms.write) { results.push('⛔ SA write denied for rm.doc()'); continue; }
                            const docName = arg;
                            if (!docName) { results.push('❌ rm.doc() requires a name argument'); continue; }
                            await window._fb.deleteDoc(window._fb.doc(db, docPath, docName));
                            results.push('🗑️ Document removed: ' + docName);
                        }
                    }
                } catch(e) {
                    results.push('❌ Error: ' + e.message);
                }
            }

            // Show results in a simple overlay
            if (results.length) {
                const overlay = document.createElement('div');
                overlay.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(15,23,42,0.98);border:1px solid #334155;border-radius:16px;padding:24px;z-index:99999;min-width:320px;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,0.7);backdrop-filter:blur(20px);';
                overlay.innerHTML = `
                    <div style="font-weight:700;font-size:14px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;">
                        <span>🔗 HyLink Results</span>
                        <button onclick="this.closest('div').parentElement ? this.closest('div').parentElement.remove() : this.parentElement.remove()" style="background:rgba(255,255,255,0.1);border:none;color:white;cursor:pointer;border-radius:8px;padding:4px 10px;">✕</button>
                    </div>
                    ${results.map(r => `<div style="font-size:12px;padding:6px 10px;background:rgba(255,255,255,0.04);border-radius:8px;margin-bottom:6px;font-family:monospace;">${r}</div>`).join('')}
                `;
                document.body.appendChild(overlay);
                setTimeout(() => overlay.remove(), 8000);
            }
        }

        // ── Main execute ──────────────────────────────────────────────
        function execute(raw, appName) {
            const { sa, html, url, commands } = parse(raw);
            const saPerms = checkSA(sa);

            // Run Firebase commands if present
            if (commands.length > 0) {
                runCommands(commands, saPerms, appName);
                return;
            }

            // Open HTML in an OS-style window
            if (html) {
                const winId = 'hylink-win-' + Date.now();
                const winEl = document.createElement('div');
                winEl.id = winId;
                winEl.className = 'window';
                winEl.style.cssText = 'width:900px;height:600px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;z-index:700;';
                const label = (appName || 'HyLink App').replace(/\.hl$/, '');
                winEl.innerHTML = `
                    <div class="win-header" style="cursor:move;user-select:none;">
                        <span style="font-weight:700;font-size:13px;">🔗 ${label}</span>
                        <div style="display:flex;gap:6px;">
                            <button onclick="this.closest('.window').style.display='none'" style="width:24px;height:24px;border-radius:6px;background:rgba(239,68,68,0.3);border:1px solid rgba(239,68,68,0.5);color:#fff;cursor:pointer;">✕</button>
                        </div>
                    </div>
                    <div class="win-body"><iframe srcdoc="" sandbox="allow-scripts allow-forms allow-same-origin"></iframe></div>
                    <div class="resizer"></div>`;
                document.body.appendChild(winEl);
                winEl.querySelector('iframe').srcdoc = html;
                // Apply size SA if present
                if (saPerms.size) {
                    if (saPerms.max) {
                        winEl.classList.add('maximized');
                    } else {
                        if (saPerms.x) winEl.style.width  = saPerms.x + (isNaN(saPerms.x) ? '' : 'px');
                        if (saPerms.y) winEl.style.height = saPerms.y + (isNaN(saPerms.y) ? '' : 'px');
                    }
                }
                // Make draggable using existing kernel
                if (window.makeWindowDraggable) window.makeWindowDraggable(winEl);
                else if (window.WindowManager && window.WindowManager.makeDraggable) window.WindowManager.makeDraggable(winEl);
                notify('🔗 HyLink', 'Opened: ' + label);
                return;
            }

            // Open URL
            if (url) {
                let finalUrl = url;
                if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) finalUrl = 'https://' + finalUrl;
                notify('🔗 HyLink', 'Opening: ' + finalUrl);
                window.open(finalUrl, '_blank');
                return;
            }

            notify('HyLink', 'Nothing to execute in this HyLink file.');
        }

        return { execute, parse, checkSA };
    })();


    // ================================================================
    // SMARTER HYLEY  —  Claude API fallback for unknown queries
    // ================================================================
    (function() {
        const _base = window.processHyleyMessage;

        window.processHyleyMessage = function(message) {
            // First try local rule-based processor
            const localResult = _base ? _base(message) : null;
            if (localResult && localResult !== '__FALLBACK__') return localResult;

            // Fall through to Claude API asynchronously
            const hyleyTyping = document.getElementById('hyley-typing');
            const hyleyChat   = document.getElementById('hyley-chat');
            if (hyleyTyping) hyleyTyping.style.display = 'block';

            (async () => {
                try {
                    const osContext = `You are Hyley, the AI assistant built into HyOS HS — a browser-based operating system. You are friendly, concise, and helpful. You know about the OS features: apps, files, wallpapers, settings, HyLink files, Firebase-backed cloud sync, Global Account, and the appspace collection. The current user is: ${user || 'unknown'}. Keep answers short and natural for a chat panel.`;

                    const resp = await fetch('https://api.anthropic.com/v1/messages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            model: 'claude-sonnet-4-20250514',
                            max_tokens: 1000,
                            system: osContext,
                            messages: [{ role: 'user', content: message }]
                        })
                    });
                    const data = await resp.json();
                    const text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
                    if (hyleyTyping) hyleyTyping.style.display = 'none';
                    if (text && hyleyChat) {
                        const msgEl = document.createElement('div');
                        msgEl.className = 'hyley-message assistant';
                        msgEl.style.cssText = 'font-size:13px;line-height:1.6;';
                        msgEl.innerHTML = text.replace(/\n/g, '<br>');
                        hyleyChat.appendChild(msgEl);
                        hyleyChat.scrollTop = hyleyChat.scrollHeight;
                    }
                } catch(e) {
                    if (hyleyTyping) hyleyTyping.style.display = 'none';
                    if (hyleyChat) {
                        const msgEl = document.createElement('div');
                        msgEl.className = 'hyley-message assistant';
                        msgEl.style.cssText = 'font-size:13px;line-height:1.6;opacity:0.6;';
                        msgEl.textContent = "I couldn't reach the AI right now. Try again in a moment.";
                        hyleyChat.appendChild(msgEl);
                        hyleyChat.scrollTop = hyleyChat.scrollHeight;
                    }
                }
            })();

            // Return sentinel — the async handler will inject the reply directly
            return '__HYLEY_ASYNC__';
        };
    })();



// Expose HyBrowser globally so hybrowser-proxy.js and hyinternet.js can access it
window.HyBrowser = HyBrowser;
window.openWebMaker = function() { openHyInternet('webmaker'); }; // backward compat alias

