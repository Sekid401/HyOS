// ageverify.js — Face-API age verification system
// Shared face-api state — accessible by both the modal and Settings > Age panel
window.MODELS_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model';
window.faceApiLoaded = false;

(function() {
    const MODELS_URL = window.MODELS_URL;
    let videoStream = null;
    let detectionLoop = null;

    window.agvShowStep = function(step) {
        ['intro','camera','result','manual'].forEach(s => {
            document.getElementById('agv-step-' + s).style.display = s === step ? 'block' : 'none';
        });
        if (step !== 'camera') agvStopCamera();
    };

    window.agvManualFallback = function() { agvShowStep('manual'); };

    window.agvStartCamera = async function() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            // Camera unavailable — requires HTTPS or localhost
            document.getElementById('agv-step-intro').style.display = 'none';
            document.getElementById('agv-step-manual').style.display = 'block';
            document.getElementById('age-gate-error').style.display = 'block';
            document.getElementById('age-gate-error').textContent = '⚠️ Camera requires HTTPS. Enter your age manually, or serve this file over HTTPS.';
            return;
        }
        agvShowStep('camera');
        const loadingOverlay = document.getElementById('agv-loading-overlay');
        loadingOverlay.style.display = 'flex';

        // getUserMedia FIRST — must be in the synchronous user gesture stack
        let stream;
        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } });
        } catch (err) {
            loadingOverlay.style.display = 'none';
            const hint = document.getElementById('agv-camera-hint');
            hint.style.color = '#ef4444';
            hint.textContent = err.name === 'NotAllowedError'
                ? '⚠️ Camera permission denied. Please allow access and try again.'
                : '⚠️ Camera error: ' + (err.message || err.name);
            return;
        }

        // Camera granted — now load models
        try {
            if (!window.faceapi) {
                await new Promise((resolve, reject) => {
                    const s = document.createElement('script');
                    s.src = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/dist/face-api.js';
                    s.onload = resolve; s.onerror = reject;
                    document.head.appendChild(s);
                });
            }
            if (!window.faceApiLoaded) {
                await faceapi.nets.tinyFaceDetector.loadFromUri(MODELS_URL);
                await faceapi.nets.ageGenderNet.loadFromUri(MODELS_URL);
                window.faceApiLoaded = true;
            }
            videoStream = stream;
            const video = document.getElementById('agv-video');
            video.srcObject = stream;
            await video.play();
            loadingOverlay.style.display = 'none';
            document.getElementById('agv-scanline').style.display = 'block';
            agvStartDetectionLoop();
        } catch (err) {
            stream.getTracks().forEach(t => t.stop());
            loadingOverlay.style.display = 'none';
            const hint = document.getElementById('agv-camera-hint');
            hint.style.color = '#ef4444';
            hint.textContent = '⚠️ Could not load face models. Check your internet connection.';
        }
    };

    function agvStartDetectionLoop() {
        const video = document.getElementById('agv-video');
        const canvas = document.getElementById('agv-overlay');
        const statusEl = document.getElementById('agv-face-status');
        const scanBtn = document.getElementById('agv-scan-btn');

        detectionLoop = setInterval(async () => {
            if (video.readyState < 2) return;
            try {
                const detection = await faceapi
                    .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
                    .withAgeAndGender();
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                if (detection) {
                    const { x, y, width, height } = detection.detection.box;
                    ctx.strokeStyle = '#0ea5e9';
                    ctx.lineWidth = 3;
                    ctx.shadowColor = '#0ea5e9';
                    ctx.shadowBlur = 14;
                    ctx.strokeRect(x, y, width, height);
                    // Corner accents
                    const c = 18;
                    ctx.lineWidth = 4;
                    [[x,y,c,0,0,c],[x+width,y,-c,0,0,c],[x,y+height,c,0,0,-c],[x+width,y+height,-c,0,0,-c]].forEach(([px,py,dx1,dy1,dx2,dy2]) => {
                        ctx.beginPath(); ctx.moveTo(px+dx1,py+dy1); ctx.lineTo(px,py); ctx.lineTo(px+dx2,py+dy2); ctx.stroke();
                    });
                    statusEl.textContent = '✅ Face detected — click Scan to continue';
                    statusEl.style.color = '#22d3ee';
                    scanBtn.disabled = false;
                    scanBtn.style.opacity = '1';
                } else {
                    statusEl.textContent = '🔍 No face detected — move closer and ensure good lighting';
                    statusEl.style.color = 'rgba(255,255,255,0.35)';
                    scanBtn.disabled = true;
                    scanBtn.style.opacity = '0.4';
                }
            } catch(e) {}
        }, 400);
    }

    function agvStopCamera() {
        if (detectionLoop) { clearInterval(detectionLoop); detectionLoop = null; }
        if (videoStream) { videoStream.getTracks().forEach(t => t.stop()); videoStream = null; }
        const video = document.getElementById('agv-video');
        if (video) video.srcObject = null;
    }

    window.agvCapture = async function() {
        const video = document.getElementById('agv-video');
        const scanBtn = document.getElementById('agv-scan-btn');
        if (detectionLoop) { clearInterval(detectionLoop); detectionLoop = null; }
        scanBtn.disabled = true;
        scanBtn.textContent = 'Analyzing…';
        try {
            const detection = await faceapi
                .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 }))
                .withAgeAndGender();
            agvStopCamera();
            if (!detection) {
                agvShowResult('error', '😕', 'No Face Detected', 'We couldn\'t detect a clear face. Make sure your face is well-lit and centred in the frame.', null);
                return;
            }
            agvShowResult('success', '✅', 'Age Estimated', 'Based on your appearance, we\'ve estimated your age. Content restrictions will be applied accordingly.', Math.round(detection.age));
        } catch(e) {
            agvStopCamera();
            agvShowResult('error', '⚠️', 'Scan Failed', 'Something went wrong during the scan. Please try again or enter your age manually.', null);
        }
    };

    function agvShowResult(type, icon, title, desc, age) {
        agvShowStep('result');
        document.getElementById('agv-result-icon').textContent = icon;
        document.getElementById('agv-result-title').textContent = title;
        document.getElementById('agv-result-desc').textContent = desc;
        const ageDisplay = document.getElementById('agv-age-display');
        const actionsEl = document.getElementById('agv-result-actions');
        if (type === 'success' && age !== null) {
            ageDisplay.style.display = 'block';
            document.getElementById('agv-age-number').textContent = age;
            actionsEl.innerHTML = `
                <button onclick="agvConfirmAge(${age})" style="width:100%;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;padding:15px;border-radius:14px;font-weight:700;font-size:14px;color:white;cursor:pointer;font-family:Outfit,sans-serif;box-shadow:0 4px 20px rgba(14,165,233,0.4);margin-bottom:8px;">Confirm — That's My Age</button>
                <button onclick="agvRetry()" style="width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:13px;border-radius:14px;font-weight:600;font-size:13px;color:rgba(255,255,255,0.6);cursor:pointer;font-family:Outfit,sans-serif;margin-bottom:8px;">Retry Scan</button>
                <button onclick="agvManualFallback()" style="width:100%;background:transparent;border:none;padding:10px;font-weight:500;font-size:12px;color:rgba(255,255,255,0.25);cursor:pointer;font-family:Outfit,sans-serif;">Enter age manually</button>`;
        } else {
            ageDisplay.style.display = 'none';
            actionsEl.innerHTML = `
                <button onclick="agvRetry()" style="width:100%;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;padding:15px;border-radius:14px;font-weight:700;font-size:14px;color:white;cursor:pointer;font-family:Outfit,sans-serif;box-shadow:0 4px 20px rgba(14,165,233,0.4);margin-bottom:8px;">Try Again</button>
                <button onclick="agvManualFallback()" style="width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:13px;border-radius:14px;font-weight:600;font-size:13px;color:rgba(255,255,255,0.6);cursor:pointer;font-family:Outfit,sans-serif;">Enter age manually</button>`;
        }
    }

    window.agvConfirmAge = function(age) {
        userSettings.userAge = age;
        userSettings.ageVerified = true;
        userSettings.faceScanned = true;
        saveSettings();
        document.getElementById('age-gate-modal').style.display = 'none';
        notify('Age Verified', `Welcome! Age estimated at ${age}. Content restrictions applied.`);
        if (document.getElementById('drawer-win')?.style.display !== 'none') {
            setDrawerMode('installed');
        }
    };

    window.agvRetry = function() { agvShowStep('intro'); };
})();

