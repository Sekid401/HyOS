// hyinternet.js — HyInternet: User-made websites browser + Web Maker
// Add to index.html after hybrowser-proxy.js:
//   <script src="js/hyinternet.js"></script>
//
// Also add the HyInternet window HTML to index.html (see bottom of this file for the snippet)

// ════════════════════════════════════════════════════════════════
// WEB MAKER — moved from HyBrowser/taskbar.js
// ════════════════════════════════════════════════════════════════
const WebMaker = {
    elements: [],
    selectedEl: null,
    siteMeta: { title: 'My Website', bgColor: '#ffffff', fontFamily: 'sans-serif' },
    publishedSites: [],
    dragging: null,
    dragOfsX: 0, dragOfsY: 0,

    components: [
        { type: 'heading', label: '📝 Heading',      defaultProps: { text: 'My Heading', fontSize: 32, color: '#1a1a2e', fontWeight: 'bold', x: 60, y: 40 } },
        { type: 'text',    label: '📄 Paragraph',    defaultProps: { text: 'Click to edit this text block.', fontSize: 16, color: '#333', x: 60, y: 100 } },
        { type: 'button',  label: '🔘 Button',       defaultProps: { text: 'Click Me', bgColor: '#2563eb', color: '#fff', borderRadius: 8, fontSize: 14, x: 60, y: 160 } },
        { type: 'image',   label: '🖼️ Image',        defaultProps: { src: 'https://picsum.photos/300/180', width: 300, height: 180, borderRadius: 8, x: 60, y: 220 } },
        { type: 'divider', label: '─ Divider',       defaultProps: { color: '#e0e0e0', width: 400, x: 60, y: 420 } },
        { type: 'card',    label: '🃏 Card',         defaultProps: { text: 'Card content goes here', bgColor: '#f8f9ff', borderRadius: 12, padding: 20, x: 60, y: 460 } },
        { type: 'nav',     label: '🗺️ Navbar',       defaultProps: { title: 'My Site', links: 'Home, About, Contact', bgColor: '#1a1a2e', color: '#fff', x: 0, y: 0, width: '100%' } },
        { type: 'hero',    label: '⭐ Hero Section', defaultProps: { title: 'Welcome!', subtitle: 'Your amazing website starts here.', bgColor: '#0f172a', color: '#fff', x: 0, y: 50 } },
    ],

    open(container) {
        try { this.publishedSites = JSON.parse(localStorage.getItem('hyos_websites') || '[]'); } catch(e) { this.publishedSites = []; }
        this.render(container);
    },

    render(container) {
        container.innerHTML = `
        <div style="display:flex;flex-direction:column;width:200px;flex-shrink:0;background:#070d1a;border-right:1px solid rgba(255,255,255,0.07);overflow-y:auto;">
            <div style="padding:12px;border-bottom:1px solid rgba(255,255,255,0.07);">
                <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;opacity:0.5;margin-bottom:8px;">Site Settings</div>
                <input id="wm-title" value="${this.siteMeta.title}" placeholder="Site title"
                    style="width:100%;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:6px 8px;color:#fff;font-size:12px;box-sizing:border-box;margin-bottom:6px;outline:none;"
                    oninput="WebMaker.siteMeta.title=this.value">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                    <span style="font-size:11px;opacity:0.6;white-space:nowrap;">BG Color</span>
                    <input type="color" id="wm-bgcolor" value="${this.siteMeta.bgColor}"
                        style="flex:1;height:26px;border-radius:6px;border:none;cursor:pointer;background:transparent;"
                        oninput="WebMaker.siteMeta.bgColor=this.value;document.getElementById('wm-canvas').style.background=this.value">
                </div>
                <div style="display:flex;gap:6px;">
                    <button onclick="WebMaker.preview()" style="flex:1;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.1);padding:6px;border-radius:7px;color:#fff;font-size:11px;font-weight:700;cursor:pointer;">Preview</button>
                    <button onclick="WebMaker.publish()" style="flex:1;background:var(--blue-600,#2563eb);border:none;padding:6px;border-radius:7px;color:#fff;font-size:11px;font-weight:700;cursor:pointer;">Publish ↑</button>
                </div>
            </div>
            <div style="padding:12px;">
                <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;opacity:0.5;margin-bottom:8px;">Components</div>
                <div style="display:flex;flex-direction:column;gap:5px;">
                    ${this.components.map(c => `
                        <div class="wb-palette-item" onclick="WebMaker.addComponent('${c.type}')">${c.label}</div>
                    `).join('')}
                </div>
            </div>
            ${this.publishedSites.length ? `
            <div style="padding:12px;border-top:1px solid rgba(255,255,255,0.07);">
                <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;opacity:0.5;margin-bottom:8px;">My Sites</div>
                ${this.publishedSites.slice(-5).map(s => `
                    <div onclick="WebMaker.openPublished('${s.id}')"
                        style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:8px;padding:8px;margin-bottom:4px;cursor:pointer;font-size:11px;transition:0.15s;"
                        onmouseover="this.style.background='rgba(37,99,235,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.04)'">
                        <div style="font-weight:600;">${s.title}</div>
                        <div style="opacity:0.4;font-size:10px;margin-top:2px;">${s.date}</div>
                    </div>
                `).join('')}
            </div>` : ''}
        </div>
        <div style="flex:1;overflow:auto;background:#1a1a2e;display:flex;align-items:flex-start;justify-content:center;padding:24px;">
            <div id="wm-canvas" class="wb-canvas"
                style="width:900px;min-height:500px;background:${this.siteMeta.bgColor};border-radius:8px;position:relative;box-shadow:0 8px 40px rgba(0,0,0,0.5);"
                onclick="WebMaker.deselect()"></div>
        </div>
        <div id="wm-props" style="width:200px;flex-shrink:0;background:#070d1a;border-left:1px solid rgba(255,255,255,0.07);padding:14px;overflow-y:auto;">
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;opacity:0.5;margin-bottom:10px;">Properties</div>
            <div id="wm-props-content" style="font-size:12px;color:rgba(255,255,255,0.5);">Select an element to edit its properties.</div>
        </div>`;

        this.elements.forEach(el => this.renderElement(el));
        this.setupCanvasDrag();
    },

    addComponent(type) {
        const comp = this.components.find(c => c.type === type);
        if (!comp) return;
        const el = { id: 'we_' + Date.now(), type, ...JSON.parse(JSON.stringify(comp.defaultProps)) };
        this.elements.push(el);
        this.renderElement(el);
        this.selectEl(el.id);
    },

    renderElement(el) {
        const canvas = document.getElementById('wm-canvas');
        if (!canvas) return;
        const old = document.getElementById(el.id);
        if (old) old.remove();
        const div = document.createElement('div');
        div.id = el.id;
        div.className = 'wb-el';
        div.style.cssText = `left:${el.x||0}px;top:${el.y||0}px;`;
        div.innerHTML = this.renderElContent(el);
        div.onclick = (e) => { e.stopPropagation(); this.selectEl(el.id); };
        div.onmousedown = (e) => { if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') this.startDrag(e, el.id); };
        canvas.appendChild(div);
    },

    renderElContent(el) {
        switch(el.type) {
            case 'heading': return `<div contenteditable="true" style="font-size:${el.fontSize||32}px;color:${el.color||'#1a1a2e'};font-weight:${el.fontWeight||'bold'};outline:none;min-width:100px;" onblur="WebMaker.updateProp('${el.id}','text',this.textContent)">${el.text||'Heading'}</div>`;
            case 'text':    return `<div contenteditable="true" style="font-size:${el.fontSize||16}px;color:${el.color||'#333'};min-width:200px;min-height:24px;outline:none;max-width:600px;line-height:1.6;" onblur="WebMaker.updateProp('${el.id}','text',this.textContent)">${el.text||'Paragraph'}</div>`;
            case 'button':  return `<button style="background:${el.bgColor||'#2563eb'};color:${el.color||'#fff'};border:none;border-radius:${el.borderRadius||8}px;padding:10px 20px;font-size:${el.fontSize||14}px;cursor:pointer;font-weight:600;">${el.text||'Button'}</button>`;
            case 'image':   return `<img src="${el.src}" style="width:${el.width||300}px;height:${el.height||180}px;border-radius:${el.borderRadius||8}px;object-fit:cover;display:block;">`;
            case 'divider': return `<hr style="border:none;border-top:2px solid ${el.color||'#e0e0e0'};width:${el.width||400}px;margin:0;">`;
            case 'card':    return `<div style="background:${el.bgColor||'#f8f9ff'};border-radius:${el.borderRadius||12}px;padding:${el.padding||20}px;min-width:280px;box-shadow:0 4px 20px rgba(0,0,0,0.08);">${el.text||'Card content'}</div>`;
            case 'nav':     return `<nav style="background:${el.bgColor||'#1a1a2e'};color:${el.color||'#fff'};padding:14px 24px;display:flex;align-items:center;justify-content:space-between;width:900px;box-sizing:border-box;"><span style="font-weight:700;font-size:16px;">${el.title||'My Site'}</span><div style="display:flex;gap:20px;font-size:13px;">${(el.links||'Home,About').split(',').map(l=>`<span style="cursor:pointer;opacity:0.8;">${l.trim()}</span>`).join('')}</div></nav>`;
            case 'hero':    return `<div style="background:${el.bgColor||'#0f172a'};color:${el.color||'#fff'};padding:60px 40px;text-align:center;width:900px;box-sizing:border-box;"><h1 style="font-size:40px;font-weight:900;margin:0 0 16px;">${el.title||'Welcome!'}</h1><p style="font-size:16px;opacity:0.7;margin:0;">${el.subtitle||'Subtitle here'}</p></div>`;
            default:        return `<div style="padding:10px;background:#eee;border-radius:4px;font-size:12px;">[${el.type}]</div>`;
        }
    },

    selectEl(id) {
        document.querySelectorAll('.wb-el').forEach(el => el.classList.remove('selected'));
        const el = document.getElementById(id);
        if (el) el.classList.add('selected');
        this.selectedEl = id;
        const data = this.elements.find(e => e.id === id);
        if (data) this.showProps(data);
    },

    deselect() {
        document.querySelectorAll('.wb-el').forEach(el => el.classList.remove('selected'));
        this.selectedEl = null;
        const p = document.getElementById('wm-props-content');
        if (p) p.innerHTML = '<div style="opacity:0.5;">Select an element to edit its properties.</div>';
    },

    showProps(el) {
        const propFields = {
            text:         ['heading','text','button','card'],
            color:        ['heading','text'],
            bgColor:      ['button','card','nav','hero'],
            fontSize:     ['heading','text','button'],
            borderRadius: ['button','image','card'],
            src:          ['image'],
            title:        ['nav','hero'],
            subtitle:     ['hero'],
            links:        ['nav'],
        };
        let html = `<div style="font-size:11px;font-weight:600;color:#93c5fd;margin-bottom:12px;text-transform:capitalize;">${el.type} Element</div>`;
        Object.entries(propFields).forEach(([prop, types]) => {
            if (!types.includes(el.type)) return;
            const val = el[prop] || '';
            html += `<div style="margin-bottom:10px;">
                <div style="font-size:10px;opacity:0.5;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;">${prop}</div>
                ${prop.includes('Color') || prop.includes('color')
                    ? `<input type="color" value="${val||'#000000'}" style="width:100%;height:28px;border-radius:6px;border:none;cursor:pointer;" onchange="WebMaker.updateProp('${el.id}','${prop}',this.value)">`
                    : `<input type="text" value="${val}" style="width:100%;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:7px;padding:5px 8px;color:#fff;font-size:11px;outline:none;box-sizing:border-box;" oninput="WebMaker.updateProp('${el.id}','${prop}',this.value)">`
                }
            </div>`;
        });
        html += `<div style="margin-top:12px;">
            <button onclick="WebMaker.deleteEl('${el.id}')" style="width:100%;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);padding:7px;border-radius:8px;color:#fca5a5;font-size:11px;font-weight:700;cursor:pointer;">Delete Element</button>
        </div>`;
        const p = document.getElementById('wm-props-content');
        if (p) p.innerHTML = html;
    },

    updateProp(id, prop, value) {
        const el = this.elements.find(e => e.id === id);
        if (!el) return;
        el[prop] = value;
        this.renderElement(el);
        this.selectEl(id);
    },

    deleteEl(id) {
        this.elements = this.elements.filter(e => e.id !== id);
        const domEl = document.getElementById(id);
        if (domEl) domEl.remove();
        this.selectedEl = null;
        const p = document.getElementById('wm-props-content');
        if (p) p.innerHTML = '<div style="opacity:0.5;">Select an element to edit its properties.</div>';
    },

    startDrag(e, id) {
        const el = document.getElementById(id);
        if (!el) return;
        this.dragging = id;
        this.dragOfsX = e.clientX - el.offsetLeft;
        this.dragOfsY = e.clientY - el.offsetTop;
        document.onmousemove = (ev) => {
            if (!this.dragging) return;
            const canvas = document.getElementById('wm-canvas');
            const target = document.getElementById(this.dragging);
            if (!target || !canvas) return;
            const x = Math.max(0, ev.clientX - this.dragOfsX);
            const y = Math.max(0, ev.clientY - this.dragOfsY);
            target.style.left = x + 'px';
            target.style.top  = y + 'px';
        };
        document.onmouseup = () => {
            if (this.dragging) {
                const target = document.getElementById(this.dragging);
                const data = this.elements.find(e => e.id === this.dragging);
                if (target && data) { data.x = target.offsetLeft; data.y = target.offsetTop; }
            }
            this.dragging = null;
            document.onmousemove = null;
            document.onmouseup = null;
        };
        e.preventDefault();
    },

    setupCanvasDrag() {},

    generateHTML() {
        const body = this.elements.map(el => {
            const domEl = document.getElementById(el.id);
            if (!domEl) return '';
            const clone = domEl.cloneNode(true);
            clone.removeAttribute('id');
            clone.classList.remove('wb-el', 'selected');
            clone.style.position = 'absolute';
            return clone.outerHTML;
        }).join('\n');
        return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${this.siteMeta.title}</title>
    <style>body{margin:0;font-family:${this.siteMeta.fontFamily};background:${this.siteMeta.bgColor};}*{box-sizing:border-box;}</style>
</head>
<body style="position:relative;min-height:600px;">${body}</body>
</html>`;
    },

    preview() {
        const html = this.generateHTML();
        const blob = new Blob([html], { type: 'text/html' });
        window.open(URL.createObjectURL(blob), '_blank');
        if (typeof notify !== 'undefined') notify('Web Maker', 'Preview opened in new window');
    },

    publish() {
        const id = 'site_' + Date.now();
        const site = {
            id,
            title:    this.siteMeta.title || 'Untitled Site',
            html:     this.generateHTML(),
            date:     new Date().toLocaleDateString(),
            elements: JSON.parse(JSON.stringify(this.elements)),
            meta:     JSON.parse(JSON.stringify(this.siteMeta))
        };
        this.publishedSites.push(site);
        localStorage.setItem('hyos_websites', JSON.stringify(this.publishedSites));
        if (typeof notify !== 'undefined') notify('Web Maker', `"${site.title}" published! ✓`);
        HyInternet.renderSites(); // refresh site list in browse tab
        // Re-render sidebar to show new site
        const container = document.getElementById('hyinternet-webmaker');
        if (container) this.render(container);
    },

    openPublished(id) {
        const site = this.publishedSites.find(s => s.id === id);
        if (!site) return;
        // Open in HyInternet browse tab
        HyInternet.viewSite(site);
    }
};

window.WebMaker = WebMaker;

// ════════════════════════════════════════════════════════════════
// HYINTERNET — User-made websites browser
// ════════════════════════════════════════════════════════════════
const HyInternet = {
    currentTab: 'browse', // 'browse' | 'webmaker'

    init() {
        this.renderTabs();
        this.showTab('browse');
    },

    renderTabs() {
        const tabBar = document.getElementById('hyinternet-tabs');
        if (!tabBar) return;
        tabBar.innerHTML = `
            <button id="hi-tab-browse"   onclick="HyInternet.showTab('browse')"
                style="padding:7px 18px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:0.15s;background:rgba(14,165,233,0.15);color:#7dd3fc;border-bottom:2px solid #0ea5e9;">
                🌐 Browse
            </button>
            <button id="hi-tab-webmaker" onclick="HyInternet.showTab('webmaker')"
                style="padding:7px 18px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:0.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;">
                ✦ Web Maker
            </button>`;
    },

    showTab(tab) {
        this.currentTab = tab;
        // Update tab styles
        ['browse','webmaker'].forEach(t => {
            const btn  = document.getElementById('hi-tab-' + t);
            const body = document.getElementById('hyinternet-' + t);
            if (btn) {
                btn.style.background   = t === tab ? 'rgba(14,165,233,0.15)' : 'transparent';
                btn.style.color        = t === tab ? '#7dd3fc' : 'rgba(255,255,255,0.4)';
                btn.style.borderBottom = t === tab ? '2px solid #0ea5e9' : '2px solid transparent';
            }
            if (body) body.style.display = t === tab ? 'flex' : 'none';
        });

        if (tab === 'browse')    this.renderSites();
        if (tab === 'webmaker')  {
            const container = document.getElementById('hyinternet-webmaker');
            if (container) WebMaker.open(container);
        }
    },

    renderSites() {
        const grid = document.getElementById('hyinternet-sites-grid');
        const viewer = document.getElementById('hyinternet-viewer');
        if (!grid) return;

        let sites = [];
        try { sites = JSON.parse(localStorage.getItem('hyos_websites') || '[]'); } catch(e) {}

        if (viewer) viewer.style.display = 'none';
        grid.style.display = 'grid';

        if (!sites.length) {
            grid.innerHTML = `
                <div style="grid-column:1/-1;text-align:center;padding:60px 20px;opacity:0.35;">
                    <div style="font-size:48px;margin-bottom:16px;">🌐</div>
                    <div style="font-size:14px;font-weight:700;margin-bottom:8px;">No sites yet</div>
                    <div style="font-size:12px;">Build your first site in the <strong>✦ Web Maker</strong> tab!</div>
                </div>`;
            return;
        }

        grid.innerHTML = sites.slice().reverse().map(s => `
            <div onclick="HyInternet.viewSite(${JSON.stringify(s).replace(/"/g,'&quot;')})"
                style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden;cursor:pointer;transition:0.2s;"
                onmouseover="this.style.borderColor='rgba(14,165,233,0.4)';this.style.transform='translateY(-2px)'"
                onmouseout="this.style.borderColor='rgba(255,255,255,0.07)';this.style.transform=''">
                <div style="height:120px;background:#1a1a2e;overflow:hidden;position:relative;">
                    <iframe srcdoc="${s.html.replace(/"/g,'&quot;')}" style="width:200%;height:200%;transform:scale(0.5);transform-origin:0 0;pointer-events:none;border:none;" scrolling="no"></iframe>
                </div>
                <div style="padding:12px;">
                    <div style="font-size:13px;font-weight:700;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${s.title}</div>
                    <div style="font-size:10px;opacity:0.4;">${s.date}</div>
                </div>
            </div>`).join('');
    },

    viewSite(site) {
        const grid   = document.getElementById('hyinternet-sites-grid');
        const viewer = document.getElementById('hyinternet-viewer');
        const iframe = document.getElementById('hyinternet-view-iframe');
        const title  = document.getElementById('hyinternet-view-title');
        if (!viewer || !iframe) return;
        if (grid)  grid.style.display   = 'none';
        viewer.style.display = 'flex';
        if (title) title.textContent = site.title;
        iframe.srcdoc = site.html;
    },

    backToGrid() {
        const grid   = document.getElementById('hyinternet-sites-grid');
        const viewer = document.getElementById('hyinternet-viewer');
        if (grid)   grid.style.display   = 'grid';
        if (viewer) viewer.style.display = 'none';
    }
};

window.HyInternet = HyInternet;

// ── Open / toggle HyInternet window ─────────────────────────────
window.openHyInternet = function(tab) {
    const win = document.getElementById('hyinternet-win');
    if (!win) { console.error('[HyInternet] Window element #hyinternet-win not found in index.html'); return; }
    if (!HyInternet._initialized) {
        HyInternet.init();
        HyInternet._initialized = true;
    }
    if (win.style.display !== 'flex') {
        win.style.display = 'flex';
        if (typeof bringToFront === 'function') bringToFront('hyinternet-win');
        else win.style.zIndex = 600;
    } else {
        win.style.zIndex = parseInt(win.style.zIndex || 600) + 1;
    }
    if (tab) HyInternet.showTab(tab);
};

// Backward-compat alias
window.openWebMaker = function() { openHyInternet('webmaker'); };

console.log('[HyInternet] Loaded — WebMaker + user sites browser ready');

/*
════════════════════════════════════════════════════════════════════
  ADD THIS WINDOW HTML TO index.html  (before </body>)
  Place it after the existing HyBrowser window block.
════════════════════════════════════════════════════════════════════

    <!-- HyInternet Window -->
    <div id="hyinternet-win" class="window" style="width:1100px;height:740px;left:50%;top:50%;transform:translate(-50%,-50%);display:none;">
        <div class="win-header" style="background:linear-gradient(135deg,rgba(14,165,233,0.12),rgba(10,15,30,0.99));">
            <div style="display:flex;align-items:center;gap:8px;">
                <span style="font-size:16px;">🌐</span>
                <span class="font-bold text-sm">HyInternet</span>
            </div>
            <div id="hyinternet-tabs" style="display:flex;align-items:flex-end;gap:2px;flex:1;padding:0 12px;overflow-x:auto;scrollbar-width:none;"></div>
            <div style="display:flex;gap:4px;">
                <button onclick="minWin('hyinternet-win')" class="hover:bg-white/10 px-3 py-1 rounded" style="font-size:14px;">−</button>
                <button onclick="maxWin('hyinternet-win')" class="hover:bg-white/10 px-3 py-1 rounded" style="font-size:12px;">⛶</button>
                <button onclick="closeApp('hyinternet-win')" class="hover:bg-red-600 px-3 py-1 rounded" style="font-size:14px;">✕</button>
            </div>
        </div>
        <div class="win-body" style="padding:0;overflow:hidden;display:flex;flex-direction:column;">

            <!-- Browse Tab Body -->
            <div id="hyinternet-browse" style="flex:1;overflow:hidden;flex-direction:column;display:flex;">
                <!-- Back bar (shown when viewing a site) -->
                <div id="hyinternet-viewer" style="display:none;flex-direction:column;flex:1;">
                    <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;background:rgba(255,255,255,0.03);border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0;">
                        <button onclick="HyInternet.backToGrid()"
                            style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:white;padding:5px 12px;border-radius:8px;cursor:pointer;font-size:12px;font-weight:700;">← Back</button>
                        <span id="hyinternet-view-title" style="font-size:13px;font-weight:700;opacity:0.8;"></span>
                    </div>
                    <iframe id="hyinternet-view-iframe" style="flex:1;border:none;background:#fff;" sandbox="allow-scripts allow-same-origin allow-forms"></iframe>
                </div>
                <!-- Sites grid -->
                <div id="hyinternet-sites-grid"
                    style="flex:1;overflow-y:auto;padding:20px;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;align-content:start;"></div>
            </div>

            <!-- Web Maker Tab Body -->
            <div id="hyinternet-webmaker" style="flex:1;overflow:hidden;flex-direction:row;display:none;"></div>

        </div>
    </div>

════════════════════════════════════════════════════════════════════
  ADD THIS SCRIPT TAG to index.html after hybrowser-proxy.js:
    <script src="js/hyinternet.js"></script>
════════════════════════════════════════════════════════════════════
*/
