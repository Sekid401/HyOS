// FBSB.js — Firebase & Supabase backend for HyOS HS
// With full IndexedDB offline sync layer
// Reads: IndexedDB first, cloud fallback. Writes: cloud + IndexedDB simultaneously.
// Realtime: Supabase subscriptions auto-mirror changes to IndexedDB.
// Write queue: offline writes are queued and flushed when back online.

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import {
    getFirestore, collection, addDoc, getDocs, updateDoc, deleteDoc,
    doc, getDoc, setDoc, serverTimestamp, onSnapshot, query, where,
    orderBy, arrayUnion, arrayRemove, increment
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// ── FIREBASE ──────────────────────────────────────────────────────────
const firebaseConfig = {
    apiKey: "AIzaSyBUTO3ELOt57fHjDEBlf921b6-HnDM4mTI",
    authDomain: "hyano-6a7f5.firebaseapp.com",
    projectId: "hyano-6a7f5",
    storageBucket: "hyano-6a7f5.firebasestorage.app",
    messagingSenderId: "64379606980",
    appId: "1:64379606980:web:c75d54657a46a92f90f691",
    measurementId: "G-26C13TV8HP"
};

let app, db;
let firebaseInitialized = false;

try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    firebaseInitialized = true;
    console.log("Firebase initialized successfully");
} catch (error) {
    console.error("Firebase initialization error:", error);
}

// ── SUPABASE ──────────────────────────────────────────────────────────
const SUPABASE_URL = 'https://xmezsrwaqqayvtulrhrp.supabase.co';
const SUPABASE_KEY = 'sb_publishable_LrvIsdLnXuDBOTGg0WEpoA_xDW7jjDf';

let supabase = null;
let supabaseInitialized = false;

try {
    const { createClient } = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    supabaseInitialized = true;
    console.log('Supabase initialized successfully');

    // Keep-alive: ping every 2 hours
    setInterval(async () => {
        try {
            await Promise.all([
                supabase.from('global_apps').select('id').limit(1),
                supabase.from('installed').select('id').limit(1),
                supabase.from('users').select('username').limit(1),
            ]);
        } catch(e) { console.warn('[Supabase] Keep-alive failed:', e); }
    }, 2 * 60 * 60 * 1000);
} catch(e) {
    console.error('Supabase initialization error:', e);
}

// ══════════════════════════════════════════════════════════════════════
// BACKEND PREFERENCE SELECTOR
// ══════════════════════════════════════════════════════════════════════
// Allows users to choose which backend to prefer: 'auto' | 'supabase' | 'firebase'

window.HyBackend = {
    getPreference() {
        return localStorage.getItem('hyos_backend_pref') || 'auto';
    },
    setPreference(pref) {
        localStorage.setItem('hyos_backend_pref', pref);
        window.dispatchEvent(new CustomEvent('hyos-backend-changed', { detail: { pref } }));
        if (typeof notify === 'function') notify('⚙️ Backend', `Now using: ${pref === 'auto' ? 'Auto (Supabase → Firebase)' : pref === 'supabase' ? 'Supabase' : 'Firebase'}`);
    },
    // Returns true if Supabase should be used (respects preference + availability)
    useSupabase() {
        const p = this.getPreference();
        if (p === 'firebase') return false;
        return supabaseInitialized;
    },
    // Returns true if Firebase should be used
    useFirebase() {
        const p = this.getPreference();
        if (p === 'supabase') return false;
        return firebaseInitialized;
    },
    status() {
        return {
            firebase:   { available: firebaseInitialized,   label: 'Firebase',   pref: this.getPreference() === 'firebase' },
            supabase:   { available: supabaseInitialized,   label: 'Supabase',   pref: this.getPreference() === 'supabase' },
            preference: this.getPreference(),
            active:     this.useSupabase() ? 'supabase' : (this.useFirebase() ? 'firebase' : 'none')
        };
    }
};

// ══════════════════════════════════════════════════════════════════════
// INDEXEDDB SYNC LAYER
// ══════════════════════════════════════════════════════════════════════
const IDB_NAME    = 'hyos_cache';
const IDB_VERSION = 1;

let idb = null;

async function openIDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(IDB_NAME, IDB_VERSION);
        req.onupgradeneeded = e => {
            const d = e.target.result;
            if (!d.objectStoreNames.contains('users'))       d.createObjectStore('users',       { keyPath: 'username' });
            if (!d.objectStoreNames.contains('global_apps')) d.createObjectStore('global_apps', { keyPath: 'id' });
            if (!d.objectStoreNames.contains('installed'))   d.createObjectStore('installed',   { keyPath: 'id' });
            if (!d.objectStoreNames.contains('appspace'))    d.createObjectStore('appspace',    { keyPath: '_path' });
            if (!d.objectStoreNames.contains('write_queue')) d.createObjectStore('write_queue', { keyPath: '_qid', autoIncrement: true });
        };
        req.onsuccess = e => resolve(e.target.result);
        req.onerror   = e => reject(e.target.error);
    });
}

function idbGet(store, key) {
    return new Promise((resolve, reject) => {
        const req = idb.transaction(store, 'readonly').objectStore(store).get(key);
        req.onsuccess = () => resolve(req.result ?? null);
        req.onerror   = () => reject(req.error);
    });
}
function idbGetAll(store) {
    return new Promise((resolve, reject) => {
        const req = idb.transaction(store, 'readonly').objectStore(store).getAll();
        req.onsuccess = () => resolve(req.result ?? []);
        req.onerror   = () => reject(req.error);
    });
}
function idbPut(store, value) {
    return new Promise((resolve, reject) => {
        const req = idb.transaction(store, 'readwrite').objectStore(store).put(value);
        req.onsuccess = () => resolve(req.result);
        req.onerror   = () => reject(req.error);
    });
}
function idbDelete(store, key) {
    return new Promise((resolve, reject) => {
        const req = idb.transaction(store, 'readwrite').objectStore(store).delete(key);
        req.onsuccess = () => resolve();
        req.onerror   = () => reject(req.error);
    });
}
function idbClear(store) {
    return new Promise((resolve, reject) => {
        const req = idb.transaction(store, 'readwrite').objectStore(store).clear();
        req.onsuccess = () => resolve();
        req.onerror   = () => reject(req.error);
    });
}

// ── WRITE QUEUE ───────────────────────────────────────────────────────
async function enqueueWrite(op) {
    try { await idbPut('write_queue', { ...op, _queued: Date.now() }); }
    catch(e) { console.warn('[IDB] enqueueWrite failed:', e); }
}

async function flushWriteQueue() {
    if (!navigator.onLine) return;
    let queue;
    try { queue = await idbGetAll('write_queue'); } catch(e) { return; }
    if (!queue.length) return;
    console.log(`[FBSB] Flushing ${queue.length} queued write(s)`);

    for (const op of queue) {
        try {
            if (op.store === 'users' && supabaseInitialized) {
                await supabase.from('users').upsert(op.payload, { onConflict: 'username' });
            } else if (op.store === 'global_apps' && supabaseInitialized) {
                if      (op.action === 'delete') await supabase.from('global_apps').delete().eq('id', op.key);
                else if (op.action === 'insert') await supabase.from('global_apps').insert(op.payload);
                else                             await supabase.from('global_apps').update(op.payload).eq('id', op.key);
            } else if (op.store === 'installed' && supabaseInitialized) {
                if (op.action === 'delete') await supabase.from('installed').delete().eq('id', op.key);
                else                        await supabase.from('installed').insert(op.payload);
            } else if (op.store === 'appspace' && supabaseInitialized) {
                if (op.action === 'delete') {
                    await supabase.storage.from('appspace').remove([op.key]);
                } else {
                    const blob = new Blob([JSON.stringify(op.payload.data, null, 2)], { type: 'application/json' });
                    await supabase.storage.from('appspace').upload(op.payload._path, blob, { upsert: true });
                }
            }
            await idbDelete('write_queue', op._qid);
        } catch(e) {
            console.warn('[FBSB] Flush failed for op:', op, e);
        }
    }
    console.log('[FBSB] Write queue flushed');
}

window.addEventListener('online',  () => { console.log('[FBSB] Back online — flushing queue'); flushWriteQueue(); });
window.addEventListener('offline', () => console.log('[FBSB] Offline — writes will be queued in IDB'));

// ── FULL SYNC: pull all cloud data into IDB after login ───────────────
async function syncAllToIDB(username) {
    if (!navigator.onLine) { console.log('[FBSB] Offline — skipping full sync'); return; }
    console.log('[FBSB] Full sync starting...');
    try {
        if (supabaseInitialized && username) {
            const { data: user } = await supabase.from('users').select('*').eq('username', username).single();
            if (user) await idbPut('users', user).catch(()=>{});
        }
        if (supabaseInitialized) {
            const { data: apps } = await supabase.from('global_apps').select('*');
            if (apps) {
                await idbClear('global_apps').catch(()=>{});
                for (const row of apps) await idbPut('global_apps', row).catch(()=>{});
            }
        }
        if (supabaseInitialized && username) {
            const { data: installed } = await supabase.from('installed').select('*').eq('owner', username);
            if (installed) {
                for (const row of installed) await idbPut('installed', row).catch(()=>{});
            }
        }
        console.log('[FBSB] Full sync complete');
    } catch(e) {
        console.warn('[FBSB] Full sync error:', e);
    }
}

window.hyosSyncToIDB = syncAllToIDB;

// ── REALTIME SUBSCRIPTIONS ────────────────────────────────────────────
function setupRealtimeSync() {
    if (!supabaseInitialized) return;
    supabase.channel('hyos-idb-sync')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'global_apps' }, async ({ eventType, old: o, new: n }) => {
            try {
                if (eventType === 'DELETE') await idbDelete('global_apps', o.id);
                else                        await idbPut('global_apps', n);
                console.log('[FBSB RT] global_apps →', eventType);
            } catch(e) { console.warn('[FBSB RT] global_apps IDB write failed:', e); }
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'installed' }, async ({ eventType, old: o, new: n }) => {
            try {
                if (eventType === 'DELETE') await idbDelete('installed', o.id);
                else                        await idbPut('installed', n);
                console.log('[FBSB RT] installed →', eventType);
            } catch(e) { console.warn('[FBSB RT] installed IDB write failed:', e); }
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, async ({ eventType, new: n }) => {
            try {
                if (eventType !== 'DELETE') await idbPut('users', n);
                console.log('[FBSB RT] users →', eventType);
            } catch(e) { console.warn('[FBSB RT] users IDB write failed:', e); }
        })
        .subscribe(status => console.log('[FBSB RT] status:', status));
}

// ── OPEN IDB + BOOT ───────────────────────────────────────────────────
try {
    idb = await openIDB();
    console.log('[FBSB] IndexedDB ready');
    setupRealtimeSync();
    flushWriteQueue();
} catch(e) {
    console.error('[FBSB] IndexedDB failed to open:', e);
}

// ══════════════════════════════════════════════════════════════════════
// SUPABASE APPSPACE (with IDB cache)
// ══════════════════════════════════════════════════════════════════════
window._appspaceCollection = 'appspace';
window.SUPABASE_URL = SUPABASE_URL;
window.SUPABASE_KEY = SUPABASE_KEY;

window.supabaseAppspace = {
    bucket: 'appspace',
    LIMIT_BYTES: 700 * 1024,
    _path(appName, colName, docName) {
        const s = appName.replace(/[^a-zA-Z0-9_-]/g, '_');
        if (docName) return `${s}/${colName}/${docName}.json`;
        if (colName) return `${s}/${colName}/`;
        return `${s}/`;
    },
    async getUsage(appName) {
        if (!supabaseInitialized) return { bytes: 0, error: 'not initialized' };
        const s = appName.replace(/[^a-zA-Z0-9_-]/g, '_');
        try {
            const { data: cols } = await supabase.storage.from(this.bucket).list(s);
            let total = 0;
            for (const col of (cols || []).filter(c => !c.name.includes('.'))) {
                const { data: docs } = await supabase.storage.from(this.bucket).list(`${s}/${col.name}/`);
                (docs || []).forEach(d => { total += d.metadata?.size || 0; });
            }
            return { bytes: total, error: null };
        } catch(e) { return { bytes: 0, error: e }; }
    },
    async writeDoc(appName, colName, docName, data) {
        const path = this._path(appName, colName, docName);
        if (idb) await idbPut('appspace', { _path: path, appName, colName, docName, data, _updated: Date.now() }).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'appspace', action: 'put', payload: { _path: path, data } });
            return { error: null };
        }
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const { error } = await supabase.storage.from(this.bucket).upload(path, blob, { upsert: true });
        return { error };
    },
    async readDoc(appName, colName, docName) {
        const path = this._path(appName, colName, docName);
        if (idb) {
            try { const c = await idbGet('appspace', path); if (c) return { data: c.data, error: null }; }
            catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: null, error: 'offline' };
        const { data, error } = await supabase.storage.from(this.bucket).download(path);
        if (error || !data) return { data: null, error };
        try {
            const parsed = JSON.parse(await data.text());
            if (idb) await idbPut('appspace', { _path: path, appName, colName, docName, data: parsed, _updated: Date.now() }).catch(()=>{});
            return { data: parsed, error: null };
        } catch(e) { return { data: null, error: e }; }
    },
    async listDocs(appName, colName) {
        if (idb) {
            try {
                const all = await idbGetAll('appspace');
                const prefix = `${appName.replace(/[^a-zA-Z0-9_-]/g, '_')}/${colName}/`;
                const local = all.filter(e => e._path.startsWith(prefix) && e._path.endsWith('.json')).map(e => e.docName);
                if (local.length) return { data: local, error: null };
            } catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: [], error: 'offline' };
        const s = appName.replace(/[^a-zA-Z0-9_-]/g, '_');
        const { data, error } = await supabase.storage.from(this.bucket).list(`${s}/${colName}/`);
        if (error) return { data: [], error };
        return { data: (data || []).filter(f => f.name.endsWith('.json')).map(f => f.name.replace('.json', '')), error: null };
    },
    async listCollections(appName) {
        if (idb) {
            try {
                const all = await idbGetAll('appspace');
                const prefix = `${appName.replace(/[^a-zA-Z0-9_-]/g, '_')}/`;
                const cols = [...new Set(all.filter(e => e._path.startsWith(prefix)).map(e => e.colName))].filter(Boolean);
                if (cols.length) return { data: cols, error: null };
            } catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: [], error: 'offline' };
        const s = appName.replace(/[^a-zA-Z0-9_-]/g, '_');
        const { data, error } = await supabase.storage.from(this.bucket).list(s);
        if (error) return { data: [], error };
        return { data: (data || []).filter(f => !f.name.includes('.')).map(f => f.name), error: null };
    },
    async deleteDoc(appName, colName, docName) {
        const path = this._path(appName, colName, docName);
        if (idb) await idbDelete('appspace', path).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'appspace', action: 'delete', key: path, payload: { _path: path } });
            return { error: null };
        }
        const { error } = await supabase.storage.from(this.bucket).remove([path]);
        return { error };
    }
};

// ══════════════════════════════════════════════════════════════════════
// SUPABASE DB: USERS (with IDB cache)
// ══════════════════════════════════════════════════════════════════════
window.sbUsers = {
    async get(username) {
        if (idb) {
            try { const c = await idbGet('users', username); if (c) return { data: c, error: null }; }
            catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: null, error: 'offline' };
        const { data, error } = await supabase.from('users').select('*').eq('username', username).single();
        if (error && error.code !== 'PGRST116') console.error('[sbUsers.get]', error);
        if (data && idb) await idbPut('users', data).catch(()=>{});
        return { data: data || null, error };
    },
    async upsert(username, fields) {
        const payload = { username, ...fields };
        if (idb) await idbPut('users', payload).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'users', action: 'upsert', payload });
            return { error: null };
        }
        const { error } = await supabase.from('users').upsert(payload, { onConflict: 'username' });
        if (error) console.error('[sbUsers.upsert]', error);
        return { error };
    },
    async updateLastLogin(username) {
        const patch = { last_login: new Date().toISOString() };
        if (idb) {
            try { const c = await idbGet('users', username); if (c) await idbPut('users', { ...c, ...patch }); }
            catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return;
        await supabase.from('users').update(patch).eq('username', username);
    }
};

// ══════════════════════════════════════════════════════════════════════
// SUPABASE DB: GLOBAL APPS (with IDB cache)
// ══════════════════════════════════════════════════════════════════════
window.sbGlobalApps = {
    _toRow(d) {
        const r = { ...d };
        const map = { createdAt:'created_at', updatedAt:'updated_at', publishedAt:'published_at', likedBy:'liked_by', dislikedBy:'disliked_by', fromMaker:'from_maker', previewImage:'preview_image' };
        Object.entries(map).forEach(([c, s]) => { if (c in r) { r[s] = r[c]; delete r[c]; } });
        return r;
    },
    _fromRow(d) {
        const r = { ...d };
        const map = { created_at:'createdAt', updated_at:'updatedAt', published_at:'publishedAt', liked_by:'likedBy', disliked_by:'dislikedBy', from_maker:'fromMaker', preview_image:'previewImage' };
        Object.entries(map).forEach(([s, c]) => { if (s in r) { r[c] = r[s]; delete r[s]; } });
        return r;
    },
    async getAll() {
        if (idb) {
            try {
                const cached = await idbGetAll('global_apps');
                if (cached.length) return { data: cached.map(r => this._fromRow(r)), error: null };
            } catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: [], error: 'offline' };
        const { data, error } = await supabase.from('global_apps').select('*');
        if (error) console.error('[sbGlobalApps.getAll]', error);
        if (data && idb) {
            await idbClear('global_apps').catch(()=>{});
            for (const row of data) await idbPut('global_apps', row).catch(()=>{});
        }
        return { data: (data || []).map(r => this._fromRow(r)), error };
    },
    async insert(appData) {
        if (!supabaseInitialized || !navigator.onLine) {
            const row = this._toRow({ ...appData, id: appData.id || 'temp_' + Date.now() });
            if (idb) await idbPut('global_apps', row).catch(()=>{});
            await enqueueWrite({ store: 'global_apps', action: 'insert', payload: this._toRow(appData) });
            return { data: this._fromRow(row), error: null };
        }
        const { data, error } = await supabase.from('global_apps').insert(this._toRow(appData)).select().single();
        if (error) console.error('[sbGlobalApps.insert]', error);
        if (data && idb) await idbPut('global_apps', data).catch(()=>{});
        return { data: data ? this._fromRow(data) : null, error };
    },
    async update(id, fields) {
        const row = this._toRow(fields);
        if (idb) {
            try { const c = await idbGet('global_apps', id); if (c) await idbPut('global_apps', { ...c, ...row }); }
            catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'global_apps', action: 'update', key: id, payload: row });
            return { error: null };
        }
        const { error } = await supabase.from('global_apps').update(row).eq('id', id);
        if (error) console.error('[sbGlobalApps.update]', error);
        return { error };
    },
    async delete(id) {
        if (idb) await idbDelete('global_apps', id).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'global_apps', action: 'delete', key: id, payload: {} });
            return { error: null };
        }
        const { error } = await supabase.from('global_apps').delete().eq('id', id);
        if (error) console.error('[sbGlobalApps.delete]', error);
        return { error };
    }
};

// ══════════════════════════════════════════════════════════════════════
// SUPABASE DB: INSTALLED APPS (with IDB cache)
// ══════════════════════════════════════════════════════════════════════
window.sbInstalled = {
    async getForUser(owner) {
        if (idb) {
            try {
                const all = await idbGetAll('installed');
                const cached = all.filter(r => r.owner === owner);
                if (cached.length) return { data: cached, error: null };
            } catch(e) {}
        }
        if (!supabaseInitialized || !navigator.onLine) return { data: [], error: 'offline' };
        const { data, error } = await supabase.from('installed').select('*').eq('owner', owner);
        if (error) console.error('[sbInstalled.getForUser]', error);
        if (data && idb) { for (const row of data) await idbPut('installed', row).catch(()=>{}); }
        return { data: data || [], error };
    },
    async insert(appData) {
        const row = { ...appData, id: appData.id || 'temp_' + Date.now() };
        if (idb) await idbPut('installed', row).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'installed', action: 'insert', payload: appData });
            return { data: row, error: null };
        }
        const { data, error } = await supabase.from('installed').insert(appData).select().single();
        if (error) console.error('[sbInstalled.insert]', error);
        if (data && idb) await idbPut('installed', data).catch(()=>{});
        return { data, error };
    },
    async delete(id) {
        if (idb) await idbDelete('installed', id).catch(()=>{});
        if (!supabaseInitialized || !navigator.onLine) {
            await enqueueWrite({ store: 'installed', action: 'delete', key: id, payload: {} });
            return { error: null };
        }
        const { error } = await supabase.from('installed').delete().eq('id', id);
        if (error) console.error('[sbInstalled.delete]', error);
        return { error };
    }
};

// ══════════════════════════════════════════════════════════════════════
// SOCIAL APIs — Friend Requests, Friendships, Messaging
// ══════════════════════════════════════════════════════════════════════
// Required Supabase tables:
//   friend_requests(id uuid pk, from_user text, to_user text, status text default 'pending', created_at timestamptz default now())
//   friendships(id uuid pk, user1 text, user2 text, created_at timestamptz default now(), unique(user1,user2))
//   messages(id uuid pk, thread_id text, from_user text, text text, created_at timestamptz default now())
//
// Required Firebase collections:
//   friend_requests/{id}: {from, to, status, time}
//   friendships/{id}: {user1, user2, time}
//   messages/{thread_id}/msgs/{id}: {from, text, time}

window.sbSocial = {

    // Deterministic thread ID for a DM between two users
    threadId(a, b) { return [a, b].sort().join('__'); },

    // ── All Users ─────────────────────────────────────────────────────
    async getAllUsers(exclude) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();

        if (useSB) {
            let q = supabase.from('users').select('username, display_name, profile_pic, created_at');
            if (exclude) q = q.neq('username', exclude);
            const { data, error } = await q.order('username');
            return { data: data || [], error };
        }
        if (useFB) {
            const snap = await getDocs(collection(db, 'users'));
            const users = snap.docs.map(d => ({ username: d.id, ...d.data() }))
                .filter(u => !exclude || u.username !== exclude);
            return { data: users, error: null };
        }
        return { data: [], error: null };
    },

    // ── Friend Requests ───────────────────────────────────────────────
    async sendRequest(fromUser, toUser) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            // Check not already pending
            const { data: existing } = await supabase.from('friend_requests')
                .select('id').eq('from_user', fromUser).eq('to_user', toUser).eq('status', 'pending');
            if (existing && existing.length) return { error: null }; // already sent
            const { error } = await supabase.from('friend_requests')
                .insert({ from_user: fromUser, to_user: toUser, status: 'pending' });
            return { error };
        }
        if (useFB) {
            await addDoc(collection(db, 'friend_requests'), { from: fromUser, to: toUser, status: 'pending', time: serverTimestamp() });
            return { error: null };
        }
        return { error: 'No backend available' };
    },

    async getIncoming(toUser) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { data, error } = await supabase.from('friend_requests')
                .select('*').eq('to_user', toUser).eq('status', 'pending');
            return { data: data || [], error };
        }
        if (useFB) {
            const q = query(collection(db, 'friend_requests'), where('to', '==', toUser), where('status', '==', 'pending'));
            const snap = await getDocs(q);
            return { data: snap.docs.map(d => ({ id: d.id, from_user: d.data().from, ...d.data() })), error: null };
        }
        return { data: [], error: null };
    },

    async getOutgoing(fromUser) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { data, error } = await supabase.from('friend_requests')
                .select('*').eq('from_user', fromUser).eq('status', 'pending');
            return { data: data || [], error };
        }
        if (useFB) {
            const q = query(collection(db, 'friend_requests'), where('from', '==', fromUser), where('status', '==', 'pending'));
            const snap = await getDocs(q);
            return { data: snap.docs.map(d => ({ id: d.id, to_user: d.data().to, ...d.data() })), error: null };
        }
        return { data: [], error: null };
    },

    async respondToRequest(requestId, status) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { error } = await supabase.from('friend_requests').update({ status }).eq('id', requestId);
            return { error };
        }
        if (useFB) {
            await updateDoc(doc(db, 'friend_requests', requestId), { status });
            return { error: null };
        }
        return { error: null };
    },

    // ── Friendships ───────────────────────────────────────────────────
    async addFriendship(user1, user2) {
        const [a, b] = [user1, user2].sort();
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { error } = await supabase.from('friendships')
                .upsert({ user1: a, user2: b }, { onConflict: 'user1,user2' });
            return { error };
        }
        if (useFB) {
            await setDoc(doc(db, 'friendships', `${a}__${b}`), { user1: a, user2: b, time: serverTimestamp() });
            return { error: null };
        }
        return { error: null };
    },

    async getFriends(username) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const [{ data: d1 }, { data: d2 }] = await Promise.all([
                supabase.from('friendships').select('user2').eq('user1', username),
                supabase.from('friendships').select('user1').eq('user2', username)
            ]);
            return { data: [...(d1||[]).map(r=>r.user2), ...(d2||[]).map(r=>r.user1)], error: null };
        }
        if (useFB) {
            const [s1, s2] = await Promise.all([
                getDocs(query(collection(db, 'friendships'), where('user1', '==', username))),
                getDocs(query(collection(db, 'friendships'), where('user2', '==', username)))
            ]);
            return { data: [...s1.docs.map(d=>d.data().user2), ...s2.docs.map(d=>d.data().user1)], error: null };
        }
        return { data: [], error: null };
    },

    async removeFriendship(user1, user2) {
        const [a, b] = [user1, user2].sort();
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            await supabase.from('friendships').delete().eq('user1', a).eq('user2', b);
        } else if (useFB) {
            await deleteDoc(doc(db, 'friendships', `${a}__${b}`)).catch(()=>{});
        }
    },

    async areFriends(user1, user2) {
        const { data } = await this.getFriends(user1);
        return (data || []).includes(user2);
    },

    // ── Messages ──────────────────────────────────────────────────────
    async sendMessage(fromUser, toUser, text) {
        const threadId = this.threadId(fromUser, toUser);
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { error } = await supabase.from('messages')
                .insert({ thread_id: threadId, from_user: fromUser, text, created_at: new Date().toISOString() });
            return { error };
        }
        if (useFB) {
            await addDoc(collection(db, `messages/${threadId}/msgs`), { from: fromUser, text, time: serverTimestamp() });
            return { error: null };
        }
        return { error: null };
    },

    async getMessages(user1, user2) {
        const threadId = this.threadId(user1, user2);
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const { data, error } = await supabase.from('messages')
                .select('*').eq('thread_id', threadId).order('created_at', { ascending: true });
            return { data: data || [], error };
        }
        if (useFB) {
            const q = query(collection(db, `messages/${threadId}/msgs`), orderBy('time', 'asc'));
            const snap = await getDocs(q);
            return { data: snap.docs.map(d => ({ id: d.id, from_user: d.data().from, ...d.data() })), error: null };
        }
        return { data: [], error: null };
    },

    subscribeMessages(user1, user2, callback) {
        const threadId = this.threadId(user1, user2);
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const ch = supabase.channel('msgs_' + threadId)
                .on('postgres_changes', {
                    event: 'INSERT', schema: 'public', table: 'messages',
                    filter: `thread_id=eq.${threadId}`
                }, p => callback(p.new))
                .subscribe();
            return () => supabase.removeChannel(ch);
        }
        if (useFB) {
            let isInit = true;
            const q = query(collection(db, `messages/${threadId}/msgs`), orderBy('time', 'asc'));
            const unsub = onSnapshot(q, snap => {
                if (isInit) { isInit = false; return; } // skip initial load (already shown via getMessages)
                snap.docChanges().forEach(c => {
                    if (c.type === 'added') callback({ from_user: c.doc.data().from, ...c.doc.data(), id: c.doc.id });
                });
            });
            return unsub;
        }
        return () => {};
    },

    subscribeRequests(toUser, callback) {
        const useSB = window.HyBackend.useSupabase();
        const useFB = window.HyBackend.useFirebase();
        if (useSB) {
            const ch = supabase.channel('reqs_' + toUser)
                .on('postgres_changes', {
                    event: 'INSERT', schema: 'public', table: 'friend_requests',
                    filter: `to_user=eq.${toUser}`
                }, p => callback(p.new))
                .subscribe();
            return () => supabase.removeChannel(ch);
        }
        if (useFB) {
            let isInit = true;
            const q = query(collection(db, 'friend_requests'), where('to', '==', toUser), where('status', '==', 'pending'));
            const unsub = onSnapshot(q, snap => {
                if (isInit) { isInit = false; return; }
                snap.docChanges().forEach(c => {
                    if (c.type === 'added') callback({ from_user: c.doc.data().from, ...c.doc.data(), id: c.doc.id });
                });
            });
            return unsub;
        }
        return () => {};
    }
};

// ── EXPOSE ALL GLOBALS TO WINDOW ──────────────────────────────────────
window.db                  = db;
window.firebaseInitialized = firebaseInitialized;
window.supabase            = supabase;
window.supabaseInitialized = supabaseInitialized;

// ── FIX: orderBy, arrayUnion, arrayRemove now included ────────────────
window._fb = {
    collection, addDoc, getDocs, updateDoc, deleteDoc,
    doc, getDoc, setDoc, serverTimestamp, onSnapshot, query, where,
    orderBy, arrayUnion, arrayRemove, increment
};

// Expose IDB helpers for anything that needs direct access
window._idb = { get: idbGet, getAll: idbGetAll, put: idbPut, delete: idbDelete, clear: idbClear };


// ══════════════════════════════════════════════════════════════════════
// AUTO-INIT: Ensure Supabase tables exist for People app
// ══════════════════════════════════════════════════════════════════════
async function hyosEnsureCollections() {
    if (!supabaseInitialized) return;
    const SQL = {
        friend_requests: `CREATE TABLE IF NOT EXISTS friend_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user text NOT NULL,
  to_user text NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);`,
        friendships: `CREATE TABLE IF NOT EXISTS friendships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_a text NOT NULL,
  user_b text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_a, user_b)
);`,
        messages: `CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id text NOT NULL,
  sender text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);`
    };
    const tables = ['friend_requests', 'friendships', 'messages'];
    for (const t of tables) {
        try {
            const { error } = await supabase.from(t).select('id').limit(1);
            if (error) {
                const warned = localStorage.getItem('hyos_table_warn_' + t);
                if (!warned) {
                    localStorage.setItem('hyos_table_warn_' + t, '1');
                    console.warn('[HyOS] Missing table:', t);
                    console.info('[HyOS] Run this SQL in your Supabase dashboard:\n' + SQL[t]);
                    setTimeout(() => {
                        if (typeof notify === 'function')
                            notify('⚠️ Supabase Setup', 'Table "' + t + '" missing — check console for SQL.');
                    }, 2000);
                }
            } else {
                console.log('[HyOS] Table ' + t + ' ✓');
            }
        } catch(e) { console.warn('[HyOS] Table check failed:', t, e); }
    }
}
setTimeout(hyosEnsureCollections, 2000);

// ── SIGNAL READY ──────────────────────────────────────────────────────
window.dispatchEvent(new CustomEvent('hyos-backend-ready', {
    detail: { firebaseInitialized, supabaseInitialized }
}));
console.log('[FBSB] Ready — Firebase:', firebaseInitialized, '| Supabase:', supabaseInitialized, '| IDB:', !!idb, '| Backend pref:', window.HyBackend.getPreference());
