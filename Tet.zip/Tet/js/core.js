// core.js — HyOS HS Core: boot, auth, settings, AppBuilder, Store, launchApp
// These are set by FBSB.js on window — we alias them here so existing code doesn't need changes
// They'll be undefined until hyos-backend-ready fires, but that's handled by the init wrapper
var db, supabase, firebaseInitialized = false, supabaseInitialized = false;
window.addEventListener('hyos-backend-ready', (e) => {
    db                  = window.db;
    supabase            = window.supabase;
    firebaseInitialized = window.firebaseInitialized;
    supabaseInitialized = window.supabaseInitialized;
});

    // ── CHANGE PASSWORD ──────────────────────────────────────────────────
    window.changeUserPassword = async function() {
        const cur = document.getElementById('chpw-current').value;
        const nw  = document.getElementById('chpw-new').value;
        const cf  = document.getElementById('chpw-confirm').value;
        const err = document.getElementById('chpw-error');
        err.style.display = 'none';
        const show = (msg) => { err.textContent = msg; err.style.display = 'block'; };
        if (!cur || !nw || !cf) return show('Please fill in all fields.');
        if (nw.length < 3) return show('New password must be at least 3 characters.');
        if (nw !== cf) return show('New passwords do not match.');
        if (!supabaseInitialized && !firebaseInitialized) return show('Not connected to cloud. Cannot change password.');
        const userId = localStorage.getItem('hyos_user_id') || user.toLowerCase();
        try {
            let userData = null, userSource = null;
            if (supabaseInitialized) {
                const { data: sbData } = await window.sbUsers.get(userId);
                if (sbData) { userData = sbData; userSource = 'supabase'; }
            }
            if (!userData && firebaseInitialized) {
                const userDoc = await window._fb.getDoc(window._fb.doc(db, 'users', userId));
                if (userDoc.exists()) { userData = userDoc.data(); userSource = 'firebase'; }
            }
            if (!userData) return show('User not found.');
            const curHash = btoa(cur);
            if (userData.password !== curHash && userData.password !== cur) return show('Current password is incorrect.');
            if (userSource === 'supabase') {
                await window.sbUsers.upsert(userId, { password: btoa(nw) });
            } else {
                await window._fb.updateDoc(window._fb.doc(db, 'users', userId), { password: btoa(nw) });
            }
            document.getElementById('chpw-current').value = '';
            document.getElementById('chpw-new').value = '';
            document.getElementById('chpw-confirm').value = '';
            notify('✅ Password Changed', 'Your password has been updated.');
        } catch(e) {
            show('Error: ' + e.message);
        }
    };

    let user = "", cloudApps = [], installedApps = [], publishedApps = [], openApps = {}, editingId = null, b64Icon = "";
    let userSettings = {
        currentWallpaper: { type: 'none', data: null },
        accentColor: '#2563eb',
        darkMode: true,
        transparency: true,
        autoInstall: false,
        rememberPositions: true,
        notifications: true,
        showDesktopIcons: true,
        snapToGrid: true,
        highContrast: false,
        reduceAnimations: false,
        largeText: false,
        stayLoggedIn: true,
        selectedGenre: 'productivity',
        profilePic: null,
        desktopIcons: [],
        installedPlugins: [],
        setupCompleted: false,
        // Taskbar settings
        taskbarPosition: 'bottom',
        autoHideTaskbar: false,
        taskbarSize: 'medium',
        showTaskbarLabels: true,
        taskbarOpacity: 90,
        showClock: true,
        clock12Hour: true,
        showDate: true,
        // Performance settings
        enableAnimations: true,
        enableTransparency: true,
        enableBlur: true,
        enableShadows: true,
        limitBackgroundApps: false,
        autoCloseIdle: false,
        maxConcurrentApps: 10,
        performanceMode: 'balanced',
        // Privacy settings
        sendUsageData: false,
        sendCrashReports: true,
        personalizedRecs: true,
        trackAppUsage: false,
        allowLocation: false,
        allowCamera: false,
        allowMicrophone: false,
        allowFiles: true,
        allowNotifications: true,
        allowWallpaper: true,
        allowClipboard: false,
        passwordForInstalls: false,
        autoLock: false,
        autoLockMinutes: 5,
        blockUnknownApps: false,
        appPermissions: {},
        // Notification settings
        enableNotifications: true,
        notifOnLockScreen: true,
        notifSounds: true,
        badgeNotifications: true,
        notifDuration: 4,
        doNotDisturb: false,
        scheduleDND: false,
        systemNotifs: true,
        installNotifs: true,
        updateNotifs: true,
        // Sound settings
        masterVolume: 70,
        systemVolume: 50,
        notifVolume: 60,
        startupSound: true,
        shutdownSound: true,
        appOpenSound: true,
        appCloseSound: false,
        errorSound: true,
        muteAll: false,
        // Network settings
        enableCloudSync: true,
        syncApps: true,
        syncSettings: true,
        syncDesktop: true,
        meteredConnection: false,
        updateOverMetered: false,
        offlineMode: false,
        cacheApps: true,
        // Storage settings
        autoClearCache: false,
        // Update settings
        autoUpdates: true,
        autoInstallAppUpdates: true,
        backgroundDownload: true,
        notifyUpdates: true,
        // Gaming settings
        enableGameBar: true,
        autoShowGameBar: true,
        enableGameMode: false,
        enableRecording: true,
        recordingQuality: 'high',
        recordAudio: true,
        recordMicrophone: false,
        showFPS: false,
        showUsage: false,
        overlayPosition: 'top-right',
        hardwareAccel: true,
        vsync: true,
        targetFPS: '60',
        showPing: false,
        networkPriority: true,
        // Default user for lock screen
        defaultUser: null,
        defaultUserId: null,
        // Theme Engine
        themeEngineEnabled: false,
        themeEngineIconBackups: {},
        activeThemeId: null,
        // Pinned apps (in taskbar)
        pinnedApps: [],
        // Age verification
        userAge: null,
        ageVerified: false,
        faceScanned: false
    };

    // Load settings from localStorage
    function loadSettings() {
        const saved = localStorage.getItem('hyos_settings');
        if (saved) {
            try { userSettings = { ...userSettings, ...JSON.parse(saved) }; }
            catch(e) { console.error('Settings parse error', e); }
        }
        // Ensure appPermissions is always a plain object
        if (!userSettings.appPermissions || typeof userSettings.appPermissions !== 'object' || Array.isArray(userSettings.appPermissions)) {
            userSettings.appPermissions = {};
        }
        
        // Apply loaded settings
        if (userSettings.accentColor) {
            document.documentElement.style.setProperty('--blue-600', userSettings.accentColor);
        }

        // Restore drawn wallpaper if saved
        if (userSettings.wallpaper?.type === 'drawn' && userSettings.wallpaper?.dataURL) {
            const bg = document.getElementById('desktop-bg');
            if (bg) {
                bg.style.backgroundImage = 'url(' + userSettings.wallpaper.dataURL + ')';
                bg.style.backgroundSize = 'cover';
                bg.style.backgroundPosition = 'center';
            }
        }

        // Restore custom font if saved
        if (userSettings.systemFont) {
            const sf = userSettings.systemFont;
            if (sf.dataURL) {
                const style = document.createElement('style');
                style.id = 'hyos-custom-font-face';
                style.textContent = `@font-face { font-family: '${sf.family}'; src: url('${sf.dataURL}'); }`;
                document.head.appendChild(style);
                setTimeout(() => document.body.style.fontFamily = `'${sf.family}', sans-serif`, 100);
            } else if (sf.url) {
                const link = document.createElement('link');
                link.id = 'hyos-font-link'; link.rel = 'stylesheet'; link.href = sf.url;
                document.head.appendChild(link);
                link.onload = () => { document.body.style.fontFamily = `'${sf.family}', sans-serif`; };
            }
        }
        
        // Update UI to reflect loaded settings
        const genreSelect = document.getElementById('genre-select');
        if (genreSelect && userSettings.selectedGenre) {
            genreSelect.value = userSettings.selectedGenre;
        }
        
        document.getElementById('account-genre').textContent = userSettings.selectedGenre || 'Not Set';
        
        // Restart auto-lock if it was enabled
        if (userSettings.autoLock) { setTimeout(() => _autoLock.setup(), 500); }
    }

    function saveSettings() {
        try {
            localStorage.setItem('hyos_settings', JSON.stringify(userSettings));
            console.log('Settings saved successfully');
        } catch (e) {
            console.error('Failed to save settings:', e);
        }
    }
    
    // Expose userSettings and saveSettings globally so other scripts can access them
    Object.defineProperty(window, 'userSettings', {
        get: () => userSettings,
        set: (v) => { userSettings = v; },
        configurable: true
    });
    window.saveSettings = saveSettings;

    // Auto-save settings every 30 seconds
    setInterval(() => {
        saveSettings();
    }, 30000);
    
    // Add click sounds to all buttons
    document.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON' || e.target.classList.contains('task-btn')) {
            playSound('click');
        }
    });

    // Check for saved login
    async function checkSavedLogin() {
        const savedUser = localStorage.getItem('hyos_user');
        const savedUserId = localStorage.getItem('hyos_user_id');
        
        if (savedUser && userSettings.stayLoggedIn) {
            // If it's a guest, allow immediate access
            if (savedUser === "Guest") {
                user = savedUser;
                document.getElementById('account-username').textContent = user;
                
                if (userSettings.setupCompleted) {
                    startOS();
                } else {
                    showSetup();
                }
                return true;
            }
            
            // Verify against Supabase DB (new users) or Firebase (old users)
            let verified = false;
            if (supabaseInitialized && savedUserId) {
                try {
                    const { data: sbData } = await window.sbUsers.get(savedUserId);
                    if (sbData) {
                        verified = true;
                        user = savedUser;
                        document.getElementById('account-username').textContent = user;
                        await window.sbUsers.updateLastLogin(savedUserId);
                    }
                } catch(e) { console.warn('Supabase saved login check failed:', e); }
            }
            if (!verified && firebaseInitialized && savedUserId) {
                try {
                    const userDocRef = window._fb.doc(db, 'users', savedUserId);
                    const userDoc = await window._fb.getDoc(userDocRef);
                    if (userDoc.exists()) {
                        verified = true;
                        user = savedUser;
                        document.getElementById('account-username').textContent = user;
                        // Firebase is read-only — skip lastLogin write
                    } else {
                        localStorage.removeItem('hyos_user');
                        localStorage.removeItem('hyos_user_id');
                    }
                } catch(error) { console.error('Saved login verification error:', error); }
            }
            if (verified) {
                if (userSettings.setupCompleted) { showRefreshLockScreen(savedUser); } else { showSetup(); }
                return true;
            } else {
                localStorage.removeItem('hyos_user');
                localStorage.removeItem('hyos_user_id');
            }
        }
        return false;
    }


    // ── OPFS / INDEXEDDB FILESYSTEM ──────────────────────────────────────────
    window.HyFS = {
        _db: null,
        async init() {
            if (this._db) return this._db;
            return new Promise((resolve, reject) => {
                const req = indexedDB.open('HyOS_FS', 1);
                req.onupgradeneeded = e => {
                    const db = e.target.result;
                    if (!db.objectStoreNames.contains('files'))
                        db.createObjectStore('files', { keyPath: 'path' });
                    if (!db.objectStoreNames.contains('apps'))
                        db.createObjectStore('apps', { keyPath: 'id' });
                    if (!db.objectStoreNames.contains('media'))
                        db.createObjectStore('media', { keyPath: 'id' });
                };
                req.onsuccess = e => { this._db = e.target.result; resolve(this._db); };
                req.onerror = () => reject(req.error);
            });
        },
        async _tx(store, mode, fn) {
            const db = await this.init();
            return new Promise((resolve, reject) => {
                const tx = db.transaction(store, mode);
                const s = tx.objectStore(store);
                const req = fn(s);
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            });
        },
        // ── Files (HyFiles) ──────────────────────────────────────────────
        async writeFile(path, data, meta = {}) {
            return this._tx('files', 'readwrite', s => s.put({ path, data, meta, modified: Date.now() }));
        },
        async readFile(path) {
            return this._tx('files', 'readonly', s => s.get(path));
        },
        async deleteFile(path) {
            return this._tx('files', 'readwrite', s => s.delete(path));
        },
        async listFiles(prefix = '') {
            const db = await this.init();
            return new Promise((resolve, reject) => {
                const tx = db.transaction('files', 'readonly');
                const req = tx.objectStore('files').getAll();
                req.onsuccess = () => resolve(req.result.filter(f => f.path.startsWith(prefix)));
                req.onerror = () => reject(req.error);
            });
        },
        // ── Downloaded apps ──────────────────────────────────────────────
        async cacheApp(app) {
            return this._tx('apps', 'readwrite', s => s.put({
                id: app.id, name: app.name, icon: app.icon, desc: app.desc,
                code: app.code, version: app.version, creator: app.creator,
                cachedAt: Date.now()
            }));
        },
        async getCachedApp(id) {
            return this._tx('apps', 'readonly', s => s.get(id));
        },
        async clearAppCache(id) {
            return this._tx('apps', 'readwrite', s => s.delete(id));
        },
        // ── Media files ──────────────────────────────────────────────────
        async saveMedia(id, blob, meta = {}) {
            return new Promise(async (resolve, reject) => {
                const reader = new FileReader();
                reader.onload = async () => {
                    await this._tx('media', 'readwrite', s => s.put({ id, data: reader.result, meta, savedAt: Date.now() }));
                    resolve();
                };
                reader.onerror = reject;
                reader.readAsDataURL(blob);
            });
        },
        async getMedia(id) {
            return this._tx('media', 'readonly', s => s.get(id));
        },
        async listMedia() {
            const db = await this.init();
            return new Promise((resolve, reject) => {
                const tx = db.transaction('media', 'readonly');
                const req = tx.objectStore('media').getAll();
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            });
        }
    };

    // Init HyFS on startup
    HyFS.init().then(() => console.log('[HyFS] IndexedDB ready')).catch(e => console.warn('[HyFS] IndexedDB failed:', e));

    // ── STORE REVIEWS ────────────────────────────────────────────────────────
    window.submitReview = async (appId) => {
        if (user === 'Guest') return notify('Reviews', 'Sign in to leave a review.');
        const text = document.getElementById('review-text')?.value?.trim();
        const rating = parseInt(document.getElementById('review-rating')?.value || '5');
        if (!text) return notify('Review', 'Please write something first.');
        const review = { user, rating, text, created_at: new Date().toISOString() };
        const app = cloudApps.find(a => a.id === appId);
        if (!app) return;
        const reviews = Array.isArray(app.reviews) ? app.reviews : [];
        // Replace existing review from same user
        const filtered = reviews.filter(r => r.user !== user);
        filtered.unshift(review);
        app.reviews = filtered;
        if (supabaseInitialized) {
            const { error } = await supabase.from('global_apps').update({ reviews: filtered }).eq('id', appId);
            if (error) { console.error('[reviews]', error); return notify('Error', error.message); }
        }
        notify('✅ Review', 'Your review was posted!');
        showInfo(appId, 'cloud');
    };

    window.renderReviews = (app) => {
        const reviews = Array.isArray(app.reviews) ? app.reviews : [];
        if (!reviews.length) return '<div style="opacity:0.4;font-size:11px;padding:12px 0;">No reviews yet. Be the first!</div>';
        return reviews.slice(0, 5).map(r => `
            <div style="background:rgba(255,255,255,0.04);border-radius:10px;padding:10px 12px;margin-bottom:8px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                    <span style="font-size:11px;font-weight:700;">${r.user}</span>
                    <span style="font-size:12px;">${'⭐'.repeat(Math.max(1,Math.min(5,r.rating||5)))}</span>
                </div>
                <div style="font-size:11px;opacity:0.7;">${r.text}</div>
                <div style="font-size:9px;opacity:0.35;margin-top:4px;">${new Date(r.created_at).toLocaleDateString()}</div>
            </div>
        `).join('');
    };

    // ── PERSIST NOTIFICATIONS TO INDEXEDDB ──────────────────────────────────
    const _rawAddNotif = window.addNotificationToPanel;
    window.addNotificationToPanel = function(title, message) {
        _rawAddNotif(title, message);
        const entry = { id: Date.now(), title, message, time: new Date().toISOString() };
        HyFS.writeFile('sys/notifications/' + entry.id, JSON.stringify(entry)).catch(() => {});
    };

    window.loadNotificationHistory = async () => {
        try {
            const files = await HyFS.listFiles('sys/notifications/');
            const list = document.getElementById('notification-list');
            if (!files.length) return;
            // Clear "no notifications" placeholder
            if (list.querySelector('div[style*="No notifications"]')) list.innerHTML = '';
            files.sort((a, b) => b.path.localeCompare(a.path)).forEach(f => {
                try {
                    const n = JSON.parse(f.data);
                    // Don't duplicate ones already shown
                    if (list.querySelector(`[data-notif-id="${n.id}"]`)) return;
                    const el = document.createElement('div');
                    el.className = 'notification-item';
                    el.dataset.notifId = n.id;
                    el.innerHTML = `
                        <div style="font-weight:600;margin-bottom:4px;">${n.title}</div>
                        <div style="font-size:11px;opacity:0.7;">${n.message || ''}</div>
                        <div style="font-size:10px;opacity:0.5;margin-top:6px;">${new Date(n.time).toLocaleTimeString()}</div>
                    `;
                    list.appendChild(el);
                } catch(e) {}
            });
            const badge = document.getElementById('notif-badge');
            const count = list.querySelectorAll('.notification-item').length;
            if (count > 0) { badge.textContent = count > 99 ? '99+' : count; badge.style.display = 'inline-block'; }
        } catch(e) { console.warn('[notif history]', e); }
    };
    // Sound System
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const sounds = {
        enabled: true,
        volume: 0.3
    };

    function playSound(type) {
        if (!sounds.enabled) return;

        // Play custom imported sound if available for this slot
        if (userSettings.customSoundData?.[type]) {
            try {
                const audio = new Audio(userSettings.customSoundData[type]);
                audio.volume = sounds.volume;
                audio.play().catch(()=>{});
                return;
            } catch(e) {}
        }

        try {
            const pack = userSettings.soundPack || 'default';

            // Per-pack presets: [waveform, freqStart, freqEnd, duration, gainMult]
            // Each type has overrides per pack
            const packProfiles = {
                default: { wave: 'sine',     gainMult: 1.0 },
                retro:   { wave: 'square',   gainMult: 0.6 },
                soft:    { wave: 'sine',     gainMult: 0.5 },
                material:{ wave: 'triangle', gainMult: 0.8 },
            };
            const profile = packProfiles[pack] || packProfiles.default;

            // Per-pack frequency/timing overrides per sound type
            const packSounds = {
                default: {
                    startup:      [440,  1320, 0.3,  false],
                    login:        [523,  784,  0.3,  false],
                    open:         [800,  1200, 0.1,  false],
                    close:        [1200, 600,  0.1,  false],
                    click:        [1000, 1000, 0.05, false],
                    notification: [660,  880,  0.25, false],
                    error:        [200,  150,  0.15, false],
                    success:      [659,  784,  0.2,  false],
                },
                retro: {
                    startup:      [220,  880,  0.4,  false],
                    login:        [440,  880,  0.3,  false],
                    open:         [440,  660,  0.12, false],
                    close:        [660,  220,  0.12, false],
                    click:        [1200, 1200, 0.04, false],
                    notification: [880,  1320, 0.2,  false],
                    error:        [120,  80,   0.2,  false],
                    success:      [440,  660,  0.25, false],
                },
                soft: {
                    startup:      [528,  1056, 0.5,  false],
                    login:        [432,  648,  0.45, false],
                    open:         [600,  900,  0.18, false],
                    close:        [900,  500,  0.18, false],
                    click:        [800,  800,  0.06, false],
                    notification: [528,  704,  0.35, false],
                    error:        [250,  180,  0.2,  false],
                    success:      [528,  660,  0.3,  false],
                },
                material: {
                    startup:      [400,  1200, 0.25, false],
                    login:        [500,  800,  0.25, false],
                    open:         [700,  1100, 0.09, false],
                    close:        [1100, 550,  0.09, false],
                    click:        [900,  900,  0.04, false],
                    notification: [700,  933,  0.2,  false],
                    error:        [180,  120,  0.12, false],
                    success:      [600,  750,  0.18, false],
                },
            };

            const typeSounds = (packSounds[pack] || packSounds.default);
            const params = typeSounds[type] || typeSounds.click;
            const [freqStart, freqEnd, duration] = params;

            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            oscillator.type = profile.wave;
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            const now = audioContext.currentTime;
            const vol = sounds.volume * profile.gainMult;
            gainNode.gain.setValueAtTime(vol, now);
            gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

            oscillator.frequency.setValueAtTime(freqStart, now);
            if (freqEnd !== freqStart) {
                oscillator.frequency.exponentialRampToValueAtTime(freqEnd, now + duration * 0.85);
            }

            oscillator.start(now);
            oscillator.stop(now + duration);
        } catch (e) {
            console.error('Sound playback error:', e);
        }
    }

    // Store pending credentials for account creation
    let pendingUsername = '';
    let pendingUsernameDisplay = ''; // For preserving capitalization
    let pendingPassword = '';

    window.handleAuth = async (bypass) => {
        const u = document.getElementById('u-in').value.trim();
        const p = document.getElementById('p-in').value;
        const errorDiv = document.getElementById('login-error');
        const successDiv = document.getElementById('login-success');
        const passwordInput = document.getElementById('p-in');
        const usernameInput = document.getElementById('u-in');
        
        // Clear previous messages
        errorDiv.style.display = 'none';
        successDiv.style.display = 'none';
        passwordInput.classList.remove('error');
        usernameInput.classList.remove('error');
        
        if (bypass) {
            // Guest bypass - no validation needed
            user = "Guest";
            document.getElementById('account-username').textContent = user;
            
            // Save login
            if (userSettings.stayLoggedIn) {
                localStorage.setItem('hyos_user', user);
            }
            
            // CRITICAL FIX: Save settings to persist setupCompleted and other settings
            saveSettings();
            
            document.getElementById('login-screen').style.opacity = '0';
            setTimeout(() => {
                document.getElementById('login-screen').style.display = 'none';
                
                // Show setup if not completed
                if (!userSettings.setupCompleted) {
                    showSetup();
                } else {
                    startOS();
                }
            }, 800);
            return;
        }
        
        // Validate input
        if (!u || !p) {
            playSound('error');
            errorDiv.textContent = 'Please enter both username and password';
            errorDiv.style.display = 'block';
            if (!u) usernameInput.classList.add('error');
            if (!p) passwordInput.classList.add('error');
            return;
        }
        
        // Validate username (3-30 chars, spaces allowed)
        if (u.length < 3 || u.length > 30) {
            playSound('error');
            errorDiv.textContent = 'Username must be 3-30 characters';
            errorDiv.style.display = 'block';
            usernameInput.classList.add('error');
            return;
        }
        
        // Validate password length
        if (p.length < 3) {
            playSound('error');
            errorDiv.textContent = 'Password must be at least 3 characters';
            errorDiv.style.display = 'block';
            passwordInput.classList.add('error');
            return;
        }
        
        // Check server for user
        if (!supabaseInitialized && !firebaseInitialized) {
            errorDiv.textContent = 'Cannot connect to server. Please try Guest Mode.';
            errorDiv.style.display = 'block';
            return;
        }

        try {
            errorDiv.textContent = 'Checking credentials...';
            errorDiv.style.display = 'block';
            errorDiv.className = 'text-blue-500 text-sm mb-2';

            const usernameLower = u.toLowerCase();
            const hashedPassword = btoa(p);
            let userData = null, userSource = null;

            if (supabaseInitialized) {
                const { data: sbData } = await window.sbUsers.get(usernameLower);
                if (sbData) { userData = sbData; userSource = 'supabase'; }
            }
            if (!userData && firebaseInitialized) {
                try {
                    const snap = await window._fb.getDoc(window._fb.doc(db, 'users', usernameLower));
                    if (snap.exists()) { userData = snap.data(); userSource = 'firebase'; }
                } catch(e) { console.warn('Firebase user lookup failed:', e); }
            }

            if (!userData) {
                errorDiv.style.display = 'none';
                errorDiv.className = 'text-red-500 text-sm mb-2';
                pendingUsername = usernameLower;
                pendingUsernameDisplay = u;
                pendingPassword = p;
                document.getElementById('new-username-display').textContent = u;
                document.getElementById('create-account-modal').style.display = 'flex';
            } else {
                const passwordMatch = userData.password === hashedPassword || userData.password === p;
                if (passwordMatch) {
                    errorDiv.style.display = 'none';
                    successDiv.textContent = 'Login successful!';
                    successDiv.style.display = 'block';
                    playSound('login');
                    user = u;
                    document.getElementById('account-username').textContent = user;
                    try {
                        if (userSource === 'supabase') {
                            await window.sbUsers.updateLastLogin(usernameLower);
                            if (userData.password === p) await window.sbUsers.upsert(usernameLower, { password: hashedPassword });
                        } else {
                            // Firebase is read-only — skip lastLogin/password write for legacy Firebase users
                        }
                    } catch(e) { console.error('Failed to update user data:', e); }
                    if (userSettings.stayLoggedIn) {
                        localStorage.setItem('hyos_user', user);
                        localStorage.setItem('hyos_user_id', usernameLower);
                    }
                    saveSettings();
                    setTimeout(() => {
                        document.getElementById('login-screen').style.opacity = '0';
                        setTimeout(() => {
                            document.getElementById('login-screen').style.display = 'none';
                            if (!userSettings.setupCompleted) { showSetup(); } else { startOS(); }
                        }, 500);
                    }, 800);
                } else {
                    playSound('error');
                    errorDiv.className = 'text-red-500 text-sm mb-2';
                    errorDiv.textContent = 'Invalid password';
                    errorDiv.style.display = 'block';
                    passwordInput.classList.add('error');
                    passwordInput.value = '';
                    passwordInput.focus();
                }
            }
        } catch (error) {
            console.error("Authentication error:", error);
            errorDiv.className = 'text-red-500 text-sm mb-2';
            errorDiv.textContent = 'Authentication failed. Please try again.';
            errorDiv.style.display = 'block';
        }
    };
    
    window.createNewAccount = async () => {
        const confirmPassword = document.getElementById('confirm-password').value;
        const confirmInput = document.getElementById('confirm-password');
        
        if (!confirmPassword) {
            confirmInput.classList.add('error');
            alert('Please confirm your password');
            return;
        }
        
        if (pendingPassword.length < 3) {
            alert('Password must be at least 3 characters long');
            return;
        }
        
        if (confirmPassword !== pendingPassword) {
            confirmInput.classList.add('error');
            alert('Passwords do not match!');
            return;
        }
        
        confirmInput.classList.remove('error');
        
        if (!supabaseInitialized && !firebaseInitialized) {
            alert('Cannot create account - server unavailable');
            return;
        }

        try {
            const createBtn = event.target;
            const originalText = createBtn.textContent;
            createBtn.textContent = 'Creating...';
            createBtn.disabled = true;

            const hashedPassword = btoa(pendingPassword);

            if (supabaseInitialized) {
                const { error: writeErr } = await window.sbUsers.upsert(pendingUsername, {
                    password: hashedPassword,
                    is_verified: false,
                    created_at: new Date().toISOString(),
                    last_login: new Date().toISOString()
                });
                if (writeErr) throw new Error(typeof writeErr === 'object' ? (writeErr.message || JSON.stringify(writeErr)) : String(writeErr));
            } else {
                const userDocRef = window._fb.doc(db, 'users', pendingUsername);
                await window._fb.setDoc(userDocRef, {
                    password: hashedPassword,
                    isVerified: false,
                    createdAt: window._fb.serverTimestamp(),
                    lastLogin: window._fb.serverTimestamp()
                });
            }
            
            // Play success sound
            playSound('success');
            
            // Close modal
            document.getElementById('create-account-modal').style.display = 'none';
            document.getElementById('confirm-password').value = '';
            createBtn.textContent = originalText;
            createBtn.disabled = false;
            
            // Show success message
            const successDiv = document.getElementById('login-success');
            successDiv.textContent = 'Account created successfully! Logging in...';
            successDiv.style.display = 'block';
            
            // Auto login with display name
            user = pendingUsernameDisplay;
            document.getElementById('account-username').textContent = user;
            
            if (userSettings.stayLoggedIn) {
                localStorage.setItem('hyos_user', user);
                localStorage.setItem('hyos_user_id', pendingUsername); // Store lowercase version
            }
            
            // CRITICAL FIX: Save settings to persist setupCompleted and other settings
            saveSettings();
            
            setTimeout(() => {
                document.getElementById('login-screen').style.opacity = '0';
                setTimeout(() => {
                    document.getElementById('login-screen').style.display = 'none';
                    
                    // New users always see setup
                    showSetup();
                }, 500);
            }, 1500);
            
        } catch (error) {
            console.error("Account creation error:", error);
            alert('Failed to create account: ' + error.message);
            event.target.textContent = 'Create Account';
            event.target.disabled = false;
        }
    };
    
    window.cancelCreateAccount = () => {
        document.getElementById('create-account-modal').style.display = 'none';
        document.getElementById('confirm-password').value = '';
        pendingUsername = '';
        pendingUsernameDisplay = '';
        pendingPassword = '';
        document.getElementById('p-in').value = '';
    };
    
    // Enter key support for confirm password
    document.getElementById('confirm-password').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            createNewAccount();
        }
    });
    
    // ESC key to close modals
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const modal = document.getElementById('create-account-modal');
            if (modal.style.display === 'flex') {
                cancelCreateAccount();
            }
        }
    });

    function showSetup() {
        document.getElementById('setup-screen').style.display = 'flex';
        document.querySelectorAll('.setup-step').forEach(s => s.classList.remove('active'));
        // If age already verified, skip to step 1
        if (userSettings.userAge !== null && userSettings.ageVerified) {
            document.getElementById('setup-step-1').classList.add('active');
        } else {
            document.getElementById('setup-step-0').classList.add('active');
        }
        populateSetupApps();
    }

    function startOS() {
        // Load persisted notification history
        setTimeout(() => loadNotificationHistory && loadNotificationHistory(), 1500);
        playSound('startup');
        document.getElementById('os-surface').classList.remove('hidden');
        loadData();
        setupDrags();
        init3D();
        renderDesktopIcons();
        loadMediaLibrary();
        HyFiles.init();
        setTimeout(() => { if (window.renderPinnedApps) renderPinnedApps(); }, 800);
        // Age gate for existing users who haven't verified age yet
        if (userSettings.userAge === null || !userSettings.ageVerified) {
            setTimeout(() => showAgeGateModal(), 600);
        }
        // Expose user getter so external scripts (hypeople.js etc.) can access it
        Object.defineProperty(window, 'hyosUser', { get: () => user, configurable: true });
        // Auto-start HyPeople background listeners so friend-request notifications fire on login
        setTimeout(() => {
            if (window.HyPeople && user && user !== 'Guest') {
                window.HyPeople._startListeners();
            }
        }, 2000);
    }
    
    // =====================
    // HYFILES FILE MANAGER
    // =====================
    
    // File system storage
    let fileSystem = {
        root: [],
        downloads: [],
        images: [],
        videos: [],
        documents: [],
        screenshots: []
    };
    
    let selectedFiles = [];
    
    const HyFiles = {
        currentFolder: 'root',
        
        init() {
            // Load saved file system
            const saved = localStorage.getItem('hyos_fs_' + user);
            if (saved) {
                try {
                    fileSystem = JSON.parse(saved);
                } catch (e) {
                    console.error('Failed to load file system:', e);
                }
            }
            this.refresh();
        },
        
        navigate(folder) {
            this.currentFolder = folder;
            selectedFiles = [];
            
            // Update sidebar
            document.querySelectorAll('.hyfiles-folder').forEach(f => {
                f.classList.remove('active');
            });
            event?.target?.closest('.hyfiles-folder')?.classList.add('active');
            
            this.refresh();
        },

        refreshSidebarCounts() {
            const folders = [
                { key:'root',        label:'📁 My Files',    id:'hyfolder-root' },
                { key:'downloads',   label:'⬇️ Downloads',   id:'hyfolder-downloads' },
                { key:'images',      label:'🖼️ Images',      id:'hyfolder-images' },
                { key:'videos',      label:'🎥 Videos',      id:'hyfolder-videos' },
                { key:'documents',   label:'📄 Documents',   id:'hyfolder-documents' },
                { key:'screenshots', label:'📸 Screenshots', id:'hyfolder-screenshots' },
            ];
            folders.forEach(f => {
                const el = document.getElementById(f.id);
                if (!el) return;
                const count = (fileSystem[f.key] || []).length;
                const badge = el.querySelector('.hyfolder-count');
                if (count > 0) {
                    if (badge) {
                        badge.textContent = count;
                    } else {
                        const b = document.createElement('span');
                        b.className = 'hyfolder-count';
                        b.style.cssText = 'margin-left:auto;font-size:10px;background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.3);color:#7dd3fc;padding:1px 6px;border-radius:10px;font-weight:700;';
                        b.textContent = count;
                        el.appendChild(b);
                    }
                } else if (badge) {
                    badge.remove();
                }
            });
        },
        
        refresh() {
            const grid = document.getElementById('hyfiles-grid');
            const empty = document.getElementById('hyfiles-empty');
            const path = document.getElementById('hyfiles-path');
            
            if (!grid || !empty || !path) return;
            
            const folderNames = {
                root: 'My Files',
                downloads: 'Downloads',
                images: 'Images',
                videos: 'Videos',
                documents: 'Documents',
                screenshots: 'Screenshots'
            };
            
            path.textContent = folderNames[this.currentFolder] || this.currentFolder;
            
            const items = fileSystem[this.currentFolder] || [];
            
            // Update sidebar count badges
            this.refreshSidebarCounts();
            
            if (items.length === 0) {
                grid.innerHTML = '';
                empty.style.display = 'block';
            } else {
                empty.style.display = 'none';
                grid.innerHTML = items.map((item, index) => {
                    const isImage = item.type && item.type.startsWith('image/');
                    const isVideo = item.type && item.type.startsWith('video/');
                    const isAudio = item.type && item.type.startsWith('audio/');
                    
                    return `
                        <div class="hyfiles-item ${selectedFiles.includes(index) ? 'selected' : ''}" 
                             onclick="HyFiles.selectFile(${index}, event)"
                             oncontextmenu="event.preventDefault(); HyFiles.showFileContextMenu(event, ${index})">
                            ${isImage ? `<img src="${item.data}" class="hyfiles-preview" onerror="this.style.display='none'">` : ''}
                            ${isVideo ? `<div class="hyfiles-icon">🎥</div>` : ''}
                            ${isAudio ? `<div class="hyfiles-icon">🎵</div>` : ''}
                            ${!isImage && !isVideo && !isAudio ? `<div class="hyfiles-icon">${item.type === 'folder' ? '📁' : '📄'}</div>` : ''}
                            <div class="hyfiles-name">${item.name}</div>
                        </div>
                    `;
                }).join('');
            }
            
            this.saveFileSystem();
        },
        
        selectFile(index, event) {
            const item = fileSystem[this.currentFolder][index];
            
            if (event && event.shiftKey) {
                if (selectedFiles.includes(index)) {
                    selectedFiles = selectedFiles.filter(i => i !== index);
                } else {
                    selectedFiles.push(index);
                }
                this.refresh();
            } else {
                // Check file extension and show appropriate dialog
                const ext = item.name.split('.').pop().toLowerCase();
                
                // File associations
                const associations = {
                    'html': ['browser', 'notepad'],
                    'txt': ['notepad'],
                    'hl': ['hylink'],
                    'Hl': ['hylink'],
                    'hL': ['hylink'],
                    'HL': ['hylink'],
                    'png': ['viewer'],
                    'jpg': ['viewer'],
                    'jpeg': ['viewer'],
                    'gif': ['viewer'],
                    'webp': ['viewer'],
                    'mp4': ['viewer'],
                    'webm': ['viewer'],
                    'mp3': ['audio'],
                    'wav': ['audio'],
                    'ogg': ['audio'],
                    'm4a': ['audio'],
                    'flac': ['audio']
                };
                
                if (associations[ext]) {
                    this.showFileAssociationDialog(item, index, associations[ext]);
                } else if (item.type && item.type.startsWith('image/')) {
                    Viewer.open(item, 'image');
                } else if (item.type && item.type.startsWith('video/')) {
                    Viewer.open(item, 'video');
                } else if (item.type && item.type.startsWith('audio/')) {
                    this.showAudioOptions(item, index);
                } else {
                    notify('File', 'Unsupported file type');
                }
            }
        },
        
        showFileAssociationDialog(item, index, apps) {
            const ext = item.name.split('.').pop().toLowerCase();
            
            // Special handling for HyLink files - open URL directly
            if (ext === 'hl') {
                this.openHyLink(item);
                return;
            }
            
            // Special handling for HTML files - show import options
            if (ext === 'html') {
                const dialog = document.createElement('div');
                dialog.className = 'context-menu';
                dialog.style.display = 'block';
                dialog.style.left = '50%';
                dialog.style.top = '50%';
                dialog.style.transform = 'translate(-50%, -50%)';
                dialog.style.minWidth = '300px';
                dialog.style.padding = '20px';
                
                dialog.innerHTML = `
                    <div style="margin-bottom: 15px; font-size: 14px; font-weight: 600;">
                        Open with...
                    </div>
                    <div style="font-size: 12px; opacity: 0.6; margin-bottom: 15px;">
                        ${item.name}
                    </div>
                    <div class="context-menu-item" onclick="HyFiles.openFileWith('notepad', ${index}); this.parentElement.remove();">
                        📝 Notepad
                    </div>
                    <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px;">
                        Cancel
                    </div>
                `;
                
                document.body.appendChild(dialog);
                
                setTimeout(() => {
                    const closeDialog = (e) => {
                        if (!dialog.contains(e.target)) {
                            dialog.remove();
                            document.removeEventListener('click', closeDialog);
                        }
                    };
                    document.addEventListener('click', closeDialog);
                }, 10);
                
                return;
            }
            
            // Original code for non-HTML files
            const dialog = document.createElement('div');
            dialog.className = 'context-menu';
            dialog.style.display = 'block';
            dialog.style.left = '50%';
            dialog.style.top = '50%';
            dialog.style.transform = 'translate(-50%, -50%)';
            dialog.style.minWidth = '300px';
            dialog.style.padding = '20px';
            
            const appNames = {
                'browser': '🌐 Browser',
                'notepad': '📝 Notepad',
                'viewer': '🖼️ Image Viewer'
            };
            
            dialog.innerHTML = `
                <div style="margin-bottom: 15px; font-size: 14px; font-weight: 600;">
                    Which app would you like to open this file with?
                </div>
                <div style="font-size: 12px; opacity: 0.6; margin-bottom: 15px;">
                    ${item.name}
                </div>
                ${apps.map(app => `
                    <div class="context-menu-item" onclick="HyFiles.openFileWith('${app}', ${index}); this.parentElement.remove();">
                        ${appNames[app] || app}
                    </div>
                `).join('')}
                <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px;">
                    Cancel
                </div>
            `;
            
            document.body.appendChild(dialog);
            
            setTimeout(() => {
                const closeDialog = (e) => {
                    if (!dialog.contains(e.target)) {
                        dialog.remove();
                        document.removeEventListener('click', closeDialog);
                    }
                };
                document.addEventListener('click', closeDialog);
            }, 10);
        },
        
        openFileWith(app, index) {
            const item = fileSystem[this.currentFolder][index];
            
            if (app === 'notepad') {
                // Open in notepad for editing
                Notepad.open(item, this.currentFolder, index);
            } else if (app === 'viewer') {
                Viewer.open(item, item.type && item.type.startsWith('image/') ? 'image' : 'video');
            } else if (app === 'hylink') {
                // Open HyLink file
                this.openHyLink(item);
            }
        },
        
        openHyLink(item) {
            try {
                let raw = (item.data || item.content || '').trim();
                HyLink.execute(raw, item.name || 'unknown');
            } catch (error) {
                notify('HyLink Error', 'Failed to open HyLink: ' + error.message);
            }
        },
        
        importFromActualFiles(hyfileIndex) {
            notify('Info', 'Browser has been removed. Use Notepad to edit HTML files.');
        },
        
        createFile() {
            const name = prompt('File name (include extension, e.g., myfile.txt or mypage.html):');
            if (!name) return;
            
            const ext = name.split('.').pop().toLowerCase();
            let fileType = 'text/plain';
            let fileData = '';
            
            if (ext === 'html') {
                fileType = 'text/html';
                fileData = '<!DOCTYPE html>\n<html>\n<head>\n    <title>HyOS HS — HyService</title>\n</head>\n<body>\n    <h1>Hello World!</h1>\n</body>\n</html>';
            } else if (ext === 'txt') {
                fileType = 'text/plain';
                fileData = '';
            } else if (ext === 'hl') {
                fileType = 'text/plain';
                fileData = 'https://example.com';
            }
            
            fileSystem[this.currentFolder].push({
                name: name,
                type: fileType,
                data: fileData,
                content: fileData,
                created: new Date().toISOString()
            });
            
            this.refresh();
            notify('Created', 'File created: ' + name);
        },
        
        deleteFile(index) {
            const item = fileSystem[this.currentFolder][index];
            if (confirm(`Delete ${item.name}?`)) {
                fileSystem[this.currentFolder].splice(index, 1);
                this.refresh();
                notify('Deleted', item.name + ' deleted');
            }
        },
        
        showFileContextMenu(event, index) {
            const item = fileSystem[this.currentFolder][index];
            const menu = document.createElement('div');
            menu.className = 'context-menu';
            menu.style.display = 'block';
            menu.style.left = event.clientX + 'px';
            menu.style.top = event.clientY + 'px';
            
            menu.innerHTML = `
                <div class="context-menu-item" onclick="HyFiles.selectFile(${index}, null); this.parentElement.remove();">
                    📂 Open
                </div>
                <div class="context-menu-item" onclick="HyFiles.deleteFile(${index}); this.parentElement.remove();">
                    🗑️ Delete
                </div>
                <div class="context-menu-item" onclick="this.parentElement.remove();">
                    ✕ Cancel
                </div>
            `;
            
            document.body.appendChild(menu);
            
            setTimeout(() => {
                const closeMenu = () => {
                    menu.remove();
                    document.removeEventListener('click', closeMenu);
                };
                document.addEventListener('click', closeMenu);
            }, 10);
        },
        
        showAudioOptions(item, index) {
            const dialog = document.createElement('div');
            dialog.className = 'context-menu';
            dialog.style.display = 'block';
            dialog.style.left = '50%';
            dialog.style.top = '50%';
            dialog.style.transform = 'translate(-50%, -50%)';
            dialog.style.minWidth = '350px';
            dialog.style.padding = '20px';
            
            dialog.innerHTML = `
                <div style="margin-bottom: 15px; font-size: 14px; font-weight: 600;">
                    🎵 Audio File Options
                </div>
                <div style="font-size: 12px; opacity: 0.6; margin-bottom: 15px;">
                    ${item.name}
                </div>
                <div class="context-menu-item" onclick="HyFiles.playAudio(${index}); this.parentElement.remove();">
                    ▶️ Play Audio
                </div>
                <div class="context-menu-item" onclick="HyFiles.copyAudioURL(${index}); this.parentElement.remove();">
                    📋 Copy URL
                </div>
                <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px;">
                    Cancel
                </div>
            `;
            
            document.body.appendChild(dialog);
            
            setTimeout(() => {
                const closeDialog = (e) => {
                    if (!dialog.contains(e.target)) {
                        dialog.remove();
                        document.removeEventListener('click', closeDialog);
                    }
                };
                document.addEventListener('click', closeDialog);
            }, 10);
        },
        
        playAudio(index) {
            const item = fileSystem[this.currentFolder][index];
            if (item && item.data) {
                const audio = new Audio(item.data);
                audio.play();
                notify('Playing', item.name);
            }
        },
        
        copyAudioURL(index) {
            const item = fileSystem[this.currentFolder][index];
            if (item && item.data) {
                navigator.clipboard.writeText(item.data).then(() => {
                    notify('Copied!', 'Audio URL copied to clipboard');
                }).catch(err => {
                    // Fallback for older browsers
                    const textarea = document.createElement('textarea');
                    textarea.value = item.data;
                    textarea.style.position = 'fixed';
                    textarea.style.opacity = '0';
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    notify('Copied!', 'Audio URL copied to clipboard');
                });
            }
        },
        
        createFolder() {
            const name = prompt('Folder name:');
            if (!name) return;
            
            fileSystem[this.currentFolder].push({
                name: name,
                type: 'folder',
                created: new Date().toISOString()
            });
            
            this.refresh();
            notify('Created', 'Folder created');
        },
        
        uploadFile() {
            const input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.accept = '*/*';
            input.onchange = (e) => {
                Array.from(e.target.files).forEach(file => {
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                        const fileData = {
                            name: file.name,
                            type: file.type,
                            data: evt.target.result,
                            size: file.size,
                            created: new Date().toISOString()
                        };
                        // Put in current folder; auto-sort only if in root
                        if (this.currentFolder === 'root') {
                            if (file.type.startsWith('image/')) fileSystem.images.push(fileData);
                            else if (file.type.startsWith('video/')) fileSystem.videos.push(fileData);
                            else fileSystem.root.push(fileData);
                        } else {
                            if (!fileSystem[this.currentFolder]) fileSystem[this.currentFolder] = [];
                            fileSystem[this.currentFolder].push(fileData);
                        }
                        this.saveFileSystem();
                        this.refresh();
                        notify('📁 Imported', file.name + ' saved to ' + this.currentFolder);                    };
                    reader.readAsDataURL(file);
                });
            };
            input.click();
        },
        
        deleteSelected() {
            if (selectedFiles.length === 0) {
                notify('Error', 'No files selected');
                return;
            }
            
            if (confirm(`Delete ${selectedFiles.length} file(s)?`)) {
                selectedFiles.sort((a, b) => b - a).forEach(index => {
                    fileSystem[this.currentFolder].splice(index, 1);
                });
                selectedFiles = [];
                this.refresh();
                notify('Deleted', 'Files deleted');
            }
        },
        
        // Called by browser when downloading
        addDownload(fileName, fileType, fileData) {
            fileSystem.downloads.push({
                name: fileName,
                type: fileType,
                data: fileData,
                created: new Date().toISOString()
            });
            this.saveFileSystem();
            notify('Downloaded', fileName + ' saved to Downloads');
        },
        
        saveFileSystem() {
            try {
                localStorage.setItem('hyos_fs_' + user, JSON.stringify(fileSystem));
            } catch (e) {
                console.error('Failed to save file system:', e);
            }
        }
    };
    
    window.HyFiles = HyFiles;
    
    // =====================
    // IMAGE/VIDEO VIEWER
    // =====================
    
    const Viewer = {
        currentFile: null,
        currentType: null,
        
        open(file, type) {
            this.currentFile = file;
            this.currentType = type;
            
            const title = document.getElementById('viewer-title');
            const image = document.getElementById('viewer-image');
            const video = document.getElementById('viewer-video');
            
            if (!title || !image || !video) return;
            
            title.textContent = '📷 ' + file.name;
            
            if (type === 'image') {
                image.src = file.data;
                image.style.display = 'block';
                video.style.display = 'none';
            } else if (type === 'video') {
                video.src = file.data;
                video.style.display = 'block';
                image.style.display = 'none';
            }
            
            toggleApp('viewer-win');
        },
        
        setAsWallpaper() {
            if (!this.currentFile) return;
            
            const bg = document.getElementById('desktop-bg');
            
            if (this.currentType === 'image') {
                bg.style.backgroundImage = `url(${this.currentFile.data})`;
                bg.style.backgroundSize = 'cover';
                bg.style.backgroundPosition = 'center';
                notify('Wallpaper Set', 'Desktop wallpaper updated!');
            } else if (this.currentType === 'video') {
                const videoEl = document.getElementById('bg-video');
                videoEl.src = this.currentFile.data;
                videoEl.style.display = 'block';
                document.getElementById('bg-3d').style.display = 'none';
                bg.style.backgroundImage = 'none';
                notify('Wallpaper Set', 'Video wallpaper enabled!');
            }
        },
        
        download() {
            if (!this.currentFile) return;
            
            const a = document.createElement('a');
            a.href = this.currentFile.data;
            a.download = this.currentFile.name;
            a.click();
            
            notify('Downloaded', this.currentFile.name + ' downloaded');
        },
        
        close() {
            closeApp('viewer-win');
        }
    };
    
    window.Viewer = Viewer;
    
    // =====================
    // NOTEPAD APP
    // =====================
    
    const Notepad = {
        currentFile: null, // { folder: string, index: number }
        
        open(file, folder, index) {
            this.currentFile = { folder, index };
            
            const title = document.getElementById('notepad-title');
            const filename = document.getElementById('notepad-filename');
            const content = document.getElementById('notepad-content');
            
            if (title) title.textContent = '📝 ' + file.name;
            if (filename) filename.textContent = file.name;
            if (content) content.value = file.data || file.content || '';
            
            toggleApp('notepad-win');
        },
        
        save() {
            if (!this.currentFile) {
                this.saveAs();
                return;
            }
            
            const content = document.getElementById('notepad-content');
            if (!content) return;
            
            const { folder, index } = this.currentFile;
            if (fileSystem[folder] && fileSystem[folder][index]) {
                fileSystem[folder][index].data = content.value;
                fileSystem[folder][index].content = content.value;
                HyFiles.saveFileSystem();
                notify('Saved', 'File saved successfully');
            }
        },
        
        saveAs() {
            const content = document.getElementById('notepad-content');
            if (!content) return;
            
            const name = prompt('File name (include extension):');
            if (!name) return;
            
            const ext = name.split('.').pop().toLowerCase();
            let fileType = 'text/plain';
            
            if (ext === 'html') {
                fileType = 'text/html';
            }
            
            const newFile = {
                name: name,
                type: fileType,
                data: content.value,
                content: content.value,
                created: new Date().toISOString()
            };
            
            fileSystem.root.push(newFile);
            HyFiles.saveFileSystem();
            
            this.currentFile = { folder: 'root', index: fileSystem.root.length - 1 };
            
            const title = document.getElementById('notepad-title');
            const filename = document.getElementById('notepad-filename');
            if (title) title.textContent = '📝 ' + name;
            if (filename) filename.textContent = name;
            
            notify('Saved', 'File saved as ' + name);
            
            if (document.getElementById('hyfiles-win').style.display === 'flex') {
                HyFiles.refresh();
            }
        },
        
        clear() {
            if (confirm('Clear all content?')) {
                const content = document.getElementById('notepad-content');
                if (content) content.value = '';
            }
        },
        
        newFile() {
            this.currentFile = null;
            const title = document.getElementById('notepad-title');
            const filename = document.getElementById('notepad-filename');
            const content = document.getElementById('notepad-content');
            
            if (title) title.textContent = '📝 Notepad';
            if (filename) filename.textContent = 'Untitled';
            if (content) content.value = '';
            
            toggleApp('notepad-win');
        }
    };
    
    window.Notepad = Notepad;
    
    // =====================
    // APP MAKER PRO - EXPLORER
    // =====================
    
    const AppBuilder = {
        currentProject: {
            name: 'My App',
            files: [
                { name: 'Main.html', type: 'html', isMainFile: true, content: '<!DOCTYPE html>\n<html>\n<head>\n    <title>HyOS HS — HyService</title>\n</head>\n<body>\n    <h1>Hello World!</h1>\n</body>\n</html>' },
                { name: 'Mani.manifest', type: 'json', content: '{\n  "name": "My App",\n  "version": "1.0",\n  "description": "A new app",\n  "native": true,\n  "permissions": []\n}' }
            ],
            currentFileIndex: 0
        },
        
        init() {
            this.renderFileTree();
            this.loadCurrentFile();
        },
        
        newFile() {
            const name = prompt('File name (e.g., style.css, Src/component.jsx) or collection(name) to create a Firestore collection:');
            if (!name) return;

            // ── COLLECTION syntax ────────────────────────────────────────
            const colMatch = name.match(/^collection\(([^)]+)\)$/i);
            if (colMatch) {
                const colName = colMatch[1].trim();
                const fileName = 'collection(' + colName + ')';
                if (this.currentProject.files.find(f => f.name === fileName)) {
                    notify('Exists', 'Collection "' + colName + '" already exists.');
                    return;
                }
                this.currentProject.files.push({
                    name: fileName,
                    type: 'collection',
                    content: JSON.stringify({ docs: {} }, null, 2),
                    folder: ''
                });
                this.currentProject.currentFileIndex = this.currentProject.files.length - 1;
                this.renderFileTree();
                this.loadCurrentFile();
                notify('🗄️ Collection', '"' + colName + '" collection created!');
                return;
            }
            
            // Block Firebase access in JSON files
            const ext = name.split('.').pop().toLowerCase();
            if (ext === 'json' && (name.toLowerCase().includes('firebase') || name.toLowerCase().includes('db'))) {
                notify('Error', 'Cannot create files with Firebase references');
                return;
            }
            
            let fileType = 'text';
            let content = '';
            
            if (ext === 'html') {
                fileType = 'html';
                content = '<!DOCTYPE html>\n<html>\n<head>\n    <title>HyOS HS — HyService</title>\n</head>\n<body>\n    \n</body>\n</html>';
            } else if (ext === 'css') {
                fileType = 'css';
                content = '/* CSS Styles */\nbody {\n    margin: 0;\n    padding: 0;\n}\n';
            } else if (ext === 'js') {
                fileType = 'js';
                content = '// JavaScript\nconsole.log("Hello from ' + name + '");\n';
            } else if (ext === 'jsx') {
                fileType = 'jsx';
                content = '// React Component\nimport React from "react";\n\nfunction MyComponent() {\n    return (\n        <div>\n            <h1>Hello from React!</h1>\n        </div>\n    );\n}\n\nexport default MyComponent;\n';
            } else if (ext === 'py') {
                fileType = 'py';
                content = '# Python Script\n\ndef main():\n    print("Hello from Python!")\n\nif __name__ == "__main__":\n    main()\n';
            } else if (ext === 'json') {
                fileType = 'json';
                content = '{\n    "action": "example",\n    "description": "JSON configuration file"\n}';
            } else if (ext === 'hl') {
                fileType = 'hl';
                content = '{\n    "Type1": "HTML",\n    "Lines": [\n        "<!DOCTYPE html>",\n        "<html>",\n        "<head>",\n        "    <title>HyOS HS — HyService</title>",\n        "</head>",\n        "<body>",\n        "    <h1>Hello from .HL!</h1>",\n        "    <button id=\\"actionBtn\\">Click Me</button>",\n        "</body>",\n        "</html>"\n    ],\n    "Type2": "JSON",\n    "Mode": "dojsonaction",\n    "JSONActions": [\n        {\n            "systemAction": "notify",\n            "title": "HL App",\n            "message": "App loaded successfully!",\n            "actiontype": "opened"\n        }\n    ]\n}';
            }
            
            // Determine folder - support nested paths
            const folder = name.includes('/') ? name.substring(0, name.lastIndexOf('/')) : '';
            
            this.currentProject.files.push({ name: name, type: fileType, content: content, folder: folder });
            this.currentProject.currentFileIndex = this.currentProject.files.length - 1;
            
            this.renderFileTree();
            this.loadCurrentFile();
            notify('Created', 'File created: ' + name);
        },
        
        renderFileTree() {
            const tree = document.getElementById('builder-file-tree');
            if (!tree) return;
            
            const icons = { html: '📄', css: '🎨', js: '⚡', jsx: '⚛️', py: '🐍', json: '⚙️', text: '📝', audio: '🎵', hl: '⛓️', Hl: '⛓️', hL: '⛓️', HL: '⛓️', collection: '🗄️' };
            
            // Get all unique folders
            const folders = {};
            this.currentProject.files.forEach(file => {
                if (file.folder) {
                    const topFolder = file.folder.split('/')[0];
                    if (!folders[topFolder]) {
                        folders[topFolder] = [];
                    }
                    folders[topFolder].push(file);
                }
            });
            
            // Sort files: Main.html first, Mani.manifest second, then Src folder (with all contents), then root files
            const sortedFiles = this.currentProject.files.map((file, idx) => ({ file, originalIndex: idx })).sort((a, b) => {
                const aName = a.file.name;
                const bName = b.file.name;
                
                // Main file (Main.html or renamed) always first
                if (a.file.isMainFile || aName === 'Main.html') return -1;
                if (b.file.isMainFile || bName === 'Main.html') return 1;
                
                // Mani.manifest always second
                if (aName === 'Mani.manifest') return -1;
                if (bName === 'Mani.manifest') return 1;
                
                // Files with folders come after root files (except special ones)
                const aHasFolder = !!a.file.folder;
                const bHasFolder = !!b.file.folder;
                
                // Src folder and its contents should come after Main.html and Mani.manifest
                const aInSrc = a.file.folder?.startsWith('Src');
                const bInSrc = b.file.folder?.startsWith('Src');
                
                if (aInSrc && !bInSrc && !bName.startsWith('Main') && !bName.startsWith('Mani')) return -1;
                if (!aInSrc && bInSrc && !aName.startsWith('Main') && !aName.startsWith('Mani')) return 1;
                
                if (!aHasFolder && bHasFolder) return -1;
                if (aHasFolder && !bHasFolder) return 1;
                
                // Within folders, sort by folder name then file name
                if (aHasFolder && bHasFolder) {
                    const aFolder = a.file.folder.split('/')[0];
                    const bFolder = b.file.folder.split('/')[0];
                    if (aFolder !== bFolder) return aFolder.localeCompare(bFolder);
                    return aName.localeCompare(bName);
                }
                
                // Root files sort alphabetically
                return aName.localeCompare(bName);
            });
            
            let html = '';
            let currentFolder = null;
            let srcFolderShown = false;
            
            sortedFiles.forEach(({ file, originalIndex }) => {
                const icon = icons[file.type] || '📄';
                const active = originalIndex === this.currentProject.currentFileIndex;
                const bgStyle = active ? 'background: #1e293b; border: 1px solid #2563eb;' : 'background: rgba(255,255,255,0.03);';
                
                // Check if this is an audio file
                const isAudio = file.type === 'audio' || (file.data && file.data.startsWith('data:audio/'));
                
                // If file is in a folder
                if (file.folder) {
                    const topFolder = file.folder.split('/')[0];
                    
                    // Add Src folder header if this is the first file in Src
                    if (topFolder === 'Src' && !srcFolderShown) {
                        srcFolderShown = true;
                        html += '<div style="padding: 8px 12px; font-size: 11px; font-weight: 700; opacity: 0.5; text-transform: uppercase; letter-spacing: 1px; display: flex; justify-content: space-between; align-items: center;">' +
                                '<span>📁 Src/</span>' +
                                '<button onclick="AppBuilder.createInFolder(\'Src\'); event.stopPropagation();" style="background: #2563eb; border: none; color: #fff; padding: 4px 8px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold;" title="Create file/subfolder in Src">➕</button>' +
                                '</div>';
                    }
                    
                    // Check if this is inside a subfolder (like JSON inside Src)
                    const isSubfolder = file.folder.includes('/');
                    
                    // Add subfolder header if needed
                    if (isSubfolder) {
                        const subfolder = file.folder.substring(file.folder.indexOf('/') + 1);
                        const fullSubfolderPath = topFolder + '/' + subfolder.split('/')[0];
                        
                        if (currentFolder !== fullSubfolderPath) {
                            currentFolder = fullSubfolderPath;
                            html += '<div style="padding: 8px 12px 8px 24px; font-size: 11px; font-weight: 700; opacity: 0.5; text-transform: uppercase; letter-spacing: 1px; display: flex; justify-content: space-between; align-items: center;">' +
                                    '<span>📁 ' + subfolder.split('/')[0] + '/</span>' +
                                    '<button onclick="AppBuilder.createInFolder(\'' + fullSubfolderPath + '\'); event.stopPropagation();" style="background: #2563eb; border: none; color: #fff; padding: 4px 8px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold;" title="Create file in ' + fullSubfolderPath + '">➕</button>' +
                                    '</div>';
                        }
                    }
                    
                    const displayName = '  └─ ' + file.name.substring(file.folder.length + 1);
                    const indent = isSubfolder ? ' margin-left: 20px;' : ' margin-left: 10px;';
                    
                    if (isAudio) {
                        html += '<div style="padding: 10px 12px; border-radius: 8px; margin-bottom: 4px; font-size: 13px;' + indent + bgStyle + '">' +
                            '<div style="display: flex; align-items: center; gap: 8px;">' +
                            '<span>' + icon + '</span>' +
                            '<span style="flex: 1;">' + displayName + '</span>' +
                            '</div>' +
                            '<button onclick="AppBuilder.copyAudioURL(' + originalIndex + '); event.stopPropagation();" style="margin-top: 6px; width: 100%; background: #2563eb; border: none; color: #fff; padding: 6px; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600;">📋 Copy URL</button>' +
                            '</div>';
                    } else {
                        html += '<div onclick="AppBuilder.selectFile(' + originalIndex + ')" style="padding: 10px 12px; border-radius: 8px; cursor: pointer; margin-bottom: 4px; font-size: 13px;' + indent + 'display: flex; align-items: center; gap: 8px; ' + bgStyle + '">' +
                            '<span>' + icon + '</span>' +
                            '<span style="flex: 1;">' + displayName + '</span>' +
                            '</div>';
                    }
                } else {
                    // Root file
                    currentFolder = null;
                    
                    if (isAudio) {
                        html += '<div style="padding: 10px 12px; border-radius: 8px; margin-bottom: 4px; font-size: 13px; ' + bgStyle + '">' +
                            '<div style="display: flex; align-items: center; gap: 8px;">' +
                            '<span>' + icon + '</span>' +
                            '<span style="flex: 1;">' + file.name + '</span>' +
                            '</div>' +
                            '<button onclick="AppBuilder.copyAudioURL(' + originalIndex + '); event.stopPropagation();" style="margin-top: 6px; width: 100%; background: #2563eb; border: none; color: #fff; padding: 6px; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600;">📋 Copy URL</button>' +
                            '</div>';
                    } else {
                        html += '<div onclick="AppBuilder.selectFile(' + originalIndex + ')" style="padding: 10px 12px; border-radius: 8px; cursor: pointer; margin-bottom: 4px; font-size: 13px; display: flex; align-items: center; gap: 8px; ' + bgStyle + '">' +
                            '<span>' + icon + '</span>' +
                            '<span style="flex: 1;">' + file.name + '</span>' +
                            '</div>';
                    }
                }
            });
            
            // Add Src folder at the end if it doesn't exist yet
            if (!srcFolderShown) {
                html += '<div style="padding: 8px 12px; font-size: 11px; font-weight: 700; opacity: 0.5; text-transform: uppercase; letter-spacing: 1px; display: flex; justify-content: space-between; align-items: center;">' +
                        '<span>📁 Src/</span>' +
                        '<button onclick="AppBuilder.createInFolder(\'Src\'); event.stopPropagation();" style="background: #2563eb; border: none; color: #fff; padding: 4px 8px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold;" title="Create file/subfolder in Src">➕</button>' +
                        '</div>';
            }
            
            tree.innerHTML = html;
        },
        
        selectFile(index) {
            // Save current file content before switching
            this.saveCurrentFile();
            
            this.currentProject.currentFileIndex = index;
            this.renderFileTree();
            this.loadCurrentFile();
        },
        
        loadCurrentFile() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file) return;

            const filenameLabel  = document.getElementById('builder-current-file');
            const editor         = document.getElementById('builder-code-editor');
            const collectionPane = document.getElementById('builder-collection-editor');

            if (filenameLabel) filenameLabel.textContent = file.name;

            if (file.type === 'collection') {
                // Show collection editor, hide textarea
                if (editor)         editor.style.display    = 'none';
                if (collectionPane) collectionPane.style.display = 'flex';
                this.renderCollectionEditor();
            } else {
                // Show textarea, hide collection editor
                if (editor)         { editor.style.display = 'flex'; editor.value = file.content || ''; }
                if (collectionPane) collectionPane.style.display = 'none';

                // Attach live preview debounce once
                if (!editor._livePreviewBound) {
                    editor._livePreviewBound = true;
                    editor.addEventListener('input', () => this._scheduleLiveRefresh());
                }
            }
        },

        saveCurrentFile() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file) return;
            // Collections save themselves on every mutation; skip textarea save for them
            if (file.type === 'collection') return;
            const editor = document.getElementById('builder-code-editor');
            if (editor) file.content = editor.value;
        },
        
        deleteCurrentFile() {
            if (this.currentProject.files.length <= 1) {
                notify('Error', 'Cannot delete the last file in project');
                return;
            }
            
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!confirm(`Delete ${file.name}?`)) return;
            
            // If deleting a JSON file, stop any associated actions
            if (file.name.endsWith('.json')) {
                try {
                    const parsed = JSON.parse(file.content);
                    const action = parsed.systemaction || parsed.systemAction;
                    
                    // Clear any timed intervals set by this JSON file
                    if (action === 'notify' && parsed.actiontype === 'timed' && parsed.repeated) {
                        // Clear all intervals (this will stop all timed notifications)
                        // Note: In a production app, you'd want to track interval IDs per JSON file
                        const highestId = setTimeout(() => {}, 0);
                        for (let i = 0; i < highestId; i++) {
                            clearInterval(i);
                        }
                        notify('Stopped', 'Timed actions from ' + file.name + ' have been stopped');
                    }
                } catch (e) {
                    // If JSON parsing fails, just continue with deletion
                    console.error('Error stopping JSON actions:', e);
                }
            }
            
            this.currentProject.files.splice(this.currentProject.currentFileIndex, 1);
            this.currentProject.currentFileIndex = Math.max(0, this.currentProject.currentFileIndex - 1);
            
            this.renderFileTree();
            this.loadCurrentFile();
            notify('Deleted', 'File deleted');
        },
        
        renameCurrentFile() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            const oldName = file.name;
            
            // Get new name from user
            const newName = prompt('Rename file:', oldName);
            
            // Validate input
            if (!newName) return; // User cancelled
            if (newName === oldName) return; // No change
            
            // Check if name already exists
            const nameExists = this.currentProject.files.some((f, idx) => 
                f.name === newName && idx !== this.currentProject.currentFileIndex
            );
            
            if (nameExists) {
                notify('Error', 'A file with this name already exists');
                return;
            }
            
            // Track if this was Main.html being renamed
            const wasMainFile = (oldName === 'Main.html');
            
            // Prevent renaming Main.html or Mani.manifest to something else
            if ((oldName === 'Main.html' || oldName === 'Mani.manifest') && 
                newName !== oldName && 
                !confirm(`Warning: Renaming ${oldName} may cause issues. Continue?`)) {
                return;
            }
            
            // Update file type based on new extension
            const ext = newName.split('.').pop().toLowerCase();
            const fileTypeMap = {
                'html': 'html',
                'css': 'css',
                'js': 'js',
                'jsx': 'jsx',
                'py': 'py',
                'json': 'json',
                'hl': 'hl'
            };
            
            if (fileTypeMap[ext]) {
                file.type = fileTypeMap[ext];
            }
            
            // Update the file name
            file.name = newName;
            
            // Mark this as the main file if it was Main.html
            if (wasMainFile) {
                file.isMainFile = true;
            }
            
            // Update folder if path changed (e.g., renamed "file.js" to "Src/file.js")
            if (newName.includes('/')) {
                file.folder = newName.substring(0, newName.lastIndexOf('/'));
            } else {
                file.folder = '';
            }
            
            // Refresh the UI
            this.renderFileTree();
            this.loadCurrentFile();
            notify('Renamed', `File renamed to ${newName}`);
        },
        
        preview() {
            this.saveCurrentFile();
            this.refreshPreview();
        },

        refreshPreview() {
            const iframe = document.getElementById('builder-preview');
            if (!iframe) return;

            // Execute JSON files for testing (notifications, etc)
            const jsonFiles = this.currentProject.files.filter(f => f.name.endsWith('.json'));
            jsonFiles.forEach(jsonFile => {
                try {
                    const parsed = JSON.parse(jsonFile.content);
                    if (parsed.systemaction || parsed.systemAction) {
                        this.executeJSONAction(parsed, true);
                    }
                } catch (e) { console.error('JSON parse error in ' + jsonFile.name + ':', e); }
            });

            // Execute .HL files
            const hlFiles = this.currentProject.files.filter(f => f.name.endsWith('.hl'));
            let hlHTML = '';
            hlFiles.forEach(hlFile => {
                try {
                    const html = this.executeHLFile(hlFile.content, true);
                    if (html) hlHTML += html;
                } catch (e) { console.error('.HL file error:', e); }
            });

            const htmlFile = this.currentProject.files.find(f => f.name.endsWith('.html'));
            const cssFiles = this.currentProject.files.filter(f => f.name.endsWith('.css'));
            const jsFiles  = this.currentProject.files.filter(f => f.name.endsWith('.js'));

            let html = htmlFile ? htmlFile.content : hlHTML;
            if (!html) return;

            if (cssFiles.length) {
                const s = '<style>' + cssFiles.map(f => f.content).join('\n') + '</style>';
                html = html.includes('</head>') ? html.replace('</head>', s + '</head>') : s + html;
            }
            if (jsFiles.length) {
                const s = '<script>' + jsFiles.map(f => f.content).join('\n') + '<\/script>';
                html = html.includes('</body>') ? html.replace('</body>', s + '</body>') : html + s;
            }

            // Use srcdoc for smooth updates instead of document.write
            iframe.srcdoc = html;

            // Flash indicator green
            const dot = document.getElementById('live-preview-indicator');
            if (dot) { dot.style.background = '#22c55e'; setTimeout(() => { dot.style.background = this._livePreviewOn ? '#22c55e' : '#334155'; }, 400); }
        },

        _livePreviewOn: false,
        _liveDebounceTimer: null,

        toggleLivePreview() {
            this._livePreviewOn = !this._livePreviewOn;
            const btn = document.getElementById('btn-live-preview');
            const dot = document.getElementById('live-preview-indicator');
            if (this._livePreviewOn) {
                btn.style.background = '#16a34a';
                btn.textContent = '⚡ Live ON';
                if (dot) dot.style.background = '#22c55e';
                this.refreshPreview();
            } else {
                btn.style.background = '#334155';
                btn.textContent = '⚡ Live';
                if (dot) dot.style.background = '#334155';
            }
        },

        _scheduleLiveRefresh() {
            if (!this._livePreviewOn) return;
            clearTimeout(this._liveDebounceTimer);
            this._liveDebounceTimer = setTimeout(() => {
                this.saveCurrentFile();
                this.refreshPreview();
            }, 600);
        },

        // ── COLLECTION EDITOR ─────────────────────────────────────────────
        _colFieldTypes: ['string', 'number', 'boolean', 'array', 'map', 'timestamp', 'geopoint', 'reference', 'null'],

        _parseCollectionName(rawName) {
            const m = rawName.match(/^collection\(([^)]+)\)$/i);
            return m ? m[1].trim() : null;
        },

        _getCollectionData() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file || file.type !== 'collection') return null;
            try { return JSON.parse(file.content || '{"docs":{}}'); } catch { return { docs: {} }; }
        },

        _saveCollectionData(data) {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (file) file.content = JSON.stringify(data, null, 2);
        },

        renderCollectionEditor() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file || file.type !== 'collection') return;

            const collectionName = this._parseCollectionName(file.name) || file.name;
            const scope = this._appspaceScope();
            document.getElementById('collection-editor-title').textContent = '🗄️ ' + collectionName;
            document.querySelector('#builder-collection-editor .text-xs') && (document.querySelector('#builder-collection-editor .text-xs').textContent = `appspace/${scope}/collections/${collectionName}/docs`);

            const data = this._getCollectionData();
            const list = document.getElementById('collection-doc-list');
            if (!list) return;

            const docs = data.docs || {};
            const docNames = Object.keys(docs);

            if (docNames.length === 0) {
                list.innerHTML = `<div style="text-align:center;padding:40px;opacity:0.3;font-size:13px;">No documents yet.<br>Click <strong>＋ New Document</strong> or type <code>doc(name)</code> above.</div>`;
                return;
            }

            list.innerHTML = docNames.map(docName => {
                const doc = docs[docName];
                const fields = doc.fields || {};
                const fieldCount = Object.keys(fields).length;
                return `
                    <div style="background:rgba(255,255,255,0.03);border:1px solid #1e293b;border-radius:12px;overflow:hidden;">
                        <div style="padding:12px 16px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;background:rgba(14,165,233,0.05);" onclick="AppBuilder.toggleDocExpand('${docName}')">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <span style="font-size:16px;">📄</span>
                                <div>
                                    <div style="font-size:13px;font-weight:700;">${docName}</div>
                                    <div style="font-size:10px;opacity:0.4;">${fieldCount} field${fieldCount !== 1 ? 's' : ''}</div>
                                </div>
                            </div>
                            <div style="display:flex;gap:6px;">
                                <button onclick="event.stopPropagation();AppBuilder.addField('${docName}')" style="background:rgba(37,99,235,0.2);border:1px solid rgba(37,99,235,0.4);color:#93c5fd;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:11px;font-weight:700;">＋ Field</button>
                                <button onclick="event.stopPropagation();AppBuilder.window._fb.deleteDoc('${docName}')" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:11px;">✕</button>
                            </div>
                        </div>
                        <div id="doc-fields-${docName}" style="padding:12px;display:flex;flex-direction:column;gap:6px;">
                            ${Object.entries(fields).map(([fieldName, fieldData]) => this._renderField(docName, fieldName, fieldData)).join('')}
                            ${fieldCount === 0 ? `<div style="font-size:11px;opacity:0.3;text-align:center;padding:8px;">No fields — click ＋ Field to add one</div>` : ''}
                        </div>
                    </div>
                `;
            }).join('');
        },

        _renderField(docName, fieldName, fieldData) {
            const type  = fieldData.type  || 'string';
            const value = fieldData.value;
            const typeColors = {
                string:'#22d3ee', number:'#a78bfa', boolean:'#fb923c',
                array:'#4ade80', map:'#facc15', timestamp:'#f472b6',
                geopoint:'#34d399', reference:'#f97316', null:'#94a3b8'
            };
            const color = typeColors[type] || '#94a3b8';

            let valueDisplay = '';
            if (type === 'boolean') {
                valueDisplay = `
                    <div style="display:flex;gap:6px;">
                        <button onclick="AppBuilder.setFieldValue('${docName}','${fieldName}',true)" style="padding:4px 12px;border-radius:6px;border:1px solid ${value===true?'#fb923c':'#334155'};background:${value===true?'rgba(251,146,60,0.2)':'transparent'};color:${value===true?'#fb923c':'#94a3b8'};cursor:pointer;font-size:11px;font-weight:700;">true</button>
                        <button onclick="AppBuilder.setFieldValue('${docName}','${fieldName}',false)" style="padding:4px 12px;border-radius:6px;border:1px solid ${value===false?'#fb923c':'#334155'};background:${value===false?'rgba(251,146,60,0.2)':'transparent'};color:${value===false?'#fb923c':'#94a3b8'};cursor:pointer;font-size:11px;font-weight:700;">false</button>
                    </div>`;
            } else if (type === 'null') {
                valueDisplay = `<span style="font-size:11px;opacity:0.4;font-style:italic;">null</span>`;
            } else if (type === 'timestamp') {
                const isCustom = value && value !== 'serverTimestamp';
                valueDisplay = `
                    <div style="display:flex;flex-direction:column;gap:4px;">
                        <button onclick="AppBuilder.setFieldValue('${docName}','${fieldName}','serverTimestamp')" style="background:${!isCustom?'rgba(244,114,182,0.2)':'rgba(255,255,255,0.05)'};border:1px solid ${!isCustom?'rgba(244,114,182,0.5)':'#334155'};color:${!isCustom?'#f472b6':'#94a3b8'};padding:4px 10px;border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;">⏱ serverTimestamp()</button>
                        <div style="display:flex;align-items:center;gap:6px;">
                            <span style="font-size:10px;opacity:0.4;">or custom:</span>
                            <input type="datetime-local" value="${isCustom ? value : ''}" onchange="AppBuilder.setFieldValue('${docName}','${fieldName}',this.value)" style="background:#0f172a;border:1px solid #334155;border-radius:6px;padding:3px 8px;color:#fff;font-size:11px;outline:none;">
                        </div>
                    </div>`;
            } else if (type === 'geopoint') {
                const geo = (typeof value === 'object' && value) ? value : { lat: 0, lng: 0 };
                valueDisplay = `
                    <div style="display:flex;align-items:center;gap:6px;">
                        <span style="font-size:10px;color:#34d399;font-weight:700;">LAT</span>
                        <input type="number" step="any" value="${geo.lat ?? 0}" onchange="AppBuilder.setGeoField('${docName}','${fieldName}','lat',this.value)" style="background:#0f172a;border:1px solid #334155;border-radius:6px;padding:4px 8px;color:#fff;font-size:12px;font-family:monospace;outline:none;width:90px;">
                        <span style="font-size:10px;color:#34d399;font-weight:700;">LNG</span>
                        <input type="number" step="any" value="${geo.lng ?? 0}" onchange="AppBuilder.setGeoField('${docName}','${fieldName}','lng',this.value)" style="background:#0f172a;border:1px solid #334155;border-radius:6px;padding:4px 8px;color:#fff;font-size:12px;font-family:monospace;outline:none;width:90px;">
                    </div>`;
            } else if (type === 'reference') {
                valueDisplay = `
                    <div style="display:flex;flex-direction:column;gap:4px;flex:1;">
                        <input value="${String(value ?? '').replace(/"/g,'&quot;')}" placeholder="e.g. appspace/MyApp/collections/users/docs/alice" onchange="AppBuilder.setFieldValue('${docName}','${fieldName}',this.value)" style="background:#0f172a;border:1px solid rgba(249,115,22,0.4);border-radius:6px;padding:5px 10px;color:#fdba74;font-size:11px;font-family:monospace;outline:none;width:100%;">
                        <span style="font-size:10px;opacity:0.35;">Firestore document path</span>
                    </div>`;
            } else if (type === 'array') {
                const arr = Array.isArray(value) ? value : [];
                valueDisplay = `
                    <div style="background:rgba(0,0,0,0.3);border-radius:6px;padding:8px;font-size:11px;font-family:monospace;min-height:28px;">[${arr.map(v => JSON.stringify(v)).join(', ')}]</div>
                    <button onclick="AppBuilder.addArrayItem('${docName}','${fieldName}')" style="background:rgba(74,222,128,0.1);border:1px solid rgba(74,222,128,0.2);color:#4ade80;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:10px;margin-top:4px;">＋ item</button>`;
            } else if (type === 'map') {
                const map = (typeof value === 'object' && value !== null && !Array.isArray(value)) ? value : {};
                valueDisplay = `<div style="background:rgba(0,0,0,0.3);border-radius:6px;padding:8px;font-size:11px;font-family:monospace;">{${Object.entries(map).map(([k,v])=>`${k}: ${JSON.stringify(v)}`).join(', ')}}</div>
                    <button onclick="AppBuilder.addMapEntry('${docName}','${fieldName}')" style="background:rgba(250,204,21,0.1);border:1px solid rgba(250,204,21,0.2);color:#facc15;padding:3px 8px;border-radius:5px;cursor:pointer;font-size:10px;margin-top:4px;">＋ entry</button>`;
            } else {
                valueDisplay = `<input value="${String(value ?? '').replace(/"/g,'&quot;')}" onchange="AppBuilder.setFieldValue('${docName}','${fieldName}',this.value)" style="background:#0f172a;border:1px solid #334155;border-radius:6px;padding:5px 10px;color:#fff;font-size:12px;font-family:monospace;outline:none;flex:1;min-width:0;">`;
            }

            return `
                <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 8px;border-radius:8px;background:rgba(255,255,255,0.02);">
                    <span style="font-size:10px;font-weight:700;color:${color};padding:3px 7px;border-radius:4px;background:${color}1a;border:1px solid ${color}33;white-space:nowrap;margin-top:2px;">${type}</span>
                    <span style="font-size:12px;font-weight:600;color:rgba(255,255,255,0.7);margin-top:4px;white-space:nowrap;">${fieldName}</span>
                    <div style="flex:1;">${valueDisplay}</div>
                    <select onchange="AppBuilder.changeFieldType('${docName}','${fieldName}',this.value)" style="background:#1e293b;border:1px solid #334155;color:#94a3b8;padding:3px 6px;border-radius:6px;font-size:10px;cursor:pointer;">
                        ${this._colFieldTypes.map(t => `<option value="${t}" ${t===type?'selected':''}>${t}</option>`).join('')}
                    </select>
                    <button onclick="AppBuilder.deleteField('${docName}','${fieldName}')" style="background:transparent;border:none;color:#ef4444;cursor:pointer;padding:2px 6px;font-size:12px;opacity:0.5;margin-top:1px;">✕</button>
                </div>`;
        },

        setGeoField(docName, fieldName, axis, rawVal) {
            const data = this._getCollectionData();
            const field = data.docs[docName]?.fields[fieldName];
            if (!field) return;
            if (typeof field.value !== 'object' || field.value === null) field.value = { lat: 0, lng: 0 };
            field.value[axis] = parseFloat(rawVal) || 0;
            this._saveCollectionData(data);
            // no full re-render needed — inputs update themselves
        },

        toggleDocExpand(docName) {
            const el = document.getElementById('doc-fields-' + docName);
            if (el) el.style.display = el.style.display === 'none' ? 'flex' : 'none';
        },

        collectionNewDoc() {
            const rawName = prompt('Document name (or type doc(name) syntax):');
            if (!rawName) return;
            const m = rawName.match(/^doc\(([^)]+)\)$/i);
            const docName = m ? m[1].trim() : rawName.trim();
            if (!docName) return;
            const data = this._getCollectionData();
            if (data.docs[docName]) { notify('Exists', 'Document "' + docName + '" already exists.'); return; }
            data.docs[docName] = { fields: {} };
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        deleteDoc(docName) {
            if (!confirm('Delete document "' + docName + '" and all its fields?')) return;
            const data = this._getCollectionData();
            delete data.docs[docName];
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        addField(docName) {
            const fieldName = prompt('Field name:');
            if (!fieldName) return;
            const type = prompt('Field type (string, number, boolean, array, map, timestamp, geopoint, reference, null):', 'string');
            if (!type || !this._colFieldTypes.includes(type)) { notify('Invalid type', 'Choose: ' + this._colFieldTypes.join(', ')); return; }
            const data = this._getCollectionData();
            const defaults = { string: '', number: 0, boolean: false, array: [], map: {}, timestamp: 'serverTimestamp', geopoint: { lat: 0, lng: 0 }, reference: '', null: null };
            data.docs[docName].fields[fieldName] = { type, value: defaults[type] };
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        deleteField(docName, fieldName) {
            const data = this._getCollectionData();
            delete data.docs[docName].fields[fieldName];
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        setFieldValue(docName, fieldName, value) {
            const data = this._getCollectionData();
            const field = data.docs[docName]?.fields[fieldName];
            if (!field) return;
            if (field.type === 'number') value = parseFloat(value) || 0;
            field.value = value;
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        changeFieldType(docName, fieldName, newType) {
            const data = this._getCollectionData();
            const field = data.docs[docName]?.fields[fieldName];
            if (!field) return;
            const defaults = { string: '', number: 0, boolean: false, array: [], map: {}, timestamp: 'serverTimestamp', geopoint: { lat: 0, lng: 0 }, reference: '', null: null };
            field.type  = newType;
            field.value = defaults[newType];
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        addArrayItem(docName, fieldName) {
            const val = prompt('Add item to array (value):');
            if (val === null) return;
            const data = this._getCollectionData();
            const field = data.docs[docName]?.fields[fieldName];
            if (!field) return;
            if (!Array.isArray(field.value)) field.value = [];
            // Try to parse as JSON, fallback to string
            try { field.value.push(JSON.parse(val)); } catch { field.value.push(val); }
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        addMapEntry(docName, fieldName) {
            const key = prompt('Map key:');
            if (!key) return;
            const val = prompt('Map value:');
            if (val === null) return;
            const data = this._getCollectionData();
            const field = data.docs[docName]?.fields[fieldName];
            if (!field) return;
            if (typeof field.value !== 'object' || Array.isArray(field.value)) field.value = {};
            try { field.value[key] = JSON.parse(val); } catch { field.value[key] = val; }
            this._saveCollectionData(data);
            this.renderCollectionEditor();
        },

        _appspaceScope() {
            const name = (document.getElementById('builder-project-name')?.value || 'MyApp').replace(/[^a-zA-Z0-9_-]/g, '_');
            return name;
        },

        _appspacePaths(collectionName) {
            const scope = this._appspaceScope();
            return {
                colDoc:  `appspace/${scope}/collections/${collectionName}`,
                docsCol: `appspace/${scope}/collections/${collectionName}/docs`
            };
        },

        async pushCollectionToAppspace() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file || file.type !== 'collection') return;
            const collectionName = this._parseCollectionName(file.name) || file.name;
            const data = this._getCollectionData();
            const docs = data.docs || {};
            const appName = this._appspaceScope();

            if (!supabaseInitialized) {
                notify('Offline', 'Supabase not connected — cannot push to Appspace.');
                return;
            }

            // Check current usage against 700kb limit
            const { bytes: usedBytes, error: usageErr } = await window.supabaseAppspace.getUsage(appName);
            if (!usageErr) {
                const LIMIT = window.supabaseAppspace.LIMIT_BYTES;
                // Estimate size of this push
                const pushSize = new Blob([JSON.stringify(docs)]).size;
                if (usedBytes + pushSize > LIMIT) {
                    const usedKB  = (usedBytes  / 1024).toFixed(1);
                    const pushKB  = (pushSize   / 1024).toFixed(1);
                    const limitKB = (LIMIT       / 1024).toFixed(0);
                    notify('AppSpace Full', `Cannot push — ${usedKB}KB used + ~${pushKB}KB new exceeds the ${limitKB}KB limit.`);
                    return;
                }
            }

            try {
                for (const [docName, docData] of Object.entries(docs)) {
                    const fields = docData.fields || {};
                    const payload = {};
                    for (const [k, f] of Object.entries(fields)) {
                        if (f.type === 'timestamp' || f.value === 'serverTimestamp') payload[k] = new Date().toISOString();
                        else if (f.type === 'null')      payload[k] = null;
                        else if (f.type === 'number')    payload[k] = parseFloat(f.value) || 0;
                        else if (f.type === 'boolean')   payload[k] = f.value === true || f.value === 'true';
                        else if (f.type === 'geopoint')  payload[k] = { latitude: parseFloat(f.value?.lat) || 0, longitude: parseFloat(f.value?.lng) || 0, _type: 'GeoPoint' };
                        else if (f.type === 'reference') payload[k] = { _type: 'Reference', path: f.value || '' };
                        else payload[k] = f.value;
                    }
                    const { error } = await window.supabaseAppspace.writeDoc(appName, collectionName, docName, payload);
                    if (error) throw new Error(String(error));
                }
                // Show updated usage after push
                const { bytes: newBytes } = await window.supabaseAppspace.getUsage(appName);
                const usedKB  = (newBytes / 1024).toFixed(1);
                const limitKB = (window.supabaseAppspace.LIMIT_BYTES / 1024).toFixed(0);
                notify('☁️ Pushed!', `"${collectionName}" → appspace/${appName} (${usedKB}KB / ${limitKB}KB used)`);
            } catch(e) {
                notify('Push Error', e.message);
                console.error('Supabase appspace push error:', e);
            }
        },

        async pullCollectionFromAppspace() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file || file.type !== 'collection') return;
            const collectionName = this._parseCollectionName(file.name) || file.name;
            const appName = this._appspaceScope();

            if (!supabaseInitialized) {
                notify('Offline', 'Supabase not connected — cannot pull from Appspace.');
                return;
            }

            try {
                const { data: docNames, error: listErr } = await window.supabaseAppspace.listDocs(appName, collectionName);
                if (listErr) throw new Error(String(listErr));
                if (!docNames || docNames.length === 0) {
                    notify('⬇️ Pull', `No documents found in Supabase appspace for "${collectionName}".`);
                    return;
                }

                const colData = this._getCollectionData();
                colData.docs = {};

                for (const docName of docNames) {
                    const { data: raw, error: readErr } = await window.supabaseAppspace.readDoc(appName, collectionName, docName);
                    if (readErr || !raw) continue;
                    const fields = {};
                    Object.entries(raw).forEach(([k, v]) => {
                        let type = 'string';
                        if (v === null)                                type = 'null';
                        else if (typeof v === 'boolean')              type = 'boolean';
                        else if (typeof v === 'number')               type = 'number';
                        else if (Array.isArray(v))                    type = 'array';
                        else if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v)) type = 'timestamp';
                        else if (v?._type === 'GeoPoint')             type = 'geopoint';
                        else if (v?._type === 'Reference')            type = 'reference';
                        else if (typeof v === 'object')               type = 'map';
                        let finalVal = v;
                        if (type === 'timestamp')  finalVal = 'serverTimestamp';
                        if (type === 'geopoint')   finalVal = { lat: v.latitude ?? 0, lng: v.longitude ?? 0 };
                        if (type === 'reference')  finalVal = v.path || '';
                        fields[k] = { type, value: finalVal };
                    });
                    colData.docs[docName] = { fields };
                }

                this._saveCollectionData(colData);
                this.renderCollectionEditor();
                notify('⬇️ Pulled!', `${docNames.length} doc(s) loaded from Supabase into "${collectionName}".`);
            } catch(e) {
                notify('Pull Error', e.message);
                console.error('Supabase appspace pull error:', e);
            }
        },

        copyCollectionCode() {
            const file = this.currentProject.files[this.currentProject.currentFileIndex];
            if (!file || file.type !== 'collection') return;
            const collectionName = this._parseCollectionName(file.name) || file.name;
            const scope = this._appspaceScope();
            const data = this._getCollectionData();
            const docs = data.docs || {};

            const lines = [
                `// Supabase Appspace — Collection: ${collectionName}`,
                `// Bucket: appspace  |  Path: ${scope}/${collectionName}/{docName}.json`,
                `// Auto-generated by HyOS App Builder`,
                ``,
                `import { createClient } from '@supabase/supabase-js';`,
                `const supabase = createClient('${SUPABASE_URL}', '${SUPABASE_KEY}');`,
                ``,
                `async function writeDoc(docName, data) {`,
                `    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });`,
                `    return supabase.storage.from('appspace').upload(\`${scope}/${collectionName}/\${docName}.json\`, blob, { upsert: true });`,
                `}`,
                ``,
                `async function readDoc(docName) {`,
                `    const { data } = await supabase.storage.from('appspace').download(\`${scope}/${collectionName}/\${docName}.json\`);`,
                `    return data ? JSON.parse(await data.text()) : null;`,
                `}`,
                ``
            ];

            Object.entries(docs).forEach(([docName, docData]) => {
                const fields = docData.fields || {};
                const obj = {};
                Object.entries(fields).forEach(([k, f]) => {
                    if (f.type === 'timestamp' || f.value === 'serverTimestamp') obj[k] = 'new Date().toISOString()';
                    else if (f.type === 'null')       obj[k] = null;
                    else if (f.type === 'boolean')    obj[k] = f.value;
                    else if (f.type === 'number')     obj[k] = f.value;
                    else if (f.type === 'geopoint')   obj[k] = `{ latitude: ${f.value?.lat ?? 0}, longitude: ${f.value?.lng ?? 0} }`;
                    else if (f.type === 'reference')  obj[k] = f.value;
                    else                              obj[k] = f.value;
                });
                const entries = Object.entries(obj).map(([k,v]) => `    ${k}: ${typeof v === 'string' && !v.startsWith('{') && !v.startsWith('new ') ? JSON.stringify(v) : v}`);
                lines.push(`await writeDoc('${docName}', {`);
                lines.push(...entries.map(l => l + ','));
                lines.push(`});`);
                lines.push(``);
            });

            const code = lines.join('\n');
            navigator.clipboard.writeText(code).then(() => notify('📋 Copied!', 'Supabase appspace code copied!'));
        },
        
        publish() {
            this.saveCurrentFile();
            
            // Get app metadata from Mani.manifest if exists
            const manifestFile = this.currentProject.files.find(f => f.name === 'Mani.manifest');
            let projectName = 'My App';
            let appIcon = '📦';
            let appDesc = 'Created with App Builder';
            
            if (manifestFile) {
                try {
                    const manifest = JSON.parse(manifestFile.content);
                    projectName = manifest.name || projectName;
                    appIcon = manifest.icon || appIcon;
                    appDesc = manifest.description || appDesc;
                } catch (e) {
                    console.error('Failed to parse manifest:', e);
                }
            }
            
            // Allow user to override
            projectName = prompt('App Name:', projectName) || projectName;
            appIcon = prompt('App Icon (emoji):', appIcon) || appIcon;
            appDesc = prompt('App Description:', appDesc) || appDesc;
            
            // Check for JSON config files and execute them (exclude Mani.manifest)
            const jsonFiles = this.currentProject.files.filter(f => 
                f.name.endsWith('.json') && f.name !== 'Mani.manifest'
            );
            
            jsonFiles.forEach(jsonFile => {
                try {
                    const parsed = JSON.parse(jsonFile.content);
                    // Execute JSON actions
                    if (parsed.action || parsed.openwith || parsed.installApp || parsed.systemAction) {
                        this.executeJSONAction(parsed);
                    }
                } catch (e) {
                    console.error('JSON parse error in ' + jsonFile.name + ':', e);
                }
            });
            
            // Execute .HL files (they contain both HTML and JSON actions)
            const hlFiles = this.currentProject.files.filter(f => f.name.endsWith('.hl'));
            let hlHTML = '';
            hlFiles.forEach(hlFile => {
                try {
                    const html = this.executeHLFile(hlFile.content, false); // false = publish mode
                    if (html) {
                        hlHTML += html;
                    }
                } catch (e) {
                    console.error('.HL file error in ' + hlFile.name + ':', e);
                }
            });
            
            // Build the final app HTML - look for Main.html or use .HL HTML
            const mainFile = this.currentProject.files.find(f => f.name === 'Main.html');
            const cssFiles = this.currentProject.files.filter(f => f.name.endsWith('.css'));
            const jsFiles = this.currentProject.files.filter(f => f.name.endsWith('.js'));
            
            // Use Main.html if available, otherwise use .HL HTML
            let finalHTML = mainFile ? mainFile.content : hlHTML;
            
            if (!finalHTML) {
                notify('Error', 'Main.html or .HL file is required to publish');
                return;
            }
            
            // Embed CSS
            if (cssFiles.length > 0) {
                const cssContent = cssFiles.map(f => f.content).join('\n');
                const styleTag = '<style>' + cssContent + '</style>';
                if (finalHTML.includes('</head>')) {
                    finalHTML = finalHTML.replace('</head>', styleTag + '</head>');
                } else {
                    finalHTML = styleTag + finalHTML;
                }
            }
            
            // Embed JS
            if (jsFiles.length > 0) {
                const jsContent = jsFiles.map(f => f.content).join('\n');
                const scriptTag = '<script>' + jsContent + '</' + 'script>';
                if (finalHTML.includes('</body>')) {
                    finalHTML = finalHTML.replace('</body>', scriptTag + '</body>');
                } else {
                    finalHTML = finalHTML + scriptTag;
                }
            }
            
            // Embed JSON and .HL runtime support for Advanced mode (non-srcdoc)
            const jsonConfigs = [];
            jsonFiles.forEach(jsonFile => {
                try {
                    const parsed = JSON.parse(jsonFile.content);
                    if (parsed.systemAction || parsed.action || parsed.openwith || parsed.installApp) {
                        jsonConfigs.push(parsed);
                    }
                } catch (e) {
                    console.error('JSON parse error:', e);
                }
            });
            
            const hlConfigs = [];
            hlFiles.forEach(hlFile => {
                try {
                    const parsed = JSON.parse(hlFile.content);
                    if (parsed.Type1 === 'HTML' && parsed.Type2 === 'JSON' && parsed.Mode === 'dojsonaction') {
                        hlConfigs.push(parsed);
                    }
                } catch (e) {
                    console.error('HL parse error:', e);
                }
            });
            
            // Inject runtime code to execute JSON and HL configs
            if (jsonConfigs.length > 0 || hlConfigs.length > 0) {
                const runtimeScript = `
                <script>
                (function() {
                    // Embedded JSON configs
                    const __JSON_CONFIGS__ = ${JSON.stringify(jsonConfigs)};
                    const __HL_CONFIGS__ = ${JSON.stringify(hlConfigs)};
                    
                    // Execute JSON actions on load
                    window.addEventListener('load', function() {
                        // Try to access parent window's functions
                        try {
                            if (window.parent && window.parent.AppBuilder && window.parent.AppBuilder.executeJSONAction) {
                                // Execute JSON configs
                                __JSON_CONFIGS__.forEach(function(config) {
                                    window.parent.AppBuilder.executeJSONAction(config, false);
                                });
                                
                                // Execute HL configs
                                __HL_CONFIGS__.forEach(function(hlConfig) {
                                    if (hlConfig.JSONActions && Array.isArray(hlConfig.JSONActions)) {
                                        hlConfig.JSONActions.forEach(function(action) {
                                            window.parent.AppBuilder.executeJSONAction(action, false);
                                        });
                                    }
                                });
                            }
                        } catch (e) {
                            console.log('App runtime: JSON/HL actions ready for execution');
                        }
                    });
                })();
                <\/script>
                `;
                
                if (finalHTML.includes('</body>')) {
                    finalHTML = finalHTML.replace('</body>', runtimeScript + '</body>');
                } else {
                    finalHTML = finalHTML + runtimeScript;
                }
            }
            
            // Create the app object
            const newApp = {
                id: 'app_' + Date.now(),
                name: projectName,
                emoji: appIcon,
                desc: appDesc,
                code: finalHTML,
                creator: user,
                fromMaker: true,
                createdAt: new Date().toISOString()
            };
            
            installedApps.push(newApp);
            
            if (!window.publishedApps) window.publishedApps = [];
            publishedApps.push(newApp);
            
            saveLocalData();
            
            notify('Published!', projectName + ' has been published to your Apps!');
            
            // Refresh drawer if open
            if (document.getElementById('drawer-win').style.display !== 'none') {
                loadDrawer('installed');
            }
        },

        // ── Preview in OS Window (HyLink-style) ──────────────────────
        previewWindow() {
            this.saveCurrentFile();
            const html = this._buildPreviewHTML();
            if (!html) { notify('Preview', 'No HTML found to preview.'); return; }

            // Remove existing preview window if any
            const old = document.getElementById('builder-preview-win');
            if (old) old.remove();

            const appName = (document.getElementById('builder-project-name') || {}).value || 'Preview';
            const winEl = document.createElement('div');
            winEl.id = 'builder-preview-win';
            winEl.className = 'window';
            winEl.style.cssText = 'width:900px;height:640px;left:calc(50% + 40px);top:calc(50% - 20px);transform:translate(-50%,-50%);display:flex;z-index:800;';
            winEl.innerHTML = `
                <div class="win-header" style="cursor:move;user-select:none;">
                    <span style="font-weight:700;font-size:13px;">▶ ${appName} — Preview</span>
                    <div style="display:flex;gap:6px;">
                        <button onclick="AppBuilder.previewWindow()" style="width:24px;height:24px;border-radius:6px;background:rgba(22,163,74,0.3);border:1px solid rgba(22,163,74,0.5);color:#fff;cursor:pointer;font-size:11px;" title="Refresh">↺</button>
                        <button onclick="this.closest('.window').remove()" style="width:24px;height:24px;border-radius:6px;background:rgba(239,68,68,0.3);border:1px solid rgba(239,68,68,0.5);color:#fff;cursor:pointer;">✕</button>
                    </div>
                </div>
                <div class="win-body"><iframe sandbox="allow-scripts allow-forms allow-same-origin" style="width:100%;height:100%;border:none;background:#fff;"></iframe></div>
                <div class="resizer"></div>`;
            document.body.appendChild(winEl);
            winEl.querySelector('iframe').srcdoc = html;
            notify('▶ Preview', appName + ' opened in window');
        },

        _buildPreviewHTML() {
            const htmlFile = this.currentProject.files.find(f => f.name === 'Main.html' || f.name.endsWith('.html'));
            const cssFiles = this.currentProject.files.filter(f => f.name.endsWith('.css'));
            const jsFiles  = this.currentProject.files.filter(f => f.name.endsWith('.js'));
            let html = htmlFile ? htmlFile.content : '';
            if (!html) return null;
            if (cssFiles.length) {
                const s = '<style>' + cssFiles.map(f => f.content).join('\n') + '</style>';
                html = html.includes('</head>') ? html.replace('</head>', s + '</head>') : s + html;
            }
            if (jsFiles.length) {
                const s = '<script>' + jsFiles.map(f => f.content).join('\n') + '<\/script>';
                html = html.includes('</body>') ? html.replace('</body>', s + '</body>') : html + s;
            }
            return html;
        },

        // ── Publish Modal ─────────────────────────────────────────────
        openPublishModal() {
            this.saveCurrentFile();
            this._publishPreviewImage = null;

            // Pre-fill from manifest
            const mani = this.currentProject.files.find(f => f.name === 'Mani.manifest');
            let name = document.getElementById('builder-project-name').value || 'My App';
            let icon = document.getElementById('builder-app-icon').value || '📱';
            let desc = document.getElementById('builder-app-desc').value || '';
            let version = '1.0';
            if (mani) { try { const m = JSON.parse(mani.content); name = m.name || name; icon = m.icon || icon; desc = m.description || desc; version = m.version || version; } catch(e){} }

            // Check if this is a republish (same name + same creator already in cloudApps or installedApps)
            const existing = cloudApps.find(a => a.creator === user && a.name === name)
                          || installedApps.find(a => a.creator === user && a.name === name);
            this._republishId   = existing ? existing.id   : null;
            this._republishSrc  = existing ? (cloudApps.find(a => a.id === existing.id) ? 'cloud' : 'local') : null;

            // Update modal title/subtitle
            document.getElementById('publish-modal-title').textContent    = existing ? '🔄 Update App' : '🚀 Publish App';
            document.getElementById('publish-modal-subtitle').textContent = existing
                ? `Updating "${existing.name}" v${existing.version || '?'} → new version`
                : 'Ship your app to the HyOS app store';
            document.querySelector('#publish-modal button[onclick*="publishFromModal"]').textContent =
                existing ? '🔄 Update Now' : '🚀 Publish Now';

            document.getElementById('publish-modal-name').value = name;
            document.getElementById('publish-modal-icon-input').value = icon;
            document.getElementById('publish-icon-preview').textContent = icon;
            document.getElementById('publish-modal-desc').value = desc;
            document.getElementById('publish-modal-version').value = version;

            // Pre-fill genre if republishing
            if (existing && existing.genre) {
                document.getElementById('publish-modal-genre').value = existing.genre;
            }

            // Pre-fill preview image if republishing
            if (existing && existing.previewImage) {
                this._publishPreviewImage = existing.previewImage;
                const thumb = document.getElementById('publish-preview-thumb');
                thumb.innerHTML = `<img src="${existing.previewImage}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">`;
                thumb.style.opacity = '1';
            } else {
                document.getElementById('publish-preview-thumb').innerHTML = 'No image';
                document.getElementById('publish-preview-thumb').style.opacity = '0.4';
            }

            document.getElementById('publish-modal').style.display = 'flex';
        },

        capturePreviewImage() {
            // Try to grab a screenshot from the last open preview window iframe
            const previewWin = document.getElementById('builder-preview-win');
            if (!previewWin) { notify('No Preview', 'Open a Preview window first, then capture.'); return; }
            const iframe = previewWin.querySelector('iframe');
            if (!iframe || !iframe.contentDocument) { notify('Capture Failed', 'Preview not accessible.'); return; }
            try {
                html2canvas(iframe.contentDocument.body, { scale: 0.5, useCORS: true, backgroundColor: '#050810' }).then(canvas => {
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                    this._publishPreviewImage = dataUrl;
                    const thumb = document.getElementById('publish-preview-thumb');
                    thumb.innerHTML = `<img src="${dataUrl}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">`;
                    thumb.style.opacity = '1';
                    notify('📸 Captured', 'Preview screenshot saved!');
                }).catch(() => notify('Capture Failed', 'Could not render preview.'));
            } catch(e) { notify('Capture Failed', e.message); }
        },

        loadPreviewImage(input) {
            const file = input.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (e) => {
                this._publishPreviewImage = e.target.result;
                const thumb = document.getElementById('publish-preview-thumb');
                thumb.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">`;
                thumb.style.opacity = '1';
            };
            reader.readAsDataURL(file);
        },

        clearPreviewImage() {
            this._publishPreviewImage = null;
            const thumb = document.getElementById('publish-preview-thumb');
            thumb.innerHTML = 'No image';
            thumb.style.opacity = '0.4';
        },

        async publishFromModal() {
            // ── Banned user check ───────────────────────────────────────
            const _banned = JSON.parse(localStorage.getItem('hyos_banned_users') || '[]');
            if (_banned.includes((user||'').toLowerCase())) { notify('🚫 Banned', 'Your account has been banned from publishing.'); return; }
            // ── Cooldown check ───────────────────────────────────────────
            if (!_checkPublishCooldown()) return;

            const name       = document.getElementById('publish-modal-name').value.trim()    || 'My App';
            const icon       = document.getElementById('publish-modal-icon-input').value.trim() || '📱';
            const desc       = document.getElementById('publish-modal-desc').value.trim()    || '';
            const version    = document.getElementById('publish-modal-version').value.trim() || '1.0';
            const genre      = document.getElementById('publish-modal-genre').value          || '';
            const toLocal    = document.getElementById('publish-to-local').checked;
            const toStore    = document.getElementById('publish-to-store').checked;
            const openAfter  = document.getElementById('publish-open-after').checked;
            const previewImg = this._publishPreviewImage || null;
            const isUpdate   = !!this._republishId;

            const finalHTML = this._buildPreviewHTML();
            if (!finalHTML) { notify('Publish Error', 'No HTML file found. Add a Main.html first.'); return; }

            const now = new Date().toISOString();
            const appData = {
                name, icon, desc, version, genre,
                code: finalHTML,
                creator: user,
                fromMaker: true,
                updatedAt: now,
                ...(previewImg ? { previewImage: previewImg } : {}),
                ...(!isUpdate ? { createdAt: now, likes: 0, dislikes: 0, likedBy: [], dislikedBy: [] } : {})
            };

            // ── Safety scan ─────────────────────────────────────────────
            const _scanResult = SafetyScanner.scan({ ...appData, files: AppBuilder.currentProject?.files || [] });
            Object.assign(appData, _scanResult.cleaned);
            const _scanOk = await SafetyScanner.prompt(_scanResult, name);
            if (!_scanOk) return;

            const publishBtn = document.querySelector('#publish-modal button[onclick*="publishFromModal"]');
            if (publishBtn) { publishBtn.disabled = true; publishBtn.textContent = isUpdate ? '⏳ Updating…' : '⏳ Publishing…'; }

            try {
                let finalApp = { ...appData };

                // ── LOCAL (My Apps) ─────────────────────────────────────────
                if (toLocal) {
                    if (isUpdate) {
                        const idx = installedApps.findIndex(a => a.id === this._republishId);
                        if (idx !== -1) {
                            installedApps[idx] = { ...installedApps[idx], ...appData };
                            finalApp = installedApps[idx];
                        } else {
                            const newId = 'app_' + Date.now();
                            finalApp = { id: newId, ...appData };
                            installedApps.push(finalApp);
                        }
                        // Update installed doc
                        if (supabaseInitialized) {
                            try { await window.sbInstalled.insert({ id: this._republishId, ...appData, owner: user, published_at: new Date().toISOString() }); } catch(e) {}
                        } else if (firebaseInitialized) {
                            try { await window._fb.updateDoc(window._fb.doc(db, 'installed', this._republishId), { ...appData, publishedAt: window._fb.serverTimestamp() }); } catch(e) {}
                        }
                    } else {
                        const newId = 'app_' + Date.now();
                        finalApp = { id: newId, ...appData };
                        installedApps.push(finalApp);
                        if (!window.publishedApps) window.publishedApps = [];
                        publishedApps.push(finalApp);
                        // Write to Supabase DB installed (new) or Firebase (old)
                        if (supabaseInitialized) {
                            try {
                                const { data: inserted } = await window.sbInstalled.insert({ ...finalApp, owner: user, published_at: new Date().toISOString() });
                                if (inserted?.id) { finalApp.id = inserted.id; installedApps[installedApps.length - 1].id = inserted.id; }
                            } catch(e) { console.warn('Supabase installed write failed:', e); }
                        } else if (firebaseInitialized) {
                            try {
                                const ref = await window._fb.addDoc(window._fb.collection(db, 'installed'), { ...finalApp, owner: user, publishedAt: window._fb.serverTimestamp() });
                                finalApp.id = ref.id; installedApps[installedApps.length - 1].id = ref.id;
                            } catch(e) { console.warn('Firestore installed write failed:', e); }
                        }
                    }
                    saveLocalData();
                }

                // ── GLOBAL STORE ────────────────────────────────────────────
                if (toStore) {
                    if (supabaseInitialized) {
                        if (isUpdate && this._republishSrc === 'cloud') {
                            await window.sbGlobalApps.update(this._republishId, { ...appData, published_at: new Date().toISOString() });
                            const ci = cloudApps.findIndex(a => a.id === this._republishId);
                            if (ci !== -1) cloudApps[ci] = { ...cloudApps[ci], ...appData };
                            // Also patch creator's own installed copy
                            const ownInstalled = installedApps.find(a => a.original_id === this._republishId || a.originalId === this._republishId);
                            if (ownInstalled) {
                                await supabase.from('installed').update(window.sbGlobalApps._toRow({ ...appData, updated_at: new Date().toISOString() })).eq('id', ownInstalled.id);
                                Object.assign(ownInstalled, appData);
                            }
                            notify('🔄 Updated!', name + ' has been updated in the Global Store!');
                        } else {
                            const { data: inserted, error: sbErr } = await window.sbGlobalApps.insert({ ...appData, owner: user, published_at: new Date().toISOString() });
                            if (sbErr) throw new Error(sbErr.message || JSON.stringify(sbErr));
                            if (inserted?.id) { finalApp = { ...finalApp, id: inserted.id }; cloudApps.push({ id: inserted.id, ...appData, owner: user }); }
                            _stampPublishCooldown();
                            notify('🌐 Store', name + ' is now live in the Global Store!');
                        }
                    } else if (firebaseInitialized) {
                        if (isUpdate && this._republishSrc === 'cloud') {
                            await window._fb.updateDoc(window._fb.doc(db, 'global_apps', this._republishId), { ...appData, publishedAt: window._fb.serverTimestamp() });
                            const ci = cloudApps.findIndex(a => a.id === this._republishId);
                            if (ci !== -1) cloudApps[ci] = { ...cloudApps[ci], ...appData };
                            notify('🔄 Updated!', name + ' has been updated in the Global Store!');
                        } else {
                            const ref = await window._fb.addDoc(window._fb.collection(db, 'global_apps'), { ...appData, owner: user, publishedAt: window._fb.serverTimestamp() });
                            finalApp = { ...finalApp, id: ref.id };
                            notify('🌐 Store', name + ' is now live in the Global Store!');
                        }
                    } else {
                        // Offline fallback
                        if (isUpdate) {
                            const ci = cloudApps.findIndex(a => a.id === this._republishId);
                            if (ci !== -1) cloudApps[ci] = { ...cloudApps[ci], ...appData };
                        } else {
                            finalApp.id = 'local_store_' + Date.now();
                            cloudApps.push(finalApp);
                        }
                        notify('🌐 Store (offline)', name + ' added to local store.');
                    }
                }

                document.getElementById('publish-modal').style.display = 'none';
                const verb = isUpdate ? 'Updated' : 'Published';
                notify('✅ ' + verb + '!', name + ' ' + (toLocal ? '📱' : '') + (toStore ? '🌐' : ''));

                // ── AUTO-PUSH COLLECTIONS TO SUPABASE APPSPACE ──────────────
                const collectionFiles = this.currentProject.files.filter(f => f.type === 'collection');
                if (collectionFiles.length > 0 && supabaseInitialized) {
                    const scope = name.replace(/[^a-zA-Z0-9_-]/g, '_');
                    for (const colFile of collectionFiles) {
                        const colName = this._parseCollectionName(colFile.name) || colFile.name;
                        let colData;
                        try { colData = JSON.parse(colFile.content || '{"docs":{}}'); } catch { colData = { docs: {} }; }
                        const docs = colData.docs || {};
                        for (const [docName, docData] of Object.entries(docs)) {
                            const fields = docData.fields || {};
                            const payload = {};
                            for (const [k, f] of Object.entries(fields)) {
                                if (f.type === 'timestamp' || f.value === 'serverTimestamp') payload[k] = new Date().toISOString();
                                else if (f.type === 'null')      payload[k] = null;
                                else if (f.type === 'number')    payload[k] = parseFloat(f.value) || 0;
                                else if (f.type === 'boolean')   payload[k] = f.value === true || f.value === 'true';
                                else if (f.type === 'geopoint')  payload[k] = { latitude: parseFloat(f.value?.lat) || 0, longitude: parseFloat(f.value?.lng) || 0, _type: 'GeoPoint' };
                                else if (f.type === 'reference') payload[k] = { _type: 'Reference', path: f.value || '' };
                                else payload[k] = f.value;
                            }
                            await window.supabaseAppspace.writeDoc(scope, colName, docName, payload);
                        }
                    }
                    notify('☁️ Appspace', `${collectionFiles.length} collection${collectionFiles.length > 1 ? 's' : ''} synced to Supabase.`);
                }

                // Refresh drawer if open
                if (document.getElementById('drawer-win').style.display !== 'none') setDrawerMode('my');

                // Open after publish
                if (openAfter) {
                    setTimeout(() => launchApp(finalApp), 400);
                }
            } catch(err) {
                notify('Publish Error', err.message);
                console.error('Publish error:', err);
            } finally {
                if (publishBtn) { publishBtn.disabled = false; publishBtn.textContent = isUpdate ? '🔄 Update Now' : '🚀 Publish Now'; }
                this._republishId  = null;
                this._republishSrc = null;
            }
        },

        executeJSONAction(config, previewMode) {
            // Block Firebase access
            const configStr = JSON.stringify(config);
            if (configStr.toLowerCase().includes('firebase') || configStr.toLowerCase().includes('firestore')) {
                notify('Security Error', 'Apps cannot access Firebase directly');
                return;
            }
            
            previewMode = previewMode || false;
            
            try {
                // Handle enhanced notifications
                const action = config.systemaction || config.systemAction;
                
                if (action === 'notify') {
                    const title = config.title || 'Notification';
                    const message = config.message || '';
                    const actionType = config.actiontype || config.actionType || 'opened';
                    
                    if (actionType === 'opened') {
                        // Show notification when app is opened
                        NotificationCenter.add(title, message);
                    } else if (actionType === 'timed') {
                        // Show notification after a delay
                        const time = parseInt(config.time) || 0;
                        const repeated = config.repeated === 'yes' || config.repeated === true;
                        
                        if (repeated) {
                            // Set up repeating notification
                            setInterval(function() {
                                NotificationCenter.add(title, message);
                            }, time * 1000);
                            
                            if (!previewMode) {
                                notify('Timed Notification', 'Repeating every ' + time + 's');
                            }
                        } else {
                            // Single delayed notification
                            setTimeout(function() {
                                NotificationCenter.add(title, message);
                            }, time * 1000);
                            
                            if (!previewMode) {
                                notify('Timed Notification', 'Will show in ' + time + 's');
                            }
                        }
                    }
                    
                    // Show immediate preview notification
                    if (previewMode && actionType === 'opened') {
                        NotificationCenter.add(title, message);
                    }
                    
                    return;
                }
                
                // Handle file associations (only in publish mode)
                if (!previewMode && config.openwith) {
                    const extension = Object.keys(config.openwith)[0];
                    const appName = config.openwith[extension];
                    
                    notify('File Association', 'Registered .' + extension + ' files to open with ' + appName);
                    
                    if (!window.customFileAssociations) {
                        window.customFileAssociations = {};
                    }
                    window.customFileAssociations[extension] = appName;
                }
                
                // Handle app installation (skip in preview mode)
                if (!previewMode && config.installApp && config.nameprompt) {
                    const appName = prompt(config.nameprompt);
                    if (appName) {
                        notify('App Install', 'Installing ' + appName + '...');
                    }
                }
                
                // Handle other system actions
                if (action === 'setWallpaper' && config.wallpaperURL) {
                    document.getElementById('desktop-bg').style.backgroundImage = 'url(' + config.wallpaperURL + ')';
                    notify('Wallpaper', 'Wallpaper changed via JSON config');
                } else if (action === 'createDesktopIcon' && config.iconData) {
                    userSettings.desktopIcons.push(config.iconData);
                    saveSettings();
                    renderDesktopIcons();
                    notify('Desktop Icon', 'Icon created via JSON config');
                }
            } catch (e) {
                console.error('Error executing JSON action:', e);
                notify('JSON Error', 'Failed to execute JSON configuration');
            }
        },
        
        // =====================================================
        // .HL FILE FORMAT SUPPORT - Connects HTML and JSON
        // =====================================================
        parseHLFile(hlContent) {
            try {
                const parsed = JSON.parse(hlContent);
                
                // Validate .HL format structure
                if (!parsed.Type1 || !parsed.Lines || !parsed.Type2 || !parsed.Mode) {
                    throw new Error('Invalid .HL file format');
                }
                
                if (parsed.Type1 !== 'HTML' || parsed.Type2 !== 'JSON') {
                    throw new Error('.HL file must have Type1: HTML and Type2: JSON');
                }
                
                if (parsed.Mode !== 'dojsonaction') {
                    throw new Error('.HL file Mode must be "dojsonaction"');
                }
                
                // Convert Lines array to HTML string
                const htmlContent = Array.isArray(parsed.Lines) ? parsed.Lines.join('\n') : '';
                
                // Get JSON actions
                const jsonActions = parsed.JSONActions || [];
                
                return {
                    html: htmlContent,
                    jsonActions: jsonActions,
                    mode: parsed.Mode,
                    valid: true
                };
                
            } catch (e) {
                console.error('Error parsing .HL file:', e);
                notify('HL Parse Error', e.message);
                return {
                    html: '',
                    jsonActions: [],
                    mode: '',
                    valid: false
                };
            }
        },
        
        executeHLFile(hlContent, previewMode = false) {
            const parsed = this.parseHLFile(hlContent);
            
            if (!parsed.valid) {
                return null;
            }
            
            // Execute JSON actions if mode is dojsonaction
            if (parsed.mode === 'dojsonaction' && parsed.jsonActions.length > 0) {
                parsed.jsonActions.forEach(action => {
                    this.executeJSONAction(action, previewMode);
                });
            }
            
            // Return the HTML content
            return parsed.html;
        },
        
        openConsole() {
            // Open browser developer console
            const consoleDialog = document.createElement('div');
            consoleDialog.className = 'context-menu';
            consoleDialog.style.display = 'block';
            consoleDialog.style.left = '50%';
            consoleDialog.style.top = '50%';
            consoleDialog.style.transform = 'translate(-50%, -50%)';
            consoleDialog.style.minWidth = '350px';
            consoleDialog.style.padding = '20px';
            
            consoleDialog.innerHTML = `
                <div style="margin-bottom: 15px; font-size: 14px; font-weight: 600;">
                    💻 Console Information
                </div>
                <div style="font-size: 13px; line-height: 1.6; opacity: 0.8; margin-bottom: 15px;">
                    To view the console for debugging your app:
                </div>
                <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: 8px; margin-bottom: 10px; font-size: 12px; font-family: monospace;">
                    • Right-click anywhere → Inspect<br>
                    • Or press F12<br>
                    • Or Ctrl+Shift+I (Windows/Linux)<br>
                    • Or Cmd+Option+I (Mac)
                </div>
                <div style="font-size: 12px; opacity: 0.6; margin-bottom: 15px;">
                    The console will show errors, logs, and debugging information from your app.
                </div>
                <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px; text-align: center;">
                    Got it!
                </div>
            `;
            
            document.body.appendChild(consoleDialog);
            
            setTimeout(() => {
                const closeDialog = (e) => {
                    if (!consoleDialog.contains(e.target)) {
                        consoleDialog.remove();
                        document.removeEventListener('click', closeDialog);
                    }
                };
                document.addEventListener('click', closeDialog);
            }, 10);
        },
        
        copyAudioURL(index) {
            const file = this.currentProject.files[index];
            if (file && file.data) {
                // Copy the data URL to clipboard
                navigator.clipboard.writeText(file.data).then(() => {
                    notify('Copied!', 'Audio URL copied to clipboard');
                }).catch(err => {
                    // Fallback for older browsers
                    const textarea = document.createElement('textarea');
                    textarea.value = file.data;
                    textarea.style.position = 'fixed';
                    textarea.style.opacity = '0';
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    notify('Copied!', 'Audio URL copied to clipboard');
                });
            }
        },
        
        importAudio() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'audio/*';
            input.multiple = true;
            input.onchange = (e) => {
                Array.from(e.target.files).forEach(file => {
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                        const audioFile = {
                            name: file.name,
                            type: 'audio',
                            data: evt.target.result,
                            content: '<!-- Audio file: ' + file.name + ' -->',
                            created: new Date().toISOString()
                        };
                        
                        this.currentProject.files.push(audioFile);
                        this.renderFileTree();
                        notify('Audio Imported', file.name + ' - Click "Copy URL" to use in your project');
                    };
                    reader.readAsDataURL(file);
                });
            };
            input.click();
        },
        
        createInFolder(folderName) {
            const name = prompt('Enter file/subfolder name (e.g., "component.jsx" or "subfolder/file.js"):');
            if (!name) return;
            
            // Construct full path
            const fullPath = folderName + '/' + name;
            
            // Block Firebase access in JSON files
            const ext = name.split('.').pop().toLowerCase();
            if (ext === 'json' && (name.toLowerCase().includes('firebase') || name.toLowerCase().includes('db'))) {
                notify('Error', 'Cannot create files with Firebase references');
                return;
            }
            
            let fileType = 'text';
            let content = '';
            
            if (ext === 'html') {
                fileType = 'html';
                content = '<!DOCTYPE html>\n<html>\n<head>\n    <title>HyOS HS — HyService</title>\n</head>\n<body>\n    \n</body>\n</html>';
            } else if (ext === 'css') {
                fileType = 'css';
                content = '/* CSS Styles */\nbody {\n    margin: 0;\n    padding: 0;\n}\n';
            } else if (ext === 'js') {
                fileType = 'js';
                content = '// JavaScript\nconsole.log("Hello from ' + fullPath + '");\n';
            } else if (ext === 'jsx') {
                fileType = 'jsx';
                content = '// React Component\nimport React from "react";\n\nfunction MyComponent() {\n    return (\n        <div>\n            <h1>Hello from React!</h1>\n        </div>\n    );\n}\n\nexport default MyComponent;\n';
            } else if (ext === 'py') {
                fileType = 'py';
                content = '# Python Script\n\ndef main():\n    print("Hello from Python!")\n\nif __name__ == "__main__":\n    main()\n';
            } else if (ext === 'json') {
                fileType = 'json';
                content = '{\n    "action": "example",\n    "description": "JSON configuration file"\n}';
            }
            
            // Determine full folder path (supports nested subfolders)
            const folder = fullPath.includes('/') ? fullPath.substring(0, fullPath.lastIndexOf('/')) : '';
            
            this.currentProject.files.push({ name: fullPath, type: fileType, content: content, folder: folder });
            this.currentProject.currentFileIndex = this.currentProject.files.length - 1;
            
            this.renderFileTree();
            this.loadCurrentFile();
            notify('Created', 'File created: ' + fullPath);
        },
        
        importIcon() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                const reader = new FileReader();
                reader.onload = (evt) => {
                    const iconInput = document.getElementById('builder-app-icon');
                    if (iconInput) {
                        // Store the base64 image data
                        b64Icon = evt.target.result;
                        iconInput.value = '🖼️ (Image)';
                        iconInput.style.backgroundImage = 'url(' + evt.target.result + ')';
                        iconInput.style.backgroundSize = 'contain';
                        iconInput.style.backgroundRepeat = 'no-repeat';
                        iconInput.style.backgroundPosition = 'center';
                        iconInput.style.color = 'transparent';
                        notify('Icon Imported', 'Custom icon image loaded');
                    }
                };
                reader.readAsDataURL(file);
            };
            input.click();
        },
        
        exportHyH() {
            // Save current file before export
            this.saveCurrentFile();
            
            const projectName = document.getElementById('builder-project-name').value || 'MyApp';
            const appIcon = document.getElementById('builder-app-icon').value || '📱';
            const appDesc = document.getElementById('builder-app-desc').value || 'Created with App Builder Pro';
            
            // Create HyH package
            const hyhPackage = {
                format: 'HyH',
                version: '1.0',
                name: projectName,
                icon: b64Icon || appIcon,
                description: appDesc,
                files: this.currentProject.files,
                created: new Date().toISOString(),
                creator: user
            };
            
            // Save to HyFiles instead of downloading to device
            const jsonString = JSON.stringify(hyhPackage, null, 2);
            const fileName = projectName.replace(/[^a-zA-Z0-9]/g, '_') + '.hyh';
            
            const fileData = {
                name: fileName,
                type: 'text/plain',
                data: jsonString,
                content: jsonString,
                size: jsonString.length,
                created: new Date().toISOString()
            };
            
            // Save to HyFiles downloads folder
            if (!fileSystem.downloads) fileSystem.downloads = [];
            fileSystem.downloads.push(fileData);
            HyFiles.saveFileSystem();
            
            notify('Exported to HyFiles', fileName + ' saved to HyFiles/Downloads!');
        },
        
        importHyH() {
            // Pick from HyFiles instead of device
            const allFiles = [];
            const folders = ['root', 'downloads', 'documents'];
            folders.forEach(folder => {
                if (fileSystem[folder]) {
                    fileSystem[folder].forEach((file, idx) => {
                        if (file.name && file.name.toLowerCase().endsWith('.hyh')) {
                            allFiles.push({ file, folder, idx });
                        }
                    });
                }
            });
            
            if (allFiles.length === 0) {
                notify('No HyH Files', 'No .hyh files found in HyFiles. Export one first.');
                return;
            }
            
            const dialog = document.createElement('div');
            dialog.className = 'context-menu';
            dialog.style.cssText = 'display: block; left: 50%; top: 50%; transform: translate(-50%, -50%); min-width: 380px; padding: 20px; z-index: 99999;';
            
            const self = this;
            window._hyhImportFiles = allFiles;
            window._hyhImportSelf = self;
            
            dialog.innerHTML = `
                <div style="margin-bottom: 15px; font-size: 15px; font-weight: 700;">📥 Import from HyFiles</div>
                <div style="font-size: 12px; opacity: 0.6; margin-bottom: 16px;">Select a .hyh file to load into App Builder</div>
                ${allFiles.map((item, i) => `
                    <div class="context-menu-item" onclick="window._doImportHyH(${i}); this.parentElement.remove();">
                        <span style="font-weight: 600;">📦 ${item.file.name}</span>
                        <span style="font-size: 11px; opacity: 0.5; margin-left: 8px;">${item.folder}</span>
                    </div>
                `).join('')}
                <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px; opacity: 0.6;">
                    Cancel
                </div>
            `;
            
            document.body.appendChild(dialog);
            
            setTimeout(() => {
                const closeDialog = (e) => {
                    if (!dialog.contains(e.target)) {
                        dialog.remove();
                        document.removeEventListener('click', closeDialog);
                    }
                };
                document.addEventListener('click', closeDialog);
            }, 10);
        },
        
        // Tab switching for Main, Statusbar, Widget, and Collaborate tabs
        switchTab(tabName) {
            const tabs = ['main','statusbar','widget','collaborate','settings'];
            tabs.forEach(t => {
                const btn = document.getElementById('builder-tab-' + t);
                const el  = document.getElementById('builder-' + t + '-content');
                if (btn) { btn.style.background = '#0f172a'; btn.style.borderColor = 'transparent'; btn.style.color = '#94a3b8'; }
                if (el)  { el.style.display = 'none'; }
            });

            const activeEl  = document.getElementById('builder-' + tabName + '-content');
            const activeBtn = document.getElementById('builder-tab-' + tabName);
            if (activeEl)  { activeEl.style.display = tabName === 'main' ? 'flex' : (tabName === 'collaborate' ? 'flex' : 'flex'); }
            if (tabName === 'settings') this._syncSettingsTab();
            if (activeBtn) { activeBtn.style.background = '#1e293b'; activeBtn.style.borderColor = '#334155'; activeBtn.style.color = '#fff'; }
        },

        onSettingFirebaseToggle(checked) {
            if (!this.currentProject) return;
            this.currentProject._useFirebase = checked;
            const track = document.getElementById('builder-setting-firebase-track');
            const thumb = document.getElementById('builder-setting-firebase-thumb');
            const tag   = document.getElementById('builder-setting-backend-tag');
            if (track) track.style.background = checked ? '#1d4ed8' : '#1e293b';
            if (thumb) { thumb.style.left = checked ? '25px' : '3px'; thumb.style.background = checked ? '#fff' : '#475569'; }
            if (tag) {
                tag.textContent = checked ? '🔥 Firebase Active' : '🟢 Supabase Active';
                tag.style.background = checked ? 'rgba(251,146,60,0.12)' : 'rgba(34,197,94,0.12)';
                tag.style.borderColor = checked ? 'rgba(251,146,60,0.3)' : 'rgba(34,197,94,0.3)';
                tag.style.color = checked ? '#fdba74' : '#86efac';
            }
        },

        onSettingNameChange(val) {
            if (!this.currentProject) return;
            this.currentProject.name = val;
            const nameInput = document.getElementById('builder-project-name');
            if (nameInput) nameInput.value = val;
        },

        _syncSettingsTab() {
            const cb = document.getElementById('builder-setting-firebase');
            if (cb) cb.checked = !!this.currentProject?._useFirebase;
            this.onSettingFirebaseToggle(!!this.currentProject?._useFirebase);
            const nameInput = document.getElementById('builder-setting-name');
            if (nameInput) nameInput.value = this.currentProject?.name || '';
        },

        // ─── SSS: Smart Search in current file ─────────────────────────
        runSSS(query) {
            const countEl = document.getElementById('builder-sss-count');
            const editor  = document.getElementById('builder-code-editor');
            if (!editor || !countEl) return;
            if (!query) { countEl.textContent = ''; return; }
            const code    = editor.value;
            const regex   = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
            const matches = code.match(regex);
            const count   = matches ? matches.length : 0;
            countEl.textContent = count > 0 ? `${count} match${count > 1 ? 'es' : ''}` : 'No matches';
            countEl.style.color = count > 0 ? '#86efac' : '#f87171';
        },

        // Called on every keystroke in the code editor
        onCodeEdit(value) {
            // Save to current file
            if (this.currentProject.files[this.currentProject.currentFileIndex]) {
                this.currentProject.files[this.currentProject.currentFileIndex].content = value;
            }
            // Update live preview if active
            if (this._livePreviewActive) this.refreshPreview();
            // Update SSS match count if search is active
            const sssInput = document.getElementById('builder-sss-input');
            if (sssInput?.value) this.runSSS(sssInput.value);
            // Sync to cloud if collaborating (debounced)
            if (this._collabPID && (supabaseInitialized || firebaseInitialized)) {
                clearTimeout(this._collabSyncTimer);
                this._collabSyncTimer = setTimeout(async () => {
                    try { await this._collabWrite(this._collabPID, { code: value }); } catch(e) {}
                }, 800);
            }
        },
        _collabSyncTimer: null,

        // ─── Audio file picker for Music Sync ───────────────────────────
        collabPickAudioFile() {
            document.getElementById('collab-audio-picker')?.click();
        },

        collabLoadAudioFile(input) {
            const file = input.files[0];
            if (!file) return;
            const blobUrl = URL.createObjectURL(file);
            const urlInput = document.getElementById('collab-music-url');
            const nameEl  = document.getElementById('collab-music-name');
            if (urlInput) urlInput.value = blobUrl;
            if (nameEl)  nameEl.textContent = '📂 ' + file.name;
            // Play locally immediately
            this._collabHandleMusic(blobUrl);
            notify('Music Sync', file.name + ' loaded — hit Broadcast to share URL');
        },

        // ─── Home screen ────────────────────────────────────────────────
        goHome() {
            document.getElementById('builder-home-screen').style.display  = 'flex';
            document.getElementById('builder-editor-shell').style.display = 'none';
            this.homeRefreshProjects();
        },

        homeOpenEditor() {
            document.getElementById('builder-home-screen').style.display  = 'none';
            document.getElementById('builder-editor-shell').style.display = 'flex';
        },

        homeNewProject() {
            const name = prompt('Project name:');
            if (!name) return;
            this.currentProject.name = name;
            this.currentProject.files = [
                { name: 'Main.html', type: 'html', isMainFile: true, content: '<!DOCTYPE html>\n<html>\n<head>\n    <title>' + name + '</title>\n</head>\n<body>\n    <h1>' + name + '</h1>\n</body>\n</html>' },
                { name: 'Mani.manifest', type: 'json', content: '{\n  "name": "' + name + '",\n  "version": "1.0",\n  "description": "A new app",\n  "native": true,\n  "permissions": []\n}' }
            ];
            this.currentProject.currentFileIndex = 0;
            this._collabPID = null;
            this._collabSubs.forEach(u => u());
            this._collabSubs = [];
            document.getElementById('builder-project-name').value = name;
            this.homeOpenEditor();
            this.init();
        },

        homeFromTemplate(type) {
            const templates = {
                blank: { name: 'New App', code: '<!DOCTYPE html>\n<html>\n<head>\n    <title>My App</title>\n    <style>\n        body { font-family: sans-serif; margin: 0; background: #0f172a; color: white; display: flex; align-items: center; justify-content: center; height: 100vh; }\n    </style>\n</head>\n<body>\n    <h1>Hello HyOS!</h1>\n</body>\n</html>' },
                game:  { name: 'New Game', code: '<!DOCTYPE html>\n<html>\n<head>\n    <title>My Game</title>\n    <style>body{margin:0;background:#000;} canvas{display:block;margin:auto;}</style>\n</head>\n<body>\n<canvas id="c" width="480" height="360"></canvas>\n<script>\nconst ctx = document.getElementById("c").getContext("2d");\nlet x = 240, y = 180, vx = 2, vy = 2, r = 15;\nfunction loop() {\n    ctx.fillStyle = "#000"; ctx.fillRect(0,0,480,360);\n    ctx.fillStyle = "#60a5fa"; ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill();\n    x+=vx; y+=vy;\n    if(x<r||x>480-r) vx*=-1;\n    if(y<r||y>360-r) vy*=-1;\n    requestAnimationFrame(loop);\n}\nloop();\n</scr' + 'ipt>\n</body>\n</html>' },
                app:   { name: 'New App', code: '<!DOCTYPE html>\n<html>\n<head>\n    <title>My App</title>\n    <style>\n        * { box-sizing: border-box; margin: 0; }\n        body { font-family: sans-serif; display: flex; height: 100vh; background: #0f172a; color: white; }\n        nav { width: 200px; background: #1e293b; padding: 20px; }\n        main { flex: 1; padding: 30px; overflow-y: auto; }\n        .nav-item { padding: 10px; border-radius: 8px; cursor: pointer; margin-bottom: 4px; }\n        .nav-item:hover { background: rgba(255,255,255,0.1); }\n    </style>\n</head>\n<body>\n    <nav>\n        <h2 style="margin-bottom:20px;">My App</h2>\n        <div class="nav-item">Home</div>\n        <div class="nav-item">Settings</div>\n    </nav>\n    <main>\n        <h1>Welcome!</h1>\n        <p>Start building your app here.</p>\n    </main>\n</body>\n</html>' },
                tool:  { name: 'New Tool', code: '<!DOCTYPE html>\n<html>\n<head>\n    <title>My Tool</title>\n    <style>\n        body { font-family: sans-serif; background: #0f172a; color: white; padding: 30px; }\n        textarea, input { width: 100%; background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 12px; color: white; margin: 8px 0; }\n        button { background: #2563eb; border: none; color: white; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-weight: bold; }\n    </style>\n</head>\n<body>\n    <h1>My Tool</h1>\n    <textarea id="input" rows="6" placeholder="Input here…"></textarea>\n    <button onclick="process()">Run</button>\n    <textarea id="output" rows="6" placeholder="Output…" readonly></textarea>\n    <script>\n    function process() {\n        document.getElementById("output").value = document.getElementById("input").value.toUpperCase();\n    }\n    </scr' + 'ipt>\n</body>\n</html>' }
            };
            const t = templates[type];
            if (!t) return;
            this.currentProject.name = t.name;
            this.currentProject.files = [
                { name: 'Main.html', type: 'html', isMainFile: true, content: t.code },
                { name: 'Mani.manifest', type: 'json', content: '{\n  "name": "' + t.name + '",\n  "version": "1.0",\n  "description": "A new app",\n  "native": true,\n  "permissions": []\n}' }
            ];
            this.currentProject.currentFileIndex = 0;
            this._collabPID = null;
            document.getElementById('builder-project-name').value = t.name;
            this.homeOpenEditor();
            this.init();
        },

        async homeRefreshProjects() {
            const grid = document.getElementById('builder-home-projects');
            if (!grid) return;
            grid.innerHTML = '<div style="opacity:0.3;font-size:13px;grid-column:1/-1;text-align:center;padding:30px 0;">Loading…</div>';

            let projects = [];

            // Try Supabase first
            if (supabaseInitialized) {
                try {
                    const { data, error } = await supabase.from('builder_projects').select('*').eq('owner', user).order('updated_at', { ascending: false }).limit(20);
                    if (!error && data) projects = data.map(p => ({ id: p.id, name: p.name, updatedAt: p.updated_at, source: 'supabase' }));
                } catch(e) {}
            }

            // Fallback to Firebase
            if (!projects.length && firebaseInitialized) {
                try {
                    const snap = await window._fb.getDocs(
                        window._fb.query(window._fb.collection(db, 'builder_projects'), window._fb.where('owner', '==', user))
                    );
                    snap.forEach(d => {
                        const data = d.data();
                        projects.push({ id: d.id, name: data.name, updatedAt: data.updatedAt || data.createdAt, source: 'firebase' });
                    });
                } catch(e) {}
            }

            if (!projects.length) {
                grid.innerHTML = '<div style="opacity:0.3;font-size:13px;grid-column:1/-1;text-align:center;padding:30px 0;">No cloud projects yet. Create one and hit ☁️ Sync!</div>';
                return;
            }

            grid.innerHTML = projects.map(p => `
                <div onclick="AppBuilder.homeOpenCloudProject('${p.id}','${p.source}')"
                    style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:16px;cursor:pointer;transition:0.15s;"
                    onmouseover="this.style.borderColor='rgba(37,99,235,0.5)';this.style.background='rgba(37,99,235,0.07)'"
                    onmouseout="this.style.borderColor='rgba(255,255,255,0.08)';this.style.background='rgba(255,255,255,0.03)'">
                    <div style="font-size:22px;margin-bottom:8px;">🛠️</div>
                    <div style="font-weight:700;font-size:13px;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</div>
                    <div style="font-size:10px;opacity:0.35;">${p.updatedAt ? new Date(p.updatedAt).toLocaleDateString() : ''}</div>
                    <div style="font-size:9px;opacity:0.25;margin-top:2px;">${p.source === 'supabase' ? '🟢 Supabase' : '🔵 Firebase'}</div>
                </div>`).join('');
        },

        async homeOpenCloudProject(pid, source) {
            try {
                let data = null;
                if (source === 'supabase' && supabaseInitialized) {
                    const { data: rows } = await supabase.from('builder_projects').select('*').eq('id', pid).single();
                    data = rows;
                } else if (firebaseInitialized) {
                    const snap = await window._fb.getDoc(window._fb.doc(db, 'builder_projects', pid));
                    data = snap.exists() ? snap.data() : null;
                }
                if (!data) { notify('App Builder', 'Project not found.'); return; }
                this._collabPID = pid;
                this._collabSource = source;
                this.currentProject.name = data.name;
                this.currentProject.files = data.files || [
                    { name: 'Main.html', type: 'html', isMainFile: true, content: data.code || '' }
                ];
                this.currentProject.currentFileIndex = 0;
                document.getElementById('builder-project-name').value = data.name;
                this.homeOpenEditor();
                this.init();
                this._collabSubscribe();
                notify('App Builder', `Opened "${data.name}"`);
            } catch(e) {
                notify('App Builder', 'Failed to open: ' + e.message);
            }
        },

        // ─── _collabDB: Supabase primary, Firebase fallback ─────────────
        _collabSource: 'supabase', // tracks where the active project lives

        async _collabWrite(pid, payload) {
            // Try Supabase first
            if (supabaseInitialized && this._collabSource !== 'firebase') {
                try {
                    const { error } = await supabase.from('builder_projects').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', pid);
                    if (!error) return { source: 'supabase' };
                    // Check if it's a storage quota error
                    if (error.message?.toLowerCase().includes('limit') || error.message?.toLowerCase().includes('quota')) {
                        notify('App Builder', 'Supabase limit reached — switching to Firebase backup ☁️');
                        this._collabSource = 'firebase';
                    } else {
                        throw error;
                    }
                } catch(e) {
                    if (this._collabSource !== 'firebase') throw e;
                }
            }
            // Firebase fallback
            if (firebaseInitialized) {
                await window._fb.updateDoc(window._fb.doc(db, 'builder_projects', pid), payload);
                return { source: 'firebase' };
            }
            throw new Error('No cloud backend available.');
        },

        async _collabCreate(payload) {
            // Try Supabase first
            if (supabaseInitialized) {
                try {
                    const { data, error } = await supabase.from('builder_projects').insert({ ...payload, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }).select().single();
                    if (!error && data) { this._collabSource = 'supabase'; return { id: data.id, source: 'supabase' }; }
                    if (error.message?.toLowerCase().includes('limit') || error.message?.toLowerCase().includes('quota')) {
                        notify('App Builder', 'Supabase limit reached — falling back to Firebase ☁️');
                    }
                } catch(e) {}
            }
            // Firebase fallback
            if (firebaseInitialized) {
                const ref = await window._fb.addDoc(window._fb.collection(db, 'builder_projects'), payload);
                this._collabSource = 'firebase';
                return { id: ref.id, source: 'firebase' };
            }
            throw new Error('No cloud backend available.');
        },

        // ─── Collaboration state ─────────────────────────────────────────
        _collabPID: null,
        _collabSubs: [],

        // Sync current project to cloud (Supabase primary, Firebase fallback)
        async collabCreateOrSync() {
            if (!supabaseInitialized && !firebaseInitialized) { notify('Collaborate', 'Cloud not available.'); return; }
            const name = document.getElementById('builder-project-name')?.value || this.currentProject.name;
            const code = document.getElementById('builder-code-editor')?.value || '';
            const statusEl = document.getElementById('collab-project-status');

            try {
                if (this._collabPID) {
                    const { source } = await this._collabWrite(this._collabPID, { name, code });
                    if (statusEl) statusEl.innerHTML = `<span style="color:#86efac;">✓ Synced</span> <span style="opacity:0.4;font-size:10px;">${source === 'supabase' ? '🟢' : '🔵'} ${name}</span>`;
                    notify('Collaborate', 'Project synced!');
                } else {
                    const payload = { name, code, owner: user, members: [user], music: '' };
                    const { id, source } = await this._collabCreate(payload);
                    this._collabPID = id;
                    if (statusEl) statusEl.innerHTML = `<span style="color:#86efac;">✓ Cloud project created</span> <span style="opacity:0.4;font-size:10px;">${source === 'supabase' ? '🟢 Supabase' : '🔵 Firebase'}</span>`;
                    this._collabSubscribe();
                    notify('Collaborate', 'Project synced to cloud!');
                }
            } catch(e) {
                notify('Collaborate', 'Sync failed: ' + e.message);
            }
        },

        _collabSubscribe() {
            if (!this._collabPID || !firebaseInitialized) return;

            // Subscribe to project doc (code + music sync)
            const unsub1 = window._fb.onSnapshot(window._fb.doc(db, 'builder_projects', this._collabPID), d => {
                if (!d.exists()) return;
                const data = d.data();
                // Sync code if we're not the one typing
                const editor = document.getElementById('builder-code-editor');
                if (editor && document.activeElement !== editor && data.code !== undefined) {
                    editor.value = data.code;
                    this.currentProject.files[this.currentProject.currentFileIndex].content = data.code;
                }
                // Music sync
                if (data.music) this._collabHandleMusic(data.music);
                // Update member list
                this._collabRenderMembers(data.members || []);
            });

            // Subscribe to chat
            const chatQuery = window._fb.query(
                window._fb.collection(db, `builder_projects/${this._collabPID}/chat`),
                window._fb.orderBy('time', 'asc')
            );
            const unsub2 = window._fb.onSnapshot(chatQuery, snap => {
                const box = document.getElementById('collab-messages');
                if (!box) return;
                box.innerHTML = '';
                snap.forEach(m => {
                    const d = m.data();
                    const content = d.type === 'file'
                        ? `<a href="${d.url}" target="_blank" style="color:#60a5fa;">📎 ${d.name}</a>`
                        : d.text;
                    const div = document.createElement('div');
                    div.style.cssText = 'background:rgba(255,255,255,0.04);border-radius:8px;padding:8px 12px;font-size:13px;';
                    div.innerHTML = `<span style="color:#60a5fa;font-weight:700;">${d.user}:</span> ${content}`;
                    box.appendChild(div);
                });
                box.scrollTop = box.scrollHeight;
            });

            this._collabSubs.forEach(u => u());
            this._collabSubs = [unsub1, unsub2];

            // Status
            const statusEl = document.getElementById('collab-project-status');
            if (statusEl) statusEl.innerHTML = `<span style="color:#86efac;">✓ Live sync active</span>`;
        },

        _collabRenderMembers(members) {
            const el = document.getElementById('collab-members-list');
            if (!el) return;
            if (!members.length) { el.textContent = 'No members yet.'; return; }
            el.innerHTML = members.map(m =>
                `<div style="padding:5px 0;font-size:12px;display:flex;align-items:center;gap:6px;">
                    <span style="color:#4ade80;">●</span> ${m}
                </div>`
            ).join('');
        },

        async collabInvite() {
            if (!this._collabPID) { notify('Collaborate', 'Sync your project first!'); return; }
            const handle = document.getElementById('collab-invite-input')?.value?.trim();
            if (!handle) return;
            try {
                // Look up user by hyUser handle
                const q = window._fb.query(window._fb.collection(db, 'users'), window._fb.where('hyUser', '==', handle));
                const snap = await window._fb.getDocs(q);
                if (snap.empty) { notify('Collaborate', `User "${handle}" not found.`); return; }
                const friendUID = snap.docs[0].id;
                await window._fb.updateDoc(window._fb.doc(db, 'builder_projects', this._collabPID), {
                    members: window._fb.arrayUnion(friendUID)
                });
                document.getElementById('collab-invite-input').value = '';
                notify('Collaborate', `${handle} added to project!`);
            } catch(e) {
                notify('Collaborate', 'Invite failed: ' + e.message);
            }
        },

        async collabSendMsg() {
            if (!this._collabPID) { notify('Collaborate', 'Sync your project first!'); return; }
            const input = document.getElementById('collab-msg-input');
            const text = input?.value?.trim();
            if (!text) return;
            try {
                await window._fb.addDoc(window._fb.collection(db, `builder_projects/${this._collabPID}/chat`), {
                    user: user || 'Anonymous', text, time: Date.now()
                });
                input.value = '';
            } catch(e) {
                notify('Collaborate', 'Send failed: ' + e.message);
            }
        },

        async collabUploadFile() {
            if (!this._collabPID) { notify('Collaborate', 'Sync your project first!'); return; }
            const f = document.getElementById('collab-file-up')?.files[0];
            if (!f) return;
            if (f.size > 1048576) { notify('Collaborate', 'File too large (max 1MB).'); return; }
            try {
                // Store as base64 in Firestore (small files only)
                const reader = new FileReader();
                reader.onload = async () => {
                    await window._fb.addDoc(window._fb.collection(db, `builder_projects/${this._collabPID}/chat`), {
                        user: user || 'Anonymous', type: 'file',
                        url: reader.result, name: f.name, time: Date.now()
                    });
                };
                reader.readAsDataURL(f);
            } catch(e) {
                notify('Collaborate', 'Upload failed: ' + e.message);
            }
        },

        async collabSyncMusic() {
            if (!this._collabPID) { notify('Collaborate', 'Sync your project first!'); return; }
            const url = document.getElementById('collab-music-url')?.value?.trim();
            if (!url) return;
            try {
                await this._collabWrite(this._collabPID, { music: url });
                notify('Collaborate', 'Music broadcast to collaborators!');
            } catch(e) {
                notify('Collaborate', 'Music sync failed: ' + e.message);
            }
        },

        _collabHandleMusic(url) {
            const audio = document.getElementById('collab-audio');
            if (!audio || !url) return;
            if (audio.src !== url) {
                audio.src = url;
                audio.play().catch(() => {});
            }
        },

        async runLSS(query) {
            const resultsEl = document.getElementById('collab-lss-results');
            if (!resultsEl) return;
            if (!query || query.length < 2) { resultsEl.innerHTML = ''; return; }
            if (!firebaseInitialized) { resultsEl.innerHTML = '<span style="opacity:0.4;">Cloud not available.</span>'; return; }

            resultsEl.innerHTML = '<span style="opacity:0.4;">Searching…</span>';
            try {
                const snap = await window._fb.getDocs(window._fb.collection(db, 'builder_projects'));
                const matches = [];
                snap.forEach(d => {
                    const data = d.data();
                    if (data.code && data.code.toLowerCase().includes(query.toLowerCase())) {
                        const idx = data.code.toLowerCase().indexOf(query.toLowerCase());
                        const snippet = data.code.substring(Math.max(0, idx - 20), idx + 60).replace(/\n/g, ' ');
                        matches.push({ name: data.name, snippet, id: d.id });
                    }
                });
                if (!matches.length) {
                    resultsEl.innerHTML = '<span style="opacity:0.4;font-size:11px;">No results.</span>';
                    return;
                }
                resultsEl.innerHTML = matches.slice(0, 8).map(m => `
                    <div style="background:rgba(255,255,255,0.04);border-radius:6px;padding:8px;margin-bottom:6px;font-size:11px;cursor:pointer;"
                        onclick="AppBuilder._collabLoadProject('${m.id}')">
                        <div style="font-weight:700;color:#60a5fa;margin-bottom:3px;">${m.name}</div>
                        <div style="opacity:0.5;font-family:monospace;">…${m.snippet}…</div>
                    </div>`).join('');
            } catch(e) {
                resultsEl.innerHTML = '<span style="opacity:0.4;font-size:11px;">Search failed.</span>';
            }
        },

        async _collabLoadProject(pid) {
            if (!firebaseInitialized) return;
            try {
                const snap = await window._fb.getDoc(window._fb.doc(db, 'builder_projects', pid));
                if (!snap.exists()) return;
                const data = snap.data();
                this._collabPID = pid;
                this.currentProject.name = data.name;
                const editor = document.getElementById('builder-code-editor');
                if (editor) editor.value = data.code || '';
                const nameInput = document.getElementById('builder-project-name');
                if (nameInput) nameInput.value = data.name;
                this._collabSubscribe();
                this.switchTab('collaborate');
                notify('Collaborate', `Loaded "${data.name}" from cloud.`);
            } catch(e) {
                notify('Collaborate', 'Load failed: ' + e.message);
            }
        },
        
        // Store for property buttons
        propertyButtons: [],
        currentIconType: 'emoji', // 'emoji' or 'image'
        currentIconData: '💾',
        
        // Update action type
        updateStatusBarActionType(type) {
            const messageConfig = document.getElementById('statusbar-message-config');
            const propertiesConfig = document.getElementById('statusbar-properties-config');
            const disabledInfo = document.getElementById('statusbar-disabled-info');
            
            messageConfig.style.display = 'none';
            propertiesConfig.style.display = 'none';
            disabledInfo.style.display = 'none';
            
            if (type === 'message') {
                messageConfig.style.display = 'block';
            } else if (type === 'properties') {
                propertiesConfig.style.display = 'block';
                this.updatePropertiesPreview();
            } else {
                disabledInfo.style.display = 'block';
            }
        },
        
        // Update message preview
        updateMessagePreview() {
            const icon = document.getElementById('statusbar-msg-icon').value || '💾';
            const text = document.getElementById('statusbar-msg-text').value || 'Saving...';
            
            document.getElementById('msg-code-icon').textContent = icon;
            document.getElementById('msg-code-text').textContent = text;
        },
        
        // Test status bar message
        testStatusBarMessage() {
            const icon = document.getElementById('statusbar-msg-icon').value || '💾';
            const text = document.getElementById('statusbar-msg-text').value || 'Saving...';
            
            if (window.setStatusBarAction) {
                window.setStatusBarAction(icon, text);
                notify('Test', 'Status bar message triggered!');
            }
        },
        
        // Pick icon from file
        pickStatusBarIcon() {
            document.getElementById('statusbar-icon-picker').click();
        },
        
        // Handle icon upload
        handleIconUpload(input) {
            const file = input.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                const base64 = e.target.result;
                this.currentIconType = 'image';
                this.currentIconData = base64;
                document.getElementById('statusbar-msg-icon').value = '🖼️';
                this.updateMessagePreview();
                notify('Icon Loaded', 'Image icon loaded successfully!');
            };
            reader.readAsDataURL(file);
        },
        
        // Add property button
        addPropertyButton() {
            const buttonId = 'btn_' + Date.now();
            const button = {
                id: buttonId,
                label: 'New Button',
                icon: '🔘',
                iconType: 'emoji',
                iconData: '??',
                action: {
                    type: 'json',
                    code: '{\n  "systemAction": "notify",\n  "title": "Button Clicked",\n  "message": "You clicked a button!"\n}'
                }
            };
            
            this.propertyButtons.push(button);
            this.renderPropertyButtons();
            this.updatePropertiesPreview();
        },
        
        // Render property buttons list
        renderPropertyButtons() {
            const list = document.getElementById('properties-button-list');
            if (!list) return;
            
            if (this.propertyButtons.length === 0) {
                list.innerHTML = '<div style="text-align: center; opacity: 0.5; padding: 20px; font-size: 13px;">No buttons yet. Click "Add Button" to create one.</div>';
                return;
            }
            
            list.innerHTML = this.propertyButtons.map((btn, index) => `
                <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px; margin-bottom: 10px; border: 1px solid #475569;">
                    <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 12px;">
                        <div style="font-weight: 600; font-size: 13px; flex: 1;">Button ${index + 1}</div>
                        <button onclick="AppBuilder.editPropertyButton(${index})" style="background: #2563eb; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; color: #fff; font-size: 11px; font-weight: 600; margin-right: 6px;">
                            ✏️ Edit
                        </button>
                        <button onclick="AppBuilder.deletePropertyButton(${index})" style="background: #ef4444; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; color: #fff; font-size: 11px; font-weight: 600;">
                            🗑️
                        </button>
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center; font-size: 12px; opacity: 0.8;">
                        <span style="font-size: 20px;">${btn.icon}</span>
                        <span>${btn.label}</span>
                    </div>
                </div>
            `).join('');
        },
        
        // Edit property button
        editPropertyButton(index) {
            const btn = this.propertyButtons[index];
            if (!btn) return;
            
            // Create modal
            const modal = document.createElement('div');
            modal.style.cssText = 'position: fixed; inset: 0; z-index: 99999; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; backdrop-filter: blur(10px);';
            
            modal.innerHTML = `
                <div style="background: #0f172a; padding: 30px; border-radius: 20px; border: 1px solid #334155; width: 600px; max-height: 80vh; overflow-y: auto;">
                    <h3 style="font-size: 18px; font-weight: 700; margin-bottom: 20px;">✏️ Edit Button</h3>
                    
                    <div style="margin-bottom: 15px;">
                        <label style="font-size: 13px; font-weight: 600; margin-bottom: 8px; display: block;">Button Label</label>
                        <input id="edit-btn-label" type="text" value="${btn.label}" style="width: 100%; background: #000; border: 1px solid #475569; padding: 10px; border-radius: 8px; color: #fff; font-size: 13px;">
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <label style="font-size: 13px; font-weight: 600; margin-bottom: 8px; display: block;">Icon</label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input id="edit-btn-icon" type="text" value="${btn.icon}" style="width: 80px; background: #000; border: 1px solid #475569; padding: 10px; border-radius: 8px; color: #fff; font-size: 18px; text-align: center;">
                            <button onclick="AppBuilder.pickButtonIcon(${index})" style="background: #7c3aed; padding: 10px 16px; border-radius: 8px; cursor: pointer; border: none; color: #fff; font-size: 13px; font-weight: 600;">
                                🖼️ Pick Image
                            </button>
                        </div>
                        <input type="file" id="edit-btn-icon-picker" accept="image/*" style="display: none;" onchange="AppBuilder.handleButtonIconUpload(this, ${index})">
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <label style="font-size: 13px; font-weight: 600; margin-bottom: 8px; display: block;">Action Type</label>
                        <select id="edit-btn-action-type" onchange="AppBuilder.updateButtonActionType(this.value, ${index})" style="width: 100%; background: #000; border: 1px solid #475569; padding: 10px; border-radius: 8px; color: #fff; font-size: 13px;">
                            <option value="json" ${btn.action.type === 'json' ? 'selected' : ''}>JSON Action</option>
                            <option value="html" ${btn.action.type === 'html' ? 'selected' : ''}>HTML/JavaScript</option>
                        </select>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="font-size: 13px; font-weight: 600; margin-bottom: 8px; display: block;">Action Code</label>
                        <textarea id="edit-btn-code" style="width: 100%; height: 200px; background: #000; border: 1px solid #475569; padding: 12px; border-radius: 8px; color: #fff; font-family: 'Courier New', monospace; font-size: 12px; resize: vertical;">${btn.action.code}</textarea>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button onclick="AppBuilder.cancelEditButton()" style="flex: 1; background: #334155; padding: 12px; border-radius: 8px; cursor: pointer; border: none; color: #fff; font-size: 13px; font-weight: 600;">
                            Cancel
                        </button>
                        <button onclick="AppBuilder.saveEditButton(${index})" style="flex: 1; background: #16a34a; padding: 12px; border-radius: 8px; cursor: pointer; border: none; color: #fff; font-size: 13px; font-weight: 600;">
                            💾 Save
                        </button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            window._editButtonModal = modal;
        },
        
        // Pick button icon
        pickButtonIcon(index) {
            document.getElementById('edit-btn-icon-picker').click();
        },
        
        // Handle button icon upload
        handleButtonIconUpload(input, index) {
            const file = input.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                const base64 = e.target.result;
                document.getElementById('edit-btn-icon').value = '🖼️';
                this.propertyButtons[index].iconType = 'image';
                this.propertyButtons[index].iconData = base64;
                notify('Icon Loaded', 'Button icon loaded!');
            };
            reader.readAsDataURL(file);
        },
        
        // Update button action type
        updateButtonActionType(type, index) {
            const code = document.getElementById('edit-btn-code');
            if (type === 'json' && code.value.trim().startsWith('<')) {
                code.value = '{\n  "systemAction": "notify",\n  "title": "Button Clicked",\n  "message": "Action executed!"\n}';
            } else if (type === 'html' && code.value.trim().startsWith('{')) {
                code.value = '<button onclick="alert(\'Button clicked!\')">Click Me</button>';
            }
        },
        
        // Save edited button
        saveEditButton(index) {
            const label = document.getElementById('edit-btn-label').value;
            const icon = document.getElementById('edit-btn-icon').value;
            const actionType = document.getElementById('edit-btn-action-type').value;
            const code = document.getElementById('edit-btn-code').value;
            
            this.propertyButtons[index].label = label;
            this.propertyButtons[index].icon = icon;
            this.propertyButtons[index].action.type = actionType;
            this.propertyButtons[index].action.code = code;
            
            this.cancelEditButton();
            this.renderPropertyButtons();
            this.updatePropertiesPreview();
            notify('Saved', 'Button updated successfully!');
        },
        
        // Cancel edit button
        cancelEditButton() {
            if (window._editButtonModal) {
                window._editButtonModal.remove();
                window._editButtonModal = null;
            }
        },
        
        // Delete property button
        deletePropertyButton(index) {
            if (confirm('Delete this button?')) {
                this.propertyButtons.splice(index, 1);
                this.renderPropertyButtons();
                this.updatePropertiesPreview();
                notify('Deleted', 'Button removed');
            }
        },
        
        // Update properties preview
        updatePropertiesPreview() {
            const preview = document.getElementById('properties-code-preview');
            if (!preview) return;
            
            const data = {
                buttons: this.propertyButtons.map(btn => ({
                    label: btn.label,
                    icon: btn.iconType === 'image' ? { type: 'image', data: btn.iconData } : btn.icon,
                    action: btn.action
                }))
            };
            
            preview.textContent = JSON.stringify(data, null, 2);
        },
        
        // Copy status bar code (for message type)
        copyStatusBarCode() {
            const icon = document.getElementById('statusbar-msg-icon')?.value || '💾';
            const text = document.getElementById('statusbar-msg-text')?.value || 'Saving...';
            
            const code = `// Show status bar action
if (window.parent && window.parent.setStatusBarAction) {
    window.parent.setStatusBarAction('${icon}', '${text}');
}`;
            
            navigator.clipboard.writeText(code).then(() => {
                notify('Copied', 'Code copied to clipboard!');
            }).catch(() => {
                const textarea = document.createElement('textarea');
                textarea.value = code;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                notify('Copied', 'Code copied to clipboard!');
            });
        },
        
        // Copy properties code
        copyPropertiesCode() {
            const preview = document.getElementById('properties-code-preview');
            if (!preview) return;
            
            const code = preview.textContent;
            
            navigator.clipboard.writeText(code).then(() => {
                notify('Copied', 'JSON copied to clipboard!');
            }).catch(() => {
                const textarea = document.createElement('textarea');
                textarea.value = code;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                notify('Copied', 'JSON copied to clipboard!');
            });
        },
        
        // Hyley Coding Assistant
        toggleHyleyAssistant() {
            const panel = document.getElementById('hyley-coding-assistant');
            const isOpen = panel.style.width === '350px';
            
            if (isOpen) {
                panel.style.width = '0';
            } else {
                panel.style.width = '350px';
            }
        },
        
        sendToHyley() {
            const input = document.getElementById('hyley-coding-input');
            const message = input.value.trim();
            
            if (!message) return;
            
            const chat = document.getElementById('hyley-coding-chat');
            
            // Add user message
            const userMsg = document.createElement('div');
            userMsg.style.cssText = 'background: rgba(37, 99, 235, 0.2); padding: 10px 12px; border-radius: 10px; margin-bottom: 10px; font-size: 13px;';
            userMsg.innerHTML = `<strong style="font-size: 11px; opacity: 0.7;">YOU</strong><br>${message}`;
            chat.appendChild(userMsg);
            
            input.value = '';
            
            // Get current code context
            const currentCode = document.getElementById('builder-code-editor').value;
            const currentFile = document.getElementById('builder-current-file').textContent;
            
            // Process and respond
            setTimeout(() => {
                const response = this.getHyleyCodingHelp(message, currentCode, currentFile);
                
                const assistantMsg = document.createElement('div');
                assistantMsg.style.cssText = 'background: rgba(255,255,255,0.05); padding: 10px 12px; border-radius: 10px; margin-bottom: 10px; font-size: 13px;';
                assistantMsg.innerHTML = `<strong style="font-size: 11px; opacity: 0.7;">HYLEY</strong><br>${response}`;
                chat.appendChild(assistantMsg);
                
                chat.scrollTop = chat.scrollHeight;
            }, 500);
        },
        
        getHyleyCodingHelp(question, code, filename) {
            const q = question.toLowerCase();
            
            // Analyze the code context
            const hasHTML = code.includes('<') && code.includes('>');
            const hasCSS = code.includes('{') && code.includes('}') && (code.includes(':') || filename.endsWith('.css'));
            const hasJS = code.includes('function') || code.includes('=>') || code.includes('const') || code.includes('let') || filename.endsWith('.js');
            
            // Debugging help
            if (q.includes('error') || q.includes('not working') || q.includes('broken') || q.includes('bug')) {
                const tips = [];
                tips.push("🔍 <strong>Debugging Tips:</strong>");
                tips.push("• Check the browser console for error messages (F12)");
                tips.push("• Verify all opening tags have closing tags");
                tips.push("• Make sure variable names are spelled correctly");
                tips.push("• Check for missing semicolons or brackets");
                if (hasJS) tips.push("• Use console.log() to check variable values");
                return tips.join('<br>');
            }
            
            // HTML help
            if (q.includes('html') || (hasHTML && (q.includes('tag') || q.includes('element')))) {
                return "📝 <strong>HTML Tips:</strong><br>• Use semantic tags like &lt;header&gt;, &lt;main&gt;, &lt;footer&gt;<br>• Every opening tag needs a closing tag<br>• IDs should be unique, classes can be reused<br>• Use &lt;div&gt; for containers and &lt;span&gt; for inline text";
            }
            
            // CSS help
            if (q.includes('css') || q.includes('style') || q.includes('color') || q.includes('design')) {
                return "🎨 <strong>CSS Tips:</strong><br>• Use flexbox or grid for layouts<br>• Colors: Use hex (#fff) or rgb(255,255,255)<br>• Spacing: margin (outside) vs padding (inside)<br>• Selectors: .class for multiple, #id for unique";
            }
            
            // JavaScript help
            if (q.includes('javascript') || q.includes('function') || q.includes('variable')) {
                return "⚡ <strong>JavaScript Tips:</strong><br>• Use 'const' for values that don't change<br>• Use 'let' for values that change<br>• Functions: function name() {} or const name = () => {}<br>• Get elements: document.getElementById('id')";
            }
            
            // Event handling
            if (q.includes('click') || q.includes('event') || q.includes('button')) {
                return "🖱️ <strong>Event Handling:</strong><br>• Add onclick in HTML: &lt;button onclick=\"myFunction()\"&gt;<br>• Or use JS: button.addEventListener('click', function)<br>• Common events: click, change, keypress, submit";
            }
            
            // Forms
            if (q.includes('form') || q.includes('input')) {
                return "📋 <strong>Forms & Inputs:</strong><br>• Get input value: document.getElementById('id').value<br>• Input types: text, number, email, password, checkbox<br>• Use labels with inputs for accessibility<br>• Prevent form submit: event.preventDefault()";
            }
            
            // Layout
            if (q.includes('center') || q.includes('layout') || q.includes('position')) {
                return "📐 <strong>Layout Tips:</strong><br>• Center: Use flexbox with justify-content and align-items<br>• Position: static (default), relative, absolute, fixed<br>• Display: block, inline, flex, grid, none";
            }
            
            // Performance
            if (q.includes('improve') || q.includes('better') || q.includes('optimize')) {
                return "⚡ <strong>Improvement Tips:</strong><br>• Minimize DOM manipulation (batch updates)<br>• Use CSS for animations when possible<br>• Compress images and minify code for production<br>• Cache elements you use frequently";
            }
            
            // Code analysis based on what they're currently writing
            if (code && code.length > 50) {
                if (!hasHTML && !hasCSS && !hasJS) {
                    return "👋 It looks like you're just getting started! Try adding some HTML to begin. Start with:<br><br>&lt;!DOCTYPE html&gt;<br>&lt;html&gt;<br>&lt;body&gt;<br>  &lt;h1&gt;Hello World!&lt;/h1&gt;<br>&lt;/body&gt;<br>&lt;/html&gt;";
                }
                
                if (hasHTML && !hasCSS) {
                    return "🎨 You have HTML! Want to add some style?<br>• Add a &lt;style&gt; tag in the &lt;head&gt;<br>• Or create a separate .css file<br>• Try: body { background: #f0f0f0; font-family: Arial; }";
                }
                
                if (hasHTML && hasCSS && !hasJS) {
                    return "⚡ Nice! You have HTML and CSS. Want to add interactivity?<br>• Create a .js file or add &lt;script&gt; tags<br>• Try adding a button with onclick<br>• Example: function sayHello() { alert('Hello!'); }";
                }
            }
            
            // General help
            const generalTips = [
                "💡 Try asking about specific topics like 'HTML', 'CSS', 'JavaScript', or 'debugging'",
                "🎯 I can help with layouts, styling, events, forms, and more!",
                "📖 Ask me things like 'how do I center elements' or 'explain functions'",
                "🚀 Want to improve your code? Ask 'how can I make this better?'"
            ];
            
            return generalTips[Math.floor(Math.random() * generalTips.length)];
        }
    };
    
    window.AppBuilder = AppBuilder;
    
    // Helper for HyFiles-based HyH import
    window._doImportHyH = (fileIndex) => {
        const item = window._hyhImportFiles[fileIndex];
        const self = window._hyhImportSelf;
        if (!item || !self) return;
        
        try {
            const hyhPackage = JSON.parse(item.file.data || item.file.content);
            
            if (hyhPackage.format !== 'HyH') {
                notify('Error', 'Invalid HyH file format');
                return;
            }
            
            self.currentProject.name = hyhPackage.name;
            self.currentProject.files = hyhPackage.files || [];
            self.currentProject.currentFileIndex = 0;
            
            document.getElementById('builder-project-name').value = hyhPackage.name;
            document.getElementById('builder-app-icon').value = hyhPackage.icon;
            document.getElementById('builder-app-desc').value = hyhPackage.description;
            
            if (hyhPackage.icon && hyhPackage.icon.startsWith('data:image')) {
                b64Icon = hyhPackage.icon;
                const iconInput = document.getElementById('builder-app-icon');
                iconInput.value = '🖼️ (Image)';
                iconInput.style.backgroundImage = 'url(' + hyhPackage.icon + ')';
                iconInput.style.backgroundSize = 'contain';
                iconInput.style.backgroundRepeat = 'no-repeat';
                iconInput.style.backgroundPosition = 'center';
                iconInput.style.color = 'transparent';
            }
            
            self.renderFileTree();
            self.loadCurrentFile();
            
            notify('Imported', hyhPackage.name + ' loaded successfully!');
        } catch (error) {
            console.error('Import error:', error);
            notify('Error', 'Failed to import HyH file');
        }
    };
    
    // =====================
    // NOTIFICATION CENTER
    // =====================
    
    const NotificationCenter = {
        notifications: [],
        isOpen: false,
        
        add(title, message, persist) {
            persist = persist !== false; // default true
            
            const notif = {
                id: 'notif_' + Date.now(),
                title: title,
                message: message,
                timestamp: new Date().toLocaleTimeString(),
                date: new Date()
            };
            
            if (persist) {
                this.notifications.unshift(notif);
                this.updateUI();
            }
            
            // Show traditional popup notification
            notify(title, message);
            
            // Update notification count badge
            this.updateBadge();
        },
        
        toggle() {
            this.isOpen = !this.isOpen;
            const panel = document.getElementById('notification-center');
            if (panel) {
                panel.style.right = this.isOpen ? '0' : '-350px';
            }
            
            // Close control center if open
            if (this.isOpen) {
                ControlCenter.close();
            }
        },
        
        close() {
            this.isOpen = false;
            const panel = document.getElementById('notification-center');
            if (panel) {
                panel.style.right = '-350px';
            }
        },
        
        clearAll() {
            if (confirm('Clear all notifications?')) {
                this.notifications = [];
                this.updateUI();
                this.updateBadge();
            }
        },
        
        remove(id) {
            this.notifications = this.notifications.filter(n => n.id !== id);
            this.updateUI();
            this.updateBadge();
        },
        
        updateUI() {
            const list = document.getElementById('notification-list');
            if (!list) return;
            
            if (this.notifications.length === 0) {
                list.innerHTML = '<div style="text-align: center; padding: 60px 20px; opacity: 0.5;">' +
                    '<div style="font-size: 48px; margin-bottom: 12px;">🔕</div>' +
                    '<div>No notifications</div>' +
                    '</div>';
            } else {
                list.innerHTML = this.notifications.map(n => 
                    '<div style="background: rgba(255,255,255,0.05); padding: 14px; border-radius: 12px; margin-bottom: 10px; border: 1px solid #334155; position: relative;">' +
                        '<div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 6px;">' +
                            '<span style="font-weight: 600; font-size: 14px;">' + n.title + '</span>' +
                            '<button onclick="NotificationCenter.remove(\'' + n.id + '\')" style="background: transparent; border: none; color: #94a3b8; cursor: pointer; padding: 0; font-size: 16px;">✕</button>' +
                        '</div>' +
                        '<div style="font-size: 13px; opacity: 0.8; margin-bottom: 6px;">' + n.message + '</div>' +
                        '<div style="font-size: 11px; opacity: 0.5;">' + n.timestamp + '</div>' +
                    '</div>'
                ).join('');
            }
        },
        
        updateBadge() {
            const badge = document.getElementById('notif-badge');
            if (!badge) return;
            
            if (this.notifications.length > 0) {
                badge.textContent = this.notifications.length > 99 ? '99+' : this.notifications.length;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }
    };
    
    window.NotificationCenter = NotificationCenter;
    
    // =====================
    // CONTROL CENTER
    // =====================
    
    const ControlCenter = {
        isOpen: false,
        state: {
            wifi: true,
            bluetooth: false,
            airplane: false,
            dnd: false,
            brightness: 80,
            volume: 50
        },
        
        toggle() {
            this.isOpen = !this.isOpen;
            const panel = document.getElementById('control-center');
            if (panel) {
                panel.style.right = this.isOpen ? '0' : '-350px';
            }
            
            // Close notification center if open
            if (this.isOpen) {
                NotificationCenter.close();
            }
        },
        
        close() {
            this.isOpen = false;
            const panel = document.getElementById('control-center');
            if (panel) {
                panel.style.right = '-350px';
            }
        },
        
        toggleWifi() {
            this.state.wifi = !this.state.wifi;
            const status = document.getElementById('wifi-status');
            const parent = status ? status.parentElement : null;
            
            if (status) {
                status.textContent = this.state.wifi ? 'Connected' : 'Disconnected';
            }
            if (parent) {
                parent.style.background = this.state.wifi ? 'rgba(37, 99, 235, 0.2)' : 'rgba(255,255,255,0.05)';
                parent.style.borderColor = this.state.wifi ? '#2563eb' : '#334155';
            }
            
            notify('Wi-Fi', this.state.wifi ? 'Connected' : 'Disconnected');
        },
        
        toggleBluetooth() {
            this.state.bluetooth = !this.state.bluetooth;
            const status = document.getElementById('bluetooth-status');
            const parent = status ? status.parentElement : null;
            
            if (status) {
                status.textContent = this.state.bluetooth ? 'On' : 'Off';
            }
            if (parent) {
                parent.style.background = this.state.bluetooth ? 'rgba(37, 99, 235, 0.2)' : 'rgba(255,255,255,0.05)';
                parent.style.borderColor = this.state.bluetooth ? '#2563eb' : '#334155';
            }
            
            notify('Bluetooth', this.state.bluetooth ? 'Enabled' : 'Disabled');
        },
        
        toggleAirplane() {
            this.state.airplane = !this.state.airplane;
            const status = document.getElementById('airplane-status');
            const parent = status ? status.parentElement : null;
            
            if (status) {
                status.textContent = this.state.airplane ? 'On' : 'Off';
            }
            if (parent) {
                parent.style.background = this.state.airplane ? 'rgba(234, 88, 12, 0.2)' : 'rgba(255,255,255,0.05)';
                parent.style.borderColor = this.state.airplane ? '#ea580c' : '#334155';
            }
            
            notify('Airplane Mode', this.state.airplane ? 'Enabled' : 'Disabled');
        },
        
        toggleDND() {
            this.state.dnd = !this.state.dnd;
            const status = document.getElementById('dnd-status');
            const parent = status ? status.parentElement : null;
            
            if (status) {
                status.textContent = this.state.dnd ? 'On' : 'Off';
            }
            if (parent) {
                parent.style.background = this.state.dnd ? 'rgba(139, 92, 246, 0.2)' : 'rgba(255,255,255,0.05)';
                parent.style.borderColor = this.state.dnd ? '#8b5cf6' : '#334155';
            }
            
            notify('Do Not Disturb', this.state.dnd ? 'Enabled' : 'Disabled');
        },
        
        setBrightness(value) {
            this.state.brightness = value;
            const label = document.getElementById('brightness-value');
            if (label) {
                label.textContent = value + '%';
            }
            
            // Apply brightness filter
            const desktop = document.getElementById('desktop-bg');
            if (desktop) {
                desktop.style.filter = 'brightness(' + (value / 100) + ')';
            }
        },
        
        setVolume(value) {
            this.state.volume = value;
            const label = document.getElementById('volume-value');
            if (label) {
                label.textContent = value + '%';
            }
        }
    };
    
    window.ControlCenter = ControlCenter;
    
    // Update openMaker to use new AppBuilder
    window.openMaker = () => { 
        toggleApp('builder-win');
        setTimeout(() => {
            // Show home screen first, not editor
            const homeScreen  = document.getElementById('builder-home-screen');
            const editorShell = document.getElementById('builder-editor-shell');
            if (homeScreen && homeScreen.style.display === 'none') {
                // Already been opened before — just show whatever state it was in
            } else if (homeScreen) {
                homeScreen.style.display  = 'flex';
                if (editorShell) editorShell.style.display = 'none';
                AppBuilder.homeRefreshProjects();
            } else {
                AppBuilder.init();
            }
        }, 100);
    };

    
    window.runSetupWizard = () => {
        closeApp('settings-win');
        document.getElementById('setup-screen').style.display = 'flex';
        document.getElementById('setup-step-1').classList.add('active');
    };


    // Setup functions
    let selectedSetupGenre = '';
    let selectedSetupApps = [];
    let selectedSetupPlugins = [];
    let setupProfilePic = null;

    window.selectGenre = (genre, elem) => {
        document.querySelectorAll('.genre-card').forEach(c => c.classList.remove('selected'));
        elem.classList.add('selected');
        selectedSetupGenre = genre;
    };

    window.handleProfilePic = (input) => {
        const file = input.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setupProfilePic = e.target.result;
                document.getElementById('profile-preview').innerHTML = `<img src="${e.target.result}" class="w-full h-full object-cover">`;
            };
            reader.readAsDataURL(file);
        }
    };

    function populateSetupApps() {
        const container = document.getElementById('setup-apps-list');
        const sampleApps = [
            { id: 'calc', name: 'Calculator', icon: '🧮', genre: 'utility' },
            { id: 'notes', name: 'Notes', icon: '📝', genre: 'productivity' },
            { id: 'paint', name: 'Paint', icon: '🎨', genre: 'creative' },
            { id: 'music', name: 'Music Player', icon: '🎵', genre: 'entertainment' },
            { id: 'terminal', name: 'Terminal', icon: '💻', genre: 'development' },
            { id: 'chat', name: 'Chat', icon: '💬', genre: 'social' }
        ];
        
        container.innerHTML = sampleApps.map(app => `
            <div class="plugin-card" onclick="toggleSetupApp('${app.id}', this)">
                <div class="flex items-center gap-3">
                    <span class="text-3xl">${app.icon}</span>
                    <div>
                        <div class="font-bold">${app.name}</div>
                        <div class="text-xs opacity-60">${app.genre}</div>
                    </div>
                </div>
                <span class="text-xl">➕</span>
            </div>
        `).join('');
    }

    window.toggleSetupApp = (id, elem) => {
        if (selectedSetupApps.includes(id)) {
            selectedSetupApps = selectedSetupApps.filter(a => a !== id);
            elem.classList.remove('selected');
            elem.querySelector('span:last-child').textContent = '➕';
        } else {
            selectedSetupApps.push(id);
            elem.classList.add('selected');
            elem.querySelector('span:last-child').textContent = '✅';
        }
    };

    window.togglePlugin = (id, elem) => {
        if (selectedSetupPlugins.includes(id)) {
            selectedSetupPlugins = selectedSetupPlugins.filter(p => p !== id);
            elem.classList.remove('selected');
        } else {
            selectedSetupPlugins.push(id);
            elem.classList.add('selected');
        }
    };

    window.confirmSetupAge = () => {
        const input = document.getElementById('setup-age-input');
        const errDiv = document.getElementById('setup-age-error');
        const age = parseInt(input.value);
        if (!age || age < 1 || age > 120) {
            errDiv.style.display = 'block';
            input.style.borderColor = '#ef4444';
            return;
        }
        errDiv.style.display = 'none';
        input.style.borderColor = '';
        userSettings.userAge = age;
        userSettings.ageVerified = true;
        saveSettings();
        nextSetupStep(1);
    };

    window.nextSetupStep = (step) => {
        document.querySelectorAll('.setup-step').forEach(s => s.classList.remove('active'));
        document.getElementById(`setup-step-${step}`).classList.add('active');
    };

    window.prevSetupStep = (step) => {
        document.querySelectorAll('.setup-step').forEach(s => s.classList.remove('active'));
        document.getElementById(`setup-step-${step}`).classList.add('active');
    };

    window.finishSetup = async () => {
        // Save setup choices
        userSettings.selectedGenre = selectedSetupGenre || 'productivity';
        userSettings.profilePic = setupProfilePic;
        userSettings.installedPlugins = selectedSetupPlugins;
        userSettings.setupCompleted = true;
        
        // Install selected apps from setup
        if (selectedSetupApps.length > 0 && (supabaseInitialized || firebaseInitialized)) {
            try {
                for (const appId of selectedSetupApps) {
                    const app = cloudApps.find(a => a.id === appId);
                    if (app) {
                        const payload = { ...app, owner: user, original_id: appId, installed_at: new Date().toISOString() };
                        if (supabaseInitialized) { await window.sbInstalled.insert(payload); }
                        else { await window._fb.addDoc(window._fb.collection(db, "installed"), { ...app, owner: user, originalId: appId, installedAt: window._fb.serverTimestamp() }); }
                        installedApps.push(payload);
                    }
                }
                notify('Apps Installed', `${selectedSetupApps.length} app(s) installed successfully`);
            } catch (error) {
                console.error("Error installing setup apps:", error);
                notify('Installation Error', 'Some apps could not be installed');
            }
        }
        
        saveSettings();
        notify('Setup Complete', 'Welcome to HyOS HS!');
        
        document.getElementById('setup-screen').style.display = 'none';
        startOS();
    };

    window.openSetup = () => {
        document.getElementById('setup-screen').style.display = 'flex';
        document.querySelectorAll('.setup-step').forEach(s => s.classList.remove('active'));
        if (userSettings.userAge !== null && userSettings.ageVerified) {
            document.getElementById('setup-step-1').classList.add('active');
        } else {
            document.getElementById('setup-step-0').classList.add('active');
        }
    };

    // Desktop icon management
    function renderDesktopIcons() {
        const desktop = document.getElementById('desktop');
        const existingIcons = desktop.querySelectorAll('.desktop-icon');
        existingIcons.forEach(icon => icon.remove());
        
        if (!userSettings.showDesktopIcons) return;
        
        userSettings.desktopIcons.forEach((iconData, index) => {
            if (iconData.type === 'folder') createFolderIcon(iconData, index);
            else createDesktopIcon(iconData);
        });
    }

    function createDesktopIcon(iconData) {
        const desktop = document.getElementById('desktop');
        const icon = document.createElement('div');
        icon.className = 'desktop-icon';
        icon.style.left = iconData.x + 'px';
        icon.style.top = iconData.y + 'px';
        icon.dataset.appId = iconData.appId;
        
        const isImg = iconData.icon?.startsWith('data');
        icon.innerHTML = `
            <div class="icon-box">
                ${isImg ? `<img src="${iconData.icon}">` : `<span class="text-3xl">${iconData.icon}</span>`}
            </div>
            <span>${iconData.name}</span>
        `;
        
        // Double-click to launch app
        let clickTimeout;
        let clickCount = 0;
        icon.addEventListener('click', (e) => {
            e.stopPropagation();
            clickCount++;
            
            if (clickCount === 1) {
                clickTimeout = setTimeout(() => {
                    clickCount = 0;
                }, 300);
            } else if (clickCount === 2) {
                clearTimeout(clickTimeout);
                clickCount = 0;
                // Launch the app
                if (iconData.appId) {
                    const app = installedApps.find(a => a.id === iconData.appId) || cloudApps.find(a => a.id === iconData.appId);
                    if (app) {
                        launchApp(app);
                        icon.classList.add('launching');
                        setTimeout(() => icon.classList.remove('launching'), 300);
                    }
                }
            }
        });
        
        // Make draggable with smooth animations
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        icon.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return; // Only left click
            
            isDragging = false; // Set to false initially
            startX = e.clientX;
            startY = e.clientY;
            initialX = icon.offsetLeft;
            initialY = icon.offsetTop;
            
            icon.style.cursor = 'grabbing';
            
            const onMove = (e) => {
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;
                
                if (!isDragging && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
                    isDragging = true;
                    icon.classList.add('dragging');
                }
                
                if (!isDragging) return;
                
                let newX = initialX + dx;
                let newY = initialY + dy;
                
                const maxX = desktop.offsetWidth - icon.offsetWidth;
                const maxY = desktop.offsetHeight - icon.offsetHeight - 60;
                newX = Math.max(0, Math.min(newX, maxX));
                newY = Math.max(0, Math.min(newY, maxY));
                
                if (userSettings.snapToGrid) {
                    newX = Math.round(newX / 100) * 100;
                    newY = Math.round(newY / 100) * 100;
                }
                
                icon.style.left = newX + 'px';
                icon.style.top = newY + 'px';

                // Highlight folder drop targets
                document.querySelectorAll('.desktop-folder').forEach(f => {
                    const r = f.getBoundingClientRect();
                    const over = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
                    f.style.outline = over ? '2px solid rgba(14,165,233,0.8)' : '';
                });
            };
            
            const onUp = (e) => {
                icon.style.cursor = 'move';
                icon.classList.remove('dragging');
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);

                // Check if dropped on a folder
                const folderTarget = Array.from(document.querySelectorAll('.desktop-folder')).find(f => {
                    const r = f.getBoundingClientRect();
                    return e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
                });
                document.querySelectorAll('.desktop-folder').forEach(f => f.style.outline = '');

                if (folderTarget && isDragging) {
                    folderTarget.dispatchEvent(new CustomEvent('hyos-drop-app', { detail: { appId: iconData.appId } }));
                    isDragging = false;
                    return;
                }
                
                if (isDragging) {
                    const iconIndex = userSettings.desktopIcons.findIndex(i => i.appId === iconData.appId);
                    if (iconIndex !== -1) {
                        userSettings.desktopIcons[iconIndex].x = parseInt(icon.style.left);
                        userSettings.desktopIcons[iconIndex].y = parseInt(icon.style.top);
                        saveSettings();
                    }
                }
                
                isDragging = false;
            };
            
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        
        // Context menu for removal and options
        icon.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            const menu = document.createElement('div');
            menu.className = 'context-menu';
            menu.style.display = 'block';
            menu.style.left = e.clientX + 'px';
            menu.style.top = e.clientY + 'px';

            const folders = userSettings.desktopIcons.filter(i => i.type === 'folder');
            const folderSubmenuItems = folders.length > 0
                ? folders.map(f => {
                    const fi = userSettings.desktopIcons.indexOf(f);
                    return `<div class="context-menu-item" style="padding-left:12px;" onclick="moveAppToFolder('${iconData.appId}',${fi});this.closest('.context-menu').remove();">📁 ${f.name}</div>`;
                  }).join('')
                : `<div class="context-menu-item" style="opacity:.4;cursor:default;padding-left:12px;">No folders yet</div>`;

            menu.innerHTML = `
                <div class="context-menu-item" onclick="
                    const app = installedApps.find(a => a.id === '${iconData.appId}') || cloudApps.find(a => a.id === '${iconData.appId}');
                    if (app) { showInfo('${iconData.appId}', installedApps.find(a => a.id === '${iconData.appId}') ? 'installed' : 'cloud'); }
                    this.parentElement.remove();
                ">📋 Properties</div>
                <div class="context-menu-item folder-submenu-trigger" style="position:relative;">
                    📁 Move to Folder ›
                    <div class="folder-submenu" style="display:none;position:absolute;left:100%;top:-4px;background:rgba(15,23,42,0.98);border:1px solid rgba(255,255,255,0.12);border-radius:10px;min-width:150px;padding:4px;z-index:10000;">
                        ${folderSubmenuItems}
                        <div style="height:1px;background:rgba(255,255,255,0.08);margin:4px 0;"></div>
                        <div class="context-menu-item" style="padding-left:12px;" onclick="createDesktopFolder();this.closest('.context-menu').remove();">＋ New Folder</div>
                    </div>
                </div>
                <div class="context-menu-item" onclick="
                    userSettings.desktopIcons = userSettings.desktopIcons.filter(i => i.appId !== '${iconData.appId}');
                    saveSettings();
                    renderDesktopIcons();
                    this.parentElement.remove();
                ">🗑️ Remove from Desktop</div>
            `;

            menu.querySelector('.folder-submenu-trigger').addEventListener('mouseenter', function() {
                this.querySelector('.folder-submenu').style.display = 'block';
            });
            menu.querySelector('.folder-submenu-trigger').addEventListener('mouseleave', function() {
                this.querySelector('.folder-submenu').style.display = 'none';
            });
            
            document.body.appendChild(menu);
            
            setTimeout(() => {
                const closeMenu = () => {
                    menu.remove();
                    document.removeEventListener('click', closeMenu);
                };
                document.addEventListener('click', closeMenu);
            }, 10);
        });
        
        desktop.appendChild(icon);
    }

    window.addToDesktop = (app) => {
        const existing = userSettings.desktopIcons.find(i => i.appId === app.id);
        if (existing) {
            notify('Already on Desktop', `${app.name} is already on your desktop`);
            return;
        }
        
        const iconData = {
            appId: app.id,
            name: app.name,
            icon: app.icon,
            x: 20 + (userSettings.desktopIcons.length * 100),
            y: 20
        };
        
        userSettings.desktopIcons.push(iconData);
        saveSettings();
        createDesktopIcon(iconData);
        notify('Added to Desktop', `${app.name} has been added to your desktop`);
    };

    // ── FOLDER SYSTEM ─────────────────────────────────────────────────────

    function createFolderIcon(folderData, folderIndex) {
        const desktop = document.getElementById('desktop');
        const icon = document.createElement('div');
        icon.className = 'desktop-icon desktop-folder';
        icon.style.left = folderData.x + 'px';
        icon.style.top = folderData.y + 'px';
        icon.dataset.folderIndex = folderIndex;

        const previewApps = (folderData.apps || []).slice(0, 4);
        const miniIcons = previewApps.map(appId => {
            const app = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
            if (!app) return '<span style="opacity:0.1;">▪</span>';
            return app.icon?.startsWith('data')
                ? `<img src="${app.icon}" style="width:18px;height:18px;border-radius:3px;object-fit:cover;">`
                : `<span style="font-size:15px;line-height:1;">${app.icon}</span>`;
        });
        while (miniIcons.length < 4) miniIcons.push('<span style="opacity:0.1;font-size:15px;">▪</span>');

        icon.innerHTML = `
            <div class="icon-box" style="background:rgba(255,255,255,0.12);backdrop-filter:blur(8px);border:1px solid rgba(255,255,255,0.18);border-radius:16px;display:grid;grid-template-columns:1fr 1fr;gap:3px;padding:7px;align-items:center;justify-items:center;width:56px;height:56px;box-sizing:border-box;">
                ${miniIcons.join('')}
            </div>
            <span>${folderData.name}</span>
        `;

        let clickCount = 0, clickTimeout;
        icon.addEventListener('click', e => {
            e.stopPropagation();
            clickCount++;
            if (clickCount === 1) clickTimeout = setTimeout(() => { clickCount = 0; }, 300);
            else if (clickCount === 2) { clearTimeout(clickTimeout); clickCount = 0; openFolder(folderIndex, parseInt(icon.style.left) + 60, parseInt(icon.style.top)); }
        });

        let isDragging = false, startX, startY, initialX, initialY;
        icon.addEventListener('mousedown', e => {
            if (e.button !== 0) return;
            isDragging = false; startX = e.clientX; startY = e.clientY; initialX = icon.offsetLeft; initialY = icon.offsetTop;
            icon.style.cursor = 'grabbing';
            const onMove = e => {
                const dx = e.clientX - startX, dy = e.clientY - startY;
                if (!isDragging && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) { isDragging = true; icon.classList.add('dragging'); }
                if (!isDragging) return;
                let nx = Math.max(0, Math.min(initialX + dx, desktop.offsetWidth - icon.offsetWidth));
                let ny = Math.max(0, Math.min(initialY + dy, desktop.offsetHeight - icon.offsetHeight - 60));
                if (userSettings.snapToGrid) { nx = Math.round(nx / 100) * 100; ny = Math.round(ny / 100) * 100; }
                icon.style.left = nx + 'px'; icon.style.top = ny + 'px';
            };
            const onUp = () => {
                icon.style.cursor = 'move'; icon.classList.remove('dragging');
                document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp);
                if (isDragging) { userSettings.desktopIcons[folderIndex].x = parseInt(icon.style.left); userSettings.desktopIcons[folderIndex].y = parseInt(icon.style.top); saveSettings(); }
                isDragging = false;
            };
            document.addEventListener('mousemove', onMove); document.addEventListener('mouseup', onUp);
        });

        icon.addEventListener('hyos-drop-app', e => {
            const appId = e.detail.appId;
            if (!folderData.apps) folderData.apps = [];
            if (!folderData.apps.includes(appId)) {
                folderData.apps.push(appId);
                userSettings.desktopIcons = userSettings.desktopIcons.filter(i => i.appId !== appId);
                saveSettings(); renderDesktopIcons();
                notify('📁 Moved to Folder', `App added to "${folderData.name}"`);
            }
        });

        icon.addEventListener('contextmenu', e => {
            e.preventDefault(); e.stopPropagation();
            const menu = document.createElement('div');
            menu.className = 'context-menu';
            menu.style.cssText = `display:block;left:${e.clientX}px;top:${e.clientY}px;`;
            menu.innerHTML = `
                <div class="context-menu-item" onclick="openFolder(${folderIndex},${e.clientX},${e.clientY});this.parentElement.remove();">📂 Open</div>
                <div class="context-menu-item" onclick="renameFolder(${folderIndex});this.parentElement.remove();">✏️ Rename</div>
                <div class="context-menu-item" onclick="deleteFolder(${folderIndex});this.parentElement.remove();" style="color:rgba(255,100,100,0.8);">🗑️ Delete Folder</div>
            `;
            document.body.appendChild(menu);
            setTimeout(() => { const c = () => { menu.remove(); document.removeEventListener('click', c); }; document.addEventListener('click', c); }, 10);
        });

        desktop.appendChild(icon);
    }

    window.openFolder = function(folderIndex, x, y) {
        document.getElementById('folder-popup')?.remove();
        const folderData = userSettings.desktopIcons[folderIndex];
        if (!folderData) return;
        const apps = (folderData.apps || []).map(id => installedApps.find(a => a.id === id) || cloudApps.find(a => a.id === id)).filter(Boolean);

        const popup = document.createElement('div');
        popup.id = 'folder-popup';
        const px = Math.min(x || 200, window.innerWidth - 320);
        const py = Math.max((y || 300) - 220, 60);
        popup.style.cssText = `position:fixed;left:${px}px;top:${py}px;width:290px;background:rgba(10,18,35,0.97);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,0.13);border-radius:22px;padding:18px;z-index:9999;box-shadow:0 24px 70px rgba(0,0,0,0.6);`;

        popup.innerHTML = `
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                <div style="font-size:14px;font-weight:700;color:white;">📁 ${folderData.name}</div>
                <div style="display:flex;gap:6px;">
                    <button onclick="renameFolder(${folderIndex});document.getElementById('folder-popup').remove();" style="background:rgba(255,255,255,0.07);border:none;color:rgba(255,255,255,0.5);padding:4px 8px;border-radius:8px;cursor:pointer;font-size:11px;">Rename</button>
                    <button onclick="document.getElementById('folder-popup').remove()" style="background:rgba(255,255,255,0.07);border:none;color:rgba(255,255,255,0.5);width:26px;height:26px;border-radius:50%;cursor:pointer;font-size:13px;">✕</button>
                </div>
            </div>
            <div id="folder-popup-grid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;min-height:64px;"></div>
            ${apps.length === 0 ? '<div style="text-align:center;opacity:.35;font-size:12px;padding:16px 0;">Folder is empty<br><span style="font-size:10px;">Drag apps here from the desktop</span></div>' : ''}
        `;

        const grid = popup.querySelector('#folder-popup-grid');
        apps.forEach(app => {
            const item = document.createElement('div');
            item.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;padding:7px 4px;border-radius:12px;transition:.15s;';
            item.onmouseover = () => item.style.background = 'rgba(255,255,255,0.08)';
            item.onmouseout = () => item.style.background = '';
            const isImg = app.icon?.startsWith('data');
            item.innerHTML = `
                <div style="width:46px;height:46px;border-radius:13px;background:rgba(255,255,255,0.07);display:flex;align-items:center;justify-content:center;font-size:28px;overflow:hidden;">
                    ${isImg ? `<img src="${app.icon}" style="width:100%;height:100%;object-fit:cover;">` : app.icon}
                </div>
                <span style="font-size:10px;color:rgba(255,255,255,0.65);text-align:center;line-height:1.2;word-break:break-word;max-width:54px;">${app.name}</span>
            `;
            let clicks = 0, ct;
            item.addEventListener('click', () => {
                clicks++;
                if (clicks === 1) ct = setTimeout(() => { clicks = 0; }, 300);
                else if (clicks === 2) { clearTimeout(ct); clicks = 0; launchApp(app); popup.remove(); }
            });
            item.addEventListener('contextmenu', e => {
                e.preventDefault(); e.stopPropagation();
                const m = document.createElement('div');
                m.className = 'context-menu';
                m.style.cssText = `display:block;left:${e.clientX}px;top:${e.clientY}px;`;
                m.innerHTML = `<div class="context-menu-item" onclick="removeFromFolder(${folderIndex},'${app.id}');this.parentElement.remove();">📤 Remove from Folder</div>`;
                document.body.appendChild(m);
                setTimeout(() => { const c = () => { m.remove(); document.removeEventListener('click', c); }; document.addEventListener('click', c); }, 10);
            });
            grid.appendChild(item);
        });

        document.body.appendChild(popup);
        setTimeout(() => {
            const close = e => { if (!popup.contains(e.target)) { popup.remove(); document.removeEventListener('click', close); } };
            document.addEventListener('click', close);
        }, 10);
    };

    window.renameFolder = function(folderIndex) {
        const folder = userSettings.desktopIcons[folderIndex];
        if (!folder) return;
        const name = prompt('Folder name:', folder.name);
        if (name?.trim()) { folder.name = name.trim(); saveSettings(); renderDesktopIcons(); }
    };

    window.deleteFolder = function(folderIndex) {
        const folder = userSettings.desktopIcons[folderIndex];
        if (!folder) return;
        if (!confirm(`Delete "${folder.name}"?\nApps inside will be moved back to the desktop.`)) return;
        (folder.apps || []).forEach((appId, i) => {
            const app = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
            if (app) userSettings.desktopIcons.push({ appId, name: app.name, icon: app.icon, x: folder.x + i * 90, y: folder.y + 90 });
        });
        userSettings.desktopIcons.splice(folderIndex, 1);
        saveSettings(); renderDesktopIcons();
    };

    window.removeFromFolder = function(folderIndex, appId) {
        const folder = userSettings.desktopIcons[folderIndex];
        if (!folder) return;
        folder.apps = (folder.apps || []).filter(id => id !== appId);
        const app = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
        if (app) userSettings.desktopIcons.push({ appId, name: app.name, icon: app.icon, x: folder.x + 90, y: folder.y });
        saveSettings(); renderDesktopIcons();
        document.getElementById('folder-popup')?.remove();
    };

    window.moveAppToFolder = function(appId, folderIndex) {
        const folder = userSettings.desktopIcons[folderIndex];
        if (!folder || folder.type !== 'folder') return;
        if (!folder.apps) folder.apps = [];
        if (!folder.apps.includes(appId)) folder.apps.push(appId);
        userSettings.desktopIcons = userSettings.desktopIcons.filter(i => i.appId !== appId);
        saveSettings(); renderDesktopIcons();
        notify('📁 Moved', `App moved to "${folder.name}"`);
    };

    window.createDesktopFolder = function(x, y) {
        const name = prompt('Folder name:', 'New Folder');
        if (!name?.trim()) return;
        const count = userSettings.desktopIcons.filter(i => i.type === 'folder').length;
        const folderData = { type: 'folder', name: name.trim(), apps: [], x: x || 20 + count * 110, y: y || 20 };
        userSettings.desktopIcons.push(folderData);
        saveSettings(); renderDesktopIcons();
        notify('📁 Folder Created', `"${folderData.name}" added to desktop`);
    };

    // Desktop context menu
    let contextMenuTimeout;
    document.getElementById('desktop').addEventListener('contextmenu', (e) => {
        if (e.target.id === 'desktop') {
            e.preventDefault();
            showContextMenu(e.clientX, e.clientY);
        }
    });

    document.getElementById('desktop').addEventListener('mousedown', (e) => {
        if (e.target.id === 'desktop' && e.button === 0) {
            contextMenuTimeout = setTimeout(() => {
                showContextMenu(e.clientX, e.clientY);
            }, 500);
        }
    });

    document.getElementById('desktop').addEventListener('mouseup', () => {
        clearTimeout(contextMenuTimeout);
    });

    // Touch long-press for desktop context menu (mobile)
    let touchLongPressTimer;
    let touchMoved = false;
    document.getElementById('desktop').addEventListener('touchstart', (e) => {
        if (e.target.id === 'desktop' || e.target.id === 'widgets-overlay') {
            touchMoved = false;
            const touch = e.touches[0];
            touchLongPressTimer = setTimeout(() => {
                if (!touchMoved) {
                    e.preventDefault();
                    showContextMenu(touch.clientX, touch.clientY);
                }
            }, 600);
        }
    }, { passive: false });
    document.getElementById('desktop').addEventListener('touchmove', () => {
        touchMoved = true;
        clearTimeout(touchLongPressTimer);
    });
    document.getElementById('desktop').addEventListener('touchend', () => {
        clearTimeout(touchLongPressTimer);
    });

    function showContextMenu(x, y) {
        const menu = document.getElementById('context-menu');
        if (!document.getElementById('ctx-new-folder')) {
            const item = document.createElement('div');
            item.id = 'ctx-new-folder';
            item.className = 'context-menu-item';
            item.innerHTML = '📁 New Folder';
            item.addEventListener('click', () => { createDesktopFolder(menu._ctxX, menu._ctxY); hideContextMenu(); });
            menu.insertBefore(item, menu.children[1]);
        }
        menu._ctxX = x; menu._ctxY = y;
        menu.style.display = 'block';
        menu.style.left = x + 'px';
        menu.style.top = y + 'px';
    }

    window.hideContextMenu = () => {
        document.getElementById('context-menu').style.display = 'none';
    };

    document.addEventListener('click', (e) => {
        if (!e.target.closest('#context-menu') && !e.target.closest('#desktop')) {
            hideContextMenu();
        }
    });

    window.openDesktopSettings = () => {
        document.getElementById('desktop-settings-panel').style.display = 'block';
        hideContextMenu();
    };

    window.closeDesktopSettings = () => {
        document.getElementById('desktop-settings-panel').style.display = 'none';
    };

    window.updateIconSize = (size) => {
        const icons = document.querySelectorAll('.desktop-icon');
        icons.forEach(icon => {
            const box = icon.querySelector('.icon-box');
            if (size === 'small') {
                box.style.width = '48px';
                box.style.height = '48px';
            } else if (size === 'medium') {
                box.style.width = '64px';
                box.style.height = '64px';
            } else {
                box.style.width = '80px';
                box.style.height = '80px';
            }
        });
    };

    window.toggleDesktopSnap = (toggle) => {
        toggle.classList.toggle('active');
        userSettings.snapToGrid = toggle.classList.contains('active');
        saveSettings();
    };

    window.clearDesktop = () => {
        if (confirm('Remove all desktop icons?')) {
            userSettings.desktopIcons = [];
            saveSettings();
            renderDesktopIcons();
        }
    };

    window.resetDesktop = () => {
        if (confirm('Reset desktop to default layout?')) {
            userSettings.desktopIcons = [];
            saveSettings();
            renderDesktopIcons();
        }
    };

    // Settings functions
    window.switchSettingsTab = (tab) => {
        document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
        document.getElementById(`tab-${tab}`).classList.add('active');
        
        document.querySelectorAll('.settings-panel').forEach(p => p.style.display = 'none');
        document.getElementById(`settings-${tab}`).style.display = 'block';
        
        // Refresh account tab info
        if (tab === 'account') {
            const label = document.getElementById('default-user-label');
            if (label) {
                label.textContent = userSettings.defaultUser
                    ? `Default user: ${userSettings.defaultUser}. Lock screen will only ask for password.`
                    : 'No default user set. When set, the lock screen will only ask for your password.';
            }
        }
        // Sync theme engine toggle
        if (tab === 'personalization') {
            const tog = document.getElementById('theme-engine-toggle');
            if (tog) tog.classList.toggle('active', !!userSettings.themeEngineEnabled);
        }
    };

    window.toggleSetting = (setting, toggle) => {
        toggle.classList.toggle('active');
        userSettings[setting] = toggle.classList.contains('active');
        saveSettings();
        
        // Apply side effects
        if (setting === 'showDesktopIcons') {
            renderDesktopIcons();
        } else if (setting === 'darkMode') {
            document.body.style.background = userSettings.darkMode ? '' : '#f1f5f9';
        } else if (setting === 'enableAnimations') {
            document.documentElement.style.setProperty('--anim-duration', userSettings.enableAnimations ? '0.25s' : '0s');
        } else if (setting === 'enableBlur') {
            document.querySelectorAll('.taskbar, #start-menu, #control-center, .window').forEach(el => {
                el.style.backdropFilter = userSettings.enableBlur ? '' : 'none';
            });
        } else if (setting === 'enableTransparency') {
            const taskbar = document.querySelector('.taskbar');
            if (taskbar) taskbar.style.background = userSettings.enableTransparency ? '' : 'rgba(15,23,42,1)';
        } else if (setting === 'enableShadows') {
            document.querySelectorAll('.window').forEach(el => {
                el.style.boxShadow = userSettings.enableShadows ? '' : 'none';
            });
        } else if (setting === 'autoHideTaskbar') {
            const taskbar = document.querySelector('.taskbar');
            if (taskbar) {
                if (userSettings.autoHideTaskbar) {
                    taskbar.style.transition = 'transform 0.3s';
                    const hide = () => { taskbar.style.transform = 'translateY(100%)'; };
                    const show = () => { taskbar.style.transform = ''; };
                    document.addEventListener('mousemove', (e) => {
                        if (e.clientY > window.innerHeight - 80) show(); else hide();
                    });
                } else {
                    taskbar.style.transform = '';
                }
            }
        } else if (setting === 'showClock') {
            const clock = document.querySelector('.status-clock') || document.getElementById('taskbar-clock');
            if (clock) clock.style.display = userSettings.showClock ? '' : 'none';
        } else if (setting === 'muteAll') {
            sounds.enabled = !userSettings.muteAll;
        } else if (setting === 'notifications' || setting === 'enableNotifications') {
            userSettings.notifications = userSettings[setting];
            userSettings.enableNotifications = userSettings[setting];
        } else if (setting === 'doNotDisturb') {
            notify('Do Not Disturb', userSettings.doNotDisturb ? 'Enabled — notifications silenced' : 'Disabled');
        } else if (setting === 'autoLock') {
            if (typeof _autoLock !== 'undefined') {
                userSettings.autoLock ? _autoLock.setup() : _autoLock.clear();
            }
        } else if (setting === 'stayLoggedIn') {
            if (!userSettings.stayLoggedIn) {
                localStorage.removeItem('hyos_user');
                localStorage.removeItem('hyos_user_id');
            } else if (user) {
                localStorage.setItem('hyos_user', user);
            }
        }
        
        notify('Settings', `${setting.replace(/([A-Z])/g, ' $1').toLowerCase()} ${userSettings[setting] ? 'enabled' : 'disabled'}`);
    };

    window.setAccentColor = (color, elem) => {
        document.querySelectorAll('.color-option').forEach(c => c.classList.remove('active'));
        elem.classList.add('active');
        userSettings.accentColor = color;
        document.documentElement.style.setProperty('--blue-600', color);
        saveSettings();
    };

    window.updateGenre = (genre) => {
        userSettings.selectedGenre = genre;
        document.getElementById('account-genre').textContent = genre;
        saveSettings();
    };

    window.changeProfilePic = () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    userSettings.profilePic = ev.target.result;
                    saveSettings();
                    notify('Profile Updated', 'Profile picture changed successfully');
                };
                reader.readAsDataURL(file);
            }
        };
        input.click();
    };

    window.updateDesktopIconSize = (size) => {
        updateIconSize(size);
    };

    // ============================================================
    // APP ICON CHANGING
    // ============================================================
    window.changeAppIcon = function(appId, mode) {
        if (user === 'Guest') { notify('Permission Denied', 'Guests cannot change app icons.'); return; }
        const app = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
        if (!app) return;
        
        // Create icon change dialog
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(8px);';
        overlay.innerHTML = `
            <div style="background:rgba(10,15,30,0.99);border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:28px;width:360px;max-width:90vw;">
                <div style="font-size:16px;font-weight:700;margin-bottom:6px;">Change Icon for "${app.name}"</div>
                <div style="font-size:12px;opacity:0.5;margin-bottom:20px;">Enter an emoji or upload an image</div>
                
                <div style="display:flex;gap:10px;align-items:center;margin-bottom:16px;">
                    <div id="icon-preview" style="width:64px;height:64px;border-radius:14px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);display:flex;align-items:center;justify-content:center;font-size:36px;flex-shrink:0;">
                        ${app.icon?.startsWith('data') ? `<img src="${app.icon}" style="width:100%;height:100%;object-fit:cover;border-radius:12px;">` : app.icon || '📱'}
                    </div>
                    <div style="flex:1;">
                        <input id="icon-emoji-input" placeholder="Emoji (e.g. 🚀)" value="${app.icon?.startsWith('data') ? '' : (app.icon || '')}" style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px 12px;border-radius:10px;color:white;font-size:18px;margin-bottom:8px;outline:none;" oninput="document.getElementById('icon-preview').innerHTML=this.value||'📱'">
                        <button onclick="document.getElementById('icon-img-upload').click()" style="width:100%;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:8px;color:white;cursor:pointer;font-size:12px;">📁 Upload Image</button>
                        <input id="icon-img-upload" type="file" accept="image/*" style="display:none;" onchange="
                            const f=this.files[0];if(!f)return;
                            const r=new FileReader();
                            r.onload=(ev)=>{
                                document.getElementById('icon-preview').innerHTML='<img src=\\''+ev.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;border-radius:12px;\\'>';
                                document.getElementById('icon-emoji-input').dataset.imgData=ev.target.result;
                                document.getElementById('icon-emoji-input').value='';
                            };
                            r.readAsDataURL(f);
                        ">
                    </div>
                </div>
                
                <div style="display:flex;gap:10px;">
                    <button onclick="this.closest('div[style]').remove()" style="flex:1;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:12px;color:white;cursor:pointer;font-weight:600;">Cancel</button>
                    <button onclick="
                        const input=document.getElementById('icon-emoji-input');
                        const imgData=input.dataset.imgData;
                        const newIcon=imgData||input.value.trim()||'📱';
                        applyAppIcon('${appId}','${mode}',newIcon);
                        this.closest('div[style*=position]').remove();
                    " style="flex:1;background:var(--blue-600,#2563eb);border:none;border-radius:12px;padding:12px;color:white;cursor:pointer;font-weight:700;">Apply</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
        setTimeout(() => document.getElementById('icon-emoji-input').focus(), 50);
    };

    window.applyAppIcon = function(appId, mode, newIcon) {
        // Update in installedApps
        const localApp = installedApps.find(a => a.id === appId);
        if (localApp) {
            localApp.icon = newIcon;
            localStorage.setItem('hyos_installed_apps', JSON.stringify(installedApps));
        }
        // Update in cloudApps
        const cloudApp = cloudApps.find(a => a.id === appId);
        if (cloudApp) cloudApp.icon = newIcon;
        
        // Update desktop icons
        userSettings.desktopIcons.forEach(di => {
            if (di.appId === appId) di.icon = newIcon;
        });
        saveSettings();
        renderDesktopIcons();
        
        // Re-render app drawer
        setDrawerMode(mode === 'cloud' ? 'store' : 'installed');
        
        notify('Icon Changed', 'App icon updated successfully!');
    };

    window.showAppIconMenu = function(e, appId, mode) {
        // Remove any existing menus
        document.querySelectorAll('.app-icon-ctx-menu').forEach(m => m.remove());
        
        const menu = document.createElement('div');
        menu.className = 'context-menu app-icon-ctx-menu';
        menu.style.cssText = `display:block;left:${Math.min(e.clientX, window.innerWidth-160)}px;top:${Math.min(e.clientY, window.innerHeight-100)}px;`;
        menu.innerHTML = `
            ${user !== 'Guest' ? `<div class="context-menu-item" onclick="changeAppIcon('${appId}','${mode}');this.parentElement.remove()">🎨 Change Icon</div>` : ''}
            <div class="context-menu-item" onclick="showInfo('${appId}','${mode}');this.parentElement.remove()">📋 Properties</div>
        `;
        document.body.appendChild(menu);
        setTimeout(() => {
            const close = () => { menu.remove(); document.removeEventListener('click', close); };
            document.addEventListener('click', close);
        }, 10);
    };

    window.clearLoginData = () => {
        if (confirm('This will log you out and clear all login data. Continue?')) {
            localStorage.removeItem('hyos_user');
            localStorage.removeItem('hyos_settings');
            location.reload();
        }
    };

    window.setDefaultUser = () => {
        if (!user || user === 'Guest') {
            notify('Error', 'You must be logged in with a real account to set a default user');
            return;
        }
        userSettings.defaultUser = user;
        userSettings.defaultUserId = localStorage.getItem('hyos_user_id') || user.toLowerCase();
        saveSettings();
        const label = document.getElementById('default-user-label');
        if (label) label.textContent = `Default user: ${user}. Lock screen will only ask for password.`;
        notify('Default User Set', `${user} will be the default user on the lock screen`);
    };

    window.clearDefaultUser = () => {
        userSettings.defaultUser = null;
        userSettings.defaultUserId = null;
        saveSettings();
        const label = document.getElementById('default-user-label');
        if (label) label.textContent = 'No default user set. When set, the lock screen will only ask for your password.';
        notify('Default User Cleared', 'Lock screen will show full login form');
    };

    // Utility functions for new settings
    window.updateTaskbarPosition = (position) => {
        userSettings.taskbarPosition = position;
        saveSettings();
        // TODO: Apply taskbar position
    };

    window.updateTaskbarSize = (size) => {
        userSettings.taskbarSize = size;
        const taskbar = document.querySelector('.taskbar');
        if (size === 'small') taskbar.style.height = '50px';
        else if (size === 'medium') taskbar.style.height = '60px';
        else taskbar.style.height = '70px';
        saveSettings();
    };

    window.updateSlider = (event, setting) => {
        const slider = event.currentTarget;
        const rect = slider.getBoundingClientRect();
        const percent = Math.min(100, Math.max(0, ((event.clientX - rect.left) / rect.width) * 100));
        const fill = slider.querySelector('.settings-slider-fill');
        fill.style.width = percent + '%';
        
        // Update value display
        if (setting === 'taskbarOpacity') {
            userSettings.taskbarOpacity = Math.round(percent);
        } else if (setting === 'maxConcurrentApps') {
            userSettings.maxConcurrentApps = Math.max(1, Math.round((percent / 100) * 20));
            document.getElementById('max-apps-value').textContent = userSettings.maxConcurrentApps;
        } else if (setting === 'masterVolume') {
            userSettings.masterVolume = Math.round(percent);
            document.getElementById('master-volume-value').textContent = Math.round(percent) + '%';
        } else if (setting === 'systemVolume') {
            userSettings.systemVolume = Math.round(percent);
            document.getElementById('system-volume-value').textContent = Math.round(percent) + '%';
        } else if (setting === 'notifVolume') {
            userSettings.notifVolume = Math.round(percent);
            document.getElementById('notif-volume-value').textContent = Math.round(percent) + '%';
        }
        
        saveSettings();
    };

    window.updatePerformanceMode = (mode) => {
        userSettings.performanceMode = mode;
        saveSettings();
        
        // Apply performance mode
        if (mode === 'performance') {
            userSettings.enableAnimations = true;
            userSettings.enableTransparency = true;
            userSettings.enableBlur = true;
            userSettings.enableShadows = true;
        } else if (mode === 'power-saver') {
            userSettings.enableAnimations = false;
            userSettings.enableTransparency = false;
            userSettings.enableBlur = false;
            userSettings.enableShadows = false;
        }
    };

    window.updateNotifDuration = (duration) => {
        userSettings.notifDuration = parseInt(duration);
        saveSettings();
    };

    window.clearAppData = () => {
        if (confirm('Clear all app cache data?')) {
            notify('Cache Cleared', 'App cache has been cleared');
        }
    };

    window.clearBrowsingData = () => {
        if (confirm('Clear all browsing data?')) {
            notify('Data Cleared', 'Browsing data has been cleared');
        }
    };

    window.exportUserData = () => {
        const data = {
            settings: userSettings,
            apps: installedApps.map(a => ({ name: a.name, id: a.id })),
            user: user
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'hyos_data_export.json';
        a.click();
        notify('Export Complete', 'Your data has been exported');
    };

    window.clearCache = () => {
        if (confirm('Clear system cache?')) {
            notify('Cache Cleared', 'System cache has been cleared');
        }
    };

    window.clearAllData = () => {
        if (confirm('This will delete ALL local data including apps and settings. Continue?')) {
            localStorage.clear();
            location.reload();
        }
    };

    window.checkForUpdates = () => {
        notify('Update Check', 'Checking for updates...');
        setTimeout(() => {
            notify('Up to Date', 'You are running the latest version');
        }, 2000);
    };

    // Calculate storage usage
    function calculateStorage() {
        try {
            let total = 0;
            for (let key in localStorage) {
                if (localStorage.hasOwnProperty(key)) {
                    total += localStorage[key].length + key.length;
                }
            }
            
            const kb = (total / 1024).toFixed(2);
            const percent = Math.min(100, (total / (5 * 1024 * 1024)) * 100); // 5MB limit estimate
            
            document.getElementById('storage-used').textContent = kb + ' KB';
            document.getElementById('storage-bar').style.width = percent + '%';
            document.getElementById('apps-storage').textContent = (kb * 0.6).toFixed(2) + ' KB';
            document.getElementById('settings-storage').textContent = (kb * 0.3).toFixed(2) + ' KB';
            document.getElementById('cache-storage').textContent = (kb * 0.1).toFixed(2) + ' KB';
        } catch (e) {
            document.getElementById('storage-used').textContent = 'Unable to calculate';
        }
    }

    // Call calculateStorage when opening storage settings
    const originalSwitchTab = window.switchSettingsTab;
    window.switchSettingsTab = (tab) => {
        originalSwitchTab(tab);
        if (tab === 'storage') {
            calculateStorage();
        }
    };

    // App drawer functions
    window.setDrawerMode = (mode) => {
        const tabs = { inst: 'installed', store: 'store', my: 'my', date: 'date', user: 'user' };
        Object.entries(tabs).forEach(([k, v]) => {
            const el = document.getElementById('btn-' + k);
            if (el) el.className = mode === v ? "text-xs font-bold border-b-2 border-blue-500 pb-1" : "text-xs font-bold opacity-50 pb-1";
        });
        
        const grid = document.getElementById('drawer-grid');

        // ── DATE SORT ───────────────────────────────────────────────────
        if (mode === 'date') {
            const all = [...cloudApps].sort((a, b) => {
                const ta = a.publishedAt?.seconds || a.publishedAt || a.updatedAt || a.createdAt || 0;
                const tb = b.publishedAt?.seconds || b.publishedAt || b.updatedAt || b.createdAt || 0;
                // Firestore Timestamp objects have .seconds; ISO strings can be compared directly
                const va = typeof ta === 'object' ? ta.seconds : new Date(ta).getTime() / 1000;
                const vb = typeof tb === 'object' ? tb.seconds : new Date(tb).getTime() / 1000;
                return vb - va;
            });
            if (all.length === 0) {
                grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:60px;opacity:0.4;font-size:14px;">No store apps yet.</div>`;
                return;
            }
            grid.innerHTML = all.map(app => {
                const isImg = app.icon?.startsWith('data');
                const ts = app.publishedAt?.seconds ? new Date(app.publishedAt.seconds * 1000) :
                           app.updatedAt ? new Date(app.updatedAt) :
                           app.createdAt ? new Date(app.createdAt) : null;
                const timeStr = ts ? ts.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Unknown date';
                const hasPreview = app.previewImage;
                return `
                    <div class="app-card" onclick="showInfo('${app.id}', 'cloud')" style="position:relative;padding:0;overflow:hidden;border-radius:14px;">
                        ${hasPreview ? `<div style="width:100%;height:72px;overflow:hidden;"><img src="${app.previewImage}" style="width:100%;height:100%;object-fit:cover;"></div>` : `<div style="width:100%;height:72px;background:linear-gradient(135deg,#0f172a,#1e293b);display:flex;align-items:center;justify-content:center;font-size:28px;">${isImg ? `<img src="${app.icon}" style="height:40px;width:40px;object-fit:cover;border-radius:8px;">` : app.icon}</div>`}
                        <div style="padding:10px;">
                            <div class="font-bold text-xs mb-1">${app.name}</div>
                            <div style="font-size:9px;opacity:0.4;">🕒 ${timeStr}</div>
                            ${app.genre ? `<div class="text-[9px] opacity-30 mt-1">${app.genre}</div>` : ''}
                        </div>
                    </div>
                `;
            }).join('');
            return;
        }
        
        if (mode === 'user') {
            // Show User tab with Publish button
            grid.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; gap: 24px; padding: 40px;">
                    <div style="text-align: center;">
                        <div style="font-size: 64px; margin-bottom: 16px;">👤</div>
                        <h2 style="font-size: 24px; font-weight: bold; margin-bottom: 8px;">${user}</h2>
                        <p style="font-size: 14px; opacity: 0.6;">HyOS Developer Account</p>
                    </div>
                    <button onclick="publishHyHToStore()" style="background: #2563eb; border: none; color: #fff; padding: 16px 32px; border-radius: 12px; cursor: pointer; font-size: 16px; font-weight: 700; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);">
                        📤 Publish HyH to Store
                    </button>
                    <div style="font-size: 13px; opacity: 0.5; max-width: 400px; text-align: center;">
                        Export your app as a HyH file from App Builder (saves to HyFiles/Downloads), then use this button to pick it from HyFiles and publish it to the global store.
                    </div>
                </div>
            `;
            return;
        }
        
        if (mode === 'store') {
            // Show store apps with like/dislike
            const apps = cloudApps;
            
            if (apps.length === 0) {
                grid.innerHTML = `
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; gap: 16px; padding: 40px;">
                        <div style="font-size: 64px; opacity: 0.3;">🛒</div>
                        <h3 style="font-size: 18px; font-weight: bold; opacity: 0.5;">No apps in store yet</h3>
                        <p style="font-size: 13px; opacity: 0.4;">Check back later or publish your own app!</p>
                    </div>
                `;
                return;
            }
            
            grid.innerHTML = apps.map(app => {
                const isImg = app.icon?.startsWith('data');
                const matchesGenre = !userSettings.selectedGenre || app.genre === userSettings.selectedGenre;
                const likes = app.likes || 0;
                const dislikes = app.dislikes || 0;
                const userLiked = app.likedBy?.includes(user);
                const userDisliked = app.dislikedBy?.includes(user);
                const ageStatus = window.getAppAgeStatus ? window.getAppAgeStatus(app) : 'ok';
                const ageLabel = ageStatus === 'inaccessible' ? '🔒' : (app.ageLimit && parseInt(app.ageLimit) > 0) ? `${app.ageLimit}+` : '';
                const ageCardStyle = ageStatus === 'inaccessible' ? 'opacity:0.45;filter:grayscale(0.6);' : ageStatus === 'age-blocked' ? 'opacity:0.45;filter:grayscale(0.4);' : '';
                
                return `
                    <div class="app-card ${matchesGenre ? 'border-blue-600/30' : ''}" onclick="showInfo('${app.id}', 'cloud')" style="${ageCardStyle}padding:0;overflow:hidden;border-radius:14px;">
                        ${app.previewImage
                            ? `<div style="width:100%;height:68px;overflow:hidden;"><img src="${app.previewImage}" style="width:100%;height:100%;object-fit:cover;"></div>`
                            : `<div style="width:100%;height:68px;background:linear-gradient(135deg,#0f172a,#1e293b);display:flex;align-items:center;justify-content:center;">${isImg ? `<img src="${app.icon}" style="height:36px;width:36px;object-fit:cover;border-radius:8px;">` : `<span style="font-size:26px;">${app.icon}</span>`}</div>`
                        }
                        <div style="padding:10px;">
                            <div class="icon-box" style="display:none;">${isImg ? `<img src="${app.icon}">` : `<span class="text-3xl">${app.icon}</span>`}</div>
                            <div class="font-bold text-xs mb-1">${app.name}</div>
                            ${app.genre ? `<div class="text-[10px] opacity-40">${app.genre}</div>` : ''}
                            ${ageLabel ? `<div style="font-size:9px;font-weight:700;background:${ageStatus==='inaccessible'?'rgba(148,163,184,0.15)':ageStatus==='age-blocked'?'rgba(239,68,68,0.15)':'rgba(34,197,94,0.15)'};color:${ageStatus==='inaccessible'?'#94a3b8':ageStatus==='age-blocked'?'#ef4444':'#22c55e'};border-radius:5px;padding:2px 6px;margin-top:4px;display:inline-block;">${ageStatus==='inaccessible'?'🔒 Inaccessible':ageStatus==='age-blocked'?`🔞 ${app.ageLimit}+`:ageLabel}</div>` : ''}
                            <div style="display: flex; gap: 8px; justify-content: center; margin-top: 8px;">
                                <button onclick="event.stopPropagation(); likeApp('${app.id}')" style="background: ${userLiked ? '#16a34a' : 'rgba(255,255,255,0.1)'}; border: none; color: #fff; padding: 4px 8px; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600;">👍 ${likes}</button>
                                <button onclick="event.stopPropagation(); dislikeApp('${app.id}')" style="background: ${userDisliked ? '#dc2626' : 'rgba(255,255,255,0.1)'}; border: none; color: #fff; padding: 4px 8px; border-radius: 6px; cursor: pointer; font-size: 11px; font-weight: 600;">👎 ${dislikes}</button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            return;
        }
        
        // Installed or My Creations - no like/dislike buttons
        const apps = mode === 'installed' ? installedApps : cloudApps.filter(a => a.creator === user);
        
        // Built-in system apps for installed tab
        const systemBuiltins = mode === 'installed' ? [
            { id: 'sys-weather', name: 'Weather', icon: '🌤️', desc: 'Live forecast', isSystem: true, action: "openWeatherApp()" },
            { id: 'sys-music', name: 'Music', icon: '🎵', desc: 'Local music player', isSystem: true, action: "openMusicApp()" },
            { id: 'sys-camera', name: 'Camera', icon: '📷', desc: 'Take photos & record video', isSystem: true, action: "openCameraApp()" },
            { id: 'sys-calculator', name: 'Calculator', icon: '🧮', desc: 'Basic & scientific', isSystem: true, action: 'openCalculator()' },
            { id: 'sys-terminal', name: 'Terminal', icon: '⌨️', desc: 'Command line', isSystem: true, action: 'openTerminal()' },
            { id: 'sys-hyvm', name: 'HyVM', icon: '🖥️', desc: 'Virtual machine', isSystem: true, action: 'openHyVM()' },
            { id: 'sys-media', name: 'Media Library', icon: '📸', desc: 'Screenshots & recordings', isSystem: true, action: 'openMediaViewer()' },
            { id: 'sys-hyfiles', name: 'HyFiles', icon: '📁', desc: 'File manager', isSystem: true, action: "toggleApp('hyfiles-win')" },
            { id: 'sys-notepad', name: 'Notepad', icon: '📝', desc: 'Text editor', isSystem: true, action: 'Notepad.newFile()' },
            { id: 'sys-maker', name: 'App Maker', icon: '🛠️', desc: 'Build apps', isSystem: true, action: 'openMaker()' },
        ] : [];

        grid.innerHTML = [
            ...systemBuiltins.map(app => `
                <div class="app-card" onclick="${app.action}" style="border: 1px solid rgba(37,99,235,0.15); position:relative;">
                    <div style="position:absolute;top:8px;right:8px;font-size:9px;background:rgba(37,99,235,0.2);border:1px solid rgba(37,99,235,0.3);color:#93c5fd;padding:1px 5px;border-radius:4px;font-weight:700;">BUILT-IN</div>
                    <div class="icon-box"><span class="text-3xl">${app.icon}</span></div>
                    <div class="font-bold text-xs mb-1">${app.name}</div>
                    <div class="text-[10px] opacity-40">${app.desc}</div>
                </div>
            `),
            ...apps.map(app => {
                const isImg = app.icon?.startsWith('data');
                const ageStatus = window.getAppAgeStatus ? window.getAppAgeStatus(app) : 'ok';
                const ageCardStyle = ageStatus === 'inaccessible' ? 'opacity:0.45;filter:grayscale(0.5);' : ageStatus === 'age-blocked' ? 'opacity:0.45;filter:grayscale(0.4);' : '';
                const ageBadge = ageStatus === 'inaccessible' ? `<div style="font-size:9px;font-weight:700;background:rgba(148,163,184,0.15);color:#94a3b8;border-radius:5px;padding:2px 6px;margin-top:4px;display:inline-block;">🔒 Inaccessible</div>` :
                    (app.ageLimit && parseInt(app.ageLimit) > 0) ? `<div style="font-size:9px;font-weight:700;background:${ageStatus==='age-blocked'?'rgba(239,68,68,0.15)':'rgba(34,197,94,0.12)'};color:${ageStatus==='age-blocked'?'#ef4444':'#22c55e'};border-radius:5px;padding:2px 6px;margin-top:4px;display:inline-block;">${ageStatus==='age-blocked'?'🔞':'✅'} ${app.ageLimit}+</div>` : '';
                const sourceApp = cloudApps.find(a => a.id === (app.original_id || app.originalId || app.id));
                const hasUpdate = sourceApp && (app.updatedAt || app.updated_at) && (sourceApp.updatedAt || sourceApp.updated_at) &&
                    new Date(sourceApp.updatedAt || sourceApp.updated_at) > new Date(app.updatedAt || app.updated_at);
                return `
                    <div class="app-card" onclick="showInfo('${app.id}', '${mode}')" oncontextmenu="event.preventDefault();event.stopPropagation();showAppIconMenu(event,'${app.id}','${mode}')" style="position:relative;${ageCardStyle}">
                        ${hasUpdate ? `<div style="position:absolute;top:6px;right:6px;background:#2563eb;color:white;font-size:8px;font-weight:800;padding:2px 6px;border-radius:99px;z-index:2;">UPDATE</div>` : ''}
                        <div class="icon-box">${isImg ? `<img src="${app.icon}">` : `<span class="text-3xl">${app.icon}</span>`}</div>
                        <div class="font-bold text-xs mb-1">${app.name}</div>
                        ${app.genre ? `<div class="text-[10px] opacity-40">${app.genre}</div>` : ''}
                        ${ageBadge}
                        <button onclick="event.stopPropagation(); addToDesktop(${JSON.stringify(app).replace(/"/g, '&quot;')})" class="mt-2 bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-xs">+ Desktop</button>
                        <button onclick="event.stopPropagation(); changeAppIcon('${app.id}','${mode}')" style="margin-top:4px;width:100%;background:rgba(255,255,255,0.07);border:none;border-radius:6px;color:rgba(255,255,255,0.6);padding:4px;cursor:pointer;font-size:10px;">🎨 Change Icon</button>
                    </div>
                `;
            })
        ].join('') || '<div style="grid-column:1/-1;text-align:center;padding:60px;opacity:0.4;font-size:14px;">No apps installed yet.<br>Browse the Store to install some!</div>';
    };

    async function loadData() {
        if (!firebaseInitialized) {
            console.warn("Firebase not initialized - running in offline mode");
            notify("Offline Mode", "Running without cloud sync");
            setDrawerMode('installed');
            return;
        }

        try {
            // ── Load global apps from Supabase DB + Firebase merge ────────
            const loadGlobalApps = async () => {
                if (supabaseInitialized) {
                    try {
                        const { data: sbApps } = await window.sbGlobalApps.getAll();
                        const sbIds = new Set((sbApps || []).map(a => a.id));
                        if (firebaseInitialized) {
                            // Subscribe to Firebase for old apps not in Supabase
                            window._fb.onSnapshot(window._fb.collection(db, "global_apps"), (snap) => {
                                const fbApps = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                                cloudApps = [...(sbApps || []), ...fbApps.filter(a => !sbIds.has(a.id))];
                                setDrawerMode('installed');
                            }, (err) => console.error("Firebase global_apps error:", err));
                        } else {
                            cloudApps = sbApps || [];
                            setDrawerMode('installed');
                        }
                    } catch(e) { console.warn('Supabase global_apps load failed:', e); }
                } else if (firebaseInitialized) {
                    window._fb.onSnapshot(window._fb.collection(db, "global_apps"), (snap) => {
                        cloudApps = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                        setDrawerMode('installed');
                    }, (err) => { console.error("Error loading global apps:", err); notify("Cloud Error", "Unable to load store apps"); });
                }
            };

            // ── Load installed apps from Supabase DB + Firebase merge ─────
            const loadInstalledApps = async () => {
                if (supabaseInitialized) {
                    try {
                        const { data: sbApps } = await window.sbInstalled.getForUser(user);
                        const sbIds = new Set((sbApps || []).map(a => a.id));
                        if (firebaseInitialized) {
                            window._fb.onSnapshot(window._fb.query(window._fb.collection(db, "installed"), window._fb.where("owner", "==", user)), (snap) => {
                                const fbApps = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                                installedApps = [...(sbApps || []), ...fbApps.filter(a => !sbIds.has(a.id))];
                                document.getElementById('total-apps-count').textContent = installedApps.length;
                                setDrawerMode('installed');
                            }, (err) => console.error("Firebase installed error:", err));
                        } else {
                            installedApps = sbApps || [];
                            document.getElementById('total-apps-count').textContent = installedApps.length;
                            setDrawerMode('installed');
                        }
                    } catch(e) { console.warn('Supabase installed load failed:', e); }
                } else if (firebaseInitialized) {
                    window._fb.onSnapshot(window._fb.query(window._fb.collection(db, "installed"), window._fb.where("owner", "==", user)), (snap) => {
                        installedApps = snap.docs.map(d => ({ id: d.id, ...d.data() }));
                        document.getElementById('total-apps-count').textContent = installedApps.length;
                        setDrawerMode('installed');
                    }, (err) => { console.error("Error loading installed apps:", err); notify("Cloud Error", "Unable to load your apps"); });
                }
            };

            await Promise.all([loadGlobalApps(), loadInstalledApps()]);

            // ── Sync installed app updates from global_apps ───────────────
            if (supabaseInitialized && installedApps.length > 0 && cloudApps.length > 0) {
                let updatedCount = 0;
                for (const installed of installedApps) {
                    const sourceId = installed.original_id || installed.originalId || installed.id;
                    const global = cloudApps.find(a => a.id === sourceId);
                    if (!global) continue;

                    const globalTs = global.updatedAt || global.publishedAt || global.createdAt;
                    const installedTs = installed.updatedAt || installed.publishedAt || installed.createdAt || installed.installed_at;
                    if (!globalTs || !installedTs) continue;

                    if (new Date(globalTs) > new Date(installedTs)) {
                        // Global is newer — patch the installed row
                        const patch = {
                            name: global.name,
                            icon: global.icon,
                            desc: global.desc,
                            version: global.version,
                            genre: global.genre,
                            code: global.code,
                            preview_image: global.previewImage || global.preview_image,
                            updated_at: new Date().toISOString()
                        };
                        const { error } = await window.sbGlobalApps._toRow
                            ? await supabase.from('installed').update(window.sbGlobalApps._toRow(patch)).eq('id', installed.id)
                            : await supabase.from('installed').update(patch).eq('id', installed.id);
                        if (!error) {
                            Object.assign(installed, { ...global, id: installed.id, owner: installed.owner });
                            updatedCount++;
                        } else {
                            console.error('[syncUpdates] patch failed:', error);
                        }
                    }
                }
                if (updatedCount > 0) {
                    notify('🔄 Updated', `${updatedCount} installed app${updatedCount > 1 ? 's' : ''} refreshed from store.`);
                    setDrawerMode('installed');
                }
            }
        } catch (error) {
            console.error("Error in loadData:", error);
            notify("Error", "Cloud sync unavailable");
        }
        
                
        loadSettings();
        updateWallpaperInfo();
        
        // Also load local data
        loadSavedApps();
    }
    
    function saveLocalData() {
        localStorage.setItem('hyos_apps_' + user, JSON.stringify(installedApps));
        localStorage.setItem('hyos_published_' + user, JSON.stringify(publishedApps));
    }
    
    function loadSavedApps() {
        const savedApps = localStorage.getItem('hyos_apps_' + user);
        if (savedApps) {
            installedApps = JSON.parse(savedApps);
        }
        
        const savedPublished = localStorage.getItem('hyos_published_' + user);
        if (savedPublished) {
            publishedApps = JSON.parse(savedPublished);
        }
    }

    function renderStore() {
        const grid = document.getElementById('store-grid');
        grid.innerHTML = cloudApps.map(app => {
            const isImg = app.icon?.startsWith('data');
            const matchesGenre = !userSettings.selectedGenre || app.genre === userSettings.selectedGenre;
            const ageStatus = window.getAppAgeStatus ? window.getAppAgeStatus(app) : 'ok';
            const ageCardStyle = ageStatus === 'inaccessible' ? 'opacity:0.45;filter:grayscale(0.6);' : ageStatus === 'age-blocked' ? 'opacity:0.45;filter:grayscale(0.4);' : '';
            const ageBadge = ageStatus === 'inaccessible' ? `<div style="font-size:9px;font-weight:700;background:rgba(148,163,184,0.15);color:#94a3b8;border-radius:5px;padding:2px 5px;margin-top:3px;display:inline-block;">🔒 Inaccessible</div>` :
                (app.ageLimit && parseInt(app.ageLimit) > 0) ? `<div style="font-size:9px;font-weight:700;background:${ageStatus==='age-blocked'?'rgba(239,68,68,0.15)':'rgba(34,197,94,0.12)'};color:${ageStatus==='age-blocked'?'#ef4444':'#22c55e'};border-radius:5px;padding:2px 5px;margin-top:3px;display:inline-block;">${app.ageLimit}+</div>` : '';
            return `
                <div class="app-card ${matchesGenre ? 'border-blue-600/30' : ''}" onclick="showInfo('${app.id}', 'cloud')" style="${ageCardStyle}">
                    <div class="icon-box">${isImg ? `<img src="${app.icon}">` : `<span class="text-3xl">${app.icon}</span>`}</div>
                    <div class="font-bold text-xs mb-1">${app.name}</div>
                    ${app.genre ? `<div class="text-[10px] opacity-40">${app.genre}</div>` : ''}
                    ${ageBadge}
                    ${matchesGenre ? '<div class="absolute top-2 right-2 text-xs">⭐</div>' : ''}
                </div>
            `;
        }).join('');
    }

    window.showInfo = (id, src) => {
        const app = src === 'cloud' || src === 'store' ? cloudApps.find(a => a.id === id) : installedApps.find(a => a.id === id);
        const isImg = app.icon?.startsWith('data');
        const isCreator = app.creator === user;
        const likes = app.likes || 0;
        const dislikes = app.dislikes || 0;
        const userLiked = app.likedBy?.includes(user);
        const userDisliked = app.dislikedBy?.includes(user);

        // Age status
        const ageStatus = window.getAppAgeStatus ? window.getAppAgeStatus(app) : 'ok';
        const ageLimitDisplay = (app.ageLimit && parseInt(app.ageLimit) > 0)
            ? `${app.ageLimit}+`
            : (ageStatus === 'inaccessible' ? 'No limit set' : 'All ages');
        const ageColor = ageStatus === 'inaccessible' ? '#94a3b8' : ageStatus === 'age-blocked' ? '#ef4444' : ageStatus === 'ok' ? '#22c55e' : '#f59e0b';
        const ageBadgeText = ageStatus === 'inaccessible' ? '🔒 Inaccessible — No age limit set' :
            ageStatus === 'age-blocked' ? `🔞 Requires ${app.ageLimit}+ (you are ${userSettings.userAge || '?'})` :
            ageStatus === 'age-unknown' ? '⚠️ Set your age to access rated apps' :
            (app.ageLimit && parseInt(app.ageLimit) > 0) ? `✅ ${app.ageLimit}+ — You can access this app` : '✅ No age restriction';

        const canRun = ageStatus === 'ok';
        const runBtnHTML = canRun
            ? `<button onclick="launchApp(${JSON.stringify(app).replace(/"/g, '&quot;')})" class="bg-blue-600 hover:bg-blue-700 p-4 rounded-xl font-bold text-xs">▶ RUN NOW</button>`
            : `<button disabled style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:16px;border-radius:12px;font-weight:700;font-size:12px;color:rgba(255,255,255,0.3);cursor:not-allowed;width:100%;">🔒 ${ageStatus === 'inaccessible' ? 'Inaccessible — No age limit set' : ageStatus === 'age-blocked' ? `Age Restricted (${app.ageLimit}+)` : 'Age verification needed'}</button>`;

        document.getElementById('info-body').innerHTML = `
            ${app.previewImage ? `<div style="width:100%;height:140px;border-radius:12px;overflow:hidden;margin-bottom:16px;"><img src="${app.previewImage}" style="width:100%;height:100%;object-fit:cover;"></div>` : ''}
            <div class="icon-box !w-24 !h-24 mb-6">${isImg ? `<img src="${app.icon}">` : `<span class="text-6xl">${app.icon}</span>`}</div>
            <h2 class="text-2xl font-black italic tracking-tighter">${app.name}</h2>
            <p class="text-blue-500 text-[10px] font-bold mb-2">CREATOR: ${app.creator || 'Unknown'} ${isCreator ? '✔' : ''}</p>
            ${app.genre ? `<div style="font-size:10px;opacity:0.5;margin-bottom:8px;">${app.genre}</div>` : ''}
            <div style="background:rgba(255,255,255,0.04);border:1px solid ${ageColor}33;border-radius:10px;padding:8px 12px;margin-bottom:14px;font-size:11px;color:${ageColor};font-weight:600;">${ageBadgeText}<span style="float:right;opacity:0.6;">Rating: ${ageLimitDisplay}</span></div>
            ${(src === 'cloud' || src === 'store') ? `
                <div style="display: flex; gap: 12px; justify-content: center; margin-bottom: 16px;">
                    <button onclick="likeApp('${id}')" style="background: ${userLiked ? '#16a34a' : 'rgba(255,255,255,0.1)'}; border: none; color: #fff; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px; font-weight: 600;">👍 ${likes}</button>
                    <button onclick="dislikeApp('${id}')" style="background: ${userDisliked ? '#dc2626' : 'rgba(255,255,255,0.1)'}; border: none; color: #fff; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px; font-weight: 600;">👎 ${dislikes}</button>
                </div>
            ` : ''}
            <div class="bg-black/40 p-5 rounded-2xl text-xs opacity-70 w-full mb-6 min-h-[80px]">${app.desc || 'No description provided.'}</div>
            <div class="w-full flex flex-col gap-2">
                ${runBtnHTML}
                ${(src === 'cloud' || src === 'store') ? `<button onclick="install('${id}')" class="bg-green-600/80 hover:bg-green-600 p-3 rounded-xl text-xs font-bold">📥 INSTALL</button>` : ''}
                ${src === 'installed' ? `<button onclick="uninstall('${id}')" class="bg-red-600/20 hover:bg-red-600/40 p-3 rounded-xl text-xs font-bold">🗑️ UNINSTALL</button>` : ''}
                ${isCreator ? `<button onclick="showAgeLimitModal('${id}','${src}')" style="background:rgba(124,58,237,0.2);border:1px solid rgba(124,58,237,0.4);padding:12px;border-radius:12px;color:white;cursor:pointer;font-size:12px;font-weight:700;width:100%;">🔞 Change Age Limit</button>` : ''}
                ${isCreator ? `<button onclick="editApp('${id}')" class="bg-purple-600/80 hover:bg-purple-600 p-3 rounded-xl text-xs font-bold">✏️ RE-CODE</button>` : ''}
                ${isCreator ? `<button onclick="showAppManagement('${id}','${src}')" style="background:rgba(14,165,233,0.15);border:1px solid rgba(14,165,233,0.35);padding:12px;border-radius:12px;color:#7dd3fc;cursor:pointer;font-size:12px;font-weight:700;width:100%;">⚙️ MANAGE APP</button>` : ''}
                ${isCreator ? `<button onclick="purge('${id}')" class="bg-red-900 hover:bg-red-800 p-3 rounded-xl text-xs font-bold">☠️ ADMIN PURGE</button>` : ''}
                <button onclick="addToDesktop(${JSON.stringify(app).replace(/"/g, '&quot;')})" class="bg-slate-700 hover:bg-slate-600 p-3 rounded-xl text-xs font-bold">🖥️ ADD TO DESKTOP</button>
            </div>
            ${(src === 'cloud' || src === 'store') ? `
            <div style="margin-top:20px;width:100%;">
                <div style="font-weight:700;font-size:12px;margin-bottom:10px;">⭐ Reviews</div>
                ${window.renderReviews(app)}
                ${user !== 'Guest' ? `
                <div style="margin-top:12px;">
                    <select id="review-rating" style="background:#0f172a;border:1px solid #334155;color:white;padding:6px 10px;border-radius:8px;font-size:12px;margin-bottom:8px;width:100%;">
                        <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                        <option value="4">⭐⭐⭐⭐ Good</option>
                        <option value="3">⭐⭐⭐ Okay</option>
                        <option value="2">⭐⭐ Poor</option>
                        <option value="1">⭐ Terrible</option>
                    </select>
                    <textarea id="review-text" placeholder="Write a review..." style="width:100%;background:#0f172a;border:1px solid #334155;color:white;padding:10px;border-radius:8px;font-size:11px;resize:none;height:60px;box-sizing:border-box;"></textarea>
                    <button onclick="submitReview('${id}')" style="margin-top:6px;width:100%;background:linear-gradient(135deg,#2563eb,#0ea5e9);border:none;padding:10px;border-radius:10px;color:white;font-weight:700;font-size:12px;cursor:pointer;">Post Review</button>
                </div>` : '<div style="opacity:0.4;font-size:11px;margin-top:8px;">Sign in to leave a review.</div>'}
            </div>` : ''}
        `;
        toggleApp('info-win');
    };

    window.showAppManagement = (id, src) => {
        const app = src === 'cloud' || src === 'store' ? cloudApps.find(a => a.id === id) : installedApps.find(a => a.id === id);
        if (!app) return;

        const overlay = document.createElement('div');
        overlay.id = 'app-mgmt-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;z-index:99995;background:rgba(0,0,0,0.75);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;';
        overlay.innerHTML = `
            <div style="background:rgba(15,23,42,0.99);border:1px solid #334155;border-radius:20px;width:480px;max-height:85vh;overflow-y:auto;padding:28px;box-shadow:0 30px 80px rgba(0,0,0,0.8);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <div>
                        <div style="font-size:18px;font-weight:800;">⚙️ Manage App</div>
                        <div style="font-size:12px;opacity:0.5;margin-top:2px;">${app.name}</div>
                    </div>
                    <button onclick="document.getElementById('app-mgmt-overlay').remove()" style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:white;cursor:pointer;padding:6px 12px;">✕</button>
                </div>

                <!-- Stats -->
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:20px;">
                    <div style="background:rgba(255,255,255,0.04);border:1px solid #334155;border-radius:10px;padding:12px;text-align:center;">
                        <div style="font-size:20px;font-weight:800;color:#0ea5e9;">${app.likes || 0}</div>
                        <div style="font-size:10px;opacity:0.5;">👍 Likes</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.04);border:1px solid #334155;border-radius:10px;padding:12px;text-align:center;">
                        <div style="font-size:20px;font-weight:800;color:#ef4444;">${app.dislikes || 0}</div>
                        <div style="font-size:10px;opacity:0.5;">👎 Dislikes</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.04);border:1px solid #334155;border-radius:10px;padding:12px;text-align:center;">
                        <div style="font-size:20px;font-weight:800;color:#22c55e;">${app.version || '1.0'}</div>
                        <div style="font-size:10px;opacity:0.5;">Version</div>
                    </div>
                </div>

                <!-- Edit metadata -->
                <div style="margin-bottom:14px;">
                    <div style="font-size:11px;font-weight:700;opacity:0.5;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Display Name</div>
                    <input id="mgmt-name" value="${app.name.replace(/"/g, '&quot;')}" style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px 14px;border-radius:10px;color:#fff;font-size:14px;font-weight:600;outline:none;box-sizing:border-box;">
                </div>
                <div style="margin-bottom:14px;">
                    <div style="font-size:11px;font-weight:700;opacity:0.5;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Version</div>
                    <input id="mgmt-version" value="${(app.version || '1.0').replace(/"/g, '&quot;')}" style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px 14px;border-radius:10px;color:#fff;font-size:13px;outline:none;box-sizing:border-box;">
                </div>
                <div style="margin-bottom:14px;">
                    <div style="font-size:11px;font-weight:700;opacity:0.5;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Description</div>
                    <textarea id="mgmt-desc" rows="3" style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px 14px;border-radius:10px;color:#fff;font-size:13px;resize:none;outline:none;box-sizing:border-box;">${app.desc || ''}</textarea>
                </div>
                <div style="margin-bottom:14px;">
                    <div style="font-size:11px;font-weight:700;opacity:0.5;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Genre</div>
                    <select id="mgmt-genre" style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px 14px;border-radius:10px;color:#fff;font-size:13px;outline:none;box-sizing:border-box;cursor:pointer;">
                        <option value="">— No category —</option>
                        ${['Utilities','Games','Productivity','Entertainment','Social','Education','Finance','Health','Creative','Developer'].map(g =>
                            `<option value="${g}" ${app.genre === g ? 'selected' : ''}>${g}</option>`
                        ).join('')}
                    </select>
                </div>

                <!-- Preview Image -->
                <div style="margin-bottom:20px;">
                    <div style="font-size:11px;font-weight:700;opacity:0.5;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">Preview Image</div>
                    <div style="display:flex;gap:10px;align-items:center;">
                        <div id="mgmt-thumb" style="width:100px;height:64px;background:#0f172a;border:1px dashed #334155;border-radius:10px;overflow:hidden;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:11px;opacity:${app.previewImage ? '1' : '0.4'};">
                            ${app.previewImage ? `<img src="${app.previewImage}" style="width:100%;height:100%;object-fit:cover;">` : 'No image'}
                        </div>
                        <label style="background:rgba(255,255,255,0.05);border:1px solid #334155;padding:8px 12px;border-radius:8px;color:rgba(255,255,255,0.5);cursor:pointer;font-size:12px;font-weight:600;">
                            📁 Upload new preview
                            <input type="file" accept="image/*" style="display:none;" onchange="
                                const r=new FileReader(); r.onload=e=>{
                                    window._mgmtPreviewImg=e.target.result;
                                    const t=document.getElementById('mgmt-thumb');
                                    t.innerHTML='<img src=\\''+e.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;\\'>';
                                    t.style.opacity='1';
                                }; r.readAsDataURL(this.files[0]);
                            ">
                        </label>
                    </div>
                </div>

                <!-- Action buttons -->
                <div style="display:flex;flex-direction:column;gap:8px;">
                    <button onclick="window.applyAppManagement('${id}','${src}')" style="background:linear-gradient(135deg,#2563eb,#1d4ed8);border:none;padding:12px;border-radius:12px;color:#fff;cursor:pointer;font-size:14px;font-weight:700;">💾 Save Changes</button>
                    <button onclick="window.unpublishApp('${id}','${src}')" style="background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);padding:12px;border-radius:12px;color:#f87171;cursor:pointer;font-size:13px;font-weight:700;">🗑️ Unpublish from Store</button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);
        window._mgmtPreviewImg = app.previewImage || null;
    };

    window.applyAppManagement = async (id, src) => {
        const name    = document.getElementById('mgmt-name')?.value.trim();
        const version = document.getElementById('mgmt-version')?.value.trim();
        const desc    = document.getElementById('mgmt-desc')?.value.trim();
        const genre   = document.getElementById('mgmt-genre')?.value;
        const preview = window._mgmtPreviewImg;

        const updates = { name, version, desc, genre, updatedAt: new Date().toISOString(), ...(preview ? { previewImage: preview } : {}) };

        try {
            if ((src === 'cloud' || src === 'store')) {
                if (supabaseInitialized) {
                    await window.sbGlobalApps.update(id, updates);
                    const ci = cloudApps.findIndex(a => a.id === id);
                    if (ci !== -1) cloudApps[ci] = { ...cloudApps[ci], ...updates };
                } else if (firebaseInitialized) {
                    await window._fb.updateDoc(window._fb.doc(db, 'global_apps', id), updates);
                    const ci = cloudApps.findIndex(a => a.id === id);
                    if (ci !== -1) cloudApps[ci] = { ...cloudApps[ci], ...updates };
                }
            } else {
                const li = installedApps.findIndex(a => a.id === id);
                if (li !== -1) { installedApps[li] = { ...installedApps[li], ...updates }; saveLocalData(); }
            }
            notify('✅ Saved', name + ' metadata updated!');
            document.getElementById('app-mgmt-overlay')?.remove();
            setDrawerMode(src === 'cloud' || src === 'store' ? 'store' : 'my');
        } catch(e) {
            notify('Error', e.message);
        }
    };

    window.unpublishApp = async (id, src) => {
        if (!confirm('Remove this app from the global store? This cannot be undone.')) return;
        try {
            if (supabaseInitialized) {
                await window.sbGlobalApps.delete(id);
                cloudApps = cloudApps.filter(a => a.id !== id);
            } else if (firebaseInitialized) {
                await window._fb.deleteDoc(window._fb.doc(db, 'global_apps', id));
                cloudApps = cloudApps.filter(a => a.id !== id);
            } else {
                cloudApps = cloudApps.filter(a => a.id !== id);
            }
            notify('🗑️ Unpublished', 'App removed from the store.');
            document.getElementById('app-mgmt-overlay')?.remove();
            document.getElementById('info-win') && closeApp('info-win');
            setDrawerMode('my');
        } catch(e) {
            notify('Error', e.message);
        }
    };

    window.likeApp = async (appId) => {
        const app = cloudApps.find(a => a.id === appId);
        if (!app) return;
        
        // Initialize arrays if they don't exist
        if (!app.likedBy) app.likedBy = [];
        if (!app.dislikedBy) app.dislikedBy = [];
        if (!app.likes) app.likes = 0;
        if (!app.dislikes) app.dislikes = 0;
        
        // Check if user already liked
        const alreadyLiked = app.likedBy.includes(user);
        const alreadyDisliked = app.dislikedBy.includes(user);
        
        if (alreadyLiked) {
            // Unlike
            app.likedBy = app.likedBy.filter(u => u !== user);
            app.likes = Math.max(0, app.likes - 1);
        } else {
            // Like
            app.likedBy.push(user);
            app.likes++;
            
            // Remove dislike if exists
            if (alreadyDisliked) {
                app.dislikedBy = app.dislikedBy.filter(u => u !== user);
                app.dislikes = Math.max(0, app.dislikes - 1);
            }
        }
        
        // Update Supabase DB (new) or Firebase (old)
        if (supabaseInitialized) {
            try { await window.sbGlobalApps.update(appId, { likes: app.likes, dislikes: app.dislikes, liked_by: app.likedBy, disliked_by: app.dislikedBy }); }
            catch(e) { console.error('Failed to update likes (Supabase):', e); }
        } else if (firebaseInitialized) {
            try { await window._fb.updateDoc(window._fb.doc(db, 'global_apps', appId), { likes: app.likes, dislikes: app.dislikes, likedBy: app.likedBy, dislikedBy: app.dislikedBy }); }
            catch(e) { console.error('Failed to update likes (Firebase):', e); }
        }
        
        // Refresh display
        setDrawerMode('store');
        
        // Refresh info modal if open
        const infoWin = document.getElementById('info-win');
        if (infoWin && infoWin.style.display !== 'none') {
            showInfo(appId, 'store');
        }
    };

    window.dislikeApp = async (appId) => {
        const app = cloudApps.find(a => a.id === appId);
        if (!app) return;
        
        // Initialize arrays if they don't exist
        if (!app.likedBy) app.likedBy = [];
        if (!app.dislikedBy) app.dislikedBy = [];
        if (!app.likes) app.likes = 0;
        if (!app.dislikes) app.dislikes = 0;
        
        // Check if user already disliked
        const alreadyLiked = app.likedBy.includes(user);
        const alreadyDisliked = app.dislikedBy.includes(user);
        
        if (alreadyDisliked) {
            // Remove dislike
            app.dislikedBy = app.dislikedBy.filter(u => u !== user);
            app.dislikes = Math.max(0, app.dislikes - 1);
        } else {
            // Dislike
            app.dislikedBy.push(user);
            app.dislikes++;
            
            // Remove like if exists
            if (alreadyLiked) {
                app.likedBy = app.likedBy.filter(u => u !== user);
                app.likes = Math.max(0, app.likes - 1);
            }
        }
        
        // Update Supabase DB (new) or Firebase (old)
        if (supabaseInitialized) {
            try { await window.sbGlobalApps.update(appId, { likes: app.likes, dislikes: app.dislikes, liked_by: app.likedBy, disliked_by: app.dislikedBy }); }
            catch(e) { console.error('Failed to update dislikes (Supabase):', e); }
        } else if (firebaseInitialized) {
            try { await window._fb.updateDoc(window._fb.doc(db, 'global_apps', appId), { likes: app.likes, dislikes: app.dislikes, likedBy: app.likedBy, dislikedBy: app.dislikedBy }); }
            catch(e) { console.error('Failed to update dislikes (Firebase):', e); }
        }
        
        // Refresh display
        setDrawerMode('store');
        
        // Refresh info modal if open
        const infoWin = document.getElementById('info-win');
        if (infoWin && infoWin.style.display !== 'none') {
            showInfo(appId, 'store');
        }
    };


    // ══════════════════════════════════════════════════════════════════════════
    // SAFETY SCANNER
    // ══════════════════════════════════════════════════════════════════════════
    const _BAD_WORDS = [
        'nigger','nigga','chink','spic','kike','gook','wetback','raghead',
        'cunt','whore','slut','faggot','fag','dyke','retard','tranny','nazi'
    ];
    const _DANGER_PATTERNS = [
        // ── eval & dynamic code execution ────────────────────────────────
        /\beval\s*\(/i,
        /new\s+Function\s*\(/i,
        /setTimeout\s*\(\s*[`"']/i,          // setTimeout("string") == eval
        /setInterval\s*\(\s*[`"']/i,          // setInterval("string") == eval
        /\bimportScripts\s*\(/i,              // workers pulling external scripts
        /import\s*\(\s*[`"']https?:/i,        // dynamic import from external URL

        // ── obfuscated eval via atob / decode ────────────────────────────
        /atob\s*\(.*\).*eval/i,
        /eval.*atob\s*\(/i,
        /decodeURIComponent.*eval/i,
        /String\.fromCharCode.*eval/i,
        /\bFunction\s*\(\s*[`"']\s*return/i, // Function("return ...")()

        // ── data exfiltration ────────────────────────────────────────────
        /\bfetch\s*\(\s*[`"']https?:/i,       // fetch to external URL
        /new\s+XMLHttpRequest/i,
        /\.open\s*\(\s*[`"'](GET|POST|PUT|DELETE|PATCH)/i,
        /new\s+WebSocket\s*\(/i,
        /navigator\.sendBeacon\s*\(/i,

        // ── cookie & storage theft ───────────────────────────────────────
        /document\.cookie/i,
        /localStorage\.clear/i,
        /localStorage\.removeItem/i,
        /sessionStorage\.clear/i,
        /indexedDB/i,

        // ── window / frame / parent escape ──────────────────────────────
        /window\.top[\s.\[]/i,
        /window\.parent[\s.\[]/i,
        /window\.opener[\s.\[]/i,
        /window\.frames[\s.\[]/i,
        /parent\.(location|document|window)/i,
        /top\.(location|document|window)/i,

        // ── location / redirect attacks ──────────────────────────────────
        /window\.location\s*=/i,
        /location\.replace\s*\(/i,
        /location\.assign\s*\(/i,
        /location\.href\s*=/i,
        /location\.reload\s*\(/i,               // hard reload can disrupt OS

        // ── DOM-based XSS beyond <script> ────────────────────────────────
        /\.innerHTML\s*=.*<script/i,
        /\.outerHTML\s*=/i,
        /document\.write\s*\(/i,
        /document\.writeln\s*\(/i,
        /<img[^>]+onerror\s*=/i,
        /<svg[^>]+onload\s*=/i,
        /javascript\s*:/i,                        // href="javascript:..."

        // ── prototype pollution ──────────────────────────────────────────
        /__proto__/i,
        /Object\.prototype\b/i,
        /constructor\s*\[\s*[`"']prototype/i,

        // ── process / environment access (sandboxed but block anyway) ────
        /\bprocess\.env\b/i,
        /\brequire\s*\(/i,
        /\bimport\s+\*\s+as/i,                 // import * as x from ...

        // ── clipboard & input snooping ───────────────────────────────────
        /navigator\.clipboard\.read/i,
        /document\.addEventListener.*keydown/i,   // keylogger pattern
        /window\.addEventListener.*keydown/i,

        // ── geolocation / device sensors ─────────────────────────────────
        /navigator\.geolocation/i,
        /navigator\.mediaDevices/i,
        /navigator\.getUserMedia/i,

        // ── service worker / background persistence ──────────────────────
        /navigator\.serviceWorker/i,
        /caches\.open\s*\(/i,

        // ── crypto mining patterns ───────────────────────────────────────
        /\bCryptoNight\b/i,
        /\bstratum\+tcp/i,
        /new\s+Worker\s*\(/i,                   // offthread mining via Worker
    ];

    function _hasBadWord(text) {
        if (!text) return false;
        // Check both raw and stripped versions to catch l33t/punctuation bypass
        const raw = text.toLowerCase();
        const stripped = raw.replace(/[^a-z0-9]/g, '');
        return _BAD_WORDS.some(w => {
            const wClean = w.replace(/[^a-z]/g, '');
            return raw.includes(w) || stripped.includes(wClean);
        });
    }
    function _cleanBadWords(text) {
        if (!text) return text;
        let out = text;
        _BAD_WORDS.forEach(w => {
            out = out.replace(new RegExp(w, 'gi'), '[BAD WORD]');
        });
        return out;
    }

    window.SafetyScanner = {
        scan(appData) {
            const r = { block: false, warnings: [], cleaned: {} };
            const code = appData.code || '';
            const fileSrc = (appData.files || []).map(f => f.content || '').join('\n');
            const src = code + fileSrc;

            // Name / desc / icon text cleaning
            if (_hasBadWord(appData.name))  { r.cleaned.name = _cleanBadWords(appData.name);  r.warnings.push('App name cleaned.'); }
            if (_hasBadWord(appData.desc))  { r.cleaned.desc = _cleanBadWords(appData.desc);  r.warnings.push('Description cleaned.'); }
            if (appData.icon && !appData.icon.startsWith('data:') && _hasBadWord(appData.icon)) {
                r.cleaned.icon = '📦'; r.warnings.push('Icon replaced.');
            }

            // Permissions warning
            const perms = Object.keys(detectRequestedPerms(appData));
            if (perms.length >= 4) r.warnings.push('⚠️ Requests ' + perms.length + ' permissions (' + perms.join(', ') + '). Users will be warned twice.');

            // Native flag
            try {
                const mf = (appData.files || []).find(f => f.name === 'Mani.manifest');
                if (mf) { const m = JSON.parse(mf.content || '{}'); if (m.native) r.warnings.push('⚠️ native:true declared — users will be warned.'); }
            } catch(e) {}

            // AppSpace size
            const nsSize = (appData.files || []).filter(f => /\.(hl|json)$/.test(f.name||'')).reduce((s,f) => s+(f.content||'').length, 0);
            if (nsSize > 307200) { r.block = true; r.warnings.push('🚫 BLOCKED: AppSpace data exceeds 300kb.'); }

            // Code size
            if (src.length > 716800) { r.block = true; r.warnings.push('🚫 BLOCKED: Code exceeds 700kb.'); }

            // Dangerous patterns
            _DANGER_PATTERNS.forEach(re => { if (re.test(src)) { r.block = true; r.warnings.push('🚫 BLOCKED: Dangerous script pattern: ' + re.source.slice(0,30)); } });

            // Bad words in code
            if (_hasBadWord(src)) { r.block = true; r.warnings.push('🚫 BLOCKED: Inappropriate language in app code.'); }

            return r;
        },

        async prompt(result, appName) {
            if (!result.warnings.length) return true;
            return new Promise(res => {
                const el = document.createElement('div');
                el.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;';
                const color = result.block ? '#ef4444' : '#f59e0b';
                const title = result.block ? '🚫 App Blocked' : '⚠️ Safety Warnings';
                el.innerHTML = `<div style="background:#0a0f1a;border:1px solid ${color}44;border-radius:20px;padding:28px;width:440px;max-width:92vw;">
                    <div style="font-size:18px;font-weight:800;color:${color};margin-bottom:12px;">${title}</div>
                    <div style="font-size:13px;font-weight:600;opacity:.6;margin-bottom:14px;">${appName}</div>
                    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;">
                        ${result.warnings.map(w=>`<div style="font-size:12px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);">${w}</div>`).join('')}
                    </div>
                    ${result.block
                        ? `<button onclick="this.closest('div[style*=position]').remove()" style="width:100%;padding:12px;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);border-radius:12px;color:#f87171;cursor:pointer;font-weight:700;">OK</button>`
                        : `<div style="display:flex;gap:10px;">
                            <button onclick="this.closest('div[style*=position]').remove();window._safetyRes(false)" style="flex:1;padding:12px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:white;cursor:pointer;">Cancel</button>
                            <button onclick="this.closest('div[style*=position]').remove();window._safetyRes(true)" style="flex:1;padding:12px;background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.4);border-radius:12px;color:#7dd3fc;cursor:pointer;font-weight:700;">Publish Anyway</button>
                          </div>`
                    }
                </div>`;
                window._safetyRes = res;
                document.body.appendChild(el);
                if (result.block) res(false);
            });
        }
    };

    // ══════════════════════════════════════════════════════════════════════════
    // PUBLISH COOLDOWN (3 minutes)
    // ══════════════════════════════════════════════════════════════════════════
    function _checkPublishCooldown() {
        const last = parseInt(localStorage.getItem('hyos_last_publish') || '0');
        const elapsed = Date.now() - last;
        const cooldown = 3 * 60 * 1000;
        if (elapsed < cooldown) {
            const rem = Math.ceil((cooldown - elapsed) / 1000);
            const m = Math.floor(rem / 60), s = rem % 60;
            notify('⏳ Cooldown', `Please wait ${m}:${String(s).padStart(2,'0')} before publishing again.`);
            return false;
        }
        return true;
    }
    function _stampPublishCooldown() { localStorage.setItem('hyos_last_publish', Date.now().toString()); }

    window.publishHyHToStore = () => {
        // Show a HyFiles picker for .hyh files
        const allFiles = [];
        const folders = ['root', 'downloads', 'documents'];
        folders.forEach(folder => {
            if (fileSystem[folder]) {
                fileSystem[folder].forEach((file, idx) => {
                    if (file.name && file.name.toLowerCase().endsWith('.hyh')) {
                        allFiles.push({ file, folder, idx });
                    }
                });
            }
        });
        
        if (allFiles.length === 0) {
            notify('No HyH Files', 'No .hyh files found in HyFiles. Export one from App Builder first.');
            return;
        }
        
        // Show a picker dialog
        const dialog = document.createElement('div');
        dialog.className = 'context-menu';
        dialog.style.cssText = 'display: block; left: 50%; top: 50%; transform: translate(-50%, -50%); min-width: 380px; padding: 20px; z-index: 99999;';
        
        dialog.innerHTML = `
            <div style="margin-bottom: 15px; font-size: 15px; font-weight: 700;">📤 Choose HyH to Publish</div>
            <div style="font-size: 12px; opacity: 0.6; margin-bottom: 16px;">Select a .hyh file from HyFiles to publish to the store</div>
            ${allFiles.map((item, i) => `
                <div class="context-menu-item" onclick="window._publishHyhFromFiles(${i}); this.parentElement.remove();">
                    <span style="font-weight: 600;">📦 ${item.file.name}</span>
                    <span style="font-size: 11px; opacity: 0.5; margin-left: 8px;">${item.folder}</span>
                </div>
            `).join('')}
            <div class="context-menu-item" onclick="this.parentElement.remove();" style="border-top: 1px solid #334155; margin-top: 10px; opacity: 0.6;">
                Cancel
            </div>
        `;
        
        document.body.appendChild(dialog);
        
        // Store allFiles for later use
        window._hyFilesForPublish = allFiles;
        
        setTimeout(() => {
            const closeDialog = (e) => {
                if (!dialog.contains(e.target)) {
                    dialog.remove();
                    document.removeEventListener('click', closeDialog);
                }
            };
            document.addEventListener('click', closeDialog);
        }, 10);
    };
    
    window._publishHyhFromFiles = async (fileIndex) => {
        const item = window._hyFilesForPublish[fileIndex];
        if (!item) return;
        const _bannedH = JSON.parse(localStorage.getItem('hyos_banned_users') || '[]');
        if (_bannedH.includes((user||'').toLowerCase())) { notify('🚫 Banned', 'Your account has been banned from publishing.'); return; }
        if (!_checkPublishCooldown()) return;
        
        try {
            const hyhPackage = JSON.parse(item.file.data || item.file.content);
            
            if (hyhPackage.format !== 'HyH') {
                notify('Error', 'Invalid HyH file format');
                return;
            }
            
            const genre = prompt('Select genre for your app:\n\nEnter one of: productivity, creative, utility, entertainment, development, social, gaming, education', 'productivity');
            if (!genre) return;
            
            const newApp = {
                name: hyhPackage.name,
                icon: hyhPackage.icon,
                desc: hyhPackage.description,
                code: hyhPackage.files[0]?.content || '',
                creator: user,
                genre: genre,
                files: hyhPackage.files,
                created: new Date().toISOString(),
                likes: 0,
                dislikes: 0,
                likedBy: [],
                dislikedBy: []
            };
            
            if (supabaseInitialized) {
                try {
                    const { data: inserted, error: sbErr } = await window.sbGlobalApps.insert({ ...newApp });
                    if (sbErr) throw new Error(sbErr.message || JSON.stringify(sbErr));
                    if (inserted?.id) { newApp.id = inserted.id; }
                    cloudApps.push(newApp);
                    notify('Published!', hyhPackage.name + ' is now live in the Store!');
                    setDrawerMode('store');
                } catch(error) { console.error('Publish error:', error); notify('Error', 'Failed to publish to store'); }
            } else if (firebaseInitialized) {
                try {
                    await window._fb.addDoc(window._fb.collection(db, 'global_apps'), newApp);
                    notify('Published!', hyhPackage.name + ' is now live in the Store!');
                    setDrawerMode('store');
                } catch(error) { console.error('Publish error:', error); notify('Error', 'Failed to publish to store'); }
            } else {
                newApp.id = 'local_' + Date.now();
                cloudApps.push(newApp);
                notify('Published Locally', hyhPackage.name + ' added to local store');
                setDrawerMode('store');
            }
        } catch (error) {
            console.error('Publish error:', error);
            notify('Error', 'Failed to read HyH file');
        }
    };

    window.closeActualApp = (appId, winId) => {
        // Clean up blob URL if it exists
        if (window.appBlobURLs && window.appBlobURLs[winId]) {
            URL.revokeObjectURL(window.appBlobURLs[winId]);
            delete window.appBlobURLs[winId];
        }
        // Unload native app if running
        if (window.HyNative) {
            const nativeId = window.HyNative.running.find(id => openApps[appId] === winId);
            if (nativeId) window.HyNative.unload(nativeId);
        }
        
        document.getElementById(winId)?.remove();
        delete openApps[appId];
        document.getElementById('task-' + winId)?.remove();
        updateTaskManager();
        
        // Hide game bar if no gaming apps are running
        const hasGamingApps = Object.keys(openApps).some(id => {
            const app = installedApps.find(a => a.id === id) || cloudApps.find(a => a.id === id);
            return app && app.genre === 'gaming';
        });
        
        if (!hasGamingApps) {
            hideGameBar();
        }
    };

    function addTaskbarBtn(appId, name, winId) {
        const btn = document.createElement('div');
        btn.id = 'task-' + winId;
        btn.className = 'task-btn active';
        btn.innerHTML = `<span>${name}</span>`;
        btn.onclick = () => {
            const win = document.getElementById(winId);
            if (win.style.display === 'none') {
                win.style.display = 'flex';
            } else {
                win.style.display = 'none';
            }
        };
        document.getElementById('taskbar-apps').appendChild(btn);
    }

    function init3D() {
        const canvas = document.getElementById('bg-3d');
        if (!userSettings.currentWallpaper?.type === '3d') {
            canvas.style.display = 'none';
            return;
        }
        
        canvas.style.display = 'block';
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ canvas, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        camera.position.z = 5;

        const geometry = new THREE.BufferGeometry();
        const vertices = [];
        for(let i = 0; i < 1000; i++) {
            vertices.push(
                Math.random() * 20 - 10,
                Math.random() * 20 - 10,
                Math.random() * 20 - 10
            );
        }
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        const material = new THREE.PointsMaterial({ color: 0x2563eb, size: 0.05 });
        const particles = new THREE.Points(geometry, material);
        scene.add(particles);

        function animate() {
            requestAnimationFrame(animate);
            particles.rotation.x += 0.0005;
            particles.rotation.y += 0.001;
            renderer.render(scene, camera);
        }
        animate();

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    window.set3DWall = (type) => {
        userSettings.currentWallpaper = { type: '3d', data: type };
        saveSettings();
        updateWallpaperInfo();
        document.getElementById('bg-video').style.display = 'none';
        document.getElementById('desktop-bg').style.backgroundImage = 'none';
        init3D();
        closeApp('wallpaper-win');
    };

    window.setCustomImage = (input) => {
        const file = input.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                userSettings.currentWallpaper = { type: 'image', data: e.target.result };
                saveSettings();
                updateWallpaperInfo();
                document.getElementById('bg-3d').style.display = 'none';
                document.getElementById('bg-video').style.display = 'none';
                document.getElementById('desktop-bg').style.backgroundImage = `url(${e.target.result})`;
                closeApp('wallpaper-win');
            };
            reader.readAsDataURL(file);
        }
    };

    window.setCustomVideo = (input) => {
        const file = input.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                userSettings.currentWallpaper = { type: 'video', data: e.target.result };
                saveSettings();
                updateWallpaperInfo();
                document.getElementById('bg-3d').style.display = 'none';
                const vid = document.getElementById('bg-video');
                vid.src = e.target.result;
                vid.style.display = 'block';
                document.getElementById('desktop-bg').style.backgroundImage = 'none';
                closeApp('wallpaper-win');
            };
            reader.readAsDataURL(file);
        }
    };


    // ── ARTIST IMAGE WALLPAPERS ──────────────────────────────────────
    window.setImageWall = function(dataUrl) {
        const bg = document.getElementById('desktop-bg');
        // Clear any 3D canvas
        const canvas = bg.querySelector('canvas');
        if (canvas) { canvas.remove(); if (window._threeRenderer) { window._threeRenderer.dispose(); window._threeRenderer = null; } }
        bg.style.backgroundImage = 'url(' + dataUrl + ')';
        bg.style.backgroundSize = 'cover';
        bg.style.backgroundPosition = 'center';
        notify('🎨 Wallpaper', 'Artist theme applied!');
        closeApp('wallpaper-win');
    };

    window.openWallpaperPicker = () => {
        toggleApp('wallpaper-win');
    };
    
    function updateWallpaperInfo() {
        const wp = userSettings.currentWallpaper;
        document.getElementById('current-wallpaper-type').textContent = wp.type || 'None';
        let desc = 'No wallpaper set';
        if (wp.type === '3d') desc = `3D Wallpaper: ${wp.data}`;
        else if (wp.type === 'live') desc = `Live Wallpaper: ${wp.data}`;
        else if (wp.type === 'image') desc = 'Custom Image';
        else if (wp.type === 'video') desc = 'Custom Video';
        document.getElementById('current-wallpaper-desc').textContent = desc;
    }

    window.updateTaskManager = () => {
        const list = document.getElementById('task-manager-list');
        if (list) {
            list.innerHTML = "";
            
            const openAppIds = Object.keys(openApps);
            
            if (openAppIds.length === 0) {
                list.innerHTML = '<div class="text-center opacity-40 text-xs py-8">No applications running</div>';
            } else {
                openAppIds.forEach(appId => {
                    const app = cloudApps.find(x => x.id === appId) || installedApps.find(x => x.id === appId || x.originalId === appId);
                    const winId = openApps[appId];
                    
                    if (app) {
                        const isImg = app.icon?.startsWith('data');
                        list.innerHTML += `
                            <div class="bg-slate-700 rounded-lg p-3 flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="icon-box !w-8 !h-8">${isImg ? `<img src="${app.icon}">` : `<span class="text-lg">${app.icon}</span>`}</div>
                                    <span class="text-xs font-bold">${app.name}</span>
                                </div>
                                <button onclick="closeActualApp('${appId}','${winId}')" class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded-lg text-xs font-bold">End</button>
                            </div>
                        `;
                    }
                });
            }
        }
        
        // Update system info counts
        const openAppsCount = document.getElementById('open-apps-count');
        const installedAppsCount = document.getElementById('installed-apps-count');
        const desktopIconsCount = document.getElementById('desktop-icons-count');
        
        if (openAppsCount) openAppsCount.textContent = Object.keys(openApps).length;
        if (installedAppsCount) installedAppsCount.textContent = installedApps.length;
        if (desktopIconsCount) desktopIconsCount.textContent = userSettings.desktopIcons.length;
    };

    window.handleFile = (i) => { 
        const r = new FileReader(); 
        r.onload = () => b64Icon = r.result; 
        r.readAsDataURL(i.files[0]); 
    };
    
    window.publish = async () => {
        const d = { 
            name: document.getElementById('m-name').value, 
            code: document.getElementById('m-code').value, 
            icon: b64Icon || document.getElementById('m-icon').value || "📦", 
            desc: document.getElementById('m-desc').value, 
            creator: user, 
            createdAt: window._fb.serverTimestamp(), 
            likes:0 
        };
        
        if (supabaseInitialized) {
            if (editingId) {
                await window.sbGlobalApps.update(editingId, d);
            } else {
                const { data: inserted, error: sbErr } = await window.sbGlobalApps.insert(d);
                if (sbErr) throw new Error(sbErr.message || JSON.stringify(sbErr));
                if (inserted?.id) cloudApps.push({ id: inserted.id, ...d });
            }
        } else if (firebaseInitialized) {
            if(editingId) {
                await window._fb.updateDoc(window._fb.doc(db, "global_apps", editingId), d);
            } else {
                await window._fb.addDoc(window._fb.collection(db, "global_apps"), d);
            }
        }
        
        toggleApp('builder-win'); 
        notify("Cloud Update", "Application pushed successfully.");
    };

    window.editApp = (id) => {
        const a = cloudApps.find(x => x.id === id) || installedApps.find(x => x.id === id); 
        if (!a) {
            notify('Error', 'App not found');
            return;
        }
        
        editingId = id;
        
        // If the app has files (HyH format), load them into App Builder
        if (a.files && Array.isArray(a.files) && a.files.length > 0) {
            AppBuilder.currentProject.name = a.name;
            AppBuilder.currentProject.files = [...a.files]; // Clone the files array
            AppBuilder.currentProject.currentFileIndex = 0;
            
            // Update the manifest fields in the builder UI
            const projectNameInput = document.getElementById('builder-project-name');
            const appIconInput = document.getElementById('builder-app-icon');
            const appDescInput = document.getElementById('builder-app-desc');
            
            if (projectNameInput) projectNameInput.value = a.name;
            if (appIconInput) appIconInput.value = a.icon || '📦';
            if (appDescInput) appDescInput.value = a.desc || '';
            
            // Handle base64 icon if present
            if (a.icon && a.icon.startsWith('data:image')) {
                b64Icon = a.icon;
                if (appIconInput) {
                    appIconInput.value = '🖼️ (Image)';
                    appIconInput.style.backgroundImage = 'url(' + a.icon + ')';
                    appIconInput.style.backgroundSize = 'contain';
                    appIconInput.style.backgroundRepeat = 'no-repeat';
                    appIconInput.style.backgroundPosition = 'center';
                    appIconInput.style.color = 'transparent';
                }
            }
            
            // Render the file tree and load the first file
            AppBuilder.renderFileTree();
            AppBuilder.loadCurrentFile();
            
            notify('Loaded', 'All ' + a.files.length + ' files loaded into App Builder!');
        } else {
            // Legacy app without files - reconstruct from code
            const htmlContent = a.code || '<!DOCTYPE html>\n<html>\n<head>\n    <title>HyOS HS — HyService</title>\n</head>\n<body>\n    <h1>Edit your app</h1>\n</body>\n</html>';
            
            AppBuilder.currentProject.name = a.name;
            AppBuilder.currentProject.files = [
                { name: 'Main.html', type: 'html', content: htmlContent },
                { name: 'Mani.manifest', type: 'json', content: '{\n  "name": "' + a.name + '",\n  "version": "1.0",\n  "description": "' + (a.desc || 'An app') + '",\n  "native": true,\n  "permissions": []\n}' }
            ];
            AppBuilder.currentProject.currentFileIndex = 0;
            
            const projectNameInput = document.getElementById('builder-project-name');
            const appIconInput = document.getElementById('builder-app-icon');
            const appDescInput = document.getElementById('builder-app-desc');
            
            if (projectNameInput) projectNameInput.value = a.name;
            if (appIconInput) appIconInput.value = a.icon || '📦';
            if (appDescInput) appDescInput.value = a.desc || '';
            
            AppBuilder.renderFileTree();
            AppBuilder.loadCurrentFile();
            
            notify('Loaded', 'App loaded into App Builder (legacy format)');
        }
        
        closeApp('info-win'); 
        toggleApp('builder-win');
    };

    window.notify = (t, m) => {
        if (!userSettings.notifications) return;
        playSound('notification');
        const n = document.createElement('div'); 
        n.className = "notif"; 
        n.innerHTML = `<b>${t}</b><p class="text-[10px] opacity-60">${m}</p>`;
        document.getElementById('notif-area').appendChild(n); 
        setTimeout(() => n.remove(), 4000);
    };

    window.install = async (id) => { 
        const a = cloudApps.find(x => x.id === id) || (publishedApps && publishedApps.find(x => x.id === id));
        if (!a) {
            notify("Error", "App not found");
            return;
        }
        
        // Save to HyFiles Downloads folder
        const appData = JSON.stringify({
            name: a.name,
            emoji: a.emoji,
            desc: a.desc,
            code: a.code,
            creator: a.creator
        });
        
        if (!fileSystem['Downloads']) {
            fileSystem['Downloads'] = [];
        }
        
        fileSystem['Downloads'].push({
            name: a.name + '.hyapp',
            type: 'application/hyapp',
            data: appData,
            content: appData,
            created: new Date().toISOString()
        });
        
        HyFiles.saveFileSystem();
        
        notify("Downloaded", a.name + " saved to HyFiles/Downloads");
        closeApp('info-win');
    };
    
    window.uninstall = async (id) => { 
        if (!firebaseInitialized) {
            notify("Offline Mode", "Cannot uninstall apps in offline mode");
            return;
        }

        try {
            await window._fb.deleteDoc(window._fb.doc(db, "installed", id));
            notify("Uninstalled", "App uninstalled successfully");
            closeApp('info-win');
        } catch (error) {
            console.error("Uninstall error:", error);
            notify("Error", "Failed to uninstall app: " + error.message);
        }
    };
    
    window.purge = async (id) => { 
        if (!supabaseInitialized && !firebaseInitialized) {
            notify("Offline Mode", "Cannot delete apps in offline mode");
            return;
        }

        if (confirm("Delete this app from the cloud? This cannot be undone.")) {
            try {
                if (supabaseInitialized) { await window.sbGlobalApps.delete(id); }
                else { await window._fb.deleteDoc(window._fb.doc(db, "global_apps", id)); }
                cloudApps = cloudApps.filter(a => a.id !== id);
                notify("Deleted", "App deleted successfully");
                closeApp('info-win');
            } catch (error) {
                console.error("Delete error:", error);
                notify("Error", "Failed to delete app: " + error.message);
            }
        }
    };
    
    window.toggleApp = (id) => { 
        const w = document.getElementById(id);
        const isOpening = w.style.display !== 'flex';
        w.style.display = (w.style.display === 'flex' ? 'none' : 'flex');
        playSound(isOpening ? 'open' : 'close');
    };
    
    window.setupDrags = setupDrags;
    
    window.toggleDrawer = (id) => { 
        const w = document.getElementById(id); 
        const isVisible = w.style.display === 'flex'; 
        document.querySelectorAll('.dock-drawer').forEach(d => d.style.display = 'none'); 
        w.style.display = isVisible ? 'none' : 'flex';
        if (!isVisible) playSound('open');
    };
    
    window.closeApp = (id) => {
        document.getElementById(id).style.display = 'none';
        playSound('close');
    };
    window.maxWin = (id) => {
        document.getElementById(id).classList.toggle('maximized');
        playSound('click');
    };
    window.minWin = (id) => {
        const win = document.getElementById(id);
        win.style.display = 'none';
        playSound('click');
    };
    window.runPrev = () => document.getElementById('m-prev').srcdoc = document.getElementById('m-code').value;
    window.changeWall = () => { 
        const u = prompt("URL:"); 
        if(u) {
            userSettings.currentWallpaper = { type: 'image', data: u };
            saveSettings();
            document.getElementById('desktop-bg').style.backgroundImage = `url(${u})`; 
        }
    };
    
    function setupDrags() {
        document.querySelectorAll('.window').forEach(win => {
            const h = win.querySelector('.win-header'), r = win.querySelector('.resizer');
            
            h.onmousedown = (e) => {
                if(win.classList.contains('maximized')) return;
                if(e.target.tagName === 'BUTTON') return;
                win.style.transform = "none";
                let ox = e.clientX - win.offsetLeft, oy = e.clientY - win.offsetTop;
                document.onmousemove = (ev) => { 
                    win.style.left = ev.clientX - ox + 'px'; 
                    win.style.top = ev.clientY - oy + 'px'; 
                };
                document.onmouseup = () => document.onmousemove = null;
            };
            
            h.ontouchstart = (e) => {
                if(win.classList.contains('maximized')) return;
                if(e.target.tagName === 'BUTTON') return;
                e.preventDefault();
                win.style.transform = "none";
                const touch = e.touches[0];
                let ox = touch.clientX - win.offsetLeft, oy = touch.clientY - win.offsetTop;
                document.ontouchmove = (ev) => { 
                    const t = ev.touches[0];
                    win.style.left = t.clientX - ox + 'px'; 
                    win.style.top = t.clientY - oy + 'px'; 
                };
                document.ontouchend = () => document.ontouchmove = null;
            };
            
            // Mouse resize
            if(r) r.onmousedown = (e) => {
                e.preventDefault();
                document.onmousemove = (ev) => { 
                    win.style.width = ev.clientX - win.offsetLeft + 'px'; 
                    win.style.height = ev.clientY - win.offsetTop + 'px'; 
                };
                document.onmouseup = () => document.onmousemove = null;
            };
            
            // Touch resize for mobile
            if(r) r.ontouchstart = (e) => {
                e.preventDefault();
                document.ontouchmove = (ev) => {
                    const touch = ev.touches[0];
                    win.style.width = touch.clientX - win.offsetLeft + 'px'; 
                    win.style.height = touch.clientY - win.offsetTop + 'px'; 
                };
                document.ontouchend = () => document.ontouchmove = null;
            };
        });
    }

    // Initialize on page load — wait for FBSB.js to finish before touching backend
    function _coreInit() {
        // Sync window globals set by FBSB.js into local scope so existing code works
        if (typeof firebaseInitialized === 'undefined') {
            window.firebaseInitialized = window.firebaseInitialized || false;
            window.supabaseInitialized = window.supabaseInitialized || false;
            window.db = window.db || null;
            window.supabase = window.supabase || null;
        }

        (async () => {
            // CRITICAL FIX: Load settings BEFORE checking saved login
            loadSettings();
            const loggedIn = await checkSavedLogin();
        })();
    }

    if (window._fbsbReady) {
        // FBSB already fired before core.js loaded (shouldn't happen but safe fallback)
        _coreInit();
    } else {
        window.addEventListener('hyos-backend-ready', () => {
            window._fbsbReady = true;
            _coreInit();
        }, { once: true });

        // Safety fallback — if FBSB never fires (e.g. network issue), boot anyway after 5s
        setTimeout(() => {
            if (!window._fbsbReady) {
                console.warn('[core] Backend ready timeout — booting without backend');
                window._fbsbReady = true;
                _coreInit();
            }
        }, 5000);
    }
    
    // =====================================================
    // BOOT SEQUENCE & RECOVERY MODE
    // =====================================================
    
    let bootProgress = 0;
    let bootIntervalId;
    let recoveryModeActive = false;
    let inSafeMode = false;
    
    // Start boot sequence
    function startBootSequence() {
        const bootScreen = document.getElementById('boot-screen');
        const progressBar = document.getElementById('boot-progress');
        const loginScreen = document.getElementById('login-screen');
        
        bootScreen.style.display = 'flex';
        
        // Animate boot progress
        bootIntervalId = setInterval(() => {
            bootProgress += Math.random() * 15 + 5; // Random progress 5-20%
            if (bootProgress >= 100) {
                bootProgress = 100;
                clearInterval(bootIntervalId);
                
                // Complete boot after a short delay
                setTimeout(() => {
                    bootScreen.style.opacity = '0';
                    bootScreen.style.transition = 'opacity 0.5s';
                    setTimeout(() => {
                        bootScreen.style.display = 'none';
                        loginScreen.style.display = 'flex';
                        // Start login clock on initial boot
                        const _tickBootClock = () => {
                            const now = new Date();
                            const clockEl = document.getElementById('login-clock-display');
                            const dateEl = document.getElementById('login-date-display');
                            if (clockEl) clockEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                            if (dateEl) dateEl.textContent = now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
                        };
                        _tickBootClock();
                        if (window._loginClockInterval) clearInterval(window._loginClockInterval);
                        window._loginClockInterval = setInterval(() => {
                            if (document.getElementById('login-screen').style.display !== 'none') {
                                _tickBootClock();
                            } else {
                                clearInterval(window._loginClockInterval);
                            }
                        }, 1000);
                    }, 500);
                }, 500);
            }
            progressBar.style.width = bootProgress + '%';
        }, 100);
    }
    
    // Listen for F10 to enter recovery mode
    let f10PressTime = 0;
    let doubleClickTimer = null;
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'F10') {
            e.preventDefault();
            const bootScreen = document.getElementById('boot-screen');
            if (bootScreen.style.display !== 'none' && bootScreen.style.display !== '') {
                enterRecoveryMode();
            }
        }
    });
    
    // Double-click/Double-tap boot screen to enter recovery
    let lastTapTime = 0;
    const doubleTapDelay = 300; // milliseconds
    
    const bootScreen = document.getElementById('boot-screen');
    
    // Desktop: Double-click
    bootScreen.addEventListener('dblclick', () => {
        enterRecoveryMode();
    });
    
    // Mobile: Double-tap
    bootScreen.addEventListener('touchend', (e) => {
        const currentTime = new Date().getTime();
        const tapTimeDiff = currentTime - lastTapTime;
        
        if (tapTimeDiff < doubleTapDelay && tapTimeDiff > 0) {
            // Double-tap detected
            e.preventDefault();
            enterRecoveryMode();
            lastTapTime = 0; // Reset to prevent triple-tap
        } else {
            lastTapTime = currentTime;
        }
    });
    
    function enterRecoveryMode() {
        clearInterval(bootIntervalId);
        document.getElementById('boot-screen').style.display = 'none';
        document.getElementById('recovery-screen').style.display = 'flex';
        recoveryModeActive = true;
    }
    
    // Recovery Mode Functions
    window.recoveryBootNormal = function() {
        inSafeMode = false;
        document.getElementById('recovery-screen').style.display = 'none';
        document.getElementById('login-screen').style.display = 'flex';
        recoveryModeActive = false;
    };
    
    window.recoveryScanVirus = function() {
        const recoveryScreen = document.getElementById('recovery-screen');
        const originalContent = recoveryScreen.innerHTML;
        
        recoveryScreen.innerHTML = `
            <div style="width: 500px; background: rgba(15, 23, 42, 0.98); border: 1px solid #334155; border-radius: 16px; padding: 30px; text-align: center;">
                <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 20px;">Virus Scan</h2>
                <div style="font-size: 48px; margin-bottom: 20px;">🛡️</div>
                <div id="scan-status" style="margin-bottom: 20px; font-size: 14px; opacity: 0.8;">Initializing scan...</div>
                <div style="width: 100%; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden; margin-bottom: 20px;">
                    <div id="scan-progress" style="width: 0%; height: 100%; background: #7c3aed; transition: width 0.3s;"></div>
                </div>
                <div id="scan-results" style="display: none; text-align: left; background: rgba(255,255,255,0.05); padding: 15px; border-radius: 12px; margin-bottom: 20px; font-size: 13px;"></div>
                <button id="scan-done-btn" onclick="recoveryBootNormal()" style="display: none; width: 100%; background: #2563eb; padding: 12px; border-radius: 12px; font-weight: 600; border: none; color: white; cursor: pointer;">Continue to Login</button>
            </div>
        `;
        
        // Simulate virus scan
        let scanProgress = 0;
        const scanItems = [
            'Scanning system files...',
            'Checking applications...',
            'Analyzing memory...',
            'Inspecting network connections...',
            'Validating boot sector...',
            'Checking for malware signatures...'
        ];
        
        let scanIndex = 0;
        const scanInterval = setInterval(() => {
            scanProgress += Math.random() * 20 + 10;
            if (scanProgress >= 100) scanProgress = 100;
            
            document.getElementById('scan-progress').style.width = scanProgress + '%';
            document.getElementById('scan-status').textContent = scanItems[scanIndex];
            
            scanIndex++;
            
            if (scanProgress >= 100) {
                clearInterval(scanInterval);
                document.getElementById('scan-status').textContent = 'Scan complete!';
                document.getElementById('scan-results').innerHTML = `
                    ✅ No threats detected<br>
                    📁 Files scanned: ${Math.floor(Math.random() * 5000 + 15000)}<br>
                    🛡️ System is secure
                `;
                document.getElementById('scan-results').style.display = 'block';
                document.getElementById('scan-done-btn').style.display = 'block';
            }
        }, 800);
    };
    
    window.recoveryResetData = function() {
        if (confirm('⚠️ WARNING: This will delete ALL data including:\n\n• User accounts\n• Saved settings\n• Installed apps\n• All files\n\nThis action CANNOT be undone. Continue?')) {
            if (confirm('Are you ABSOLUTELY sure? This is your last chance to cancel.')) {
                // Clear all localStorage
                localStorage.clear();
                
                // Show reset animation
                const recoveryScreen = document.getElementById('recovery-screen');
                recoveryScreen.innerHTML = `
                    <div style="width: 500px; background: rgba(15, 23, 42, 0.98); border: 1px solid #334155; border-radius: 16px; padding: 30px; text-align: center;">
                        <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 20px;">Resetting Device...</h2>
                        <div style="font-size: 48px; margin-bottom: 20px; animation: pulse 2s infinite;">🔄</div>
                        <p style="opacity: 0.8;">Please wait...</p>
                    </div>
                `;
                
                // Reload after 2 seconds
                setTimeout(() => {
                    location.reload();
                }, 2000);
            }
        }
    };
    
    window.recoverySafeMode = function() {
        inSafeMode = true;
        document.getElementById('recovery-screen').style.display = 'none';
        document.getElementById('login-screen').style.display = 'flex';
        recoveryModeActive = false;
        
        // Show safe mode indicator after login
        setTimeout(() => {
            if (document.getElementById('os-surface') && document.getElementById('os-surface').classList.contains('hidden') === false) {
                const safeModeIndicator = document.createElement('div');
                safeModeIndicator.id = 'safe-mode-indicator';
                safeModeIndicator.style.cssText = 'position: fixed; top: 45px; left: 50%; transform: translateX(-50%); background: rgba(202, 138, 4, 0.95); color: white; padding: 8px 20px; border-radius: 20px; z-index: 9999; font-weight: 600; font-size: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
                safeModeIndicator.textContent = '🔒 Safe Mode Active';
                document.body.appendChild(safeModeIndicator);
            }
        }, 1000);
    };
    
    window.recoveryTerminal = function() {
        const recoveryScreen = document.getElementById('recovery-screen');
        recoveryScreen.innerHTML = `
            <div style="width: 700px; background: rgba(15, 23, 42, 0.98); border: 1px solid #334155; border-radius: 16px; padding: 30px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                    <h2 style="font-size: 24px; font-weight: 700;">Recovery Terminal</h2>
                    <button onclick="recoveryBootNormal()" style="background: #475569; padding: 8px 16px; border-radius: 8px; border: none; color: white; cursor: pointer;">Exit</button>
                </div>
                <div id="terminal-output" style="background: #000; color: #0f0; font-family: monospace; padding: 15px; border-radius: 12px; height: 400px; overflow-y: auto; font-size: 13px; margin-bottom: 15px;"></div>
                <input id="terminal-input" type="text" placeholder="Type 'help' for commands..." style="width: 100%; background: #000; color: #0f0; border: 1px solid #334155; padding: 12px; border-radius: 12px; font-family: monospace; outline: none;" onkeypress="if(event.key === 'Enter') processTerminalCommand()">
            </div>
        `;
        
        const output = document.getElementById('terminal-output');
        output.innerHTML = 'HyOS HS Recovery Terminal<br>Type "help" for available commands<br><br>';
        document.getElementById('terminal-input').focus();
    };
    
    window.processTerminalCommand = function() {
        const input = document.getElementById('terminal-input');
        const output = document.getElementById('terminal-output');
        const command = input.value.trim().toLowerCase();
        
        output.innerHTML += `<span style="color: #fff">$ ${input.value}</span><br>`;
        
        if (command === 'help') {
            output.innerHTML += `Available commands:<br>
            - help: Show this help message<br>
            - status: Show system status<br>
            - clear: Clear terminal<br>
            - reboot: Reboot system<br>
            - reset: Reset all data<br>
            - exit: Return to recovery menu<br><br>`;
        } else if (command === 'status') {
            output.innerHTML += `System Status:<br>
            Version: HyOS HS v1.0<br>
            Mode: Recovery<br>
            Storage: ${(Math.random() * 30 + 20).toFixed(1)}% used<br>
            Memory: ${(Math.random() * 50 + 30).toFixed(1)}% used<br><br>`;
        } else if (command === 'clear') {
            output.innerHTML = '';
        } else if (command === 'reboot') {
            output.innerHTML += 'Rebooting system...<br>';
            setTimeout(() => location.reload(), 1500);
        } else if (command === 'reset') {
            output.innerHTML += 'Use recovery menu for reset operations<br><br>';
        } else if (command === 'exit') {
            const recoveryScreen = document.getElementById('recovery-screen');
            recoveryScreen.innerHTML = `
                <div style="width: 500px; background: rgba(15, 23, 42, 0.98); border: 1px solid #334155; border-radius: 16px; padding: 30px;">
                    <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 20px; text-align: center;">Recovery Mode</h2>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <button onclick="recoveryBootNormal()" style="width: 100%; background: #2563eb; padding: 12px 16px; border-radius: 12px; font-weight: 600; transition: 0.2s; text-align: left; display: flex; align-items: center; gap: 12px; border: none; color: white; cursor: pointer;">
                            <span style="font-size: 20px;">🚀</span><span>Boot Normally</span>
                        </button>
                        <button onclick="recoveryScanVirus()" style="width: 100%; background: #7c3aed; padding: 12px 16px; border-radius: 12px; font-weight: 600; transition: 0.2s; text-align: left; display: flex; align-items: center; gap: 12px; border: none; color: white; cursor: pointer;">
                            <span style="font-size: 20px;">🛡️</span><span>Scan for Viruses</span>
                        </button>
                        <button onclick="recoveryResetData()" style="width: 100%; background: #dc2626; padding: 12px 16px; border-radius: 12px; font-weight: 600; transition: 0.2s; text-align: left; display: flex; align-items: center; gap: 12px; border: none; color: white; cursor: pointer;">
                            <span style="font-size: 20px;">⚠️</span><span>Reset Device Data</span>
                        </button>
                        <button onclick="recoverySafeMode()" style="width: 100%; background: #ca8a04; padding: 12px 16px; border-radius: 12px; font-weight: 600; transition: 0.2s; text-align: left; display: flex; align-items: center; gap: 12px; border: none; color: white; cursor: pointer;">
                            <span style="font-size: 20px;">🔒</span><span>Safe Mode</span>
                        </button>
                        <button onclick="recoveryTerminal()" style="width: 100%; background: #475569; padding: 12px 16px; border-radius: 12px; font-weight: 600; transition: 0.2s; text-align: left; display: flex; align-items: center; gap: 12px; border: none; color: white; cursor: pointer;">
                            <span style="font-size: 20px;">⌨️</span><span>Terminal</span>
                        </button>
                    </div>
                </div>
            `;
        } else if (command) {
            output.innerHTML += `Unknown command: ${command}<br>Type "help" for available commands<br><br>`;
        }
        
        input.value = '';
        output.scrollTop = output.scrollHeight;
    };
    
    // Start boot sequence on page load
    setTimeout(() => {
        startBootSequence();
    }, 100);
    
    
    // Login screen: Enter key support
    document.getElementById('p-in').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleAuth(false);
        }
    });
    
    document.getElementById('u-in').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleAuth(false);
        }
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Ctrl/Cmd + D: Toggle apps drawer
        if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
            e.preventDefault();
            toggleDrawer('drawer-win');
        }
        
        // Ctrl/Cmd + S: Open settings
        if ((e.ctrlKey || e.metaKey) && e.key === ',') {
            e.preventDefault();
            toggleApp('settings-win');
        }
        
        // Ctrl/Cmd + N: Open app maker
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            openMaker();
        }
        
        // Ctrl/Cmd + W: Close active window (if any)
        if ((e.ctrlKey || e.metaKey) && e.key === 'w') {
            e.preventDefault();
            const activeWindow = document.querySelector('.window[style*="display: flex"]');
            if (activeWindow) {
                activeWindow.style.display = 'none';
            }
        }
        
        // Escape: Close all drawers and context menus
        if (e.key === 'Escape') {
            document.querySelectorAll('.dock-drawer').forEach(d => d.style.display = 'none');
            hideContextMenu();
        }
    });
    
    // Welcome notification with tips
    setTimeout(() => {
        if (!localStorage.getItem('hyos-welcome-shown')) {
            notify('Welcome to HyOS HS v1.0!', 'Desktop icons are now draggable. Double-click to launch apps. Right-click desktop for options. Press Ctrl+D for apps.');
            localStorage.setItem('hyos-welcome-shown', 'true');
        }
    }, 2000);
    
    // Auto-arrange desktop icons option
    window.autoArrangeIcons = () => {
        const iconWidth = 100;
        const iconHeight = 100;
        const margin = 20;
        const maxCols = Math.floor((window.innerWidth - margin * 2) / iconWidth);
        
        userSettings.desktopIcons.forEach((iconData, index) => {
            const col = index % maxCols;
            const row = Math.floor(index / maxCols);
            iconData.x = margin + (col * iconWidth);
            iconData.y = margin + (row * iconHeight);
        });
        
        saveSettings();
        renderDesktopIcons();
        notify('Icons Arranged', 'Desktop icons have been auto-arranged');
    };

    // Game Bar functionality
    let gameBarVisible = false;
    let isRecording = false;
    let gameModeEnabled = false;
    let fpsCounterVisible = false;
    
    window.toggleGameBar = () => {
        const gameBar = document.getElementById('game-bar');
        const toggle = document.querySelector('.game-bar-toggle');
        
        if (gameBarVisible) {
            gameBar.classList.add('collapsed');
            gameBarVisible = false;
        } else {
            gameBar.classList.remove('collapsed');
            gameBarVisible = true;
            startPerformanceMonitoring();
        }
    };
    
    window.showGameBar = () => {
        if (userSettings.enableGameBar) {
            const gameBar = document.getElementById('game-bar');
            const toggle = document.querySelector('.game-bar-toggle');
            gameBar.style.display = 'flex';
            toggle.style.display = 'flex';
            
            if (userSettings.autoShowGameBar) {
                gameBar.classList.remove('collapsed');
                gameBarVisible = true;
                startPerformanceMonitoring();
            }
        }
    };
    
    window.hideGameBar = () => {
        const gameBar = document.getElementById('game-bar');
        const toggle = document.querySelector('.game-bar-toggle');
        gameBar.style.display = 'none';
        toggle.style.display = 'none';
        gameBarVisible = false;
        stopPerformanceMonitoring();
    };
    
    // Media storage system
    let mediaLibrary = {
        screenshots: [],
        recordings: []
    };
    
    // Load media library from localStorage
    function loadMediaLibrary() {
        const saved = localStorage.getItem('hyos_media');
        if (saved) {
            mediaLibrary = JSON.parse(saved);
        }
    }
    
    function saveMediaLibrary() {
        localStorage.setItem('hyos_media', JSON.stringify(mediaLibrary));
    }
    
    window.captureScreenshot = async () => {
        // Try method 1: Screen Capture API (getDisplayMedia)
        if (navigator.mediaDevices && typeof navigator.mediaDevices.getDisplayMedia === 'function') {
            try {
                notify('Screen Capture', 'Please select the screen/window to capture');
                
                // Request screen capture using getDisplayMedia
                const stream = await navigator.mediaDevices.getDisplayMedia({
                    video: { mediaSource: 'screen' }
                });
                
                // Create a video element to capture the frame
                const video = document.createElement('video');
                video.srcObject = stream;
                video.play();
                
                // Wait for video to load
                await new Promise(resolve => {
                    video.onloadedmetadata = resolve;
                });
                
                // Create canvas and capture the current frame
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0);
                
                // Stop the stream
                stream.getTracks().forEach(track => track.stop());
                
                // Convert to data URL
                const dataUrl = canvas.toDataURL('image/png');
                
                // Create screenshot metadata
                const screenshot = {
                    id: 'ss-' + Date.now(),
                    name: `Screenshot_${new Date().toLocaleDateString().replace(/\//g, '-')}_${new Date().toLocaleTimeString().replace(/:/g, '-')}.png`,
                    timestamp: Date.now(),
                    date: new Date().toISOString(),
                    type: 'screenshot',
                    dataUrl: dataUrl,
                    method: 'Screen Capture API'
                };
                
                mediaLibrary.screenshots.push(screenshot);
                saveMediaLibrary();
                
                // Also save to HyFiles
                if (typeof HyFiles !== 'undefined') {
                    fileSystem.screenshots.push({
                        name: screenshot.name,
                        type: 'image/png',
                        data: screenshot.dataUrl,
                        created: screenshot.date
                    });
                    HyFiles.saveFileSystem();
                    // Auto-refresh HyFiles if open
                    if (document.getElementById('hyfiles-win')?.style.display !== 'none') HyFiles.refresh();
                }
                
                notify('Screenshot Captured', 'Screenshot saved via Screen Capture API');
                return;
            } catch (error) {
                if (error.name === 'NotAllowedError') {
                    notify('Trying html2canvas...', 'Screen capture denied, using DOM capture instead');
                } else {
                    console.error('Screen Capture API error:', error);
                    notify('Trying html2canvas...', 'Screen capture failed, using DOM capture');
                }
                // Fall through to html2canvas method
            }
        }
        
        // Method 2: html2canvas (fallback - captures DOM only)
        if (typeof html2canvas !== 'undefined') {
            try {
                notify('Capturing...', 'Capturing HyOS HS desktop with html2canvas');
                
                // Capture the entire OS surface
                const targetElement = document.getElementById('os-surface') || document.body;
                const canvas = await html2canvas(targetElement, {
                    backgroundColor: '#020617',
                    scale: window.devicePixelRatio || 1,
                    useCORS: true,
                    allowTaint: true,
                    logging: false,
                    windowWidth: window.innerWidth,
                    windowHeight: window.innerHeight
                });
                
                // Convert to data URL
                const dataUrl = canvas.toDataURL('image/png');
                
                // Create screenshot metadata
                const screenshot = {
                    id: 'ss-' + Date.now(),
                    name: `Screenshot_${new Date().toLocaleDateString().replace(/\//g, '-')}_${new Date().toLocaleTimeString().replace(/:/g, '-')}.png`,
                    timestamp: Date.now(),
                    date: new Date().toISOString(),
                    type: 'screenshot',
                    dataUrl: dataUrl,
                    method: 'html2canvas'
                };
                
                mediaLibrary.screenshots.push(screenshot);
                saveMediaLibrary();
                
                // Also save to HyFiles
                if (typeof HyFiles !== 'undefined') {
                    fileSystem.screenshots.push({
                        name: screenshot.name,
                        type: 'image/png',
                        data: screenshot.dataUrl,
                        created: screenshot.date
                    });
                    HyFiles.saveFileSystem();
                    if (document.getElementById('hyfiles-win')?.style.display !== 'none') HyFiles.refresh();
                }
                
                notify('Screenshot Captured', 'HyOS HS desktop captured via html2canvas');
                return;
            } catch (error) {
                console.error('html2canvas error:', error);
                notify('Screenshot Error', 'html2canvas failed: ' + error.message);
            }
        }
        
        // Method 3: Demo fallback (if all else fails)
        notify('Demo Mode', 'No capture method available, creating placeholder');
        
        const screenshot = {
            id: 'ss-' + Date.now(),
            name: `Screenshot_${new Date().toLocaleDateString().replace(/\//g, '-')}_${new Date().toLocaleTimeString().replace(/:/g, '-')}.png`,
            timestamp: Date.now(),
            date: new Date().toISOString(),
            type: 'screenshot',
            dataUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
            method: 'Demo placeholder'
        };
        
        mediaLibrary.screenshots.push(screenshot);
        saveMediaLibrary();
        
        if (typeof HyFiles !== 'undefined') {
            fileSystem.screenshots.push({
                name: screenshot.name,
                type: 'image/png',
                data: screenshot.dataUrl,
                created: screenshot.date
            });
            HyFiles.saveFileSystem();
            if (document.getElementById('hyfiles-win')?.style.display !== 'none') HyFiles.refresh();
        }
        
        notify('Screenshot Saved', 'Demo screenshot saved');
    };
    
    let recordingStartTime = null;
    let mediaRecorder = null;
    let recordedChunks = [];
    
    window.toggleRecording = async () => {
        const icon = document.getElementById('record-icon');
        const label = document.getElementById('record-label');
        
        // Check if getDisplayMedia is supported
        if (!navigator.mediaDevices || typeof navigator.mediaDevices.getDisplayMedia !== 'function') {
            notify('Not Supported', 'Screen recording requires a modern browser with HTTPS');
            return;
        }
        
        if (!isRecording) {
            // Start recording
            try {
                // Request screen capture
                const stream = await navigator.mediaDevices.getDisplayMedia({
                    video: { mediaSource: 'screen' },
                    audio: true // Include system audio if available
                });
                
                // Create MediaRecorder
                recordedChunks = [];
                mediaRecorder = new MediaRecorder(stream, {
                    mimeType: 'video/webm;codecs=vp9'
                });
                
                mediaRecorder.ondataavailable = (event) => {
                    if (event.data.size > 0) {
                        recordedChunks.push(event.data);
                    }
                };
                
                mediaRecorder.onstop = () => {
                    // Create recording metadata
                    const duration = recordingStartTime ? Math.floor((Date.now() - recordingStartTime) / 1000) : 0;
                    const blob = new Blob(recordedChunks, { type: 'video/webm' });
                    
                    // Convert to data URL
                    const reader = new FileReader();
                    reader.onloadend = () => {
                        const recording = {
                            id: 'rec-' + Date.now(),
                            name: `Recording_${new Date().toLocaleDateString().replace(/\//g, '-')}_${new Date().toLocaleTimeString().replace(/:/g, '-')}.webm`,
                            timestamp: Date.now(),
                            date: new Date().toISOString(),
                            type: 'recording',
                            duration: duration,
                            durationFormatted: formatDuration(duration),
                            dataUrl: reader.result
                        };
                        
                        mediaLibrary.recordings.push(recording);
                        saveMediaLibrary();
                        
                        // Also save to HyFiles
                        if (typeof HyFiles !== 'undefined') {
                            fileSystem.videos.push({
                                name: recording.name,
                                type: 'video/webm',
                                data: recording.dataUrl,
                                created: recording.date
                            });
                            HyFiles.saveFileSystem();
                        }
                        
                        notify('Recording Stopped', `Recording saved (${recording.durationFormatted})`);
                    };
                    reader.readAsDataURL(blob);
                    
                    // Stop all tracks
                    stream.getTracks().forEach(track => track.stop());
                    recordingStartTime = null;
                };
                
                // Handle if user stops sharing
                stream.getVideoTracks()[0].onended = () => {
                    if (isRecording) {
                        toggleRecording();
                    }
                };
                
                mediaRecorder.start();
                isRecording = true;
                recordingStartTime = Date.now();
                icon.textContent = '⏹️';
                label.textContent = 'Stop Recording';
                notify('Recording Started', 'Screen recording in progress');
                
            } catch (error) {
                if (error.name === 'NotAllowedError') {
                    notify('Recording Cancelled', 'Screen capture permission denied');
                } else {
                    notify('Recording Error', 'Failed to start recording: ' + error.message);
                }
                isRecording = false;
                icon.textContent = '⏺️';
                label.textContent = 'Start Recording';
            }
        } else {
            // Stop recording
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.stop();
            }
            isRecording = false;
            icon.textContent = '⏺️';
            label.textContent = 'Start Recording';
        }
    };
    
    function formatDuration(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    window.exportMedia = (id, type) => {
        const item = type === 'screenshot' ? 
            mediaLibrary.screenshots.find(s => s.id === id) :
            mediaLibrary.recordings.find(r => r.id === id);
            
        if (item) {
            // Create download link
            const link = document.createElement('a');
            link.download = `${item.name}.${type === 'screenshot' ? 'png' : 'mp4'}`;
            link.href = item.dataUrl || 'data:text/plain;base64,'; // Placeholder
            link.click();
            notify('Exported', `${item.name} exported`);
        }
    };
    
    window.deleteMedia = (id, type) => {
        if (confirm('Delete this media item?')) {
            if (type === 'screenshot') {
                mediaLibrary.screenshots = mediaLibrary.screenshots.filter(s => s.id !== id);
            } else {
                mediaLibrary.recordings = mediaLibrary.recordings.filter(r => r.id !== id);
            }
            saveMediaLibrary();
            notify('Deleted', 'Media item deleted');
            
            // Refresh media viewer if open
            const mediaWin = document.getElementById('media-viewer-win');
            if (mediaWin && mediaWin.style.display === 'flex') {
                loadMediaViewer();
            }
        }
    };
    
    window.clearAllMedia = () => {
        if (confirm('Delete ALL screenshots and recordings? This cannot be undone!')) {
            mediaLibrary = { screenshots: [], recordings: [] };
            saveMediaLibrary();
            notify('Cleared', 'All media deleted');
            
            // Refresh media viewer if open
            const mediaWin = document.getElementById('media-viewer-win');
            if (mediaWin && mediaWin.style.display === 'flex') {
                loadMediaViewer();
            }
        }
    };
    
    window.toggleGameMode = () => {
        gameModeEnabled = !gameModeEnabled;
        const status = document.getElementById('game-mode-status');
        
        if (gameModeEnabled) {
            status.textContent = 'Enabled';
            status.classList.add('text-green-500');
            notify('Game Mode', 'Game Mode enabled - Performance optimized');
        } else {
            status.textContent = 'Disabled';
            status.classList.remove('text-green-500');
            notify('Game Mode', 'Game Mode disabled');
        }
    };
    
    window.toggleFPSCounter = () => {
        fpsCounterVisible = !fpsCounterVisible;
        const status = document.getElementById('fps-status');
        
        if (fpsCounterVisible) {
            status.textContent = 'Visible';
            status.classList.add('text-green-500');
            notify('FPS Counter', 'FPS counter now visible');
        } else {
            status.textContent = 'Hidden';
            status.classList.remove('text-green-500');
        }
    };
    
    window.updateGameVolume = (value) => {
        document.getElementById('game-vol-value').textContent = value + '%';
    };
    
    window.updateSystemVolume = (value) => {
        document.getElementById('system-vol-value').textContent = value + '%';
    };
    
    // Performance monitoring
    let performanceInterval;
    
    function startPerformanceMonitoring() {
        if (performanceInterval) return;
        
        performanceInterval = setInterval(() => {
            // Simulated performance metrics
            const cpuUsage = Math.floor(Math.random() * 30 + 20);
            const memoryUsage = Math.floor(Math.random() * 20 + 40);
            const fps = Math.floor(Math.random() * 10 + 55);
            
            document.getElementById('cpu-usage').textContent = cpuUsage + '%';
            document.getElementById('memory-usage').textContent = memoryUsage + '%';
            document.getElementById('fps-display').textContent = fps + ' FPS';
        }, 1000);
    }
    
    function stopPerformanceMonitoring() {
        if (performanceInterval) {
            clearInterval(performanceInterval);
            performanceInterval = null;
        }
    }
    
    // Gaming settings functions
    window.updateRecordingQuality = (quality) => {
        userSettings.recordingQuality = quality;
        saveSettings();
        notify('Recording Quality', `Quality set to ${quality}`);
    };
    
    window.updateOverlayPosition = (position) => {
        userSettings.overlayPosition = position;
        saveSettings();
    };
    
    window.updateTargetFPS = (fps) => {
        userSettings.targetFPS = fps;
        saveSettings();
        notify('Target FPS', `Frame rate target set to ${fps}`);
    };
    
    // Keyboard shortcut for Game Bar
    document.addEventListener('keydown', (e) => {
        // Win + G (or Cmd + G on Mac) for Game Bar
        if ((e.metaKey || e.ctrlKey) && e.key === 'g') {
            e.preventDefault();
            if (document.getElementById('game-bar').style.display === 'flex') {
                toggleGameBar();
            }
        }
    });

    // Update Firebase + Supabase status in About section
    setTimeout(async () => {
        const statusElem = document.getElementById('firebase-status');
        const projectElem = document.getElementById('firebase-project-id');
        const sbStatusElem = document.getElementById('supabase-status');
        
        if (statusElem) {
            if (firebaseInitialized) {
                statusElem.innerHTML = '<span class="text-green-500">✓ Connected</span>';
            } else {
                statusElem.innerHTML = '<span class="text-red-500">✗ Offline Mode</span>';
            }
        }
        
        if (projectElem) {
            projectElem.textContent = firebaseInitialized ? firebaseConfig.projectId : 'Not connected';
        }

        // ── Supabase ping ─────────────────────────────────────────────
        if (sbStatusElem) {
            if (!supabaseInitialized) {
                sbStatusElem.innerHTML = '<span class="text-red-500">✗ Not initialized</span>';
            } else {
                try {
                    const start = Date.now();
                    const { error } = await supabase.from('users').select('username').limit(1);
                    const ms = Date.now() - start;
                    if (error) {
                        sbStatusElem.innerHTML = `<span class="text-red-500">✗ Error: ${error.message}</span>`;
                    } else {
                        sbStatusElem.innerHTML = `<span class="text-green-500">✓ Connected <span style="opacity:.5;font-size:11px">${ms}ms</span></span>`;
                    }
                } catch(e) {
                    sbStatusElem.innerHTML = `<span class="text-red-500">✗ Unreachable</span>`;
                }
            }
        }
    }, 1000);

    // ========================
    // APP DOWNLOAD & INSTALLATION
    // ========================
    
    window.downloadApp = function(websiteId) {
        const site = browserState.userWebsites.find(s => s.id === websiteId);
        if (!site || !site.app) {
            notify('Error', 'App not found');
            return;
        }
        
        // Show installation prompt
        browserState.pendingInstall = {
            app: site.app,
            websiteName: site.name,
            websiteId: websiteId
        };
        
        document.getElementById('install-app-name').textContent = site.app.name;
        document.getElementById('install-from-website').textContent = site.name;
        document.getElementById('install-app-desc').textContent = site.app.description;
        document.getElementById('install-prompt-overlay').style.display = 'flex';
    };
    
    window.cancelInstall = function() {
        browserState.pendingInstall = null;
        document.getElementById('install-prompt-overlay').style.display = 'none';
    };
    
    window.confirmInstall = async function() {
        if (!browserState.pendingInstall) return;
        
        const { app, websiteName } = browserState.pendingInstall;
        
        // Create the app object
        const newApp = {
            name: app.name,
            emoji: app.emoji,
            desc: app.description,
            code: app.code,
            creator: user,
            fromBrowser: true,
            sourceWebsite: websiteName,
            id: 'browser_app_' + Date.now()
        };
        
        // Add to installed apps
        installedApps.push(newApp);

        // Cache app code locally in IndexedDB
        HyFS.cacheApp(newApp).catch(e => console.warn('[HyFS cache]', e));
        
        // Save to Supabase DB (new) or Firebase (old)
        if (supabaseInitialized) {
            try { await window.sbInstalled.insert({ ...newApp, owner: user }); }
            catch(e) { console.error('Failed to save app to Supabase:', e); }
        } else if (firebaseInitialized) {
            try { await window._fb.addDoc(window._fb.collection(db, 'apps'), newApp); }
            catch(e) { console.error('Failed to save app to Firebase:', e); }
        }
        
        // Save locally
        saveLocalData();
        
        // Refresh the drawer if it's open
        if (document.getElementById('drawer-win').style.display !== 'none') {
            loadDrawer('installed');
        }
        
        // Close prompt
        document.getElementById('install-prompt-overlay').style.display = 'none';
        browserState.pendingInstall = null;
        
        // Save download record to Firebase downloads
        if (firebaseInitialized) {
            try {
                const downloadData = {
                    user: user,
                    appName: app.name,
                    websiteName: websiteName,
                    timestamp: new Date().toISOString(),
                    size: new Blob([app.code]).size
                };
                
                // If file is > 2MB, compress it (simulated)
                if (downloadData.size > 2 * 1024 * 1024) {
                    downloadData.size = 1 * 1024 * 1024; // Compressed to 1MB
                    downloadData.compressed = true;
                }
                
                await window._fb.setDoc(window._fb.doc(db, 'users', user, 'downloads', newApp.id), downloadData);
            } catch (error) {
                console.error('Failed to save download record:', error);
            }
        }
        
        notify('App Installed', app.name + ' has been installed and appears in your Apps menu!');
        
        // Execute the app code if it modifies the system
        try {
            // Create a sandboxed execution context
            const appFunction = new Function('notify', 'document', 'window', app.code);
            appFunction(notify, document, window);
        } catch (error) {
            console.error('App execution error:', error);
            notify('App Error', 'App installed but execution failed. You can still run it from the Apps menu.');
        }
    };

    // =====================================================
    // PRIVACY SETTINGS — FULL IMPLEMENTATION
    // =====================================================

    const PRIVACY_KEYS = ['sendUsageData','sendCrashReports','personalizedRecs','trackAppUsage',
        'allowLocation','allowCamera','allowMicrophone','allowFiles',
        'allowNotifications','allowWallpaper','allowClipboard',
        'passwordForInstalls','autoLock','blockUnknownApps'];

    // Sync all privacy toggle elements from saved userSettings
    function syncPrivacyUI() {
        PRIVACY_KEYS.forEach(key => {
            const el = document.getElementById('ptog-' + key);
            if (!el) return;
            userSettings[key] ? el.classList.add('active') : el.classList.remove('active');
        });
        const minsRow = document.getElementById('autolock-mins-row');
        if (minsRow) minsRow.style.display = userSettings.autoLock ? 'flex' : 'none';
        const minsEl = document.getElementById('autolock-mins');
        if (minsEl) minsEl.value = userSettings.autoLockMinutes || 5;
        renderPerAppPerms();
    }

    // Called by each privacy toggle in the settings panel
    window.privacyToggle = (key, el) => {
        el.classList.toggle('active');
        userSettings[key] = el.classList.contains('active');
        saveSettings();

        // Side effects
        if (key === 'autoLock') {
            const row = document.getElementById('autolock-mins-row');
            if (row) row.style.display = userSettings.autoLock ? 'flex' : 'none';
            userSettings.autoLock ? _autoLock.setup() : _autoLock.clear();
        }

        // If a global perm is turned OFF, strip it from all existing app grants
        const permKeyMap = {allowMicrophone:'mic', allowCamera:'cam', allowLocation:'loc', allowNotifications:'notif', allowWallpaper:'wallpaper', allowClipboard:'clipboard', allowFiles:'files'};
        const permKey = permKeyMap[key];
        if (permKey && !userSettings[key]) {
            const p = userSettings.appPermissions || {};
            Object.keys(p).forEach(id => { if (p[id]) p[id][permKey] = false; });
            saveSettings();
            renderPerAppPerms();
        }

        const label = { sendUsageData:'Usage data', sendCrashReports:'Crash reports', personalizedRecs:'Personalized recs', trackAppUsage:'App usage tracking', allowLocation:'Location', allowCamera:'Camera', allowMicrophone:'Microphone', allowFiles:'Files', allowNotifications:'Notifications', allowWallpaper:'Wallpaper', allowClipboard:'Clipboard', passwordForInstalls:'Install password', autoLock:'Auto-lock', blockUnknownApps:'Block unknown apps' }[key] || key;
        notify('Privacy', label + ' ' + (userSettings[key] ? 'enabled' : 'disabled'));
    };

    window.updateAutoLockMins = (val) => {
        userSettings.autoLockMinutes = parseInt(val);
        saveSettings();
        if (userSettings.autoLock) _autoLock.setup();
    };

    // ---- Auto-lock (IIFE module) ----
    const _autoLock = (() => {
        let timer = null;
        let lastAct = Date.now();
        const bump = () => { lastAct = Date.now(); };
        return {
            setup() {
                this.clear();
                document.addEventListener('mousemove', bump);
                document.addEventListener('keydown', bump);
                document.addEventListener('click', bump);
                timer = setInterval(() => {
                    const mins = userSettings.autoLockMinutes || 5;
                    if (Date.now() - lastAct > mins * 60000) this.lock();
                }, 15000);
            },
            clear() {
                clearInterval(timer);
                document.removeEventListener('mousemove', bump);
                document.removeEventListener('keydown', bump);
                document.removeEventListener('click', bump);
            },
            lock() {
                const os = document.getElementById('os-surface');
                const login = document.getElementById('login-screen');
                if (os && login) {
                    os.classList.add('hidden');
                    login.style.display = 'flex';
                    login.style.opacity = '1';
                    notify('Auto-Locked', 'Session locked due to inactivity');
                }
            }
        };
    })();

    // ---- Per-app permissions UI ----
    const PERM_META = {
        mic:       { icon:'🎤', label:'Microphone' },
        cam:       { icon:'📷', label:'Camera' },
        loc:       { icon:'📍', label:'Location' },
        notif:     { icon:'🔔', label:'Notifications' },
        wallpaper: { icon:'🖼️', label:'Wallpaper' },
        clipboard: { icon:'📋', label:'Clipboard' },
        files:     { icon:'📁', label:'Files' }
    };

    function renderPerAppPerms() {
        const container = document.getElementById('per-app-perms');
        if (!container) return;
        const p = userSettings.appPermissions || {};
        const entries = Object.entries(p).filter(([,v]) => v && Object.keys(v).length > 0);

        if (!entries.length) {
            container.innerHTML = '<div style="text-align:center;padding:28px;opacity:.35;font-size:12px;">No apps have requested permissions yet.</div>';
            return;
        }

        container.innerHTML = entries.map(([appId, appPerms]) => {
            const app = (installedApps || []).find(a => a.id === appId);
            const name = app ? app.name : appId;
            const icon = app ? (app.icon || '📱') : '📱';
            const isImg = icon.startsWith('data');
            const iconHtml = isImg ? `<img src="${icon}" style="width:100%;height:100%;object-fit:cover;">` : icon;

            const chips = Object.entries(appPerms).map(([perm, granted]) => {
                const m = PERM_META[perm] || {icon:'🔑', label:perm};
                const bg = granted ? 'rgba(37,99,235,.25)' : 'rgba(255,255,255,.05)';
                const border = granted ? '#3b82f6' : '#334155';
                const col = granted ? '#93c5fd' : '#64748b';
                return `<button onclick="toggleAppPerm('${appId}','${perm}')" style="padding:3px 9px;border-radius:8px;border:1px solid ${border};background:${bg};color:${col};font-size:11px;font-weight:700;cursor:pointer;">${m.icon} ${m.label} ${granted?'✓':'✗'}</button>`;
            }).join('');

            return `<div style="background:rgba(255,255,255,.03);border:1px solid #1e293b;border-radius:12px;padding:12px;margin-bottom:8px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:9px;">
                    <div style="display:flex;align-items:center;gap:9px;">
                        <div style="width:30px;height:30px;border-radius:8px;background:#1e293b;display:flex;align-items:center;justify-content:center;overflow:hidden;font-size:15px;flex-shrink:0;">${iconHtml}</div>
                        <span style="font-weight:700;font-size:13px;">${name}</span>
                    </div>
                    <button onclick="revokeAppPerms('${appId}')" style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:#fca5a5;padding:3px 9px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;">Revoke All</button>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:5px;">${chips}</div>
            </div>`;
        }).join('');
    }

    window.toggleAppPerm = (appId, perm) => {
        const p = userSettings.appPermissions;
        if (!p || !p[appId]) return;
        p[appId][perm] = !p[appId][perm];
        saveSettings();
        renderPerAppPerms();
    };

    window.revokeAppPerms = (appId) => {
        const p = userSettings.appPermissions?.[appId];
        if (p) Object.keys(p).forEach(k => p[k] = false);
        saveSettings();
        renderPerAppPerms();
        notify('Permissions', 'All permissions revoked');
    };

    window.clearAllPerms = () => {
        if (!confirm('Reset all app permissions? Apps will ask again on next launch.')) return;
        userSettings.appPermissions = {};
        saveSettings();
        renderPerAppPerms();
        notify('Permissions Reset', 'All app permissions cleared');
    };

    // Wrap switchSettingsTab to sync privacy UI when opening that tab
    (() => {
        const _orig = window.switchSettingsTab;
        window.switchSettingsTab = (tab) => {
            _orig(tab);
            if (tab === 'privacy') syncPrivacyUI();
        };
    })();

    // =====================================================
    // APP PERMISSION PROMPT SYSTEM
    // =====================================================

    let _permResolve = null;

    // Scan app content to detect which permissions it needs
    function detectRequestedPerms(app) {
        const src = (app.code || '') + (app.files || []).map(f => f.content || f.data || '').join(' ');
        const req = {};
        if (/getUserMedia|AudioContext|MediaRecorder/i.test(src))          req.mic = false;
        if (/getUserMedia.*video|facingMode|videoWidth/i.test(src))        req.cam = false;
        if (/geolocation|getCurrentPosition|watchPosition/i.test(src))    req.loc = false;
        if (/clipboard\.write|clipboard\.read|execCommand.*copy/i.test(src)) req.clipboard = false;
        if (/HyFiles|fileSystem|hyos_fs/i.test(src))                       req.files = false;
        // JSON-based permissions — scan .json files
        (app.files || []).filter(f => f.name?.endsWith('.json')).forEach(f => {
            try {
                const cfg = JSON.parse(f.content || '{}');
                const act = cfg.systemaction || cfg.systemAction;
                if (act === 'notify')       req.notif = false;
                if (act === 'setWallpaper') req.wallpaper = false;
            } catch(e) {}
        });
        // .hl files — read JSONActions for permissions
        (app.files || []).filter(f => f.name?.endsWith('.hl')).forEach(f => {
            try {
                const hl = JSON.parse(f.content || f.data || '{}');
                (hl.JSONActions || []).forEach(action => {
                    const act = action.systemaction || action.systemAction || action.action;
                    if (act === 'notify')       req.notif = false;
                    if (act === 'setWallpaper') req.wallpaper = false;
                });
            } catch(e) {}
        });
        // Mani.manifest permissions array — most explicit source
        const manifest = (app.files || []).find(f => f.name === 'Mani.manifest');
        if (manifest) {
            try {
                const mani = JSON.parse(manifest.content || manifest.data || '{}');
                (mani.permissions || []).forEach(p => {
                    const key = p.toLowerCase();
                    if (key in GLOBAL_KEY) req[key] = false;
                });
            } catch(e) {}
        }
        // Also detect inline JSON action strings in code
        if (/"systemaction"\s*:\s*"notify"|"systemAction"\s*:\s*"notify"/i.test(src))           req.notif = false;
        if (/"systemaction"\s*:\s*"setWallpaper"|"systemAction"\s*:\s*"setWallpaper"/i.test(src)) req.wallpaper = false;
        return req;
    }

    // Global setting key for each permission
    const GLOBAL_KEY = {mic:'allowMicrophone', cam:'allowCamera', loc:'allowLocation', notif:'allowNotifications', wallpaper:'allowWallpaper', clipboard:'allowClipboard', files:'allowFiles'};

    // Full copy for permission prompt labels
    const PERM_COPY = {
        mic:       {label:'Access microphone',  desc:'Record audio from your device'},
        cam:       {label:'Access camera',       desc:'Use your device camera'},
        loc:       {label:'Access location',     desc:'Know your geographic location'},
        notif:     {label:'Send notifications',  desc:'Push system notifications via JSON config',  tag:'JSON'},
        wallpaper: {label:'Set wallpaper',        desc:'Change your desktop wallpaper via JSON config', tag:'JSON'},
        clipboard: {label:'Clipboard access',    desc:'Read and write clipboard content'},
        files:     {label:'HyFiles access',      desc:'Read and write files in your HyFiles storage'}
    };

    function showPermPrompt(app, requested) {
        return new Promise(resolve => {
            // Filter to only perms not globally blocked
            const perms = Object.keys(requested).filter(p => userSettings[GLOBAL_KEY[p] || ''] !== false);

            if (!perms.length) { resolve({}); return; }

            const icon = app.icon || '📱';
            const isImg = icon.startsWith('data');
            document.getElementById('apo-icon').innerHTML = isImg
                ? `<img src="${icon}" style="width:100%;height:100%;object-fit:cover;">`
                : `<span style="font-size:26px;">${icon}</span>`;
            document.getElementById('apo-name').textContent = app.name;

            document.getElementById('apo-list').innerHTML = perms.map(p => {
                const m = PERM_META[p] || {icon:'🔑', label:p};
                const c = PERM_COPY[p] || {label:p, desc:''};
                const tag = c.tag ? `<span style="font-size:9px;background:rgba(37,99,235,.35);padding:1px 6px;border-radius:4px;font-weight:800;margin-left:6px;vertical-align:middle">${c.tag}</span>` : '';
                return `<label style="display:flex;align-items:flex-start;gap:12px;background:rgba(255,255,255,.04);border:1px solid #1e293b;border-radius:11px;padding:12px;cursor:pointer;">
                    <input type="checkbox" id="apc-${p}" checked style="width:16px;height:16px;margin-top:2px;accent-color:#2563eb;flex-shrink:0;cursor:pointer;">
                    <div>
                        <div style="font-weight:700;font-size:13px;">${m.icon} ${c.label}${tag}</div>
                        <div style="font-size:11px;opacity:.5;margin-top:2px;">${c.desc}</div>
                    </div>
                </label>`;
            }).join('');

            document.getElementById('app-perm-overlay').style.display = 'flex';

            _permResolve = (allow) => {
                document.getElementById('app-perm-overlay').style.display = 'none';
                if (!allow) { resolve({}); return; }
                const granted = {};
                perms.forEach(p => {
                    const cb = document.getElementById('apc-' + p);
                    granted[p] = cb ? cb.checked : false;
                });
                resolve(granted);
            };
        });
    }

    window.resolveAppPerm = (allow) => {
        if (_permResolve) { _permResolve(allow); _permResolve = null; }
    };

    function saveAppPerms(appId, granted) {
        if (!userSettings.appPermissions) userSettings.appPermissions = {};
        if (!userSettings.appPermissions[appId]) userSettings.appPermissions[appId] = {};
        Object.assign(userSettings.appPermissions[appId], granted);
        saveSettings();
        renderPerAppPerms();
    }

    // =====================================================
    // PATCHED launchApp — async, shows permission prompt
    // =====================================================
    window.launchApp = async (app) => {
        if (app.id === 'media-viewer-system' || app.isSystemApp) {
            openMediaViewer(); return;
        }

        // Block unknown apps if that setting is on
        if (userSettings.blockUnknownApps && !installedApps.find(a => a.id === app.id)) {
            notify('Blocked', `${app.name} was blocked — install it from the Store or disable "Block unknown apps" in Privacy Settings.`);
            return;
        }

        // AGE CHECK
        const ageStatus = window.getAppAgeStatus ? window.getAppAgeStatus(app) : 'ok';
        if (ageStatus === 'inaccessible') {
            notify('Inaccessible', `${app.name} has no age rating set by the creator and cannot be opened.`);
            return;
        }
        if (ageStatus === 'age-blocked') {
            notify('Age Restricted', `${app.name} requires you to be ${app.ageLimit}+ to open.`);
            return;
        }
        if (ageStatus === 'age-unknown') {
            notify('Age Required', `Please set your age before opening age-restricted apps.`);
            showAgeGateModal();
            return;
        }

        // Show permission prompt if first launch and app requests perms
        const requested = detectRequestedPerms(app);
        const hasReqs = Object.keys(requested).length > 0;
        const alreadyDecided = !!(userSettings.appPermissions && userSettings.appPermissions[app.id]);

        if (hasReqs && !alreadyDecided) {
            const granted = await showPermPrompt(app, requested);
            saveAppPerms(app.id, granted);
        }

        const winId = 'app-' + Date.now();
        const win = document.createElement('div');
        win.id = winId;
        win.className = 'window';
        win.style.cssText = 'width: 800px; height: 600px; left: 50%; top: 50%; transform: translate(-50%, -50%); display: flex;';
        
        const isImg = app.icon?.startsWith('data');

        // ── Native mode: inject .hyh directly (no iframe) ────────────────
        if (window.HyNative && window.HyNative.isNative(app)) {
            win.innerHTML = `
                <div class="win-header">
                    <div class="flex items-center gap-2">
                        <div class="icon-box !w-6 !h-6">${isImg ? `<img src="${app.icon}">` : `<span class="text-sm">${app.icon}</span>`}</div>
                        <span class="font-bold text-sm">${app.name}</span>
                        <span style="font-size:9px;background:rgba(34,197,94,0.2);color:#4ade80;padding:1px 6px;border-radius:4px;font-weight:700;">NATIVE</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="minWin('${winId}')" class="hover:bg-white/10 px-3 py-1 rounded">−</button>
                        <button onclick="maxWin('${winId}')" class="hover:bg-white/10 px-3 py-1 rounded">⬜</button>
                        <button onclick="closeActualApp('${app.id}','${winId}')" class="hover:bg-red-600 px-3 py-1 rounded">✕</button>
                    </div>
                </div>
                <div class="win-body"></div>
                <div class="resizer"></div>
            `;
            document.getElementById('desktop').appendChild(win);
            makeDraggable(win);
            openApps[app.id] = winId;
            window.HyNative.load(app, winId);
            return;
        }

        // Check if Srcdoc mode is enabled (default: disabled)
        const useSrcdoc = userSettings.useSrcdoc || false;
        
        let iframeHTML = '';
        
        if (useSrcdoc) {
            // Srcdoc mode: Use sandboxed srcdoc iframe without same-origin (prevents OS conflicts)
            iframeHTML = `<iframe srcdoc="${app.code.replace(/"/g, '&quot;')}" sandbox="allow-scripts allow-forms allow-modals allow-popups"></iframe>`;
        } else {
            // Advanced mode: Support JSON, Python, React, HL files (requires same-origin)
            // Create a blob URL for the app code
            const blob = new Blob([app.code], { type: 'text/html' });
            const blobURL = URL.createObjectURL(blob);
            
            iframeHTML = `<iframe src="${blobURL}" sandbox="allow-scripts allow-same-origin allow-forms allow-modals allow-popups" data-app-id="${app.id}"></iframe>`;
            
            // Store blob URL for cleanup later
            if (!window.appBlobURLs) window.appBlobURLs = {};
            window.appBlobURLs[winId] = blobURL;
        }
        
        win.innerHTML = `
            <div class="win-header">
                <div class="flex items-center gap-2">
                    <div class="icon-box !w-6 !h-6">${isImg ? `<img src="${app.icon}">` : `<span class="text-sm">${app.icon}</span>`}</div>
                    <span class="font-bold text-sm">${app.name}</span>
                </div>
                <div class="flex gap-2">
                    <button onclick="minWin('${winId}')" class="hover:bg-white/10 px-3 py-1 rounded">−</button>
                    <button onclick="maxWin('${winId}')" class="hover:bg-white/10 px-3 py-1 rounded">⬜</button>
                    <button onclick="closeActualApp('${app.id}','${winId}')" class="hover:bg-red-600 px-3 py-1 rounded">✕</button>
                </div>
            </div>
            <div class="win-body">${iframeHTML}</div>
            <div class="resizer"></div>
        `;
        
        document.getElementById('os-surface').appendChild(win);
        setupDrags();
        openApps[app.id] = winId;
        addTaskbarBtn(app.id, app.name, winId);
        updateTaskManager();
        
        if (app.genre === 'gaming' && userSettings.enableGameBar) showGameBar();
    };

    // =====================================================
    // PATCHED executeJSONAction — permission gate for JSON actions
    // =====================================================
    (() => {
        const _orig = AppBuilder.executeJSONAction.bind(AppBuilder);
        AppBuilder.executeJSONAction = function(config, previewMode, callerAppId) {
            const action = config.systemaction || config.systemAction;

            // Gate: notify
            if (action === 'notify' && !previewMode) {
                if (!userSettings.allowNotifications) {
                    notify('Blocked', 'Notifications are globally disabled in Privacy Settings'); return;
                }
                if (callerAppId) {
                    const p = userSettings.appPermissions?.[callerAppId];
                    if (p && p.notif === false) {
                        notify('Blocked', 'App notification permission was denied'); return;
                    }
                }
            }

            // Gate: setWallpaper
            if (action === 'setWallpaper' && !previewMode) {
                if (!userSettings.allowWallpaper) {
                    notify('Blocked', 'Wallpaper changes are globally disabled in Privacy Settings'); return;
                }
                if (callerAppId) {
                    const p = userSettings.appPermissions?.[callerAppId];
                    if (p && p.wallpaper === false) {
                        notify('Blocked', 'App wallpaper permission was denied'); return;
                    }
                }
            }

            _orig(config, previewMode);
        };
    })();

    // =====================================================
    // STATUS BAR FUNCTIONALITY
    // =====================================================
    
    // Update date and time
    function updateDateTime() {
        const now = new Date();
        const options = { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        document.getElementById('statusbar-datetime').textContent = now.toLocaleDateString('en-US', options);
    }
    
    // Start datetime clock
    setInterval(updateDateTime, 1000);
    updateDateTime();
    
    // Toggle Services Menu
    window.toggleServicesMenu = function(event) {
        event.stopPropagation();
        const menu = document.getElementById('services-menu');
        const rect = event.currentTarget.getBoundingClientRect();
        
        // Close other panels
        document.getElementById('notification-panel').style.display = 'none';
        document.getElementById('hyley-panel').style.display = 'none';
        
        if (menu.style.display === 'block') {
            menu.style.display = 'none';
        } else {
            menu.style.display = 'block';
            menu.style.top = '45px';
            menu.style.left = rect.left + 'px';
        }
    };
    
    // Toggle Notifications Panel
    window.toggleNotifications = function(event) {
        event.stopPropagation();
        const panel = document.getElementById('notification-panel');
        
        // Close other panels
        document.getElementById('services-menu').style.display = 'none';
        document.getElementById('hyley-panel').style.display = 'none';
        
        if (panel.style.display === 'flex') {
            panel.style.display = 'none';
        } else {
            panel.style.display = 'flex';
        }
    };
    
    // Clear all notifications
    window.clearNotifications = function() {
        const list = document.getElementById('notification-list');
        list.innerHTML = '<div class="notification-item" style="text-align: center; opacity: 0.5; padding: 40px;">No notifications</div>';
        document.getElementById('notif-badge').style.display = 'none';
    };
    
    // Add notification to panel
    window.addNotificationToPanel = function(title, message) {
        const list = document.getElementById('notification-list');
        
        // Remove "no notifications" message if present
        if (list.querySelector('div[style*="No notifications"]')) {
            list.innerHTML = '';
        }
        
        const notifItem = document.createElement('div');
        notifItem.className = 'notification-item';
        notifItem.innerHTML = `
            <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
            <div style="font-size: 11px; opacity: 0.7;">${message}</div>
            <div style="font-size: 10px; opacity: 0.5; margin-top: 6px;">${new Date().toLocaleTimeString()}</div>
        `;
        
        list.insertBefore(notifItem, list.firstChild);
        
        // Update badge
        const badge = document.getElementById('notif-badge');
        const count = list.querySelectorAll('.notification-item').length;
        badge.textContent = count > 99 ? '99+' : count;
        badge.style.display = 'inline-block';
    };
    
    // Update original notify function to also add to panel
    const originalNotify = window.notify;
    window.notify = function(title, message) {
        originalNotify(title, message);
        addNotificationToPanel(title, message);
    };
    
    // Set status bar action (for apps)
    window.setStatusBarAction = function(icon, text) {
        document.getElementById('statusbar-app-icon').textContent = icon;
        document.getElementById('statusbar-app-text').textContent = text;
        document.getElementById('statusbar-app-action').style.display = 'flex';
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            document.getElementById('statusbar-app-action').style.display = 'none';
        }, 3000);
    };
    
    // =====================================================
    // HYLEY ASSISTANT
    // =====================================================
    
    // Hyley's knowledge base
