// hypeople.js — HyPeople: Users & Requests App for HyOS HS
// Features: Browse users, send/receive friend requests (with button notifications),
//           friends-only chat, and add friend to App Builder project.

// ══════════════════════════════════════════════════════════════════════
// ACTION NOTIFICATION — extends the existing notification system
// Adds notifications with clickable Accept / Decline style buttons
// ══════════════════════════════════════════════════════════════════════
window.addActionNotification = function(title, message, actions = []) {
    const list = document.getElementById('notification-list');
    if (!list) return;

    // Clear placeholder
    const placeholder = list.querySelector('[data-notif-placeholder]');
    if (placeholder) placeholder.remove();

    const item = document.createElement('div');
    item.className = 'notification-item';
    item.dataset.notifId = 'action_' + Date.now();

    const btnHTML = actions.map(a =>
        `<button onclick="${a.onclick}" style="padding:5px 14px;border-radius:7px;background:${a.bg};border:1px solid ${a.border};color:${a.color};font-size:11px;font-weight:700;cursor:pointer;transition:0.15s;">${a.label}</button>`
    ).join('');

    item.innerHTML = `
        <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px;">
            <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:14px;">👥</div>
            <div style="flex:1;">
                <div style="font-weight:700;font-size:12px;margin-bottom:2px;">${title}</div>
                <div style="font-size:11px;opacity:0.7;">${message}</div>
            </div>
        </div>
        <div style="display:flex;gap:7px;padding-left:42px;">${btnHTML}</div>
        <div style="font-size:10px;opacity:0.4;margin-top:7px;padding-left:42px;">${new Date().toLocaleTimeString()}</div>
    `;

    list.insertBefore(item, list.firstChild);

    // Update badge
    const badge = document.getElementById('notif-badge');
    if (badge) {
        const count = list.querySelectorAll('.notification-item').length;
        badge.textContent = count > 99 ? '99+' : count;
        badge.style.display = 'inline-block';
    }

    // Friend-request toast popup (special styled, not regular toast)
    _showFriendReqToast(title, message, actions);
};

// Special friend-request popup toast with action buttons
function _showFriendReqToast(title, message, actions) {
    const existing = document.getElementById('hypeople-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'hypeople-toast';
    toast.style.cssText = `
        position:fixed;top:52px;right:14px;z-index:99998;
        background:rgba(8,14,28,0.97);border:1px solid rgba(37,99,235,0.45);
        border-radius:18px;padding:16px 18px;width:310px;
        box-shadow:0 12px 50px rgba(0,0,0,0.7),0 0 0 1px rgba(37,99,235,0.1);
        backdrop-filter:blur(24px);
        animation:_hpSlideIn 0.3s cubic-bezier(0.34,1.56,0.64,1);
    `;

    const btnHTML = actions.map(a =>
        `<button onclick="${a.onclick};document.getElementById('hypeople-toast')?.remove()" style="padding:7px 18px;border-radius:9px;background:${a.bg};border:1px solid ${a.border};color:${a.color};font-size:12px;font-weight:700;cursor:pointer;">${a.label}</button>`
    ).join('');

    toast.innerHTML = `
        <style>
            @keyframes _hpSlideIn { from { opacity:0;transform:translateX(30px) scale(0.95); } to { opacity:1;transform:none; } }
        </style>
        <button onclick="this.parentElement.remove()" style="position:absolute;top:10px;right:12px;background:none;border:none;color:rgba(255,255,255,0.3);font-size:14px;cursor:pointer;line-height:1;">✕</button>
        <div style="display:flex;align-items:center;gap:11px;margin-bottom:12px;">
            <div style="width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">👋</div>
            <div>
                <div style="font-size:12px;font-weight:800;">${title}</div>
                <div style="font-size:11px;opacity:0.6;margin-top:1px;">${message}</div>
            </div>
        </div>
        <div style="display:flex;gap:8px;">${btnHTML}</div>
    `;

    document.body.appendChild(toast);
    setTimeout(() => toast?.remove(), 18000);
}

// ══════════════════════════════════════════════════════════════════════
// HYPEOPLE APP
// ══════════════════════════════════════════════════════════════════════
window.HyPeople = {
    _win: null,
    _activeTab: 'people',
    _chatWith: null,
    _chatSub: null,
    _reqSub: null,
    _allUsers: [],
    _friends: [],
    _pendingReqCount: 0,

    // ── Window Management ────────────────────────────────────────────
    open() {
        if (this._win) {
            this._win.style.display = 'flex';
            if (typeof focusWindow === 'function') focusWindow('hypeople-win');
            this.switchTab(this._activeTab);
            return;
        }
        this._inject();
        this._startListeners();
        this.switchTab('people');
    },

    close() {
        if (this._win) this._win.style.display = 'none';
        if (this._chatSub)  { try { this._chatSub(); } catch(e) {} this._chatSub = null; }
        if (this._reqSub)   { try { this._reqSub();  } catch(e) {} this._reqSub  = null; }
    },

    _inject() {
        const win = document.createElement('div');
        win.id        = 'hypeople-win';
        win.className = 'window';
        win.style.cssText = 'width:860px;height:580px;left:calc(50% - 430px);top:calc(50% - 290px);display:flex;flex-direction:column;min-width:600px;min-height:400px;';
        win.innerHTML = `
            <div class="win-header" style="background:rgba(6,11,22,0.98);">
                <div style="display:flex;align-items:center;gap:9px;">
                    <div style="width:24px;height:24px;border-radius:7px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:13px;">👥</div>
                    <span style="font-weight:800;font-size:13px;letter-spacing:-0.3px;">Users & Requests</span>
                </div>
                <div class="flex gap-2">
                    <button onclick="minWin('hypeople-win')" class="hover:bg-white/10 px-3 py-1 rounded">−</button>
                    <button onclick="maxWin('hypeople-win')" class="hover:bg-white/10 px-3 py-1 rounded">⛶</button>
                    <button onclick="HyPeople.close()" class="hover:bg-red-600 px-3 py-1 rounded">✕</button>
                </div>
            </div>
            <div class="win-body" style="display:flex;overflow:hidden;padding:0;flex:1;">
                <!-- Sidebar -->
                <div style="width:196px;border-right:1px solid rgba(255,255,255,0.06);display:flex;flex-direction:column;background:rgba(0,0,0,0.18);flex-shrink:0;padding:8px 6px;">
                    <div style="padding:10px 10px 6px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:1.2px;opacity:0.35;color:#93c5fd;">SOCIAL</div>
                    ${this._navBtn('people',   '🔍', 'People')}
                    ${this._navBtn('requests', '📨', 'Requests', 'hp-req-badge')}
                    ${this._navBtn('friends',  '👫', 'Friends')}
                    ${this._navBtn('chat',     '💬', 'Chat')}
                    <div style="flex:1;"></div>
                    <div style="padding:8px;border-top:1px solid rgba(255,255,255,0.06);margin-top:8px;">
                        <div id="hp-backend-pill" style="font-size:9px;padding:4px 8px;border-radius:6px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.25);color:#86efac;text-align:center;font-weight:700;cursor:pointer;" onclick="HyPeople._cycleBackend()">⚡ Auto</div>
                    </div>
                </div>
                <!-- Content -->
                <div id="hp-content" style="flex:1;overflow:hidden;display:flex;flex-direction:column;position:relative;"></div>
            </div>
            <div class="resizer"></div>
        `;
        document.getElementById('os-surface').appendChild(win);
        if (typeof setupDrags === 'function') setupDrags();
        this._win = win;
        this._updateBackendPill();
    },

    _navBtn(tab, icon, label, badgeId) {
        return `
            <button id="hp-tab-${tab}" onclick="HyPeople.switchTab('${tab}')"
                style="display:flex;align-items:center;gap:9px;padding:9px 10px;border:none;background:transparent;color:white;cursor:pointer;text-align:left;width:100%;font-size:12px;font-weight:500;border-radius:9px;margin-bottom:2px;transition:background 0.15s;">
                <span style="font-size:15px;width:20px;text-align:center;">${icon}</span>
                <span style="flex:1;">${label}</span>
                ${badgeId ? `<span id="${badgeId}" style="display:none;background:#ef4444;color:white;border-radius:10px;min-width:18px;height:18px;line-height:18px;text-align:center;padding:0 5px;font-size:9px;font-weight:800;"></span>` : ''}
            </button>
        `;
    },

    switchTab(tab) {
        this._activeTab = tab;
        ['people','requests','friends','chat'].forEach(t => {
            const btn = document.getElementById('hp-tab-' + t);
            if (btn) btn.style.background = t === tab
                ? 'rgba(37,99,235,0.28)' : 'transparent';
        });
        if (tab === 'people')   this.renderPeople();
        if (tab === 'requests') this.renderRequests();
        if (tab === 'friends')  this.renderFriends();
        if (tab === 'chat')     this.renderChatTab();
    },

    // ── Backend pill ─────────────────────────────────────────────────
    _updateBackendPill() {
        const pill = document.getElementById('hp-backend-pill');
        if (!pill || !window.HyBackend) return;
        const s = window.HyBackend.status();
        const labels = { auto: '⚡ Auto', supabase: '🟢 Supabase', firebase: '🔥 Firebase' };
        pill.textContent = labels[s.preference] || '⚡ Auto';
    },
    _cycleBackend() {
        if (!window.HyBackend) return;
        const order = ['auto','supabase','firebase'];
        const cur   = window.HyBackend.getPreference();
        const next  = order[(order.indexOf(cur) + 1) % order.length];
        window.HyBackend.setPreference(next);
        this._updateBackendPill();
    },

    // ── PEOPLE TAB ───────────────────────────────────────────────────
    async renderPeople() {
        const c = document.getElementById('hp-content');
        if (!c) return;
        c.innerHTML = `
            <div style="padding:16px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.06);">
                <div style="font-size:13px;font-weight:700;margin-bottom:10px;">Browse Users</div>
                <div style="position:relative;">
                    <span style="position:absolute;left:11px;top:50%;transform:translateY(-50%);opacity:0.35;font-size:12px;">🔍</span>
                    <input id="hp-search" type="text" placeholder="Search by username…" oninput="HyPeople._filterPeople(this.value)"
                        style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:8px 12px 8px 32px;color:white;font-size:12px;outline:none;">
                </div>
            </div>
            <div id="hp-users-wrap" style="flex:1;overflow-y:auto;padding:14px 18px;">
                <div style="opacity:0.4;font-size:12px;text-align:center;padding:30px;">Loading users…</div>
            </div>
        `;
        await this._loadPeople();
    },

    async _loadPeople() {
        const me = this._me();
        if (!window.sbSocial) {
            const wrap = document.getElementById('hp-users-wrap');
            if (wrap) wrap.innerHTML = '<div style="opacity:0.4;font-size:12px;text-align:center;padding:40px;">⚠️ Social backend not connected.<br>Sign in or connect a backend to browse users.</div>';
            return;
        }
        const [{ data: users }, { data: friends }, { data: outgoing }] = await Promise.all([
            window.sbSocial.getAllUsers(me),
            window.sbSocial.getFriends(me),
            window.sbSocial.getOutgoing(me)
        ]);
        this._allUsers  = users   || [];
        this._friends   = friends || [];
        const friendSet  = new Set(this._friends);
        const pendingSet = new Set((outgoing||[]).map(r => r.to_user || r.to));
        this._renderPeopleGrid(this._allUsers, friendSet, pendingSet);
    },

    _renderPeopleGrid(users, friendSet, pendingSet) {
        const wrap = document.getElementById('hp-users-wrap');
        if (!wrap) return;
        if (!users.length) {
            wrap.innerHTML = '<div style="opacity:0.4;font-size:12px;text-align:center;padding:40px;">No users found.</div>';
            return;
        }
        const cards = users.map(u => {
            const name   = u.username;
            const isFriend  = friendSet  && friendSet.has(name);
            const isPending = pendingSet && pendingSet.has(name);
            const initials = name.slice(0,2).toUpperCase();
            const bg = ['#1d4ed8','#6d28d9','#065f46','#92400e','#9f1239','#0e7490'][name.charCodeAt(0) % 6];

            let btn;
            if (isFriend) {
                btn = `<button disabled style="padding:5px 12px;background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac;border-radius:8px;font-size:10px;font-weight:700;">✓ Friends</button>`;
            } else if (isPending) {
                btn = `<button disabled style="padding:5px 12px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.35);border-radius:8px;font-size:10px;font-weight:600;">Pending…</button>`;
            } else {
                btn = `<button onclick="HyPeople.sendRequest('${name}')" style="padding:5px 12px;background:rgba(37,99,235,0.22);border:1px solid rgba(37,99,235,0.4);color:#93c5fd;border-radius:8px;font-size:10px;font-weight:700;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(37,99,235,0.4)'" onmouseout="this.style.background='rgba(37,99,235,0.22)'">+ Add Friend</button>`;
            }

            return `
                <div style="display:flex;align-items:center;gap:12px;padding:11px 14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:13px;margin-bottom:7px;transition:background 0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.06)'" onmouseout="this.style.background='rgba(255,255,255,0.03)'">
                    <div style="width:36px;height:36px;border-radius:50%;background:${bg};display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:white;flex-shrink:0;">${initials}</div>
                    <div style="flex:1;">
                        <div style="font-size:13px;font-weight:600;">${name}</div>
                        ${u.display_name ? `<div style="font-size:10px;opacity:0.4;">${u.display_name}</div>` : ''}
                    </div>
                    ${btn}
                </div>`;
        }).join('');
        wrap.innerHTML = cards;
    },

    _filterPeople(q) {
        const lo = q.toLowerCase();
        const filtered = this._allUsers.filter(u => u.username.toLowerCase().includes(lo));
        this._renderPeopleGrid(filtered, new Set(this._friends), new Set());
    },

    async sendRequest(toUser) {
        const me = this._me();
        if (!me || me === 'Guest') return typeof notify === 'function' && notify('HyPeople', 'Sign in to send friend requests.');
        if (!window.sbSocial) return;
        const { error } = await window.sbSocial.sendRequest(me, toUser);
        if (error && error !== null && typeof error === 'object' && error.message) {
            return typeof notify === 'function' && notify('HyPeople', 'Error: ' + error.message);
        }
        typeof notify === 'function' && notify('📨 Friend Request', `Request sent to ${toUser}!`);
        await this._loadPeople();
    },

    // ── REQUESTS TAB ─────────────────────────────────────────────────
    async renderRequests() {
        const c = document.getElementById('hp-content');
        if (!c) return;
        c.innerHTML = `
            <div style="padding:16px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.06);">
                <div style="font-size:13px;font-weight:700;">Incoming Friend Requests</div>
            </div>
            <div id="hp-req-list" style="flex:1;overflow-y:auto;padding:14px 18px;">
                <div style="opacity:0.4;font-size:12px;text-align:center;padding:30px;">Loading…</div>
            </div>
        `;
        const me = this._me();
        const { data: reqs } = await window.sbSocial.getIncoming(me);
        const list = document.getElementById('hp-req-list');
        if (!list) return;

        if (!reqs || !reqs.length) {
            list.innerHTML = `
                <div style="text-align:center;padding:50px 20px;opacity:0.45;">
                    <div style="font-size:32px;margin-bottom:10px;">🎉</div>
                    <div style="font-size:13px;font-weight:600;">All caught up!</div>
                    <div style="font-size:11px;margin-top:4px;">No pending friend requests.</div>
                </div>`;
            return;
        }

        list.innerHTML = reqs.map(r => {
            const from = r.from_user || r.from;
            const bg   = ['#1d4ed8','#6d28d9','#065f46','#92400e'][from.charCodeAt(0) % 4];
            return `
                <div id="hp-req-card-${r.id}" style="display:flex;align-items:center;gap:14px;padding:14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;margin-bottom:9px;">
                    <div style="width:42px;height:42px;border-radius:50%;background:${bg};display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:800;color:white;flex-shrink:0;">${from.slice(0,2).toUpperCase()}</div>
                    <div style="flex:1;">
                        <div style="font-size:13px;font-weight:700;">${from}</div>
                        <div style="font-size:11px;opacity:0.45;margin-top:2px;">wants to be your friend</div>
                    </div>
                    <button onclick="HyPeople.acceptRequest('${r.id}','${from}')" style="padding:7px 15px;background:rgba(34,197,94,0.18);border:1px solid rgba(34,197,94,0.4);color:#86efac;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(34,197,94,0.32)'" onmouseout="this.style.background='rgba(34,197,94,0.18)'">Accept</button>
                    <button onclick="HyPeople.declineRequest('${r.id}')" style="padding:7px 14px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;border-radius:9px;font-size:11px;font-weight:700;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(239,68,68,0.25)'" onmouseout="this.style.background='rgba(239,68,68,0.12)'">Decline</button>
                </div>`;
        }).join('');

        this._updateReqBadge(reqs.length);
    },

    async acceptRequest(requestId, fromUser) {
        const me = this._me();
        await window.sbSocial.respondToRequest(requestId, 'accepted');
        await window.sbSocial.addFriendship(me, fromUser);
        typeof notify === 'function' && notify('👫 New Friend!', `You and ${fromUser} are now friends.`);
        document.getElementById('hp-req-card-' + requestId)?.remove();
        this._pendingReqCount = Math.max(0, this._pendingReqCount - 1);
        this._updateReqBadge(this._pendingReqCount);
        // Remove from toast if open
        document.getElementById('hypeople-toast')?.remove();
    },

    async declineRequest(requestId) {
        await window.sbSocial.respondToRequest(requestId, 'declined');
        document.getElementById('hp-req-card-' + requestId)?.remove();
        this._pendingReqCount = Math.max(0, this._pendingReqCount - 1);
        this._updateReqBadge(this._pendingReqCount);
        document.getElementById('hypeople-toast')?.remove();
    },

    _updateReqBadge(count) {
        this._pendingReqCount = count;
        // Notification panel badge inside People window
        const b = document.getElementById('hp-req-badge');
        if (b) { b.textContent = count; b.style.display = count > 0 ? 'inline-block' : 'none'; }
        // Taskbar People button badge
        const tb = document.getElementById('taskbar-people-badge');
        if (tb) { tb.textContent = count; tb.style.display = count > 0 ? 'inline-block' : 'none'; }
    },

    // ── FRIENDS TAB ──────────────────────────────────────────────────
    async renderFriends() {
        const c = document.getElementById('hp-content');
        if (!c) return;
        c.innerHTML = `
            <div style="padding:16px 18px 10px;border-bottom:1px solid rgba(255,255,255,0.06);">
                <div style="font-size:13px;font-weight:700;">My Friends</div>
            </div>
            <div id="hp-friends-list" style="flex:1;overflow-y:auto;padding:14px 18px;">
                <div style="opacity:0.4;font-size:12px;text-align:center;padding:30px;">Loading…</div>
            </div>
        `;
        const me = this._me();
        const { data: friends } = await window.sbSocial.getFriends(me);
        this._friends = friends || [];

        const list = document.getElementById('hp-friends-list');
        if (!list) return;

        if (!this._friends.length) {
            list.innerHTML = `
                <div style="text-align:center;padding:50px 20px;opacity:0.45;">
                    <div style="font-size:32px;margin-bottom:10px;">👋</div>
                    <div style="font-size:13px;font-weight:600;">No friends yet</div>
                    <div style="font-size:11px;margin-top:4px;">Head to <b>People</b> to add some!</div>
                </div>`;
            return;
        }

        list.innerHTML = this._friends.map(fname => {
            const bg = ['#1d4ed8','#6d28d9','#065f46','#92400e','#9f1239','#0e7490'][fname.charCodeAt(0) % 6];
            return `
                <div style="display:flex;align-items:center;gap:13px;padding:12px 14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:13px;margin-bottom:7px;transition:0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.06)'" onmouseout="this.style.background='rgba(255,255,255,0.03)'">
                    <div style="width:38px;height:38px;border-radius:50%;background:${bg};display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;color:white;flex-shrink:0;">${fname.slice(0,2).toUpperCase()}</div>
                    <div style="flex:1;">
                        <div style="font-size:13px;font-weight:600;">${fname}</div>
                        <div style="font-size:10px;color:#4ade80;margin-top:1px;">● Friend</div>
                    </div>
                    <button onclick="HyPeople.openChatWith('${fname}')" title="Chat" style="padding:6px 12px;background:rgba(37,99,235,0.18);border:1px solid rgba(37,99,235,0.3);color:#93c5fd;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(37,99,235,0.32)'" onmouseout="this.style.background='rgba(37,99,235,0.18)'">💬 Chat</button>
                    <button onclick="HyPeople.addToProject('${fname}')" title="Add to project" style="padding:6px 12px;background:rgba(124,58,237,0.18);border:1px solid rgba(124,58,237,0.3);color:#c4b5fd;border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(124,58,237,0.32)'" onmouseout="this.style.background='rgba(124,58,237,0.18)'">🔨 Project</button>
                    <button onclick="HyPeople._removeFriend('${fname}')" title="Remove friend" style="padding:6px 9px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#fca5a5;border-radius:8px;font-size:12px;cursor:pointer;transition:0.15s;" onmouseover="this.style.background='rgba(239,68,68,0.22)'" onmouseout="this.style.background='rgba(239,68,68,0.1)'">✕</button>
                </div>`;
        }).join('');
    },

    async _removeFriend(fname) {
        if (!confirm(`Remove ${fname} as a friend?`)) return;
        await window.sbSocial.removeFriendship(this._me(), fname);
        typeof notify === 'function' && notify('HyPeople', `Removed ${fname} from friends.`);
        this.renderFriends();
    },

    // ── CHAT TAB ─────────────────────────────────────────────────────
    async renderChatTab() {
        const c = document.getElementById('hp-content');
        if (!c) return;

        const me = this._me();
        const { data: friends } = await window.sbSocial.getFriends(me);
        this._friends = friends || [];

        c.innerHTML = `
            <div style="display:flex;height:100%;overflow:hidden;">
                <!-- Conversation list -->
                <div style="width:190px;border-right:1px solid rgba(255,255,255,0.06);display:flex;flex-direction:column;flex-shrink:0;">
                    <div style="padding:12px 14px 8px;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:1.2px;opacity:0.35;color:#93c5fd;">Conversations</div>
                    <div style="flex:1;overflow-y:auto;">
                        ${this._friends.length ? this._friends.map(f => `
                            <button id="hp-conv-${f}" onclick="HyPeople.openChatWith('${f}')"
                                style="display:flex;align-items:center;gap:9px;padding:9px 12px;width:100%;border:none;background:transparent;color:white;cursor:pointer;text-align:left;transition:0.15s;"
                                onmouseover="if(HyPeople._chatWith!=='${f}')this.style.background='rgba(255,255,255,0.05)'"
                                onmouseout="if(HyPeople._chatWith!=='${f}')this.style.background='transparent'">
                                <div style="width:30px;height:30px;border-radius:50%;background:#2563eb;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;flex-shrink:0;">${f.slice(0,2).toUpperCase()}</div>
                                <div style="font-size:12px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${f}</div>
                            </button>`).join('')
                        : '<div style="padding:16px;font-size:11px;opacity:0.35;text-align:center;">No friends yet</div>'}
                    </div>
                </div>
                <!-- Chat area -->
                <div id="hp-chat-area" style="flex:1;display:flex;flex-direction:column;overflow:hidden;">
                    <div style="flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;opacity:0.3;">
                        <div style="font-size:32px;">💬</div>
                        <div style="font-size:13px;font-weight:600;">Select a friend to chat</div>
                    </div>
                </div>
            </div>
        `;

        if (this._chatWith && this._friends.includes(this._chatWith)) {
            this.openChatWith(this._chatWith);
        }
    },

    async openChatWith(friendName) {
        this._chatWith = friendName;

        if (this._activeTab !== 'chat') {
            this.switchTab('chat');
            return;
        }

        // Highlight active conversation
        document.querySelectorAll('[id^="hp-conv-"]').forEach(b => b.style.background = 'transparent');
        const active = document.getElementById('hp-conv-' + friendName);
        if (active) active.style.background = 'rgba(37,99,235,0.2)';

        const area = document.getElementById('hp-chat-area');
        if (!area) return;

        const me = this._me();
        const bg = ['#1d4ed8','#6d28d9','#065f46','#92400e','#9f1239','#0e7490'][friendName.charCodeAt(0) % 6];

        area.innerHTML = `
            <div style="padding:11px 16px;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;align-items:center;gap:10px;flex-shrink:0;">
                <div style="width:28px;height:28px;border-radius:50%;background:${bg};display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;">${friendName.slice(0,2).toUpperCase()}</div>
                <span style="font-size:13px;font-weight:700;">${friendName}</span>
                <button onclick="HyPeople.addToProject('${friendName}')" style="margin-left:auto;padding:4px 10px;background:rgba(124,58,237,0.18);border:1px solid rgba(124,58,237,0.3);color:#c4b5fd;border-radius:7px;font-size:10px;font-weight:700;cursor:pointer;">🔨 Add to Project</button>
            </div>
            <div id="hp-messages" style="flex:1;overflow-y:auto;padding:12px 16px;display:flex;flex-direction:column;gap:5px;"></div>
            <div style="padding:9px 12px;border-top:1px solid rgba(255,255,255,0.06);display:flex;gap:8px;flex-shrink:0;">
                <input id="hp-msg-in" type="text" placeholder="Message ${friendName}…"
                    onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();HyPeople.sendMessage();}"
                    style="flex:1;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:8px 14px;color:white;font-size:12px;outline:none;">
                <button onclick="HyPeople.sendMessage()" style="padding:8px 16px;background:var(--blue-600,#2563eb);border:none;border-radius:10px;color:white;font-weight:800;cursor:pointer;font-size:13px;flex-shrink:0;">↑</button>
            </div>
        `;

        // Load history
        const { data: msgs } = await window.sbSocial.getMessages(me, friendName);
        (msgs || []).forEach(m => this._appendMsg(m.from_user || m.from, m.text, false));

        // Unsub old listener, sub new
        if (this._chatSub) { try { this._chatSub(); } catch(e) {} }
        this._chatSub = window.sbSocial.subscribeMessages(me, friendName, msg => {
            const fromUser = msg.from_user || msg.from;
            if (fromUser !== me) this._appendMsg(fromUser, msg.text, true);
        });
    },

    _appendMsg(from, text, animate) {
        const box = document.getElementById('hp-messages');
        if (!box) return;
        const me   = this._me();
        const isMe = from === me;
        const div  = document.createElement('div');
        div.style.cssText = `display:flex;justify-content:${isMe?'flex-end':'flex-start'};${animate?'animation:_hpMsgIn 0.2s ease;':''}`;
        div.innerHTML = `
            <div style="max-width:68%;padding:8px 12px;border-radius:${isMe?'14px 14px 4px 14px':'14px 14px 14px 4px'};background:${isMe?'rgba(37,99,235,0.45)':'rgba(255,255,255,0.07)'};font-size:12px;line-height:1.5;word-break:break-word;">
                ${!isMe ? `<div style="font-size:9px;font-weight:700;color:#60a5fa;margin-bottom:3px;text-transform:uppercase;letter-spacing:0.5px;">${from}</div>` : ''}
                ${text.replace(/</g,'&lt;').replace(/>/g,'&gt;')}
            </div>
        `;
        box.appendChild(div);
        box.scrollTop = box.scrollHeight;
    },

    async sendMessage() {
        const input = document.getElementById('hp-msg-in');
        const text  = input?.value?.trim();
        if (!text || !this._chatWith) return;
        const me = this._me();
        if (!me || me === 'Guest') return typeof notify === 'function' && notify('HyPeople', 'Sign in to send messages.');

        input.value = '';
        this._appendMsg(me, text, false);

        const { error } = await window.sbSocial.sendMessage(me, this._chatWith, text);
        if (error) typeof notify === 'function' && notify('Chat Error', String(error.message || error));
    },

    // ── ADD TO PROJECT ────────────────────────────────────────────────
    async addToProject(friendName) {
        const me = this._me();
        let projects = [];

        try {
            if (window.supabaseInitialized) {
                const { data } = await window.supabase.from('builder_projects').select('id, name').eq('owner', me);
                projects = data || [];
            } else if (window.firebaseInitialized) {
                const q = window._fb.query(window._fb.collection(window.db, 'builder_projects'), window._fb.where('owner', '==', me));
                const snap = await window._fb.getDocs(q);
                projects = snap.docs.map(d => ({ id: d.id, name: d.data().name || d.id }));
            }
        } catch(e) {
            typeof notify === 'function' && notify('HyPeople', 'Failed to load projects: ' + e.message);
            return;
        }

        if (!projects.length) {
            typeof notify === 'function' && notify('HyPeople', 'No App Builder projects found. Build something first!');
            return;
        }

        // Project picker overlay
        const overlay = document.createElement('div');
        overlay.id = 'hp-project-overlay';
        overlay.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,0.75);z-index:200;display:flex;align-items:center;justify-content:center;border-radius:inherit;backdrop-filter:blur(6px);';
        overlay.innerHTML = `
            <div style="background:#0a1020;border:1px solid rgba(255,255,255,0.12);border-radius:18px;padding:22px 24px;min-width:290px;max-width:360px;width:88%;">
                <div style="font-size:14px;font-weight:800;margin-bottom:5px;">Add ${friendName} to Project</div>
                <div style="font-size:11px;opacity:0.5;margin-bottom:16px;">Select a project to add them as a collaborator</div>
                <div style="display:flex;flex-direction:column;gap:6px;max-height:220px;overflow-y:auto;">
                    ${projects.map(p => `
                        <button onclick="HyPeople._doAddToProject('${p.id}','${(p.name||p.id).replace(/[^a-zA-Z0-9 ]/g,'')}','${friendName}')"
                            style="padding:11px 14px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:white;font-size:12px;font-weight:600;text-align:left;cursor:pointer;transition:0.15s;"
                            onmouseover="this.style.background='rgba(37,99,235,0.25)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                            🔨 ${p.name || p.id}
                        </button>`).join('')}
                </div>
                <button onclick="document.getElementById('hp-project-overlay')?.remove()" style="width:100%;margin-top:12px;padding:9px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:white;font-size:12px;font-weight:600;cursor:pointer;">Cancel</button>
            </div>
        `;
        const content = document.getElementById('hp-content');
        if (content) { content.style.position = 'relative'; content.appendChild(overlay); }
    },

    async _doAddToProject(projectId, projectName, friendName) {
        document.getElementById('hp-project-overlay')?.remove();
        try {
            if (window.firebaseInitialized) {
                await window._fb.updateDoc(window._fb.doc(window.db, 'builder_projects', projectId), {
                    members: window._fb.arrayUnion(friendName)
                });
            } else if (window.supabaseInitialized) {
                const { data } = await window.supabase.from('builder_projects').select('members').eq('id', projectId).single();
                const members = Array.isArray(data?.members) ? [...data.members] : [];
                if (!members.includes(friendName)) {
                    members.push(friendName);
                    await window.supabase.from('builder_projects').update({ members }).eq('id', projectId);
                }
            }
            typeof notify === 'function' && notify('✅ Project', `${friendName} added to "${projectName}"!`);
        } catch(e) {
            typeof notify === 'function' && notify('HyPeople', 'Failed: ' + e.message);
        }
    },

    // ── Realtime Listeners ────────────────────────────────────────────
    _startListeners() {
        const me = this._me();
        if (!me || me === 'Guest' || !window.sbSocial) return;
        // Don't double-subscribe
        if (this._reqSub) return;

        // Listen for incoming friend requests
        this._reqSub = window.sbSocial.subscribeRequests(me, (req) => {
            const from = req.from_user || req.from;
            this._pendingReqCount++;
            this._updateReqBadge(this._pendingReqCount);

            // Show action notification with buttons
            window.addActionNotification(
                `👋 Friend Request`,
                `${from} has sent a friend request!`,
                [
                    { label: 'Accept',  bg: 'rgba(34,197,94,0.75)',  border: 'rgba(34,197,94,0.9)',  color: '#fff', onclick: `HyPeople.acceptRequest('${req.id}','${from}')` },
                    { label: 'Decline', bg: 'rgba(239,68,68,0.55)', border: 'rgba(239,68,68,0.8)', color: '#fff', onclick: `HyPeople.declineRequest('${req.id}')` }
                ]
            );

            // Auto-refresh requests tab if open
            if (this._activeTab === 'requests') this.renderRequests();
        });

        // Load initial pending count
        window.sbSocial.getIncoming(me).then(({ data }) => {
            this._updateReqBadge((data || []).length);
        });
    },

    // ── Helper ────────────────────────────────────────────────────────
    _me() {
        return window.hyosUser || localStorage.getItem('hyos_user') || '';
    }
};

// ── Add global open function so it can be called from dock etc ────────
window.openHyPeople = () => window.HyPeople.open();

// ── CSS injection for message animation ───────────────────────────────
(function() {
    const s = document.createElement('style');
    s.textContent = `
        @keyframes _hpMsgIn {
            from { opacity:0; transform:translateY(6px) scale(0.97); }
            to   { opacity:1; transform:none; }
        }
    `;
    document.head.appendChild(s);
})();

console.log('[HyPeople] Loaded — call HyPeople.open() or openHyPeople()');
