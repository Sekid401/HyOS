// hybrowser-proxy.js — Proxy fallback layer for HyBrowser
// Drop this after taskbar.js in index.html:
//   <script src="js/hybrowser-proxy.js"></script>
//
// Flow:
//   1. Try allorigins first
//   2. If allorigins fails/times out, try corsproxy
//   3. If both fail, show a friendly in-iframe error page

(function () {
    'use strict';

    const PROXIES = [
        url => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
        url => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    ];

    const TIMEOUT_MS = 6000;

    // URLs that should never be proxied (HyInternet sites, local, etc.)
    function shouldSkipProxy(url) {
        try {
            const { hostname, protocol } = new URL(url);
            return (
                protocol === 'blob:' ||
                protocol === 'data:' ||
                hostname === 'localhost' ||
                hostname === '127.0.0.1' ||
                hostname.endsWith('.local')
            );
        } catch (e) {
            return true;
        }
    }

    // Try each proxy in order, return first working proxy URL or null
    async function resolveProxy(url) {
        for (const makeProxy of PROXIES) {
            const proxyUrl = makeProxy(url);
            try {
                const res = await fetch(proxyUrl, {
                    method: 'HEAD',
                    signal: AbortSignal.timeout(TIMEOUT_MS),
                });
                if (res.ok || res.status === 0 /* opaque */) return proxyUrl;
            } catch (e) {
                // timed out or network error — try next
            }
        }
        // HEAD failed for both, try GET on allorigins as last resort
        // (allorigins returns 200 even for blocked sites via GET /raw)
        try {
            const res = await fetch(PROXIES[0](url), {
                signal: AbortSignal.timeout(TIMEOUT_MS),
            });
            if (res.ok) return PROXIES[0](url);
        } catch (e) {}

        return null;
    }

    function errorPage(url) {
        return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Can't reach page</title></head>
<body style="margin:0;background:#070d1a;color:white;font-family:Outfit,sans-serif;
             display:flex;flex-direction:column;align-items:center;justify-content:center;
             height:100vh;text-align:center;padding:40px;box-sizing:border-box;">
  <div style="font-size:48px;margin-bottom:16px;">🌐</div>
  <div style="font-size:18px;font-weight:700;margin-bottom:8px;">This page couldn't be loaded</div>
  <div style="font-size:13px;opacity:0.45;margin-bottom:24px;word-break:break-all;max-width:500px;">${url}</div>
  <div style="font-size:12px;opacity:0.3;">Both proxy mirrors failed.<br>The site may be down or blocking all proxy access.</div>
</body>
</html>`;
    }

    // Patch HyBrowser.navigate once it exists
    function patchNavigate() {
        if (typeof HyBrowser === 'undefined' || typeof HyBrowser.navigate !== 'function') {
            setTimeout(patchNavigate, 100);
            return;
        }

        const _original = HyBrowser.navigate.bind(HyBrowser);

        HyBrowser.navigate = async function (input) {
            if (!input || !input.trim()) { _original(input); return; }

            let url = input.trim();
            const isUrl = url.startsWith('http') || url.startsWith('//') || /^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/.test(url);

            // Non-URLs are search queries — let original handle them (they go to Brave Search, no proxy needed)
            if (!isUrl) { _original(input); return; }
            if (!url.startsWith('http')) url = 'https://' + url;

            // Skip proxy for local/blob/HyInternet URLs
            if (shouldSkipProxy(url)) { _original(url); return; }

            // Run original first to update URL bar, tabs, history, loading bar
            _original(url);

            // Now patch the iframe src to use proxy
            const iframe = document.getElementById('browser-iframe');
            if (!iframe) return;

            // Show a subtle "connecting via proxy" indicator
            const urlBar = document.getElementById('browser-url');
            const originalPlaceholder = urlBar?.placeholder;
            if (urlBar) urlBar.style.opacity = '0.6';

            const proxyUrl = await resolveProxy(url);

            if (urlBar) urlBar.style.opacity = '1';

            if (proxyUrl) {
                // Only replace src if the iframe hasn't already navigated away
                // (user clicked something else while we were resolving)
                if (iframe.src !== proxyUrl) {
                    iframe.src = proxyUrl;
                }
            } else {
                // Both proxies failed — show friendly error
                iframe.srcdoc = errorPage(url);
                iframe.src = 'about:blank';
            }
        };

        console.log('[HyBrowser Proxy] Navigate patched — allorigins → corsproxy fallback active');
    }

    // Wait for DOM + HyBrowser to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', patchNavigate);
    } else {
        patchNavigate();
    }
})();
