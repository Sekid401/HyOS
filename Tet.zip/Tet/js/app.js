// app.js — HyOS HS preinstalled apps: Pomodoro, Music, HyDraw, UnitConverter,
//          PasswordVault, ThemeStore, HyleyMemory, AllApps, HyleyRecs, Camera, Weather
var db, supabase, firebaseInitialized = false, supabaseInitialized = false;
window.addEventListener('hyos-backend-ready', (e) => {
    db = window.db; supabase = window.supabase;
    firebaseInitialized = window.firebaseInitialized;
    supabaseInitialized = window.supabaseInitialized;
});
    window.PomodoroApp = {
        state: 'idle', seconds: 0, interval: null, sessions: 0,
        settings: { focus: 25, shortBreak: 5, longBreak: 15 },
        syncCallbacks: [],
        tick() {
            if (this.seconds <= 0) {
                this.sessions++;
                this.state = this.state === 'focus' ? (this.sessions % 4 === 0 ? 'longbreak' : 'break') : 'focus';
                this.seconds = (this.state === 'focus' ? this.settings.focus : this.state === 'longbreak' ? this.settings.longBreak : this.settings.shortBreak) * 60;
                if (typeof notify !== 'undefined') notify('⏱️ Pomodoro', this.state === 'focus' ? 'Focus time! 🎯' : 'Break time! ☕');
            } else { this.seconds--; }
            this.render(); this.syncCallbacks.forEach(cb => cb());
        },
        start(mode) {
            if (this.interval) clearInterval(this.interval);
            this.state = mode;
            this.seconds = (mode === 'focus' ? this.settings.focus : mode === 'break' ? this.settings.shortBreak : this.settings.longBreak) * 60;
            this.interval = setInterval(() => this.tick(), 1000);
            this.render();
        },
        pause() {
            if (this.interval) { clearInterval(this.interval); this.interval = null; }
            else if (this.state !== 'idle') { this.interval = setInterval(() => this.tick(), 1000); }
            this.render();
        },
        reset() { if (this.interval) clearInterval(this.interval); this.interval = null; this.state = 'idle'; this.seconds = 0; this.render(); },
        render() {
            const el = document.getElementById('pomodoro-display');
            const stateEl = document.getElementById('pomodoro-state');
            const progEl = document.getElementById('pomodoro-progress');
            const pauseBtn = document.getElementById('pomodoro-pause-btn');
            if (!el) return;
            const m = String(Math.floor(this.seconds/60)).padStart(2,'0');
            const s = String(this.seconds%60).padStart(2,'0');
            el.textContent = `${m}:${s}`;
            if (stateEl) stateEl.textContent = this.state==='idle'?'Ready':this.state==='focus'?'🎯 Focus':this.state==='break'?'☕ Short Break':'🛋️ Long Break';
            const total = (this.state==='focus'?this.settings.focus:this.state==='break'?this.settings.shortBreak:this.settings.longBreak)*60;
            if (progEl && total>0) progEl.style.width = ((total-this.seconds)/total*100).toFixed(1)+'%';
            if (pauseBtn) pauseBtn.textContent = this.interval ? '⏸ Pause' : '▶ Resume';
        }
    };
    window.openPomodoro = function() {
        let win = document.getElementById('pomodoro-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'pomodoro-win';
            win.className = 'window';
            win.style.cssText = 'width:340px;height:420px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:16px;">⏱️</span>
                        <span class="font-bold text-sm">Pomodoro Timer</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="closeApp('pomodoro-win')" class="win-ctrl-btn win-ctrl-close">✕</button>
                    </div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;gap:16px;">
                    <div id="pomodoro-state" style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:2px;opacity:0.5;">Ready</div>
                    <div id="pomodoro-display" style="font-size:72px;font-weight:900;font-family:monospace;letter-spacing:-4px;color:#0ea5e9;line-height:1;">25:00</div>
                    <div style="width:100%;height:4px;background:rgba(255,255,255,0.07);border-radius:2px;overflow:hidden;">
                        <div id="pomodoro-progress" style="height:100%;background:linear-gradient(90deg,#0ea5e9,#22d3ee);border-radius:2px;width:0%;transition:width 0.5s;"></div>
                    </div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;">
                        <button onclick="PomodoroApp.start('focus')" style="padding:10px 18px;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;border-radius:12px;color:white;font-size:13px;font-weight:700;cursor:pointer;">🎯 Focus</button>
                        <button onclick="PomodoroApp.start('break')" style="padding:10px 18px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:white;font-size:13px;font-weight:700;cursor:pointer;">☕ Break</button>
                        <button id="pomodoro-pause-btn" onclick="PomodoroApp.pause()" style="padding:10px 18px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);border-radius:12px;color:#0ea5e9;font-size:13px;font-weight:700;cursor:pointer;">⏸ Pause</button>
                        <button onclick="PomodoroApp.reset()" style="padding:10px 14px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);border-radius:12px;color:#f87171;font-size:13px;cursor:pointer;">↺</button>
                    </div>
                    <div style="text-align:center;font-size:11px;opacity:0.35;margin-top:8px;">25min focus → 5min break → repeat<br>Every 4 sessions = long break (15min)</div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600; PomodoroApp.render();
    };

    // ─── FEATURE 2: HYMUSIC ──────────────────────────────────────
    window.HyMusic = {
        tracks: [
            { title:'Neon Drift',       artist:'HyOS Beats',  genre:'Synthwave',   color:'#0ea5e9', isBuiltin:true },
            { title:'Midnight Code',    artist:'Digital Rain', genre:'Techno',      color:'#a78bfa', isBuiltin:true },
            { title:'Aqua Pulse',       artist:'Cyberflow',    genre:'Lo-fi',       color:'#22d3ee', isBuiltin:true },
            { title:'Electric Dawn',    artist:'Future Core',  genre:'EDM',         color:'#f59e0b', isBuiltin:true },
            { title:'Glass Mountains',  artist:'Ambient AI',   genre:'Ambient',     color:'#34d399', isBuiltin:true },
            { title:'Pixel Storm',      artist:'RetroFuture',  genre:'Drum & Bass', color:'#f87171', isBuiltin:true }
        ],
        current:0, playing:false, progress:0, interval:null, vizInterval:null,
        audio: null,

        loadImported() {
            try {
                const saved = JSON.parse(localStorage.getItem('hyos_music_imports') || '[]');
                saved.forEach(t => { if (!this.tracks.find(x => x.title === t.title && !x.isBuiltin)) this.tracks.push(t); });
            } catch(e) {}
        },

        saveImported() {
            const imports = this.tracks.filter(t => !t.isBuiltin);
            localStorage.setItem('hyos_music_imports', JSON.stringify(imports));
        },

        importFile() {
            const inp = document.createElement('input');
            inp.type='file'; inp.accept='audio/*'; inp.multiple=true;
            inp.onchange = (e) => {
                Array.from(e.target.files).forEach(file => {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        // Try to parse artist/title from filename
                        const base = file.name.replace(/\.[^.]+$/, '');
                        const parts = base.split(/[-–—_]/);
                        const artist = parts.length > 1 ? parts[0].trim() : 'Unknown';
                        const title  = parts.length > 1 ? parts.slice(1).join(' ').trim() : base.trim();
                        const colors = ['#0ea5e9','#a78bfa','#22d3ee','#f59e0b','#34d399','#f87171','#fb923c','#e879f9'];
                        const track = {
                            title, artist, genre: 'Imported',
                            color: colors[Math.floor(Math.random()*colors.length)],
                            isBuiltin: false,
                            audioData: ev.target.result
                        };
                        this.tracks.push(track);
                        this.saveImported();
                        this.rebuildList();
                        notify('🎵 Imported', `${title} added to HyMusic`);
                    };
                    reader.readAsDataURL(file);
                });
            };
            inp.click();
        },

        play() {
            const t = this.tracks[this.current];
            this.playing = true;
            clearInterval(this.interval);

            // If it's a real audio file, use Audio API
            if (t.audioData) {
                if (this.audio) { this.audio.pause(); this.audio.src=''; }
                this.audio = new Audio(t.audioData);
                this.audio.volume = 0.8;
                this.audio.ontimeupdate = () => {
                    if (this.audio.duration) {
                        this.progress = (this.audio.currentTime / this.audio.duration) * 100;
                        this.updateUI();
                    }
                };
                this.audio.onended = () => { this.progress=0; this.next(); };
                this.audio.play().catch(()=>{});
            } else {
                if (this.audio) { this.audio.pause(); this.audio = null; }
                // Simulated progress for demo tracks
                this.interval = setInterval(() => {
                    this.progress = Math.min(100, this.progress + 0.12);
                    if (this.progress >= 100) { this.progress=0; this.next(); return; }
                    this.updateUI();
                }, 500);
            }
            this.startViz(); this.updateUI();
        },

        pause() {
            this.playing = false;
            clearInterval(this.interval);
            clearInterval(this.vizInterval);
            if (this.audio) this.audio.pause();
            this.updateUI();
        },

        toggle() { this.playing ? this.pause() : this.play(); },

        next() {
            this.progress=0;
            this.current=(this.current+1)%this.tracks.length;
            if(this.playing) this.play(); else this.updateUI();
        },
        prev() {
            this.progress=0;
            this.current=(this.current-1+this.tracks.length)%this.tracks.length;
            if(this.playing) this.play(); else this.updateUI();
        },

        seek(pct) {
            this.progress = pct;
            if (this.audio && this.audio.duration) {
                this.audio.currentTime = (pct/100) * this.audio.duration;
            }
            this.updateUI();
        },

        remove(idx) {
            if (this.tracks[idx]?.isBuiltin) { notify('Cannot Remove','Built-in tracks cannot be deleted'); return; }
            if (this.current === idx) { this.pause(); this.current=0; }
            else if (this.current > idx) this.current--;
            this.tracks.splice(idx,1);
            this.saveImported();
            this.rebuildList();
        },

        startViz() {
            clearInterval(this.vizInterval);
            this.vizInterval = setInterval(() => {
                document.querySelectorAll('.music-viz-bar').forEach(b => { b.style.height = (8+Math.random()*48)+'px'; });
            }, 100);
        },

        updateUI() {
            const t = this.tracks[this.current];
            if (!t) return;
            const sel = (id) => document.getElementById(id);
            if (sel('music-title')) sel('music-title').textContent = t.title;
            if (sel('music-artist')) sel('music-artist').textContent = `${t.artist} · ${t.genre}`;
            if (sel('music-progress-bar')) sel('music-progress-bar').style.width = this.progress+'%';
            if (sel('music-play-btn')) sel('music-play-btn').textContent = this.playing ? '⏸' : '▶';
            if (sel('music-status')) sel('music-status').textContent = this.playing ? `▶ Playing` : '⏸ Paused';
            const disk = sel('music-disk');
            if (disk) { disk.style.background=`conic-gradient(${t.color} 0deg,${t.color}44 180deg,#111 181deg)`; disk.style.animationPlayState=this.playing?'running':'paused'; }
            const mini = sel('music-mini');
            if (mini) mini.textContent = this.playing ? `♪ ${t.title}` : '';
            // Update track list highlights
            document.querySelectorAll('.hymusic-track').forEach((el,i) => {
                el.style.background = i===this.current ? 'rgba(14,165,233,0.12)' : 'transparent';
                el.style.borderColor = i===this.current ? 'rgba(14,165,233,0.3)' : 'transparent';
            });
        },

        rebuildList() {
            const list = document.getElementById('music-tracklist');
            if (!list) return;
            list.innerHTML = this.tracks.map((t,i) => this._trackHTML(t,i)).join('');
        },

        _trackHTML(t,i) {
            const dur = t.isBuiltin ? `3:${(30+i*7).toString().padStart(2,'0')}` : '♪';
            return `<div class="hymusic-track" onclick="HyMusic.current=${i};HyMusic.progress=0;HyMusic.play();"
                style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:8px;cursor:pointer;transition:0.15s;border:1px solid transparent;"
                onmouseover="this.style.background='rgba(255,255,255,0.06)'" onmouseout="if(HyMusic.current!==${i}){this.style.background='transparent';this.style.borderColor='transparent';}">
                <div style="width:8px;height:8px;border-radius:50%;background:${t.color};flex-shrink:0;"></div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${t.title}</div>
                    <div style="font-size:10px;opacity:0.5;">${t.artist} · ${t.genre}</div>
                </div>
                <div style="font-size:10px;opacity:0.3;flex-shrink:0;">${dur}</div>
                ${!t.isBuiltin ? `<button onclick="event.stopPropagation();HyMusic.remove(${i})"
                    style="background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);border-radius:6px;color:#f87171;font-size:11px;padding:2px 7px;cursor:pointer;" title="Remove">✕</button>` : ''}
            </div>`;
        }
    };

    // Load imports on startup
    HyMusic.loadImported();

    window.openHyMusic = function() {
        let win = document.getElementById('hymusic-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'hymusic-win';
            win.className = 'window';
            win.style.cssText = 'width:400px;height:560px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header" style="background:linear-gradient(135deg,rgba(14,165,233,0.12),rgba(10,15,30,0.98));">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:16px;">🎵</span>
                        <span class="font-bold text-sm">HyMusic</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <button onclick="HyMusic.importFile()" title="Import music files"
                            style="padding:4px 10px;background:rgba(14,165,233,0.15);border:1px solid rgba(14,165,233,0.35);border-radius:8px;color:#7dd3fc;font-size:11px;font-weight:700;cursor:pointer;">
                            ＋ Import
                        </button>
                        <button onclick="closeApp('hymusic-win')" class="win-ctrl-btn win-ctrl-close">✕</button>
                    </div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:column;overflow:hidden;">
                    <!-- Player area -->
                    <div style="padding:20px 20px 14px;background:linear-gradient(180deg,rgba(14,165,233,0.08),transparent);text-align:center;flex-shrink:0;">
                        <div id="music-disk" style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px;background:conic-gradient(#0ea5e9 0deg,#0ea5e944 180deg,#111 181deg);animation:spin 4s linear infinite;animation-play-state:paused;border:3px solid rgba(255,255,255,0.1);box-shadow:0 0 20px rgba(14,165,233,0.2);"></div>
                        <div id="music-title" style="font-size:16px;font-weight:800;margin-bottom:3px;">Neon Drift</div>
                        <div id="music-artist" style="font-size:11px;opacity:0.5;margin-bottom:12px;">HyOS Beats · Synthwave</div>
                        <!-- Visualizer -->
                        <div style="display:flex;align-items:flex-end;justify-content:center;gap:2px;height:40px;margin-bottom:10px;">
                            ${Array(20).fill(0).map(()=>`<div class="music-viz-bar" style="width:3px;height:8px;background:linear-gradient(#0ea5e9,#22d3ee);border-radius:2px;transition:height 0.1s;"></div>`).join('')}
                        </div>
                        <!-- Progress bar (clickable seek) -->
                        <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;margin-bottom:12px;cursor:pointer;"
                             onclick="HyMusic.seek((event.offsetX/this.offsetWidth)*100)">
                            <div id="music-progress-bar" style="height:100%;background:linear-gradient(90deg,#0ea5e9,#22d3ee);width:0%;transition:width 0.5s;border-radius:2px;pointer-events:none;"></div>
                        </div>
                        <!-- Controls -->
                        <div style="display:flex;align-items:center;justify-content:center;gap:12px;">
                            <button onclick="HyMusic.prev()" style="background:rgba(255,255,255,0.07);border:none;color:white;font-size:18px;cursor:pointer;width:36px;height:36px;border-radius:50%;transition:0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.07)'">⏮</button>
                            <button id="music-play-btn" onclick="HyMusic.toggle()" style="background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;color:white;font-size:20px;cursor:pointer;width:48px;height:48px;border-radius:50%;box-shadow:0 0 20px rgba(14,165,233,0.3);transition:0.15s;">▶</button>
                            <button onclick="HyMusic.next()" style="background:rgba(255,255,255,0.07);border:none;color:white;font-size:18px;cursor:pointer;width:36px;height:36px;border-radius:50%;transition:0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.07)'">⏭</button>
                        </div>
                        <div id="music-status" style="font-size:10px;opacity:0.35;margin-top:8px;">⏸ Paused</div>
                    </div>
                    <!-- Track list — populated dynamically on open -->
                    <div style="flex:1;overflow-y:auto;border-top:1px solid rgba(255,255,255,0.06);padding:6px;" id="music-tracklist"></div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display='flex'; win.style.zIndex=600;
        // Always rebuild tracklist so newly imported songs appear immediately
        HyMusic.rebuildList();
        HyMusic.updateUI();
    };

    // ─── FEATURE 3: HYDRAW ───────────────────────────────────────
    window.HyDraw = {
        canvas:null, ctx:null, tool:'pen', color:'#0ea5e9', size:5, drawing:false, lastX:0, lastY:0, history:[], histIdx:-1,
        init() {
            this.canvas = document.getElementById('hydraw-canvas');
            if (!this.canvas) return;
            const resize = () => {
                const dpr = window.devicePixelRatio || 1;
                const rect = this.canvas.getBoundingClientRect();
                if (!this.canvas.width || this.canvas.width < 10) {
                    this.canvas.width = rect.width * dpr;
                    this.canvas.height = rect.height * dpr;
                    this.ctx = this.canvas.getContext('2d');
                    this.ctx.scale(dpr, dpr);
                    this.ctx.fillStyle = '#0a0f1a';
                    this.ctx.fillRect(0,0,rect.width,rect.height);
                    this.saveHistory();
                } else { this.ctx = this.canvas.getContext('2d'); }
            };
            resize();
            const pos = (e) => {
                const rect = this.canvas.getBoundingClientRect();
                const src = e.touches ? e.touches[0] : e;
                return { x: src.clientX - rect.left, y: src.clientY - rect.top };
            };
            const down = (e) => { e.preventDefault(); this.drawing=true; const p=pos(e); this.lastX=p.x; this.lastY=p.y; };
            const move = (e) => {
                if (!this.drawing) return; e.preventDefault();
                const p = pos(e);
                this.ctx.beginPath();
                this.ctx.lineCap = 'round'; this.ctx.lineJoin = 'round';
                if (this.tool==='eraser') { this.ctx.globalCompositeOperation='destination-out'; this.ctx.lineWidth=this.size*4; }
                else { this.ctx.globalCompositeOperation='source-over'; this.ctx.strokeStyle=this.color; this.ctx.lineWidth=this.size; }
                this.ctx.moveTo(this.lastX,this.lastY); this.ctx.lineTo(p.x,p.y); this.ctx.stroke();
                this.lastX=p.x; this.lastY=p.y;
            };
            const up = () => { if(this.drawing){this.drawing=false;this.saveHistory();} };
            this.canvas.addEventListener('mousedown',down);
            this.canvas.addEventListener('mousemove',move);
            this.canvas.addEventListener('mouseup',up);
            this.canvas.addEventListener('touchstart',down,{passive:false});
            this.canvas.addEventListener('touchmove',move,{passive:false});
            this.canvas.addEventListener('touchend',up);
        },
        saveHistory() {
            if(!this.ctx) return;
            this.histIdx++;
            this.history.splice(this.histIdx);
            this.history.push(this.ctx.getImageData(0,0,this.canvas.width,this.canvas.height));
            if(this.history.length>40){this.history.shift();this.histIdx--;}
        },
        undo() { if(this.histIdx>0){this.histIdx--;this.ctx.putImageData(this.history[this.histIdx],0,0);} },
        redo() { if(this.histIdx<this.history.length-1){this.histIdx++;this.ctx.putImageData(this.history[this.histIdx],0,0);} },
        clear() { const r=this.canvas.getBoundingClientRect(); this.ctx.globalCompositeOperation='source-over'; this.ctx.fillStyle='#0a0f1a'; this.ctx.fillRect(0,0,r.width,r.height); this.saveHistory(); },
        save() { const a=document.createElement('a'); a.download='hydraw.png'; a.href=this.canvas.toDataURL(); a.click(); }
    };
    window.openHyDraw = function() {
        let win = document.getElementById('hydraw-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'hydraw-win';
            win.className = 'window';
            win.style.cssText = 'width:680px;height:500px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            const colors = ['#0ea5e9','#22d3ee','#a78bfa','#f87171','#34d399','#f59e0b','#ffffff','#64748b','#111827','#000'];
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🎨</span><span class="font-bold text-sm">HyDraw</span></div>
                    <div class="flex gap-2">
                        <button onclick="HyDraw.undo()" title="Undo" style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:white;padding:4px 8px;border-radius:6px;cursor:pointer;font-size:11px;">↩</button>
                        <button onclick="HyDraw.redo()" title="Redo" style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:white;padding:4px 8px;border-radius:6px;cursor:pointer;font-size:11px;">↪</button>
                        <button onclick="HyDraw.clear()" style="background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#f87171;padding:4px 8px;border-radius:6px;cursor:pointer;font-size:11px;">Clear</button>
                        <button onclick="HyDraw.save()" style="background:rgba(14,165,233,0.15);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;padding:4px 8px;border-radius:6px;cursor:pointer;font-size:11px;">💾</button>
                        <button onclick="closeApp('hydraw-win')" class="win-ctrl-btn win-ctrl-close">✕</button>
                    </div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:row;overflow:hidden;">
                    <!-- Toolbar -->
                    <div style="width:48px;background:rgba(255,255,255,0.02);border-right:1px solid rgba(255,255,255,0.06);display:flex;flex-direction:column;align-items:center;padding:8px 4px;gap:6px;flex-shrink:0;">
                        ${[['pen','✏️','Pen'],['eraser','⬜','Eraser'],['fill','🪣','Fill']].map(([t,ic,lbl])=>
                            `<button onclick="HyDraw.tool='${t}';document.querySelectorAll('.draw-tool-btn').forEach(b=>b.style.background='transparent');this.style.background='rgba(14,165,233,0.2)';" class="draw-tool-btn" title="${lbl}" style="width:36px;height:36px;border:none;border-radius:8px;cursor:pointer;font-size:16px;background:transparent;transition:0.15s;">${ic}</button>`).join('')}
                        <div style="width:100%;height:1px;background:rgba(255,255,255,0.07);margin:4px 0;"></div>
                        ${[2,4,8,14].map(s=>
                            `<button onclick="HyDraw.size=${s};document.querySelectorAll('.draw-size-btn').forEach(b=>b.style.borderColor='transparent');this.style.borderColor='#0ea5e9';" class="draw-size-btn" title="Size ${s}" style="width:${8+s}px;height:${8+s}px;border-radius:50%;background:white;border:2px solid transparent;cursor:pointer;transition:0.15s;flex-shrink:0;"></button>`).join('')}
                        <div style="width:100%;height:1px;background:rgba(255,255,255,0.07);margin:4px 0;"></div>
                        ${colors.map(c=>`<div onclick="HyDraw.color='${c}';document.querySelectorAll('.draw-color-btn').forEach(b=>b.style.outline='none');this.style.outline='2px solid white';" class="draw-color-btn" style="width:20px;height:20px;border-radius:50%;background:${c};cursor:pointer;flex-shrink:0;transition:0.15s;border:${c==='#fff'||c==='#ffffff'?'1px solid rgba(255,255,255,0.3)':'none'};"></div>`).join('')}
                    </div>
                    <!-- Canvas -->
                    <canvas id="hydraw-canvas" style="flex:1;cursor:crosshair;touch-action:none;"></canvas>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        setTimeout(() => HyDraw.init(), 100);
    };

    // ─── FEATURE 4: CLIPBOARD MANAGER ────────────────────────────
    window.ClipboardManager = {
        history: JSON.parse(localStorage.getItem('hyos_clip') || '[]'),
        add(text) {
            if (!text || !text.trim()) return;
            this.history = this.history.filter(h => h !== text);
            this.history.unshift(text);
            if (this.history.length > 25) this.history = this.history.slice(0, 25);
            localStorage.setItem('hyos_clip', JSON.stringify(this.history));
            this.renderPanel();
        },
        renderPanel() {
            const list = document.getElementById('clipboard-list');
            if (!list) return;
            if (!this.history.length) { list.innerHTML = '<div style="text-align:center;padding:30px;opacity:0.4;font-size:13px;">Nothing copied yet</div>'; return; }
            list.innerHTML = this.history.map((text,i) => `
                <div style="padding:10px 14px;border-radius:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);margin-bottom:8px;cursor:pointer;display:flex;align-items:flex-start;gap:10px;transition:0.2s;" onclick="navigator.clipboard?.writeText(${JSON.stringify(text)}).then(()=>notify('📋 Copied','Pasted to clipboard!'))" onmouseover="this.style.background='rgba(14,165,233,0.07)';this.style.borderColor='rgba(14,165,233,0.25)'" onmouseout="this.style.background='rgba(255,255,255,0.03)';this.style.borderColor='rgba(255,255,255,0.07)'">
                    <div style="flex:1;font-size:12px;line-height:1.4;word-break:break-all;opacity:0.85;">${text.slice(0,100)}${text.length>100?'…':''}</div>
                    <button onclick="event.stopPropagation();ClipboardManager.history.splice(${i},1);localStorage.setItem('hyos_clip',JSON.stringify(ClipboardManager.history));ClipboardManager.renderPanel();" style="background:rgba(239,68,68,0.15);border:none;color:#f87171;cursor:pointer;border-radius:6px;width:22px;height:22px;flex-shrink:0;font-size:11px;">✕</button>
                </div>`).join('');
        }
    };
    document.addEventListener('copy', () => {
        setTimeout(() => navigator.clipboard?.readText().then(t => ClipboardManager.add(t)).catch(()=>{}), 150);
    });
    window.openClipboardManager = function() {
        let panel = document.getElementById('clipboard-panel');
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'clipboard-panel';
            panel.style.cssText = 'position:fixed;top:40px;right:15px;width:350px;max-height:520px;background:rgba(5,8,16,0.98);border:1px solid rgba(14,165,233,0.2);border-radius:16px;z-index:19999;backdrop-filter:blur(30px);box-shadow:0 20px 60px rgba(0,0,0,0.7);display:none;flex-direction:column;overflow:hidden;';
            panel.innerHTML = `
                <div style="padding:14px 16px;border-bottom:1px solid rgba(255,255,255,0.07);display:flex;justify-content:space-between;align-items:center;">
                    <span style="font-weight:700;font-size:14px;">📋 Clipboard History</span>
                    <div style="display:flex;gap:8px;">
                        <button onclick="ClipboardManager.history=[];localStorage.removeItem('hyos_clip');ClipboardManager.renderPanel();" style="font-size:10px;padding:4px 8px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.25);color:#f87171;border-radius:6px;cursor:pointer;">Clear</button>
                        <button onclick="this.closest('#clipboard-panel').style.display='none'" style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:white;width:24px;height:24px;border-radius:6px;cursor:pointer;font-size:12px;">✕</button>
                    </div>
                </div>
                <div id="clipboard-list" style="flex:1;overflow-y:auto;padding:10px;"></div>`;
            document.body.appendChild(panel);
        }
        const isOpen = panel.style.display !== 'none';
        panel.style.display = isOpen ? 'none' : 'flex';
        if (!isOpen) ClipboardManager.renderPanel();
    };

    // ─── FEATURE 5: QUICK NOTES SIDEBAR ─────────────────────────
    window.QuickNotes = {
        notes: JSON.parse(localStorage.getItem('hyos_qnotes') || '[]'),
        save() { localStorage.setItem('hyos_qnotes', JSON.stringify(this.notes)); },
        add() {
            const input = document.getElementById('qnote-input');
            if (!input || !input.value.trim()) return;
            this.notes.unshift({ id: Date.now(), text: input.value.trim(), time: new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) });
            input.value = ''; this.save(); this.render();
        },
        remove(id) { this.notes = this.notes.filter(n => n.id !== id); this.save(); this.render(); },
        render() {
            const list = document.getElementById('qnotes-list');
            if (!list) return;
            if (!this.notes.length) { list.innerHTML = '<div style="text-align:center;padding:20px;opacity:0.4;font-size:12px;">No notes yet!</div>'; return; }
            const accents = ['#0ea5e9','#a78bfa','#34d399','#f59e0b','#f87171'];
            list.innerHTML = this.notes.map((n,i) => `
                <div style="padding:10px 12px;border-radius:10px;background:rgba(255,255,255,0.03);border-left:3px solid ${accents[i%accents.length]};margin-bottom:8px;position:relative;">
                    <div style="font-size:12px;line-height:1.5;word-break:break-word;padding-right:20px;">${n.text}</div>
                    <div style="font-size:10px;opacity:0.3;margin-top:4px;">${n.time}</div>
                    <button onclick="QuickNotes.remove(${n.id})" style="position:absolute;top:8px;right:8px;background:transparent;border:none;color:rgba(255,255,255,0.3);cursor:pointer;font-size:12px;" onmouseover="this.style.color='#f87171'" onmouseout="this.style.color='rgba(255,255,255,0.3)'">✕</button>
                </div>`).join('');
        }
    };
    window.openQuickNotes = function() {
        let panel = document.getElementById('quicknotes-panel');
        if (!panel) {
            panel = document.createElement('div');
            panel.id = 'quicknotes-panel';
            panel.style.cssText = 'position:fixed;top:40px;left:15px;width:300px;max-height:500px;background:rgba(5,8,16,0.98);border:1px solid rgba(14,165,233,0.18);border-radius:16px;z-index:19999;backdrop-filter:blur(30px);box-shadow:0 20px 60px rgba(0,0,0,0.7);display:none;flex-direction:column;overflow:hidden;';
            panel.innerHTML = `
                <div style="padding:14px 16px;border-bottom:1px solid rgba(255,255,255,0.07);display:flex;justify-content:space-between;align-items:center;">
                    <span style="font-weight:700;font-size:14px;">📝 Quick Notes</span>
                    <button onclick="this.closest('#quicknotes-panel').style.display='none'" style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:white;width:24px;height:24px;border-radius:6px;cursor:pointer;font-size:12px;">✕</button>
                </div>
                <div style="padding:10px;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;gap:8px;">
                    <input id="qnote-input" placeholder="Write a note…" onkeydown="if(event.key==='Enter')QuickNotes.add()" style="flex:1;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                    <button onclick="QuickNotes.add()" style="background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;color:white;padding:8px 12px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:700;">+</button>
                </div>
                <div id="qnotes-list" style="flex:1;overflow-y:auto;padding:10px;"></div>`;
            document.body.appendChild(panel);
        }
        const isOpen = panel.style.display !== 'none';
        panel.style.display = isOpen ? 'none' : 'flex';
        if (!isOpen) QuickNotes.render();
    };

    // ─── FEATURE 6: FOCUS MODE ───────────────────────────────────
    let _focusModeActive = false;
    window.toggleFocusMode = function() {
        _focusModeActive = !_focusModeActive;
        let overlay = document.getElementById('focus-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'focus-overlay';
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:590;display:none;cursor:pointer;transition:opacity 0.4s;';
            overlay.title = 'Click to exit Focus Mode';
            overlay.onclick = () => toggleFocusMode();
            document.body.appendChild(overlay);
        }
        if (_focusModeActive) { overlay.style.display='block'; setTimeout(()=>overlay.style.opacity='1',10); if(typeof notify!=='undefined') notify('🎯 Focus Mode','Distractions dimmed! Click to exit.'); }
        else { overlay.style.opacity='0'; setTimeout(()=>overlay.style.display='none',400); }
    };

    // ─── FEATURE 7: NIGHT LIGHT ──────────────────────────────────
    let _nightLightOn = JSON.parse(localStorage.getItem('hyos_nightlight') || 'false');
    window.toggleNightLight = function() {
        _nightLightOn = !_nightLightOn;
        localStorage.setItem('hyos_nightlight', _nightLightOn);
        let filter = document.getElementById('night-light-overlay');
        if (!filter) {
            filter = document.createElement('div');
            filter.id = 'night-light-overlay';
            filter.style.cssText = 'position:fixed;inset:0;background:rgba(255,100,0,0.14);z-index:99997;pointer-events:none;transition:opacity 0.5s;opacity:0;';
            document.body.appendChild(filter);
        }
        filter.style.opacity = _nightLightOn ? '1' : '0';
        if(typeof notify!=='undefined') notify('🌙 Night Light', _nightLightOn ? 'Blue light filter ON 🟠' : 'Blue light filter OFF');
        const btn = document.getElementById('nightlight-btn');
        if (btn) btn.style.color = _nightLightOn ? '#fb923c' : '';
    };
    if (_nightLightOn) setTimeout(() => toggleNightLight(), 2000);

    // ─── FEATURE 8: WORLD CLOCK APP ──────────────────────────────
    window.openWorldClock = function() {
        let win = document.getElementById('worldclock-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'worldclock-win';
            win.className = 'window';
            win.style.cssText = 'width:620px;height:420px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🌍</span><span class="font-bold text-sm">World Clock</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('worldclock-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;padding:20px;overflow-y:auto;">
                    <div id="worldclock-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px;"></div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        const zones = [['🇺🇸','New York','America/New_York'],['🇬🇧','London','Europe/London'],['🇯🇵','Tokyo','Asia/Tokyo'],['🇫🇷','Paris','Europe/Paris'],['🇦🇪','Dubai','Asia/Dubai'],['🇦🇺','Sydney','Australia/Sydney'],['🇮🇳','Mumbai','Asia/Kolkata'],['🇧🇷','São Paulo','America/Sao_Paulo'],['🇨🇳','Shanghai','Asia/Shanghai'],['🇰🇷','Seoul','Asia/Seoul'],['🇷🇺','Moscow','Europe/Moscow'],['🇺🇸','LA','America/Los_Angeles']];
        const render = () => {
            const el = document.getElementById('worldclock-grid');
            if (!el || win.style.display === 'none') return;
            const now = new Date();
            el.innerHTML = zones.map(([flag,city,tz]) => {
                const time = now.toLocaleTimeString('en-US', { timeZone:tz, hour:'2-digit', minute:'2-digit', hour12:true });
                const date = now.toLocaleDateString('en-US', { timeZone:tz, weekday:'short', month:'short', day:'numeric' });
                return `<div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:14px;text-align:center;transition:0.2s;" onmouseover="this.style.borderColor='rgba(14,165,233,0.4)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.07)'">
                    <div style="font-size:22px;margin-bottom:5px;">${flag}</div>
                    <div style="font-size:11px;opacity:0.5;margin-bottom:6px;">${city}</div>
                    <div style="font-size:18px;font-weight:800;font-family:monospace;color:#0ea5e9;">${time}</div>
                    <div style="font-size:10px;opacity:0.3;margin-top:3px;">${date}</div>
                </div>`;
            }).join('');
        };
        render();
        if (!window._wcInt) window._wcInt = setInterval(() => { if (document.getElementById('worldclock-win')?.style.display!=='none') render(); }, 15000);
    };

    // ─── FEATURE 9: UNIT CONVERTER ───────────────────────────────
    window.UnitConverter = {
        cats: {
            '📏 Length': { u:['mm','cm','m','km','in','ft','mi'], c:[0.001,0.01,1,1000,0.0254,0.3048,1609.344] },
            '⚖️ Weight': { u:['mg','g','kg','lb','oz'], c:[0.000001,0.001,1,0.453592,0.0283495] },
            '🌡️ Temp': null,
            '💨 Speed': { u:['m/s','km/h','mph','knot'], c:[1,0.2778,0.44704,0.51444] },
            '📐 Area': { u:['m²','km²','ft²','acre'], c:[1,1e6,0.0929,4046.86] },
            '🧪 Volume': { u:['mL','L','fl oz','gal'], c:[0.001,1,0.029574,3.78541] }
        },
        cur: '📏 Length',
        convert() {
            const from = document.getElementById('uc-from')?.value, to = document.getElementById('uc-to')?.value;
            const val = parseFloat(document.getElementById('uc-val')?.value);
            const res = document.getElementById('uc-result');
            if (!res || isNaN(val)) return;
            let result;
            if (this.cur === '🌡️ Temp') {
                if (from==='°C'&&to==='°F') result=val*9/5+32;
                else if (from==='°F'&&to==='°C') result=(val-32)*5/9;
                else if (from==='°C'&&to==='K') result=val+273.15;
                else if (from==='K'&&to==='°C') result=val-273.15;
                else if (from==='°F'&&to==='K') result=(val-32)*5/9+273.15;
                else if (from==='K'&&to==='°F') result=(val-273.15)*9/5+32;
                else result=val;
            } else {
                const cat = this.cats[this.cur];
                const fi=cat.u.indexOf(from), ti=cat.u.indexOf(to);
                if(fi<0||ti<0){res.textContent='Invalid units';return;}
                result = val * cat.c[fi] / cat.c[ti];
            }
            res.innerHTML = `<span style="color:#0ea5e9;font-size:18px;font-weight:800;">${parseFloat(result.toPrecision(8)).toLocaleString()}</span><span style="opacity:0.6;font-size:14px;"> ${to}</span>`;
        },
        setCategory(cat) {
            this.cur = cat;
            const units = cat === '🌡️ Temp' ? ['°C','°F','K'] : this.cats[cat].u;
            const fromSel = document.getElementById('uc-from'), toSel = document.getElementById('uc-to');
            if (fromSel && toSel) {
                fromSel.innerHTML = units.map(u=>`<option>${u}</option>`).join('');
                toSel.innerHTML = units.map((u,i)=>`<option ${i===1?'selected':''}>${u}</option>`).join('');
            }
            document.querySelectorAll('.uc-cat').forEach(b => {
                b.style.background = b.dataset.c===cat ? 'rgba(14,165,233,0.2)' : 'rgba(255,255,255,0.04)';
                b.style.borderColor = b.dataset.c===cat ? 'rgba(14,165,233,0.5)' : 'rgba(255,255,255,0.08)';
                b.style.color = b.dataset.c===cat ? '#0ea5e9' : 'rgba(255,255,255,0.7)';
            });
        }
    };
    window.openUnitConverter = function() {
        let win = document.getElementById('unitconv-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'unitconv-win';
            win.className = 'window';
            win.style.cssText = 'width:420px;height:480px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            const cats = Object.keys(UnitConverter.cats).concat(['🌡️ Temp']);
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🔢</span><span class="font-bold text-sm">Unit Converter</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('unitconv-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;padding:20px;display:flex;flex-direction:column;gap:14px;overflow-y:auto;">
                    <div style="display:flex;gap:6px;flex-wrap:wrap;">
                        ${Object.keys(UnitConverter.cats).map(c=>`<button class="uc-cat" data-c="${c}" onclick="UnitConverter.setCategory('${c}')" style="padding:6px 10px;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.04);color:rgba(255,255,255,0.7);transition:0.15s;">${c}</button>`).join('')}
                    </div>
                    <input id="uc-val" type="number" placeholder="Enter value" oninput="UnitConverter.convert()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:12px;color:white;font-size:18px;font-weight:700;outline:none;width:100%;">
                    <div style="display:flex;gap:10px;align-items:center;">
                        <select id="uc-from" onchange="UnitConverter.convert()" style="flex:1;background:#0a0f1a;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px;color:white;font-size:14px;"></select>
                        <div style="opacity:0.4;font-size:18px;">→</div>
                        <select id="uc-to" onchange="UnitConverter.convert()" style="flex:1;background:#0a0f1a;border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px;color:white;font-size:14px;"></select>
                    </div>
                    <div id="uc-result" style="background:rgba(14,165,233,0.06);border:1px solid rgba(14,165,233,0.2);border-radius:12px;padding:20px;text-align:center;min-height:60px;display:flex;align-items:center;justify-content:center;font-size:16px;"></div>
                    <div style="opacity:0.4;font-size:11px;text-align:center;">Select a category, enter a value, and pick units</div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        setTimeout(() => UnitConverter.setCategory('📏 Length'), 50);
    };

    // ─── FEATURE 10: COLOR PICKER ────────────────────────────────
    window.openColorPicker = function() {
        let win = document.getElementById('colorpicker-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'colorpicker-win';
            win.className = 'window';
            win.style.cssText = 'width:340px;height:440px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🎨</span><span class="font-bold text-sm">Color Picker</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('colorpicker-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;padding:20px;display:flex;flex-direction:column;gap:14px;">
                    <div style="display:flex;gap:12px;align-items:center;">
                        <input type="color" id="cp-native" value="#0ea5e9" oninput="document.getElementById('cp-hex').value=this.value;cpUpdate()" style="width:56px;height:56px;border:none;border-radius:12px;cursor:pointer;background:transparent;">
                        <div style="flex:1;">
                            <div style="font-size:10px;opacity:0.5;margin-bottom:4px;">HEX</div>
                            <input id="cp-hex" type="text" value="#0ea5e9" oninput="document.getElementById('cp-native').value=this.value;cpUpdate()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:14px;font-family:monospace;width:100%;outline:none;">
                        </div>
                    </div>
                    <div id="cp-preview" style="width:100%;height:60px;border-radius:12px;background:#0ea5e9;transition:0.3s;box-shadow:0 4px 20px currentColor;"></div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:8px;padding:10px;">
                            <div style="font-size:10px;opacity:0.4;margin-bottom:4px;">RGB</div>
                            <div id="cp-rgb" style="font-size:12px;font-weight:700;font-family:monospace;">rgb(14, 165, 233)</div>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:8px;padding:10px;">
                            <div style="font-size:10px;opacity:0.4;margin-bottom:4px;">HSL</div>
                            <div id="cp-hsl" style="font-size:12px;font-weight:700;font-family:monospace;">hsl(199, 89%, 48%)</div>
                        </div>
                    </div>
                    <div>
                        <div style="font-size:10px;opacity:0.4;margin-bottom:8px;">SHADES</div>
                        <div id="cp-palette" style="display:flex;gap:6px;flex-wrap:wrap;"></div>
                    </div>
                    <button onclick="const h=document.getElementById('cp-hex').value;navigator.clipboard?.writeText(h).then(()=>notify('🎨 Copied',h))" style="background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;padding:10px;border-radius:10px;cursor:pointer;font-weight:700;font-size:13px;">📋 Copy HEX</button>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600; setTimeout(cpUpdate, 50);
    };
    window.cpUpdate = function() {
        const hexEl = document.getElementById('cp-hex');
        if (!hexEl) return;
        const hex = hexEl.value;
        if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return;
        const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
        const r1=r/255, g1=g/255, b1=b/255, max=Math.max(r1,g1,b1), min=Math.min(r1,g1,b1);
        let h, s, l=(max+min)/2;
        if(max===min){h=s=0;}else{const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);h=(max===r1?(g1-b1)/d+(g1<b1?6:0):max===g1?(b1-r1)/d+2:(r1-g1)/d+4)/6;}
        const prev = document.getElementById('cp-preview');
        if (prev) { prev.style.background=hex; prev.style.boxShadow=`0 4px 20px ${hex}88`; }
        const rgb = document.getElementById('cp-rgb');
        if (rgb) rgb.textContent = `rgb(${r}, ${g}, ${b})`;
        const hsl = document.getElementById('cp-hsl');
        if (hsl) hsl.textContent = `hsl(${Math.round(h*360)}, ${Math.round(s*100)}%, ${Math.round(l*100)}%)`;
        const palette = document.getElementById('cp-palette');
        if (palette) {
            const shades = [0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8].map(f=>{
                const nr=Math.min(255,Math.round(r*f)),ng=Math.min(255,Math.round(g*f)),nb=Math.min(255,Math.round(b*f));
                return '#'+[nr,ng,nb].map(x=>x.toString(16).padStart(2,'0')).join('');
            });
            palette.innerHTML = shades.map(c=>`<div onclick="document.getElementById('cp-hex').value='${c}';document.getElementById('cp-native').value='${c}';cpUpdate();" style="width:28px;height:28px;border-radius:6px;background:${c};cursor:pointer;border:2px solid transparent;transition:0.15s;" onmouseover="this.style.borderColor='white'" onmouseout="this.style.borderColor='transparent'" title="${c}"></div>`).join('');
        }
    };

    // ─── FEATURE 11: DESKTOP THEMES ──────────────────────────────
    window.DesktopThemes = {
        themes: {
            hs: { name:'HyOS HS', accent:'#0ea5e9', accent2:'#22d3ee', bg:'#030508' },
            dracula: { name:'Dracula', accent:'#bd93f9', accent2:'#ff79c6', bg:'#0d0d1a' },
            cyberpunk: { name:'Cyberpunk', accent:'#faff00', accent2:'#ff0080', bg:'#0a0005' },
            forest: { name:'Forest', accent:'#4ade80', accent2:'#86efac', bg:'#020b02' },
            sunset: { name:'Sunset', accent:'#fb923c', accent2:'#fbbf24', bg:'#0d0500' },
            rose: { name:'Rose', accent:'#fb7185', accent2:'#fda4af', bg:'#0d0308' },
            midnight: { name:'Midnight', accent:'#6366f1', accent2:'#818cf8', bg:'#03040d' }
        },
        cur: localStorage.getItem('hyos_theme') || 'hs',
        apply(id) {
            const t = this.themes[id]; if (!t) return;
            this.cur = id; localStorage.setItem('hyos_theme', id);
            document.documentElement.style.setProperty('--accent', t.accent);
            document.documentElement.style.setProperty('--accent-2', t.accent2);
            document.documentElement.style.setProperty('--accent-glow', t.accent+'33');
            document.documentElement.style.setProperty('--blue-600', t.accent);
            document.body.style.background = t.bg;
            if(typeof notify!=='undefined') notify('🎨 Theme', `${t.name} applied!`);
            this.render();
        },
        render() {
            const el = document.getElementById('theme-picker-grid');
            if (!el) return;
            el.innerHTML = Object.entries(this.themes).map(([id,t]) => `
                <div onclick="DesktopThemes.apply('${id}')" style="padding:12px;border-radius:12px;cursor:pointer;border:2px solid ${id===this.cur?t.accent:'rgba(255,255,255,0.08)'};background:${id===this.cur?t.accent+'22':'rgba(255,255,255,0.03)'};transition:0.2s;text-align:center;" onmouseover="this.style.borderColor='${t.accent}'" onmouseout="this.style.borderColor='${id===this.cur?t.accent:'rgba(255,255,255,0.08)'}'">
                    <div style="display:flex;gap:4px;justify-content:center;margin-bottom:8px;">
                        <div style="width:14px;height:14px;border-radius:50%;background:${t.accent};"></div>
                        <div style="width:14px;height:14px;border-radius:50%;background:${t.accent2};"></div>
                        <div style="width:14px;height:14px;border-radius:50%;background:${t.bg};border:1px solid rgba(255,255,255,0.2);"></div>
                    </div>
                    <div style="font-size:11px;font-weight:700;">${t.name}${id===this.cur?' ✓':''}</div>
                </div>`).join('');
        }
    };
    window.openThemePicker = function() {
        let win = document.getElementById('themes-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'themes-win';
            win.className = 'window';
            win.style.cssText = 'width:500px;height:400px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🎨</span><span class="font-bold text-sm">Desktop Themes</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('themes-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;padding:20px;overflow-y:auto;">
                    <div style="font-size:12px;opacity:0.5;margin-bottom:16px;">Select a theme to instantly change the OS look and feel</div>
                    <div id="theme-picker-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;"></div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        setTimeout(() => DesktopThemes.render(), 50);
    };
    setTimeout(() => DesktopThemes.apply(DesktopThemes.cur), 1800);

    // ─── FEATURE 12: PASSWORD VAULT ──────────────────────────────
    window.PasswordVault = {
        entries: [], unlocked: false,
        mh: localStorage.getItem('pvault_mh') || null,
        hash(s) { let h=0; for(let i=0;i<s.length;i++){h=((h<<5)-h)+s.charCodeAt(i);h|=0;} return Math.abs(h).toString(36); },
        load() { try { this.entries = JSON.parse(atob(localStorage.getItem('pvault_e') || 'W10=')); } catch(e) { this.entries = []; } },
        save() { localStorage.setItem('pvault_e', btoa(JSON.stringify(this.entries))); },
        unlock(pw) { if (this.hash(pw) === this.mh) { this.unlocked=true; this.load(); return true; } return false; },
        setMaster(pw) { this.mh=this.hash(pw); localStorage.setItem('pvault_mh',this.mh); this.unlocked=true; this.load(); },
        render() {
            const l = document.getElementById('vault-list');
            if (!l) return;
            if (!this.entries.length) { l.innerHTML = '<div style="text-align:center;padding:30px;opacity:0.4;font-size:13px;">No saved passwords</div>'; return; }
            l.innerHTML = this.entries.map((e,i) => `
                <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);margin-bottom:8px;">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div><div style="font-weight:700;font-size:13px;">🌐 ${e.site}</div><div style="font-size:11px;opacity:0.5;margin-top:2px;">👤 ${e.user}</div></div>
                        <div style="display:flex;gap:6px;">
                            <button onclick="navigator.clipboard?.writeText('${e.pass}').then(()=>notify('🔑 Copied','Password copied!'))" style="padding:5px 8px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;border-radius:6px;cursor:pointer;font-size:10px;font-weight:700;">Copy</button>
                            <button onclick="PasswordVault.entries.splice(${i},1);PasswordVault.save();PasswordVault.render();" style="padding:5px 8px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);color:#f87171;border-radius:6px;cursor:pointer;font-size:10px;">✕</button>
                        </div>
                    </div>
                </div>`).join('');
        }
    };
    window.openPasswordVault = function() {
        let win = document.getElementById('vault-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'vault-win';
            win.className = 'window';
            win.style.cssText = 'width:380px;height:520px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">🔑</span><span class="font-bold text-sm">Password Vault</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('vault-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:column;overflow:hidden;">
                    <div id="vault-locked" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:30px;gap:14px;">
                        <div style="font-size:48px;">🔒</div>
                        <div id="vault-lock-msg" style="font-size:14px;font-weight:600;opacity:0.7;">Enter master password</div>
                        <input id="vault-master-input" type="password" placeholder="Master password" onkeydown="if(event.key==='Enter')vaultSubmitMaster()" style="width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:12px;color:white;font-size:14px;outline:none;text-align:center;">
                        <button onclick="vaultSubmitMaster()" style="width:100%;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;padding:12px;border-radius:12px;color:white;font-size:14px;font-weight:700;cursor:pointer;">Unlock</button>
                    </div>
                    <div id="vault-content" style="flex:1;display:none;flex-direction:column;overflow:hidden;">
                        <div style="padding:12px;border-bottom:1px solid rgba(255,255,255,0.06);display:flex;flex-direction:column;gap:8px;">
                            <input id="vault-site" placeholder="Site name" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                            <input id="vault-user" placeholder="Username / Email" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                            <div style="display:flex;gap:8px;">
                                <input id="vault-pass" type="password" placeholder="Password" style="flex:1;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                                <button onclick="const el=document.getElementById('vault-pass');el.type=el.type==='password'?'text':'password';" style="padding:8px 10px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:white;cursor:pointer;font-size:12px;">👁</button>
                            </div>
                            <button onclick="vaultAddEntry()" style="background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;padding:10px;border-radius:10px;color:white;font-size:13px;font-weight:700;cursor:pointer;">+ Save Password</button>
                        </div>
                        <div id="vault-list" style="flex:1;overflow-y:auto;padding:10px;"></div>
                    </div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        const locked = document.getElementById('vault-locked');
        const content = document.getElementById('vault-content');
        if (PasswordVault.unlocked) {
            locked.style.display='none'; content.style.display='flex'; PasswordVault.render();
        } else {
            locked.style.display='flex'; content.style.display='none';
            document.getElementById('vault-lock-msg').textContent = PasswordVault.mh ? 'Enter master password' : 'Create a master password';
        }
    };
    window.vaultSubmitMaster = function() {
        const input = document.getElementById('vault-master-input');
        if (!input || input.value.length < 3) { notify('🔑 Vault','Password must be 3+ chars'); return; }
        if (!PasswordVault.mh) PasswordVault.setMaster(input.value);
        else if (!PasswordVault.unlock(input.value)) { notify('🔑 Vault','Wrong password!'); input.value=''; return; }
        input.value = '';
        document.getElementById('vault-locked').style.display='none';
        document.getElementById('vault-content').style.display='flex';
        PasswordVault.render();
    };
    window.vaultAddEntry = function() {
        const s=document.getElementById('vault-site')?.value?.trim();
        const u=document.getElementById('vault-user')?.value?.trim();
        const p=document.getElementById('vault-pass')?.value?.trim();
        if(!s||!u||!p){notify('🔑 Vault','Fill in all fields');return;}
        PasswordVault.entries.push({ site:s, user:u, pass:p, added:new Date().toLocaleDateString() });
        PasswordVault.save(); PasswordVault.render();
        ['vault-site','vault-user','vault-pass'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
        notify('🔑 Vault','Password saved!');
    };

    // ─── FEATURE 13: AI WALLPAPER GENERATOR ──────────────────────
    // ═══════════════════════════════════════════════════════════════
    // THEME STORE — replaces the old WallpaperGen
    // ═══════════════════════════════════════════════════════════════
    window.ThemeStore = {
        /* ── built-in themes ─────────────────────────────────────── */
        themes: [
            {
                id: 'neon-grid', name: 'Neon Grid', author: 'HyOS Team',
                accent: '#0ea5e9',
                wallpaper: { css: 'linear-gradient(rgba(14,165,233,0.12) 1px,transparent 1px),linear-gradient(90deg,rgba(14,165,233,0.12) 1px,transparent 1px),#030508', size: '50px 50px' },
                icons: { settings:'⚙️', files:'📂', browser:'🌐', terminal:'💻', store:'🛍️', notes:'📝' }
            },
            {
                id: 'aurora', name: 'Aurora Borealis', author: 'HyOS Team',
                accent: '#22d3ee',
                wallpaper: { css: 'radial-gradient(ellipse at 20% 50%,rgba(14,165,233,0.28) 0%,transparent 50%),radial-gradient(ellipse at 80% 50%,rgba(167,139,250,0.2) 0%,transparent 50%),radial-gradient(ellipse at 50% 80%,rgba(34,211,238,0.18) 0%,transparent 40%),#030508' },
                icons: { settings:'🔧', files:'🗂️', browser:'🔭', terminal:'🖥️', store:'🛒', notes:'📓' }
            },
            {
                id: 'cyberpunk', name: 'Cyberpunk 2099', author: 'HyOS Team',
                accent: '#ff0080',
                wallpaper: { css: 'linear-gradient(rgba(255,0,128,0.08) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,255,0.06) 1px,transparent 1px),radial-gradient(ellipse at top,#0a0015,#030508),#030508', size: '60px 60px' },
                icons: { settings:'⚡', files:'💾', browser:'🕶️', terminal:'🤖', store:'🏪', notes:'🗒️' }
            },
            {
                id: 'deep-ocean', name: 'Deep Ocean', author: 'HyOS Team',
                accent: '#0369a1',
                wallpaper: { css: 'radial-gradient(ellipse at top,#041428 0%,#030508 100%)' },
                icons: { settings:'🐚', files:'🪸', browser:'🐋', terminal:'🦑', store:'🐙', notes:'🐠' }
            },
            {
                id: 'forest', name: 'Emerald Forest', author: 'HyOS Team',
                accent: '#4ade80',
                wallpaper: { css: 'radial-gradient(ellipse at 50% 0%,rgba(74,222,128,0.1) 0%,transparent 60%),linear-gradient(180deg,#020b02 0%,#030508 100%)' },
                icons: { settings:'🌿', files:'🍃', browser:'🦋', terminal:'🌱', store:'🍄', notes:'🍀' }
            },
            {
                id: 'sunset', name: 'Stellar Sunset', author: 'HyOS Team',
                accent: '#f97316',
                wallpaper: { css: 'linear-gradient(180deg,#050008 0%,#1a0510 30%,#200a05 60%,#030508 100%)' },
                icons: { settings:'☀️', files:'🌅', browser:'🌇', terminal:'🌆', store:'🌃', notes:'🌙' }
            },
            {
                id: 'starfield', name: 'Starfield', author: 'HyOS Team',
                accent: '#a78bfa',
                wallpaper: { css: 'radial-gradient(ellipse at center,#090915 0%,#030508 80%),radial-gradient(2px 2px at 10% 20%,rgba(255,255,255,0.6) 0%,transparent 100%),radial-gradient(2px 2px at 80% 60%,rgba(14,165,233,0.4) 0%,transparent 100%),radial-gradient(2px 2px at 40% 80%,rgba(255,255,255,0.3) 0%,transparent 100%)' },
                icons: { settings:'🪐', files:'🛸', browser:'🔭', terminal:'👾', store:'⭐', notes:'🌌' }
            },
            {
                id: 'warm-glow', name: 'Warm Glow', author: 'HyOS Team',
                accent: '#fb923c',
                wallpaper: { css: 'radial-gradient(circle at 50% 120%,rgba(251,146,60,0.2) 0%,transparent 50%),radial-gradient(circle at 80% 50%,rgba(251,191,36,0.08) 0%,transparent 40%),#030508' },
                icons: { settings:'🕯️', files:'📜', browser:'☕', terminal:'🔥', store:'🧡', notes:'🍁' }
            },
            {
                id: 'retro', name: 'Retro', author: 'HyOS Team',
                accent: '#39ff14',
                font: 'retro',
                soundPack: 'retro',
                cursor: 'retro',
                wallpaper: {
                    css: 'repeating-linear-gradient(0deg,rgba(0,0,0,0.15) 0px,rgba(0,0,0,0.15) 1px,transparent 1px,transparent 4px),repeating-linear-gradient(90deg,rgba(0,255,0,0.03) 0px,rgba(0,255,0,0.03) 1px,transparent 1px,transparent 80px),radial-gradient(ellipse at 50% 50%,#001a00 0%,#000800 60%,#000000 100%)',
                    size: 'auto,80px 100%,cover'
                },
                icons: {
                    calculator:'🧮', terminal:'📺', files:'💾', notepad:'📄',
                    maker:'🔧', browser:'📡', settings:'⚙️', media:'📼',
                    hydraw:'🖊️', hymusic:'🎮', pomodoro:'⏰', worldclock:'🕐',
                    converter:'📐', colorpick:'🎨', vault:'🔒', themestore:'🕹️',
                    clipboard:'📋', quicknotes:'📝', emoji:'😀', widgetland:'🧩',
                    hyvm:'🖥️', camera:'📷', weather:'📺', music:'🎵',
                }
            },
        ],

        /* ── wallpaper-only presets (legacy) ─────────────────────── */
        presets: [
            { name:'Neon Grid',     css:'linear-gradient(rgba(14,165,233,0.12) 1px,transparent 1px),linear-gradient(90deg,rgba(14,165,233,0.12) 1px,transparent 1px),#030508', size:'50px 50px' },
            { name:'Aurora',        css:'radial-gradient(ellipse at 20% 50%,rgba(14,165,233,0.28) 0%,transparent 50%),radial-gradient(ellipse at 80% 50%,rgba(167,139,250,0.2) 0%,transparent 50%),radial-gradient(ellipse at 50% 80%,rgba(34,211,238,0.18) 0%,transparent 40%),#030508' },
            { name:'Cyberpunk',     css:'linear-gradient(rgba(255,0,128,0.08) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,255,0.06) 1px,transparent 1px),radial-gradient(ellipse at top,#0a0015,#030508),#030508', size:'60px 60px' },
            { name:'Deep Ocean',    css:'radial-gradient(ellipse at top,#041428 0%,#030508 100%)' },
            { name:'Forest',        css:'radial-gradient(ellipse at 50% 0%,rgba(74,222,128,0.1) 0%,transparent 60%),linear-gradient(180deg,#020b02 0%,#030508 100%)' },
            { name:'Sunset',        css:'linear-gradient(180deg,#050008 0%,#1a0510 30%,#200a05 60%,#030508 100%)' },
            { name:'Starfield',     css:'radial-gradient(ellipse at center,#090915 0%,#030508 80%),radial-gradient(2px 2px at 10% 20%,rgba(255,255,255,0.6) 0%,transparent 100%)' },
            { name:'Warm Glow',     css:'radial-gradient(circle at 50% 120%,rgba(251,146,60,0.2) 0%,transparent 50%),radial-gradient(circle at 80% 50%,rgba(251,191,36,0.08) 0%,transparent 40%),#030508' }
        ],

        /* ── apply a full theme ───────────────────────────────────── */
        applyTheme(themeId) {
            const t = this.themes.find(th => th.id === themeId);
            if (!t) return;

            // Backup original icons if not already backed up
            if (!userSettings.themeEngineIconBackups || Object.keys(userSettings.themeEngineIconBackups).length === 0) {
                const backups = {};
                installedApps.forEach(a => { backups[a.id] = a.icon; });
                cloudApps.forEach(a => { if (!backups[a.id]) backups[a.id] = a.icon; });
                userSettings.themeEngineIconBackups = backups;
            }

            // Apply wallpaper
            const bg = document.getElementById('desktop-bg');
            if (bg) {
                bg.style.background = t.wallpaper.css;
                bg.style.backgroundSize = t.wallpaper.size || '';
            }

            // Apply accent color
            if (t.accent) setAccentColor(t.accent);

            // Apply icon overrides to any app whose id/name loosely matches
            const iconMap = t.icons;
            const applyIconToApp = (app) => {
                const key = Object.keys(iconMap).find(k =>
                    app.id?.toLowerCase().includes(k) ||
                    app.name?.toLowerCase().includes(k)
                );
                if (key) app.icon = iconMap[key];
            };
            installedApps.forEach(applyIconToApp);
            cloudApps.forEach(applyIconToApp);

            // Save state
            userSettings.themeEngineEnabled = true;
            userSettings.activeThemeId = themeId;
            saveSettings();
            localStorage.setItem('hyos_installed_apps', JSON.stringify(installedApps));

            renderDesktopIcons();
            this.renderThemes();

            // Update toggle in settings
            const tog = document.getElementById('theme-engine-toggle');
            if (tog) tog.classList.add('active');

            // Apply font if theme specifies one
            if (t.font) {
                const f = this.builtinFonts.find(f=>f.id===t.font);
                if (f) { this._loadAndApplyFont(f.url, f.family); userSettings.systemFont = { url:f.url, family:f.family, name:f.name }; saveSettings(); }
            }
            // Apply sound pack if theme specifies one
            if (t.soundPack) { userSettings.soundPack = t.soundPack; saveSettings(); }
            // Apply cursor if theme specifies one
            if (t.cursor && window.CursorManager) { CursorManager.apply(t.cursor); CursorManager._updateTouchCursorVisual && CursorManager._updateTouchCursorVisual(); }

            notify('🎨 Theme Applied', `${t.name} is now active!`);
        },

        /* ── apply only wallpaper ─────────────────────────────────── */
        applyWallpaper(idx) {
            const p = this.presets[idx]; if (!p) return;
            const bg = document.getElementById('desktop-bg');
            if (bg) { bg.style.background = p.css; bg.style.backgroundSize = p.size || ''; }
            notify('🖼️ Wallpaper', `${p.name} applied!`);
            this.renderWallpapers();
        },

        /* ── render themes tab ────────────────────────────────────── */
        renderThemes() {
            const el = document.getElementById('ts-themes-grid');
            if (!el) return;
            el.innerHTML = this.themes.map(t => `
                <div onclick="ThemeStore.applyTheme('${t.id}')"
                     style="border-radius:14px;overflow:hidden;cursor:pointer;border:2px solid ${userSettings.activeThemeId===t.id?'#0ea5e9':'rgba(255,255,255,0.08)'};transition:0.2s;background:rgba(255,255,255,0.03);"
                     onmouseover="this.style.borderColor='#0ea5e9';this.style.transform='scale(1.02)'"
                     onmouseout="this.style.borderColor='${userSettings.activeThemeId===t.id?'#0ea5e9':'rgba(255,255,255,0.08)'}';;this.style.transform=''">
                    <div style="height:80px;background:${t.wallpaper.css};${t.wallpaper.size?'background-size:'+t.wallpaper.size:''}"></div>
                    <div style="padding:10px 12px;background:rgba(0,0,0,0.7);">
                        <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
                            <div style="width:10px;height:10px;border-radius:50%;background:${t.accent};flex-shrink:0;"></div>
                            <span style="font-size:12px;font-weight:700;">${t.name}</span>
                            ${userSettings.activeThemeId===t.id?'<span style="margin-left:auto;font-size:9px;background:rgba(14,165,233,0.25);border:1px solid rgba(14,165,233,0.4);padding:1px 6px;border-radius:10px;color:#7dd3fc;">ACTIVE</span>':''}
                        </div>
                        <div style="font-size:10px;opacity:0.4;">by ${t.author}</div>
                        <div style="display:flex;gap:4px;margin-top:6px;font-size:16px;">${Object.values(t.icons).slice(0,5).join(' ')}</div>
                    </div>
                </div>`).join('');
        },

        /* ── render wallpapers tab ────────────────────────────────── */
        renderWallpapers() {
            const el = document.getElementById('ts-wall-grid');
            if (!el) return;
            el.innerHTML = this.presets.map((p,i) => `
                <div onclick="ThemeStore.applyWallpaper(${i})"
                     style="border-radius:12px;overflow:hidden;cursor:pointer;border:2px solid rgba(255,255,255,0.08);transition:0.2s;"
                     onmouseover="this.style.borderColor='#0ea5e9';this.style.transform='scale(1.02)'"
                     onmouseout="this.style.borderColor='rgba(255,255,255,0.08)';this.style.transform=''">
                    <div style="height:70px;background:${p.css};${p.size?'background-size:'+p.size:''}"></div>
                    <div style="padding:6px 8px;background:rgba(0,0,0,0.6);font-size:11px;font-weight:600;">${p.name}</div>
                </div>`).join('');
        },

        /* ── render icon maker tab ────────────────────────────────── */
        renderIconMaker() {
            const el = document.getElementById('ts-icon-list');
            if (!el) return;
            const allApps = [...installedApps, ...cloudApps.filter(a => !installedApps.find(b=>b.id===a.id))];
            if (allApps.length === 0) {
                el.innerHTML = '<div style="text-align:center;padding:28px;opacity:.35;font-size:12px;">No apps installed yet.</div>';
                return;
            }
            el.innerHTML = allApps.map(a => `
                <div style="display:flex;align-items:center;gap:12px;padding:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:12px;margin-bottom:8px;">
                    <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,0.07);display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;overflow:hidden;">
                        ${a.icon?.startsWith('data') ? `<img src="${a.icon}" style="width:100%;height:100%;object-fit:cover;border-radius:10px;">` : (a.icon||'📱')}
                    </div>
                    <div style="flex:1;min-width:0;">
                        <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${a.name}</div>
                        ${a.isSystem ? '<div style="font-size:10px;opacity:.35;">System App</div>' : a.genre ? `<div style="font-size:10px;opacity:.35;">${a.genre}</div>` : ''}
                    </div>
                    <button onclick="ThemeStore.editIcon('${a.id}')"
                        style="padding:6px 12px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);border-radius:8px;color:#7dd3fc;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap;">
                        Edit Icon
                    </button>
                </div>`).join('');
        },

        /* ── open single-icon editor ──────────────────────────────── */
        editIcon(appId) {
            const app = installedApps.find(a=>a.id===appId)||cloudApps.find(a=>a.id===appId);
            if (!app) return;
            // Backup original if first edit
            if (!userSettings.themeEngineIconBackups[appId]) {
                userSettings.themeEngineIconBackups[appId] = app.icon;
            }
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(8px);';
            overlay.innerHTML = `
                <div style="background:rgba(10,15,30,0.99);border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:28px;width:340px;max-width:90vw;">
                    <div style="font-size:16px;font-weight:700;margin-bottom:4px;">Edit Icon — ${app.name}</div>
                    <div style="font-size:11px;opacity:.45;margin-bottom:18px;">Type an emoji or upload an image</div>
                    <div style="display:flex;gap:12px;align-items:center;margin-bottom:16px;">
                        <div id="ts-icon-preview" style="width:60px;height:60px;border-radius:14px;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);display:flex;align-items:center;justify-content:center;font-size:32px;flex-shrink:0;overflow:hidden;">
                            ${app.icon?.startsWith('data')?`<img src="${app.icon}" style="width:100%;height:100%;object-fit:cover;border-radius:12px;">`:(app.icon||'📱')}
                        </div>
                        <div style="flex:1;">
                            <input id="ts-emoji-in" placeholder="Emoji (e.g. 🚀)" value="${app.icon?.startsWith('data')?'':(app.icon||'')}"
                                style="width:100%;background:#0f172a;border:1px solid #334155;padding:10px;border-radius:10px;color:white;font-size:18px;margin-bottom:8px;outline:none;"
                                oninput="document.getElementById('ts-icon-preview').innerHTML=this.value||'📱'">
                            <button onclick="document.getElementById('ts-img-up').click()"
                                style="width:100%;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:8px;color:white;cursor:pointer;font-size:12px;">📁 Upload Image</button>
                            <input id="ts-img-up" type="file" accept="image/*" style="display:none;" onchange="
                                const f=this.files[0];if(!f)return;
                                const r=new FileReader();
                                r.onload=(ev)=>{
                                    document.getElementById('ts-icon-preview').innerHTML='<img src=\\''+ev.target.result+'\\' style=\\'width:100%;height:100%;object-fit:cover;border-radius:12px;\\'>';
                                    document.getElementById('ts-emoji-in').dataset.img=ev.target.result;
                                    document.getElementById('ts-emoji-in').value='';
                                };r.readAsDataURL(f);">
                        </div>
                    </div>
                    <div style="display:flex;gap:10px;">
                        <button onclick="this.closest('div[style*=position]').remove()"
                            style="flex:1;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:12px;color:white;cursor:pointer;font-weight:600;">Cancel</button>
                        <button onclick="
                            const inp=document.getElementById('ts-emoji-in');
                            const newIcon=inp.dataset.img||inp.value.trim()||'📱';
                            ThemeStore._saveIconChange('${appId}',newIcon);
                            this.closest('div[style*=position]').remove();"
                            style="flex:1;background:#0ea5e9;border:none;border-radius:12px;padding:12px;color:white;cursor:pointer;font-weight:700;">Apply</button>
                    </div>
                </div>`;
            document.body.appendChild(overlay);
            overlay.addEventListener('click', e=>{ if(e.target===overlay)overlay.remove(); });
            setTimeout(()=>document.getElementById('ts-emoji-in')?.focus(),50);
        },

        _saveIconChange(appId, newIcon) {
            const la = installedApps.find(a=>a.id===appId);
            if (la) { la.icon=newIcon; localStorage.setItem('hyos_installed_apps',JSON.stringify(installedApps)); }
            const ca = cloudApps.find(a=>a.id===appId);
            if (ca) ca.icon=newIcon;
            userSettings.desktopIcons.forEach(di=>{ if(di.appId===appId)di.icon=newIcon; });
            userSettings.themeEngineEnabled = true;
            saveSettings();
            renderDesktopIcons();
            this.renderIconMaker();
            notify('🎨 Icon Updated','Icon changed successfully!');
        },

        /* ── switch tabs inside the window ───────────────────────── */
        switchTab(tab) {
            ['themes','wallpapers','iconmaker','sounds','fonts','cursors'].forEach(t=>{
                const tabBtn  = document.getElementById('ts-tab-'+t);
                const tabBody = document.getElementById('ts-body-'+t);
                if (tabBtn)  { tabBtn.style.background  = t===tab?'rgba(14,165,233,0.15)':'transparent'; tabBtn.style.color=t===tab?'#7dd3fc':'rgba(255,255,255,0.4)'; tabBtn.style.borderBottom=t===tab?'2px solid #0ea5e9':'2px solid transparent'; }
                if (tabBody) tabBody.style.display = t===tab?'flex':'none';
            });
            // ensure the active body shows as flex col
            const active = document.getElementById('ts-body-'+tab);
            if (active) active.style.flexDirection = 'column';
            if (tab==='themes')     this.renderThemes();
            if (tab==='wallpapers') this.renderWallpapers();
            if (tab==='iconmaker')  this.renderIconMaker();
            if (tab==='sounds')     this.renderSounds();
            if (tab==='fonts')      this.renderFonts();
            if (tab==='cursors')    { if(window.CursorManager) CursorManager.renderCursors(); };
        },

        /* ── sound packs ─────────────────────────────────────────── */
        soundPacks: [
            { id:'default',  name:'HyOS Default',  desc:'Clean minimal sounds',  emoji:'🔵', sounds:{notification:'',click:'',open:'',close:'',error:''} },
            { id:'retro',    name:'Retro',          desc:'Old-school beeps',       emoji:'🕹️', sounds:{notification:'retro-notif',click:'retro-click',open:'retro-open',close:'retro-close',error:'retro-error'} },
            { id:'soft',     name:'Soft',           desc:'Gentle muted tones',     emoji:'🌸', sounds:{notification:'soft-notif',click:'soft-click',open:'soft-open',close:'soft-close',error:'soft-error'} },
            { id:'material', name:'Material',       desc:'Google-style sounds',    emoji:'🟢', sounds:{notification:'material-notif',click:'material-click',open:'material-open',close:'material-close',error:'material-error'} },
        ],

        renderSounds() {
            const grid = document.getElementById('ts-sound-packs');
            if (!grid) return;
            const current = userSettings.soundPack || 'default';
            grid.innerHTML = this.soundPacks.map(p => `
                <div onclick="ThemeStore.applySoundPack('${p.id}')" style="padding:14px;border-radius:12px;border:2px solid ${p.id===current?'#0ea5e9':'rgba(255,255,255,0.08)'};background:${p.id===current?'rgba(14,165,233,0.12)':'rgba(255,255,255,0.03)'};cursor:pointer;transition:.15s;">
                    <div style="font-size:24px;margin-bottom:6px;">${p.emoji}</div>
                    <div style="font-size:13px;font-weight:700;">${p.name}</div>
                    <div style="font-size:10px;opacity:.45;margin-top:2px;">${p.desc}</div>
                    ${p.id===current?'<div style="font-size:9px;color:#0ea5e9;font-weight:800;margin-top:6px;">✓ ACTIVE</div>':''}
                </div>`).join('');
            // Show custom sounds
            const customSounds = userSettings.customSounds || {};
            const current2 = document.getElementById('ts-sound-current');
            if (current2) {
                const entries = Object.entries(customSounds);
                current2.innerHTML = entries.length ? entries.map(([slot, name]) =>
                    `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                        <span style="font-size:12px;opacity:.7;">${slot}: <strong style="opacity:1;">${name}</strong></span>
                        <button onclick="ThemeStore.removeCustomSound('${slot}')" style="background:none;border:none;color:#f87171;cursor:pointer;font-size:11px;">✕</button>
                    </div>`).join('') : '<span style="opacity:.35;font-size:11px;">No custom sounds imported yet.</span>';
            }
        },

        applySoundPack(id) {
            userSettings.soundPack = id;
            saveSettings();
            notify('🔊 Sound Pack', `${this.soundPacks.find(p=>p.id===id)?.name || id} applied!`);
            this.renderSounds();
        },

        importSound() {
            const slot = document.getElementById('ts-sound-slot')?.value || 'notification';
            const input = document.createElement('input');
            input.type = 'file'; input.accept = '.mp3,.wav,.ogg,.m4a';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                    if (!userSettings.customSoundData) userSettings.customSoundData = {};
                    if (!userSettings.customSounds)    userSettings.customSounds    = {};
                    userSettings.customSoundData[slot] = ev.target.result;
                    userSettings.customSounds[slot]    = file.name;
                    saveSettings();
                    notify('🔊 Sound Imported', `"${file.name}" set as ${slot} sound`);
                    this.renderSounds();
                };
                reader.readAsDataURL(file);
            };
            input.click();
        },

        removeCustomSound(slot) {
            if (userSettings.customSoundData) delete userSettings.customSoundData[slot];
            if (userSettings.customSounds)    delete userSettings.customSounds[slot];
            saveSettings();
            this.renderSounds();
        },

        /* ── fonts ───────────────────────────────────────────────── */
        builtinFonts: [
            { id:'outfit',     name:'Outfit',      sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap',         family:'Outfit' },
            { id:'inter',      name:'Inter',        sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap',           family:'Inter' },
            { id:'geist',      name:'Geist',        sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Geist:wght@400;700&display=swap',           family:'Geist' },
            { id:'mono',       name:'Geist Mono',   sample:'Aa 01 {}',  url:'https://fonts.googleapis.com/css2?family=Geist+Mono:wght@400;700&display=swap',      family:'Geist Mono' },
            { id:'nunito',     name:'Nunito',        sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap',          family:'Nunito' },
            { id:'space',      name:'Space Grotesk', sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;700&display=swap',   family:'Space Grotesk' },
            { id:'sora',       name:'Sora',          sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=Sora:wght@400;700&display=swap',            family:'Sora' },
            { id:'dm',         name:'DM Sans',       sample:'Aa Bb Cc',  url:'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&display=swap',         family:'DM Sans' },
            { id:'retro',      name:'Press Start 2P', sample:'A B C',  url:'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',               family:'Press Start 2P' },
        ],

        renderFonts() {
            const grid = document.getElementById('ts-font-grid');
            if (!grid) return;
            const current = userSettings.systemFont?.family || 'Outfit';
            grid.innerHTML = this.builtinFonts.map(f => `
                <div onclick="ThemeStore.applyFont('${f.id}')" style="padding:14px;border-radius:12px;border:2px solid ${f.family===current?'#0ea5e9':'rgba(255,255,255,0.08)'};background:${f.family===current?'rgba(14,165,233,0.12)':'rgba(255,255,255,0.03)'};cursor:pointer;transition:.15s;">
                    <div style="font-family:'${f.family}',sans-serif;font-size:20px;font-weight:700;margin-bottom:4px;">${f.sample}</div>
                    <div style="font-size:12px;font-weight:700;">${f.name}</div>
                    ${f.family===current?'<div style="font-size:9px;color:#0ea5e9;font-weight:800;margin-top:4px;">✓ ACTIVE</div>':''}
                </div>`).join('');
        },

        applyFont(id) {
            const f = this.builtinFonts.find(f=>f.id===id);
            if (!f) return;
            this._loadAndApplyFont(f.url, f.family);
            userSettings.systemFont = { url: f.url, family: f.family, name: f.name };
            saveSettings();
            notify('🔤 Font', `${f.name} applied!`);
            this.renderFonts();
        },

        importFontURL() {
            const url = document.getElementById('ts-font-url')?.value?.trim();
            if (!url) return;
            // Extract family name from Google Fonts URL
            let family = 'Custom Font';
            const match = url.match(/family=([^:&]+)/);
            if (match) family = decodeURIComponent(match[1].replace(/\+/g,' '));
            this._loadAndApplyFont(url, family);
            userSettings.systemFont = { url, family, name: family };
            saveSettings();
            notify('🔤 Font', `${family} imported and applied!`);
            this.renderFonts();
        },

        importFontFile() {
            const input = document.createElement('input');
            input.type = 'file'; input.accept = '.ttf,.otf,.woff,.woff2';
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const family = file.name.replace(/\.[^.]+$/, '');
                    const style = document.createElement('style');
                    style.id = 'hyos-custom-font-face';
                    document.getElementById('hyos-custom-font-face')?.remove();
                    style.textContent = `@font-face { font-family: '${family}'; src: url('${ev.target.result}'); }`;
                    document.head.appendChild(style);
                    this._applyFontFamily(family);
                    userSettings.systemFont = { dataURL: ev.target.result, family, name: family };
                    saveSettings();
                    notify('🔤 Font', `${family} imported and applied!`);
                    this.renderFonts();
                };
                reader.readAsDataURL(file);
            };
            input.click();
        },

        resetFont() {
            this._applyFontFamily('Outfit');
            userSettings.systemFont = null;
            saveSettings();
            notify('🔤 Font', 'Reset to Outfit (default)');
            this.renderFonts();
        },

        _loadAndApplyFont(url, family) {
            const existing = document.getElementById('hyos-font-link');
            if (existing) existing.remove();
            if (url.includes('googleapis.com') || url.startsWith('http')) {
                const link = document.createElement('link');
                link.id = 'hyos-font-link'; link.rel = 'stylesheet'; link.href = url;
                document.head.appendChild(link);
                link.onload = () => this._applyFontFamily(family);
            } else {
                this._applyFontFamily(family);
            }
        },

        _applyFontFamily(family) {
            document.documentElement.style.setProperty('--system-font', `'${family}', sans-serif`);
            document.body.style.fontFamily = `'${family}', sans-serif`;
            // Apply to all major elements
            document.querySelectorAll('.win-header, .task-btn, .statusbar-item, .context-menu-item, .settings-tab, button')
                .forEach(el => { el.style.fontFamily = `'${family}', sans-serif`; });
        },

        /* ── legacy compat for WallpaperGen.apply() calls ─────────── */
        apply(idx) { this.applyWallpaper(idx); },
        render()   { this.renderWallpapers(); }
    };
    // Alias for backward compat
    /* ── Cursor Manager ──────────────────────────────────────────── */
    window.CursorManager = {
        BUILTIN: [
            { id:'system',    name:'System',      emoji:'🖱️',  css:'auto' },
            { id:'none',      name:'Hidden',      emoji:'🚫',  css:'none' },
            { id:'crosshair', name:'Crosshair',   emoji:'➕',  css:'crosshair' },
            { id:'neon',      name:'Neon Blue',   emoji:'💙',  css:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpolygon points='2,2 2,18 7,13 10,20 13,19 10,12 16,12' fill='%230ea5e9' stroke='%23fff' stroke-width='1'/%3E%3C/svg%3E") 0 0, auto` },
            { id:'retro',     name:'Retro',       emoji:'🕹️',  css:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Crect x='0' y='0' width='2' height='10' fill='white'/%3E%3Crect x='2' y='2' width='2' height='2' fill='white'/%3E%3Crect x='4' y='4' width='2' height='2' fill='white'/%3E%3Crect x='6' y='6' width='2' height='2' fill='white'/%3E%3C/svg%3E") 0 0, auto` },
            { id:'purple',    name:'Purple',      emoji:'💜',  css:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpolygon points='2,2 2,18 7,13 10,20 13,19 10,12 16,12' fill='%23a78bfa' stroke='%23fff' stroke-width='1'/%3E%3C/svg%3E") 0 0, auto` },
            { id:'red',       name:'Red',         emoji:'❤️',  css:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpolygon points='2,2 2,18 7,13 10,20 13,19 10,12 16,12' fill='%23ef4444' stroke='%23fff' stroke-width='1'/%3E%3C/svg%3E") 0 0, auto` },
            { id:'dot',       name:'Dot',         emoji:'⚫',  css:`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Ccircle cx='6' cy='6' r='5' fill='white' stroke='%23333' stroke-width='1'/%3E%3C/svg%3E") 6 6, auto` },
        ],

        _cur: localStorage.getItem('hyos_cursor') || 'system',
        _customCSS: localStorage.getItem('hyos_cursor_custom') || null,

        init() {
            this.apply(this._cur);
            this._initTouchCursor();
        },

        apply(id) {
            this._cur = id;
            localStorage.setItem('hyos_cursor', id);
            const surface = document.getElementById('os-surface') || document.body;
            if (id === 'custom' && this._customCSS) {
                surface.style.cursor = this._customCSS;
            } else {
                const theme = this.BUILTIN.find(c => c.id === id);
                surface.style.cursor = theme ? theme.css : 'auto';
            }
            this.renderCursors && this.renderCursors();
        },

        applyCustom(dataURL, name) {
            const css = `url("${dataURL}") 0 0, auto`;
            this._customCSS = css;
            this._cur = 'custom';
            localStorage.setItem('hyos_cursor_custom', css);
            localStorage.setItem('hyos_cursor', 'custom');
            const surface = document.getElementById('os-surface') || document.body;
            surface.style.cursor = css;
            notify('🖱️ Cursor', `Custom cursor "${name}" applied!`);
            this.renderCursors && this.renderCursors();
        },

        importFile() {
            const inp = document.createElement('input');
            inp.type = 'file';
            inp.accept = '.png,.svg,.cur,.ico';
            inp.onchange = e => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = ev => this.applyCustom(ev.target.result, file.name);
                reader.readAsDataURL(file);
            };
            inp.click();
        },

        reset() {
            this._customCSS = null;
            localStorage.removeItem('hyos_cursor_custom');
            this.apply('system');
        },

        _touchEl: null,
        _initTouchCursor() {
            // Only on touch devices
            if (!('ontouchstart' in window)) return;
            const el = document.createElement('div');
            el.id = 'hyos-touch-cursor';
            el.style.cssText = 'position:fixed;pointer-events:none;z-index:99999;width:28px;height:28px;transform:translate(-2px,-2px);display:none;transition:transform 0.05s;';
            document.body.appendChild(el);
            this._touchEl = el;
            this._updateTouchCursorVisual();
            document.addEventListener('touchmove', e => {
                const t = e.touches[0];
                el.style.display = 'block';
                el.style.left = t.clientX + 'px';
                el.style.top  = t.clientY + 'px';
            }, { passive: true });
            document.addEventListener('touchend', () => {
                setTimeout(() => { el.style.display = 'none'; }, 400);
            });
        },

        _updateTouchCursorVisual() {
            if (!this._touchEl) return;
            const id = this._cur;
            if (id === 'none' || id === 'system') { this._touchEl.innerHTML = ''; return; }
            if (id === 'custom' && this._customCSS) {
                // extract url from css
                const m = this._customCSS.match(/url\("([^"]+)"\)/);
                if (m) { this._touchEl.innerHTML = `<img src="${m[1]}" style="width:28px;height:28px;image-rendering:pixelated;">`; }
                return;
            }
            const EMOJIS = { crosshair:'➕', neon:'💙', retro:'🕹️', purple:'💜', red:'❤️', dot:'⚫' };
            this._touchEl.innerHTML = `<span style="font-size:22px;line-height:1;">${EMOJIS[id] || '🖱️'}</span>`;
        },

        renderCursors() {
            const grid = document.getElementById('ts-cursor-grid');
            if (!grid) return;
            const cur = this._cur;
            const hasCustom = !!this._customCSS;
            grid.innerHTML = this.BUILTIN.map(c => `
                <div onclick="CursorManager.apply('${c.id}');CursorManager._updateTouchCursorVisual();"
                    style="padding:14px;border-radius:12px;border:2px solid ${c.id===cur?'#0ea5e9':'rgba(255,255,255,0.08)'};background:${c.id===cur?'rgba(14,165,233,0.12)':'rgba(255,255,255,0.03)'};cursor:pointer;transition:.15s;text-align:center;">
                    <div style="font-size:26px;margin-bottom:6px;">${c.emoji}</div>
                    <div style="font-size:12px;font-weight:700;">${c.name}</div>
                </div>`).join('') +
                (hasCustom ? `<div onclick="CursorManager.apply('custom');CursorManager._updateTouchCursorVisual();"
                    style="padding:14px;border-radius:12px;border:2px solid ${'custom'===cur?'#0ea5e9':'rgba(255,255,255,0.08)'};background:${'custom'===cur?'rgba(14,165,233,0.12)':'rgba(255,255,255,0.03)'};cursor:pointer;transition:.15s;text-align:center;">
                    <div style="font-size:26px;margin-bottom:6px;">📁</div>
                    <div style="font-size:12px;font-weight:700;">Custom</div>
                </div>` : '');
        }
    };
    CursorManager.init();

    window.WallpaperGen = window.ThemeStore;

    /* ── toggle theme engine from settings ──────────────────────── */
    window.toggleThemeEngine = function(el) {
        const nowOn = !el.classList.contains('active');
        el.classList.toggle('active', nowOn);
        userSettings.themeEngineEnabled = nowOn;
        if (!nowOn) {
            // Revert all icons to originals
            const backups = userSettings.themeEngineIconBackups || {};
            installedApps.forEach(a => { if (backups[a.id] !== undefined) a.icon = backups[a.id]; });
            cloudApps.forEach(a  => { if (backups[a.id] !== undefined) a.icon = backups[a.id]; });
            userSettings.desktopIcons.forEach(di => { if (backups[di.appId]) di.icon = backups[di.appId]; });
            userSettings.activeThemeId = null;
            localStorage.setItem('hyos_installed_apps', JSON.stringify(installedApps));
            saveSettings();
            renderDesktopIcons();
            notify('🎨 Theme Engine', 'Disabled — all icons restored.');
        } else {
            saveSettings();
            notify('🎨 Theme Engine', 'Enabled — visit Theme Store to apply a theme.');
        }
    };

    /* ── open theme store window ────────────────────────────────── */
    window.openThemeStore = window.openWallpaperGen = function() {
        let win = document.getElementById('themestore-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'themestore-win';
            win.className = 'window';
            win.style.cssText = 'width:680px;height:520px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:16px;">🎨</span>
                        <span class="font-bold text-sm">Theme Store</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="closeApp('themestore-win')" class="win-ctrl-btn win-ctrl-close">✕</button>
                    </div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:column;">
                    <!-- Tab bar -->
                    <div style="display:flex;gap:2px;padding:10px 14px 0;border-bottom:1px solid rgba(255,255,255,0.07);flex-shrink:0;overflow-x:auto;">
                        <button id="ts-tab-themes"     onclick="ThemeStore.switchTab('themes')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:rgba(14,165,233,0.15);color:#7dd3fc;border-bottom:2px solid #0ea5e9;white-space:nowrap;" class="active">🎨 Themes</button>
                        <button id="ts-tab-wallpapers" onclick="ThemeStore.switchTab('wallpapers')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">🖼️ Wallpapers</button>
                        <button id="ts-tab-iconmaker"  onclick="ThemeStore.switchTab('iconmaker')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">✏️ Icons</button>
                        <button id="ts-tab-sounds"     onclick="ThemeStore.switchTab('sounds')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">🔊 Sounds</button>
                        <button id="ts-tab-fonts"      onclick="ThemeStore.switchTab('fonts')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">🔤 Fonts</button>
                        <button id="ts-tab-cursors"    onclick="ThemeStore.switchTab('cursors')"
                            style="padding:8px 16px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;transition:.15s;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">🖱️ Cursors</button>
                    </div>
                    <!-- Themes body -->
                    <div id="ts-body-themes" style="flex:1;overflow-y:auto;padding:16px;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:14px;">Full themes — wallpaper + accent color + icon pack. Click to apply.</div>
                        <div id="ts-themes-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;"></div>
                    </div>
                    <!-- Wallpapers body -->
                    <div id="ts-body-wallpapers" style="flex:1;overflow-y:auto;padding:16px;display:none;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:14px;">CSS-crafted wallpaper presets — applies wallpaper only, no icon changes.</div>
                        <div id="ts-wall-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-bottom:16px;"></div>
                        <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:14px;">
                            <div style="font-size:11px;opacity:0.5;margin-bottom:8px;">Custom wallpaper URL</div>
                            <div style="display:flex;gap:8px;">
                                <input id="custom-wall-url" placeholder="https://example.com/image.jpg"
                                    style="flex:1;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                                <button onclick="applyCustomWallpaper()" style="padding:8px 12px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;border-radius:8px;cursor:pointer;font-size:12px;font-weight:700;">Apply</button>
                            </div>
                        </div>
                    </div>
                    <!-- Icon Maker body -->
                    <div id="ts-body-iconmaker" style="flex:1;overflow-y:auto;padding:16px;display:none;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:6px;">Change the icon for any installed app. Changes are saved as part of the active theme.</div>
                        <div style="font-size:10px;opacity:0.35;margin-bottom:14px;padding:8px 10px;background:rgba(255,255,255,0.03);border-radius:8px;border:1px solid rgba(255,255,255,0.06);">
                            ℹ️ To revert all icons, go to <strong>Settings → Personalization</strong> and toggle Theme Engine off.
                        </div>
                        <div id="ts-icon-list"></div>
                    </div>
                    <!-- Sounds body -->
                    <div id="ts-body-sounds" style="flex:1;overflow-y:auto;padding:16px;display:none;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:14px;">Sound packs change system sounds like notifications, clicks and window events.</div>
                        <div id="ts-sound-packs" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-bottom:20px;"></div>
                        <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:14px;">
                            <div style="font-size:12px;font-weight:700;margin-bottom:10px;">🔊 Import Custom Sound</div>
                            <div style="font-size:10px;opacity:0.4;margin-bottom:10px;">Import an .mp3 or .wav file to use as a custom notification sound.</div>
                            <div style="display:flex;gap:8px;flex-wrap:wrap;">
                                <select id="ts-sound-slot" style="flex:1;min-width:120px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                                    <option value="notification">Notification</option>
                                    <option value="click">Click</option>
                                    <option value="open">Window Open</option>
                                    <option value="close">Window Close</option>
                                    <option value="error">Error</option>
                                </select>
                                <button onclick="ThemeStore.importSound()" style="padding:8px 14px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;border-radius:8px;cursor:pointer;font-size:12px;font-weight:700;">📂 Import</button>
                            </div>
                            <div id="ts-sound-current" style="margin-top:12px;font-size:11px;opacity:0.4;">No custom sounds imported yet.</div>
                        </div>
                    </div>
                    <!-- Fonts body -->
                    <div id="ts-body-fonts" style="flex:1;overflow-y:auto;padding:16px;display:none;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:14px;">Change the system font. Applied to the entire OS.</div>
                        <div id="ts-font-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-bottom:20px;"></div>
                        <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:14px;">
                            <div style="font-size:12px;font-weight:700;margin-bottom:10px;">🔤 Import Custom Font</div>
                            <div style="font-size:10px;opacity:0.4;margin-bottom:10px;">Import a .ttf, .otf, or .woff2 file, or paste a Google Fonts URL.</div>
                            <div style="display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
                                <input id="ts-font-url" placeholder="https://fonts.googleapis.com/css2?family=..." style="flex:1;min-width:140px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:white;font-size:12px;outline:none;">
                                <button onclick="ThemeStore.importFontURL()" style="padding:8px 14px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;border-radius:8px;cursor:pointer;font-size:12px;font-weight:700;">Apply URL</button>
                            </div>
                            <button onclick="ThemeStore.importFontFile()" style="width:100%;padding:9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:rgba(255,255,255,0.6);cursor:pointer;font-size:12px;font-weight:700;">📂 Import Font File (.ttf / .otf / .woff2)</button>
                            <button onclick="ThemeStore.resetFont()" style="width:100%;margin-top:8px;padding:9px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:8px;color:#f87171;cursor:pointer;font-size:12px;font-weight:700;">↩ Reset to Default Font</button>
                        </div>
                    </div>
                    <!-- Cursors body -->
                    <div id="ts-body-cursors" style="flex:1;overflow-y:auto;padding:16px;display:none;flex-direction:column;">
                        <div style="font-size:11px;opacity:0.4;margin-bottom:14px;">Custom cursor themes. On mobile, a touch cursor overlay follows your finger.</div>
                        <div id="ts-cursor-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;margin-bottom:20px;"></div>
                        <div style="border-top:1px solid rgba(255,255,255,0.06);padding-top:14px;">
                            <div style="font-size:12px;font-weight:700;margin-bottom:10px;">📂 Import Custom Cursor</div>
                            <div style="font-size:10px;opacity:0.4;margin-bottom:10px;">.png .svg .cur .ico — recommended 32×32px</div>
                            <button onclick="CursorManager.importFile()" style="width:100%;padding:9px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:rgba(255,255,255,0.6);cursor:pointer;font-size:12px;font-weight:700;">📂 Import Cursor File</button>
                            <button onclick="CursorManager.reset()" style="width:100%;margin-top:8px;padding:9px;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.2);border-radius:8px;color:#f87171;cursor:pointer;font-size:12px;font-weight:700;">↩ Reset to System Cursor</button>
                        </div>
                    </div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
            // Tab button active style logic
            win.querySelectorAll('[id^=ts-tab-]').forEach(btn => {
                btn.addEventListener('click', function() {
                    win.querySelectorAll('[id^=ts-tab-]').forEach(b => {
                        b.style.background = 'transparent';
                        b.style.color = 'rgba(255,255,255,0.4)';
                        b.style.borderBottom = '2px solid transparent';
                    });
                    this.style.background = 'rgba(14,165,233,0.15)';
                    this.style.color = '#7dd3fc';
                    this.style.borderBottom = '2px solid #0ea5e9';
                });
            });
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
        setTimeout(() => ThemeStore.switchTab('themes'), 50);
    };

    window.applyCustomWallpaper = function() {
        const url = document.getElementById('custom-wall-url')?.value?.trim();
        if (!url) return;
        const bg = document.getElementById('desktop-bg');
        if (bg) { bg.style.background = `url('${url}') center/cover no-repeat`; }
        notify('🖼️ Wallpaper', 'Custom wallpaper applied!');
    };

    // ─── FEATURE 14: FOCUS MODE + SNAP WINDOWS ───────────────────
    window.snapWindow = function(winId, side) {
        const win = document.getElementById(winId);
        if (!win) return;
        win.classList.remove('maximized');
        const h = window.innerHeight - 110, top = 38;
        const map = {
            left: `left:0;top:${top}px;width:50vw;height:${h}px;`,
            right: `left:50vw;top:${top}px;width:50vw;height:${h}px;`,
            tl: `left:0;top:${top}px;width:50vw;height:${h/2}px;`,
            tr: `left:50vw;top:${top}px;width:50vw;height:${h/2}px;`,
            bl: `left:0;top:${top+h/2}px;width:50vw;height:${h/2}px;`,
            br: `left:50vw;top:${top+h/2}px;width:50vw;height:${h/2}px;`
        };
        if (side === 'max') { win.classList.add('maximized'); return; }
        if (map[side]) win.style.cssText += `;${map[side]};transform:none;border-radius:0;`;
    };
    document.addEventListener('keydown', (e) => {
        if (!e.ctrlKey || !e.shiftKey) return;
        const activeWin = [...document.querySelectorAll('.window')].sort((a,b) => parseInt(b.style.zIndex||0)-parseInt(a.style.zIndex||0))[0];
        if (!activeWin) return;
        if (e.key==='ArrowLeft'){e.preventDefault();snapWindow(activeWin.id,'left');}
        if (e.key==='ArrowRight'){e.preventDefault();snapWindow(activeWin.id,'right');}
        if (e.key==='ArrowUp'){e.preventDefault();snapWindow(activeWin.id,'max');}
    });

    // ─── FEATURE 15: EMOJI PICKER ────────────────────────────────
    window.EmojiPicker = {
        cats: {
            '😀':['😀','😂','🥲','😎','🤩','😍','🥰','😴','🤔','😤','🥺','😱','🤗','😇','🤯','🥳','😭','🙃','😏','😑'],
            '👋':['👋','✋','🤚','🖐','👌','✌','🤞','🤙','💪','🦾','👐','🙌','👏','🤲','🤜','🤛'],
            '❤️':['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝'],
            '⭐':['⭐','🌟','✨','💫','🌙','☀️','🌈','⚡','🔥','❄️','🌊','🌸','🌺','🍀','🌴','🦋'],
            '🎉':['🎉','🎊','🎈','🎁','🏆','🎯','🎮','🕹','🎲','🎸','🎵','🎶','🚀','💡','✅','🔥'],
            '🐶':['🐶','🐱','🐭','🐰','🦊','🐻','🐼','🦁','🐯','🦋','🐙','🦈','🦄','🐲','🦅','🦜'],
            '🍕':['🍕','🍔','🍟','🌮','🌯','🥗','🍜','🍱','🍣','🧁','🍰','☕','🧃','🍺','🥤','🍩']
        },
        render(cat) {
            const grid = document.getElementById('emoji-grid');
            const emojis = cat ? this.cats[cat] : Object.values(this.cats).flat();
            if (grid) grid.innerHTML = emojis.map(e => `<span onclick="EmojiPicker.pick('${e}')" style="font-size:22px;cursor:pointer;padding:5px;border-radius:8px;display:inline-block;transition:0.1s;line-height:1;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='transparent'">${e}</span>`).join('');
        },
        pick(emoji) {
            navigator.clipboard?.writeText(emoji).then(() => notify('😀 Emoji', `${emoji} copied!`));
            document.getElementById('emoji-picker-panel').style.display = 'none';
        },
        open() {
            let panel = document.getElementById('emoji-picker-panel');
            if (!panel) {
                panel = document.createElement('div');
                panel.id = 'emoji-picker-panel';
                panel.style.cssText = 'position:fixed;bottom:72px;right:60px;width:300px;background:rgba(5,8,16,0.98);border:1px solid rgba(14,165,233,0.2);border-radius:16px;z-index:20000;backdrop-filter:blur(30px);box-shadow:0 -10px 40px rgba(0,0,0,0.7);display:none;flex-direction:column;overflow:hidden;';
                const catKeys = Object.keys(this.cats);
                panel.innerHTML = `
                    <div style="padding:10px;border-bottom:1px solid rgba(255,255,255,0.07);display:flex;gap:4px;flex-wrap:wrap;">
                        ${catKeys.map(c=>`<button onclick="EmojiPicker.render('${c}')" style="font-size:16px;background:transparent;border:none;cursor:pointer;padding:4px;border-radius:6px;transition:0.1s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='transparent'">${c}</button>`).join('')}
                        <button onclick="EmojiPicker.render()" style="font-size:12px;background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.25);color:#0ea5e9;border-radius:8px;padding:4px 8px;cursor:pointer;font-weight:700;">All</button>
                        <button onclick="this.closest('#emoji-picker-panel').style.display='none'" style="margin-left:auto;font-size:12px;background:transparent;border:none;color:rgba(255,255,255,0.4);cursor:pointer;padding:4px;">✕</button>
                    </div>
                    <div id="emoji-grid" style="padding:10px;max-height:200px;overflow-y:auto;line-height:1.8;"></div>
                    <div style="padding:8px 10px;border-top:1px solid rgba(255,255,255,0.06);font-size:10px;opacity:0.35;text-align:center;">Click to copy emoji</div>`;
                document.body.appendChild(panel);
            }
            const isOpen = panel.style.display !== 'none';
            panel.style.display = isOpen ? 'none' : 'flex';
            if (!isOpen) this.render();
        }
    };
    // Add emoji button to statusbar
    setTimeout(() => {
        const sRight = document.querySelector('.statusbar-right');
        if (sRight && !document.getElementById('emoji-sb-btn')) {
            const btn = document.createElement('div');
            btn.id = 'emoji-sb-btn';
            btn.className = 'statusbar-item';
            btn.textContent = '😀';
            btn.title = 'Emoji Picker';
            btn.onclick = () => EmojiPicker.open();
            sRight.insertBefore(btn, sRight.firstChild);
        }
    }, 500);

    // ─── FEATURE 16: HYLEY ADVANCED COMMANDS ─────────────────────
    window.HyleyMemory = {
        facts: JSON.parse(localStorage.getItem('hyley_mem') || '[]'),
        add(f) { this.facts.unshift({f,t:Date.now()}); if(this.facts.length>30) this.facts.pop(); localStorage.setItem('hyley_mem', JSON.stringify(this.facts)); },
        find(q) { return this.facts.find(f => f.f.toLowerCase().includes(q.toLowerCase())); }
    };
    const _prevHyleyProcessor = window.processHyleyMessage;
    window.processHyleyMessage = function(msg) {
        const m = msg.toLowerCase().trim();
        // Memory
        if (/^(remember|note that)\s+/i.test(msg)) { const f=msg.replace(/^(remember|note that)\s+/i,''); HyleyMemory.add(f); return `✅ Remembered: <em>${f}</em>`; }
        if (/^(what do you know about|do you remember)\s+/i.test(msg)) { const q=msg.replace(/^(what do you know about|do you remember)\s+/i,''); const found=HyleyMemory.find(q); return found?`🧠 Yes: <em>${found.f}</em>`:`Nothing about "${q}" yet. Try "remember ..."!`; }
        if (m==='what do you remember'||m==='my memories') { const all=HyleyMemory.facts; return all.length?`🧠 ${all.length} memories:<br>`+all.slice(0,6).map(f=>`• ${f.f}`).join('<br>'):`No memories yet! Say "remember [fact]"`; }
        // App launchers
        if(m.includes('draw')||m.includes('hydraw')){openHyDraw();return'🎨 Opening HyDraw!';}
        if(m.includes('music')||m.includes('hymusic')){openHyMusic();return'🎵 Opening HyMusic!';}
        if(m.includes('pomodoro')||m.includes('focus timer')){openPomodoro();return'⏱️ Pomodoro timer opened!';}
        if(m.includes('world clock')){openWorldClock();return'🌍 World Clock opened!';}
        if(m.includes('unit converter')||m.includes('convert ')){openUnitConverter();return'🔢 Unit Converter opened!';}
        if(m.includes('color picker')){openColorPicker();return'🎨 Color Picker opened!';}
        if(m.includes('clipboard')){openClipboardManager();return'📋 Clipboard Manager opened!';}
        if(m.includes('quick notes')){openQuickNotes();return'📝 Quick Notes opened!';}
        if(m.includes('theme')){openThemeStore();return'🎨 Theme Store opened!';}
        if(m.includes('wallpaper')){openThemeStore();return'🎨 Theme Store opened!';}
        if(m.includes('password vault')||m.includes('vault')){openPasswordVault();return'🔑 Password Vault opened!';}
        if(m.includes('widgetland')||m.includes('widgets')){openWidgetland();return'✦ Widgetland opened!';}
        // Focus & Night Light
        if(m.includes('focus mode')){toggleFocusMode();return`🎯 Focus Mode ${_focusModeActive?'ON':'OFF'}!`;}
        if(m.includes('night light')||m.includes('blue light')){toggleNightLight();return`🌙 Night light ${_nightLightOn?'ON':'OFF'}!`;}
        // Fun stuff
        const facts=['🌍 There are more chess games possible than atoms in the universe!','🐙 Octopuses have 3 hearts and blue blood!','⚡ Lightning strikes Earth ~100 times per second!','🧠 Your brain uses about 23 watts — enough to power a light bulb!','🎵 Music triggers dopamine release just like food or love!'];
        if(m.includes('fact')||m.includes('trivia')||m.includes('interesting')){return facts[Math.floor(Math.random()*facts.length)];}
        const quotes=['"Make it work, make it right, make it fast." — Kent Beck','"Simplicity is the soul of efficiency." — Austin Freeman','"Code is like humor. When you have to explain it, it\'s bad." — Cory House'];
        if(m.includes('quote')||m.includes('inspire')){return'💬 '+quotes[Math.floor(Math.random()*quotes.length)];}
        // Math eval
        const mathM = msg.match(/^[\s\d+\-*/().%^,]+$/);
        if (mathM) { try { const r=Function('"use strict";return('+msg.replace(/\^/g,'**')+')')(); if(typeof r==='number'&&isFinite(r)) return `🧮 <strong>${msg} = ${r.toLocaleString()}</strong>`; } catch(e){} }
        if (m.includes('system info')) { const up=Math.floor(performance.now()/60000); const mem=performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576):'?'; return `💻 HyOS HS<br>⏱ Uptime: ${up}min<br>🧠 Memory: ${mem}MB<br>✅ All systems OK`; }
        return _prevHyleyProcessor ? _prevHyleyProcessor(msg) : null;
    };

    // ─── FEATURE 17: KEYBOARD SHORTCUTS ──────────────────────────
    window.showShortcutHelp = function() {
        let win = document.getElementById('shortcuts-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'shortcuts-win';
            win.className = 'window';
            win.style.cssText = 'width:500px;height:500px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            const shortcuts = [
                ['Ctrl+Shift+W','Open Widgetland'],['Ctrl+Shift+N','Quick Notes'],['Ctrl+Shift+F','Focus Mode'],['Ctrl+Shift+L','Night Light'],['Ctrl+Shift+D','HyDraw'],['Ctrl+Shift+M','HyMusic'],['Ctrl+Shift+E','Emoji Picker'],['Ctrl+Shift+?','This Help'],['Ctrl+Shift+→','Snap Window Right'],['Ctrl+Shift+←','Snap Window Left'],['Ctrl+Shift+↑','Maximize Window'],['Win+G','Game Bar'],['Ctrl+Z','Undo (in HyDraw)']
            ];
            win.innerHTML = `
                <div class="win-header">
                    <div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">⌨️</span><span class="font-bold text-sm">Keyboard Shortcuts</span></div>
                    <div class="flex gap-2"><button onclick="closeApp('shortcuts-win')" class="win-ctrl-btn win-ctrl-close">✕</button></div>
                </div>
                <div class="win-body" style="background:#050810;padding:20px;overflow-y:auto;">
                    <div style="font-size:12px;opacity:0.5;margin-bottom:16px;">HyOS HS keyboard shortcuts for power users</div>
                    ${shortcuts.map(([k,d])=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;border-radius:8px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);margin-bottom:6px;"><span style="font-size:12px;opacity:0.8;">${d}</span><kbd style="background:rgba(14,165,233,0.12);border:1px solid rgba(14,165,233,0.3);color:#0ea5e9;padding:4px 8px;border-radius:6px;font-size:11px;font-family:monospace;font-weight:700;">${k}</kbd></div>`).join('')}
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
        }
        win.style.display = 'flex'; win.style.zIndex = 600;
    };
    document.addEventListener('keydown', (e) => {
        if (!e.ctrlKey || !e.shiftKey) return;
        if (e.key==='W') { e.preventDefault(); openWidgetland(); }
        if (e.key==='N') { e.preventDefault(); openQuickNotes(); }
        if (e.key==='F') { e.preventDefault(); toggleFocusMode(); }
        if (e.key==='L') { e.preventDefault(); toggleNightLight(); }
        if (e.key==='D') { e.preventDefault(); openHyDraw(); }
        if (e.key==='M') { e.preventDefault(); openHyMusic(); }
        if (e.key==='E') { e.preventDefault(); EmojiPicker.open(); }
        if (e.key==='?') { e.preventDefault(); showShortcutHelp(); }
        const wins = [...document.querySelectorAll('.window')].filter(w=>w.style.display!=='none');
        if (!wins.length) return;
        const top = wins.sort((a,b)=>parseInt(b.style.zIndex||0)-parseInt(a.style.zIndex||0))[0];
        if (e.key==='ArrowLeft') { e.preventDefault(); snapWindow(top.id,'left'); }
        if (e.key==='ArrowRight') { e.preventDefault(); snapWindow(top.id,'right'); }
        if (e.key==='ArrowUp') { e.preventDefault(); snapWindow(top.id,'max'); }
    });

    // ─── FEATURE 18: STATUSBAR MINI MUSIC PLAYER ─────────────────
    setTimeout(() => {
        const sl = document.querySelector('.statusbar-left');
        if (sl && !document.getElementById('music-mini')) {
            const el = document.createElement('div');
            el.id = 'music-mini';
            el.className = 'statusbar-item';
            el.style.cssText = 'font-size:11px;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer;';
            el.onclick = openHyMusic;
            el.title = 'Open HyMusic';
            sl.appendChild(el);
        }
    }, 600);

    // ─── FEATURE 19: NEW WIDGETS BUNDLE ──────────────────────────
    setTimeout(() => {
        if (typeof WidgetSystem === 'undefined') return;
        WidgetSystem.builtinWidgets.push(
            { id:'worldtime', name:'World Time', size:'medium', icon:'🌍', desc:'3 timezones',
              preview:'<div style="padding:10px;font-size:12px;"><div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span style="opacity:0.5;">🇺🇸 NY</span><strong style="color:#0ea5e9;font-family:monospace;">12:00 PM</strong></div><div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span style="opacity:0.5;">🇬🇧 LDN</span><strong style="color:#0ea5e9;font-family:monospace;">5:00 PM</strong></div></div>',
              render() { const uid='wt'+Date.now(); return `<div id="${uid}" style="padding:10px;display:flex;flex-direction:column;gap:6px;"></div>`; },
              init(el) {
                  const zones=[['🇺🇸','NY','America/New_York'],['🇬🇧','LDN','Europe/London'],['🇯🇵','TYO','Asia/Tokyo']];
                  const c=el.querySelector('div');
                  const upd=()=>{if(!c)return;const n=new Date();c.innerHTML=zones.map(([f,ci,tz])=>`<div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;"><span style="opacity:0.5;">${f} ${ci}</span><strong style="font-family:monospace;color:#0ea5e9;">${n.toLocaleTimeString('en-US',{timeZone:tz,hour:'2-digit',minute:'2-digit',hour12:true})}</strong></div>`).join('');};
                  upd(); setInterval(upd,10000);
              }
            },
            { id:'cryptoticker', name:'Crypto Ticker', size:'small', icon:'₿', desc:'Live simulated prices',
              preview:'<div style="padding:10px;text-align:center;"><div style="font-size:16px;font-weight:800;color:#f59e0b;">₿ $67,420</div><div style="font-size:10px;color:#34d399;">+2.4% ↑</div></div>',
              render() { return `<div id="ctick${Date.now()}" style="padding:10px;"></div>`; },
              init(el) {
                  const c=el.querySelector('div'), coins=[{s:'₿ BTC',b:67420,col:'#f59e0b'},{s:'Ξ ETH',b:3284,col:'#a78bfa'},{s:'◎ SOL',b:178,col:'#0ea5e9'}];
                  const upd=()=>{if(!c)return;c.innerHTML=coins.map(({s,b,col})=>{const d=(Math.random()-0.48)*2,p=(b*(1+d*0.005)).toFixed(0),pc=(d*0.5).toFixed(2),up=parseFloat(pc)>=0;return`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;"><span style="font-size:11px;font-weight:700;color:${col}">${s}</span><div style="text-align:right"><div style="font-size:11px;font-weight:800;font-family:monospace;">$${parseInt(p).toLocaleString()}</div><div style="font-size:9px;color:${up?'#34d399':'#f87171'}">${up?'+':''}${pc}%</div></div></div>`;}).join('');};
                  upd(); setInterval(upd,3000);
              }
            },
            { id:'quicknotes_widget', name:'Quick Note', size:'small', icon:'📌', desc:'Tap-to-type notes',
              preview:'<div style="padding:10px;font-size:11px;opacity:0.7;font-style:italic;">Tap to write a note…</div>',
              render() { const s=localStorage.getItem('hyos_sticky')||''; return `<div style="padding:8px;"><textarea placeholder="Write a note…" onchange="localStorage.setItem('hyos_sticky',this.value)" style="width:100%;background:transparent;border:none;color:white;font-size:12px;resize:none;outline:none;height:80px;font-family:Outfit,sans-serif;line-height:1.5;-webkit-tap-highlight-color:transparent;">${s}</textarea></div>`; }
            }
        );
    }, 1000);

    // ─── FEATURE 20: CONTEXT MENU ADDITIONS ──────────────────────
    setTimeout(() => {
        const cm = document.getElementById('context-menu');
        if (!cm) return;
        const existing = cm.querySelector('div');
        if (!existing) return;
        const extras = document.createElement('div');
        extras.innerHTML = `
            <div class="context-menu-item" onclick="openHyDraw();hideContextMenu()">🎨 <span>HyDraw</span></div>
            <div class="context-menu-item" onclick="openHyMusic();hideContextMenu()">🎵 <span>HyMusic</span></div>
            <div class="context-menu-item" onclick="openPomodoro();hideContextMenu()">⏱️ <span>Pomodoro Timer</span></div>
            <div class="context-menu-item" onclick="toggleFocusMode();hideContextMenu()">🎯 <span>Toggle Focus Mode</span></div>
            <div class="context-menu-item" onclick="openThemeStore();hideContextMenu()">🎨 <span>Theme Store</span></div>
            <div class="context-menu-item" onclick="openThemeStore();hideContextMenu()">🖼️ <span>Wallpapers</span></div>`;
        const cancelBtn = existing.querySelector('.context-menu-item:last-child');
        if (cancelBtn) existing.insertBefore(extras, cancelBtn);
        else existing.appendChild(extras);
    }, 1000);

    // ─── FEATURE 21: CONTROL CENTER EXTRAS ───────────────────────
    setTimeout(() => {
        const cc = document.getElementById('control-center');
        if (!cc) return;
        const ccBody = cc.querySelector('div:nth-child(2)');
        if (!ccBody) return;
        const extras = document.createElement('div');
        extras.style.cssText = 'margin-top:12px;display:grid;grid-template-columns:repeat(3,1fr);gap:8px;';
        extras.innerHTML = `
            <div onclick="toggleNightLight()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:12px 8px;border-radius:10px;cursor:pointer;text-align:center;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                <div style="font-size:20px;margin-bottom:4px;">🌙</div>
                <div style="font-size:10px;font-weight:600;" id="nightlight-btn">Night Light</div>
            </div>
            <div onclick="toggleFocusMode()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:12px 8px;border-radius:10px;cursor:pointer;text-align:center;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                <div style="font-size:20px;margin-bottom:4px;">🎯</div>
                <div style="font-size:10px;font-weight:600;">Focus</div>
            </div>
            <div onclick="showShortcutHelp()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:12px 8px;border-radius:10px;cursor:pointer;text-align:center;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                <div style="font-size:20px;margin-bottom:4px;">⌨️</div>
                <div style="font-size:10px;font-weight:600;">Shortcuts</div>
            </div>`;
        ccBody.insertBefore(extras, ccBody.querySelector('button'));
    }, 800);

    // ─── FEATURE 22: TASKBAR QUICK LAUNCH EXTRAS ─────────────────
    // Clipboard, Quick Notes, and Emoji are standalone apps accessible from All Apps
    // They are intentionally NOT injected into the taskbar to keep it clean

    // ─── FEATURE 23: REGISTER IN GLOBAL SEARCH ───────────────────
    setTimeout(() => {
        if (!window.GlobalSearch) return;
        GlobalSearch.commands.push(
            { name:'HyDraw',         desc:'Drawing canvas',        action:'openHyDraw()',        icon:'tool' },
            { name:'HyMusic',        desc:'Music player',          action:'openHyMusic()',       icon:'tool' },
            { name:'Pomodoro',       desc:'Focus / work timer',    action:'openPomodoro()',      icon:'tool' },
            { name:'World Clock',    desc:'Multiple timezones',    action:'openWorldClock()',    icon:'tool' },
            { name:'Unit Converter', desc:'Convert any unit',      action:'openUnitConverter()',  icon:'tool' },
            { name:'Color Picker',   desc:'Pick and convert colors',action:'openColorPicker()',  icon:'tool' },
            { name:'Password Vault', desc:'Local password manager',action:'openPasswordVault()', icon:'tool' },
            { name:'Theme Store',    desc:'Themes, wallpapers & icon maker', action:'openThemeStore()',    icon:'tool' },
            { name:'AI Wallpapers',  desc:'Wallpaper presets',     action:'openThemeStore()',  icon:'tool' },
            { name:'All Apps',       desc:'Browse & pin all apps', action:'openAllApps()',      icon:'tool' },
            { name:'Clipboard',      desc:'Clipboard history',     action:'openClipboardManager()',icon:'tool'},
            { name:'Quick Notes',    desc:'Fast sticky notes',     action:'openQuickNotes()',    icon:'tool' },
            { name:'Focus Mode',     desc:'Dim distractions',      action:'toggleFocusMode()',   icon:'tool' },
            { name:'Night Light',    desc:'Blue light filter',     action:'toggleNightLight()',  icon:'tool' },
            { name:'Shortcuts',      desc:'Keyboard shortcuts list',action:'showShortcutHelp()', icon:'tool' }
        );
        if (window.buildStartMenu) buildStartMenu();
    }, 2500);

    // ═══════════════════════════════════════════════════════════════
    // ALL APPS LAUNCHER — every app, pinnable, searchable
    // ═══════════════════════════════════════════════════════════════
    const ALL_APPS_REGISTRY = [
        // System / built-in apps
        { id:'sys-calculator',  name:'Calculator',      icon:'🧮', cat:'System',    action:'openCalculator()' },
        { id:'sys-terminal',    name:'Terminal',        icon:'⌨️', cat:'System',    action:'openTerminal()' },
        { id:'sys-hyfiles',     name:'HyFiles',         icon:'📁', cat:'System',    action:"toggleApp('hyfiles-win')" },
        { id:'sys-notepad',     name:'Notepad',         icon:'📝', cat:'System',    action:'Notepad.newFile()' },
        { id:'sys-maker',       name:'App Maker',       icon:'🛠️', cat:'System',    action:'openMaker()' },
        { id:'sys-browser',     name:'HyBrowser',       icon:'🌐', cat:'System',    action:'openHyBrowser()' },
        { id:'sys-settings',    name:'Settings',        icon:'⚙️', cat:'System',    action:"toggleApp('settings-win')" },
        { id:'sys-media',       name:'Media Library',   icon:'📸', cat:'System',    action:'openMediaViewer()' },
        // Built-in tools
        { id:'tool-hydraw',     name:'HyDraw',          icon:'🎨', cat:'Tools',     action:'openHyDraw()' },
        { id:'tool-hymusic',    name:'HyMusic',         icon:'🎵', cat:'Tools',     action:'openHyMusic()' },
        { id:'tool-pomodoro',   name:'Pomodoro',        icon:'⏱️', cat:'Tools',     action:'openPomodoro()' },
        { id:'tool-worldclock', name:'World Clock',     icon:'🕐', cat:'Tools',     action:'openWorldClock()' },
        { id:'tool-converter',  name:'Unit Converter',  icon:'⚖️', cat:'Tools',     action:'openUnitConverter()' },
        { id:'tool-colorpick',  name:'Color Picker',    icon:'🎨', cat:'Tools',     action:'openColorPicker()' },
        { id:'tool-vault',      name:'Password Vault',  icon:'🔐', cat:'Tools',     action:'openPasswordVault()' },
        { id:'tool-themestore', name:'Theme Store',     icon:'🖼️', cat:'Tools',     action:'openThemeStore()' },
        { id:'tool-clipboard',  name:'Clipboard',       icon:'📋', cat:'Tools',     action:'openClipboardManager()' },
        { id:'tool-quicknotes', name:'Quick Notes',     icon:'📌', cat:'Tools',     action:'openQuickNotes()' },
        { id:'tool-emoji',      name:'Emoji Picker',    icon:'😀', cat:'Tools',     action:'EmojiPicker.open()' },
        { id:'tool-widgetland', name:'Widgetland',      icon:'🧩', cat:'Tools',     action:'openWidgetland()' },
        { id:'tool-hyvm',       name:'HyVM',            icon:'💻', cat:'Tools',     action:'openHyVM()' },
        // Social
        { id:'sys-hypeople',    name:'People',          icon:'👥', cat:'Social',    action:'openHyPeople()' },
    ];

    window.renderPinnedApps = function() {
        const bar = document.getElementById('taskbar-pinned');
        if (!bar) return;
        const pinned = userSettings.pinnedApps || [];
        if (pinned.length === 0) { bar.innerHTML = ''; return; }
        bar.innerHTML = `
            <div class="taskbar-sep"></div>
            ${pinned.map(p => {
                const isImg = p.icon?.startsWith('data');
                return `<div class="task-btn" onclick="${p.action}" title="${p.name}" style="gap:5px;padding:0 10px;position:relative;" oncontextmenu="event.preventDefault();showPinnedCtx(event,'${p.id}')">
                    <span style="font-size:16px;">${isImg ? `<img src="${p.icon}" style="width:18px;height:18px;border-radius:4px;object-fit:cover;">` : p.icon}</span>
                    <span style="font-size:11px;">${p.name}</span>
                </div>`;
            }).join('')}`;
    };

    window.showPinnedCtx = function(e, appId) {
        document.querySelectorAll('.pinned-ctx').forEach(m => m.remove());
        const m = document.createElement('div');
        m.className = 'context-menu pinned-ctx';
        m.style.cssText = `display:block;left:${Math.min(e.clientX,window.innerWidth-180)}px;top:${e.clientY-60}px;`;
        m.innerHTML = `<div class="context-menu-item" onclick="unpinApp('${appId}');this.parentElement.remove()">📌 Unpin from Taskbar</div>`;
        document.body.appendChild(m);
        setTimeout(()=>{ const c=()=>{m.remove();document.removeEventListener('click',c);}; document.addEventListener('click',c); },10);
    };

    window.pinApp = function(appId) {
        if (!userSettings.pinnedApps) userSettings.pinnedApps = [];
        // Check registry first, then installedApps
        const regApp = ALL_APPS_REGISTRY.find(a => a.id === appId);
        const instApp = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
        const src = regApp || instApp;
        if (!src) return;
        if (userSettings.pinnedApps.find(p => p.id === appId)) {
            notify('Already Pinned', src.name + ' is already in the taskbar');
            return;
        }
        const entry = {
            id: src.id,
            name: src.name,
            icon: src.icon,
            action: regApp ? src.action : `showInfo('${src.id}','installed')`
        };
        userSettings.pinnedApps.push(entry);
        saveSettings();
        renderPinnedApps();
        notify('📌 Pinned', src.name + ' added to taskbar');
    };

    window.unpinApp = function(appId) {
        if (!userSettings.pinnedApps) return;
        const app = userSettings.pinnedApps.find(p => p.id === appId);
        userSettings.pinnedApps = userSettings.pinnedApps.filter(p => p.id !== appId);
        saveSettings();
        renderPinnedApps();
        if (app) notify('📌 Unpinned', app.name + ' removed from taskbar');
    };

    window.openAllApps = function() {
        let win = document.getElementById('allapps-win');
        if (!win) {
            win = document.createElement('div');
            win.id = 'allapps-win';
            win.className = 'window';
            win.style.cssText = 'width:820px;height:580px;left:50%;top:50%;transform:translate(-50%,-50%);display:flex;';
            win.innerHTML = `
                <div class="win-header" style="background:linear-gradient(135deg,rgba(14,165,233,0.12),rgba(10,15,30,0.99));">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:18px;">⊞</span>
                        <span class="font-bold" style="font-size:14px;">All Apps</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <input id="allapps-search" placeholder="Search apps…" oninput="AllApps.search(this.value)"
                            style="background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:6px 12px;color:white;font-size:12px;outline:none;width:200px;">
                        <button onclick="closeApp('allapps-win')" class="win-ctrl-btn win-ctrl-close" style="margin-left:4px;">✕</button>
                    </div>
                </div>
                <div class="win-body" style="background:#050810;display:flex;flex-direction:column;overflow:hidden;">
                    <!-- Category tabs -->
                    <div style="display:flex;gap:4px;padding:12px 16px 0;border-bottom:1px solid rgba(255,255,255,0.06);flex-shrink:0;overflow-x:auto;" id="allapps-tabs">
                        <button onclick="AllApps.filter('All')" class="allapps-tab active" style="padding:7px 14px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;background:rgba(14,165,233,0.15);color:#7dd3fc;border-bottom:2px solid #0ea5e9;white-space:nowrap;">All</button>
                        <button onclick="AllApps.filter('System')" class="allapps-tab" style="padding:7px 14px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">⚙️ System</button>
                        <button onclick="AllApps.filter('Tools')" class="allapps-tab" style="padding:7px 14px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">🛠️ Tools</button>
                        <button onclick="AllApps.filter('Installed')" class="allapps-tab" style="padding:7px 14px;border:none;border-radius:8px 8px 0 0;font-size:12px;font-weight:700;cursor:pointer;background:transparent;color:rgba(255,255,255,0.4);border-bottom:2px solid transparent;white-space:nowrap;">📦 Installed</button>
                    </div>
                    <!-- Grid -->
                    <div id="allapps-grid" style="flex:1;overflow-y:auto;padding:16px;display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;align-content:start;"></div>
                </div>`;
            document.getElementById('os-surface')?.appendChild(win);
            makeDraggable(win);
            // Tab style handler
            win.querySelectorAll('.allapps-tab').forEach(btn => {
                btn.addEventListener('click', function() {
                    win.querySelectorAll('.allapps-tab').forEach(b => {
                        b.style.background='transparent'; b.style.color='rgba(255,255,255,0.4)'; b.style.borderBottom='2px solid transparent';
                    });
                    this.style.background='rgba(14,165,233,0.15)';
                    this.style.color='#7dd3fc';
                    this.style.borderBottom='2px solid #0ea5e9';
                });
            });
        }
        win.style.display='flex'; win.style.zIndex=600;
        AllApps.render('All');
    };

    window.AllApps = {
        currentFilter: 'All',

        getAll() {
            const installed = installedApps.map(a => ({ ...a, cat: 'Installed', action: `showInfo('${a.id}','installed')` }));
            return [...ALL_APPS_REGISTRY, ...installed];
        },

        render(filter) {
            this.currentFilter = filter || this.currentFilter;
            const q = document.getElementById('allapps-search')?.value?.toLowerCase() || '';
            this.renderList(q);
        },

        search(q) { this.renderList(q.toLowerCase()); },

        renderList(q) {
            const grid = document.getElementById('allapps-grid');
            if (!grid) return;
            const pinned = (userSettings.pinnedApps || []).map(p => p.id);
            let apps = this.getAll();
            if (this.currentFilter !== 'All') apps = apps.filter(a => a.cat === this.currentFilter);
            if (q) apps = apps.filter(a => a.name.toLowerCase().includes(q) || (a.cat||'').toLowerCase().includes(q));
            if (apps.length === 0) {
                grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;opacity:.35;font-size:13px;">No apps found</div>';
                return;
            }
            grid.innerHTML = apps.map(app => {
                const isImg = app.icon?.startsWith('data');
                const isPinned = pinned.includes(app.id);
                return `
                    <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:14px 10px;text-align:center;cursor:pointer;transition:0.15s;position:relative;"
                         onclick="${app.action}"
                         onmouseover="this.style.background='rgba(255,255,255,0.07)';this.style.borderColor='rgba(14,165,233,0.35)'"
                         onmouseout="this.style.background='rgba(255,255,255,0.03)';this.style.borderColor='rgba(255,255,255,0.07)'">
                        <div style="width:52px;height:52px;margin:0 auto 10px;border-radius:13px;background:rgba(255,255,255,0.07);display:flex;align-items:center;justify-content:center;font-size:26px;overflow:hidden;">
                            ${isImg ? `<img src="${app.icon}" style="width:100%;height:100%;object-fit:cover;border-radius:11px;">` : app.icon}
                        </div>
                        <div style="font-size:11px;font-weight:700;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${app.name}</div>
                        <div style="font-size:9px;opacity:.35;margin-bottom:8px;">${app.cat}</div>
                        <button onclick="event.stopPropagation();${isPinned ? `unpinApp('${app.id}')` : `pinApp('${app.id}')`};AllApps.render();"
                            style="width:100%;padding:4px 6px;border-radius:7px;font-size:10px;font-weight:700;cursor:pointer;transition:0.15s;
                                   ${isPinned ? 'background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.4);color:#7dd3fc;' : 'background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.5);'}">
                            ${isPinned ? '📌 Pinned' : '📌 Pin'}
                        </button>
                    </div>`;
            }).join('');
        },

        filter(cat) { this.render(cat); }
    };

    // Render pinned apps on startup
    setTimeout(() => renderPinnedApps(), 1500);

    // ═══════════════════════════════════════════════════════════════
    // HYLEY RECOMMENDATIONS ENGINE
    // ═══════════════════════════════════════════════════════════════
    window.HyleyRecs = {
        current: 'apps',

        appRecs: [
            { icon:'🎨', name:'HyDraw',        reason:'Great for quick sketches & notes',        action:"openHyDraw()",        badge:'Creative' },
            { icon:'⏱️', name:'Pomodoro',       reason:'Boost focus with timed work sessions',    action:"openPomodoro()",       badge:'Productivity' },
            { icon:'🎵', name:'HyMusic',        reason:'Play music while you work',               action:"openHyMusic()",        badge:'Ambient' },
            { icon:'🔐', name:'Password Vault', reason:'Keep your credentials secure',            action:"openPasswordVault()",  badge:'Security' },
            { icon:'🌐', name:'HyBrowser',      reason:'Browse the web without leaving HyOS',    action:"openHyBrowser()",      badge:'Browse' },
            { icon:'⌨️', name:'Terminal',       reason:'Power user? The terminal awaits',         action:"openTerminal()",        badge:'Dev' },
            { icon:'⚖️', name:'Unit Converter', reason:'Quick conversions at your fingertips',   action:"openUnitConverter()",  badge:'Utility' },
            { icon:'🕐', name:'World Clock',    reason:'Track multiple timezones easily',         action:"openWorldClock()",     badge:'Time' },
            { icon:'📌', name:'Quick Notes',    reason:'Jot ideas instantly without losing flow', action:"openQuickNotes()",     badge:'Notes' },
            { icon:'🎨', name:'Color Picker',   reason:'Pick and convert colors on the fly',      action:"openColorPicker()",    badge:'Design' },
        ],

        themeRecs: [
            { theme: ThemeStore?.themes?.[0], reason:'Clean, minimal cyber aesthetic', fit:'Focus & work sessions' },
            { theme: ThemeStore?.themes?.[1], reason:'Soothing gradient for long sessions', fit:'Creative & relaxed moods' },
            { theme: ThemeStore?.themes?.[2], reason:'High energy neon for late nights', fit:'Night sessions & gaming' },
            { theme: ThemeStore?.themes?.[4], reason:'Calming green tones, easy on eyes', fit:'Daytime productivity' },
            { theme: ThemeStore?.themes?.[6], reason:'Mysterious deep space vibes', fit:'Focus & deep work' },
            { theme: ThemeStore?.themes?.[5], reason:'Warm dusk tones, cozy feeling', fit:'Evening & creative work' },
        ],

        musicRecs: [
            { icon:'🎵', genre:'Synthwave',    reason:'Great for late-night coding sessions', tracks:['Neon Drift','Electric Dawn'] },
            { icon:'🎧', genre:'Lo-fi',         reason:'Helps maintain calm focus for hours', tracks:['Aqua Pulse'] },
            { icon:'🔊', genre:'Ambient',       reason:'Non-distracting background soundscape', tracks:['Glass Mountains'] },
            { icon:'⚡', genre:'Drum & Bass',   reason:'High BPM for creative bursts', tracks:['Pixel Storm'] },
            { icon:'🎹', genre:'Techno',        reason:'Rhythmic and immersive for deep work', tracks:['Midnight Code'] },
        ],

        tips: [
            { icon:'⌨️', tip:'Press Ctrl+Shift+S for a quick screenshot anytime', category:'Shortcut' },
            { icon:'📌', tip:'Pin your most-used apps to the taskbar via All Apps → Pin', category:'Workflow' },
            { icon:'🎨', tip:'Apply a full theme from Theme Store to instantly refresh your desktop', category:'Style' },
            { icon:'⊞',  tip:'Use Ctrl+Shift+→ / ← to snap windows side by side', category:'Multitask' },
            { icon:'🔍', tip:'The global search bar (top center) finds apps, files, and commands', category:'Search' },
            { icon:'🖼️', tip:'Set a custom wallpaper URL in Theme Store → Wallpapers tab', category:'Style' },
            { icon:'🎵', tip:'Import your own MP3/OGG/WAV files into HyMusic via "+ Import"', category:'Music' },
            { icon:'🌙', tip:'Enable Night Light in Control Center to reduce eye strain at night', category:'Comfort' },
            { icon:'📸', tip:'Screenshots automatically save to HyFiles → Screenshots folder', category:'Files' },
            { icon:'🎯', tip:'Focus Mode (Control Center) dims everything except your active window', category:'Focus' },
        ],

        show(tab) {
            this.current = tab;
            // Update tab styles
            ['apps','themes','music','tips'].forEach(t => {
                const btn = document.getElementById('hrec-tab-'+t);
                if (btn) {
                    btn.style.background = t===tab ? 'rgba(14,165,233,0.2)' : 'transparent';
                    btn.style.color = t===tab ? '#7dd3fc' : 'rgba(255,255,255,0.4)';
                }
            });
            this.render();
        },

        render() {
            const el = document.getElementById('hyley-rec-list');
            if (!el) return;
            if (this.current === 'apps') {
                // Pick 3 random
                const picks = [...this.appRecs].sort(()=>Math.random()-0.5).slice(0,3);
                el.innerHTML = picks.map(a => `
                    <div class="app-rec-card" onclick="${a.action}">
                        <div class="app-rec-icon">${a.icon}</div>
                        <div class="app-rec-info"><div class="app-rec-name">${a.name}</div><div class="app-rec-reason">${a.reason}</div></div>
                        <div class="app-rec-badge">${a.badge}</div>
                    </div>`).join('');
            } else if (this.current === 'themes') {
                const picks = [...this.themeRecs].sort(()=>Math.random()-0.5).slice(0,3).filter(r=>r.theme);
                el.innerHTML = picks.map(r => r.theme ? `
                    <div class="app-rec-card" onclick="ThemeStore.applyTheme('${r.theme.id}')" style="align-items:flex-start;">
                        <div style="width:44px;height:36px;border-radius:8px;background:${r.theme.wallpaper.css};flex-shrink:0;overflow:hidden;border:1px solid rgba(255,255,255,0.1);"></div>
                        <div class="app-rec-info">
                            <div class="app-rec-name">${r.theme.name}</div>
                            <div class="app-rec-reason">${r.reason}</div>
                            <div style="font-size:9px;opacity:.4;margin-top:2px;">Best for: ${r.fit}</div>
                        </div>
                        <div class="app-rec-badge" style="background:rgba(${r.theme.accent.startsWith('#')?'14,165,233':r.theme.accent},0.2);">Apply</div>
                    </div>` : '').join('');
            } else if (this.current === 'music') {
                const picks = [...this.musicRecs].sort(()=>Math.random()-0.5).slice(0,3);
                el.innerHTML = picks.map(m => `
                    <div class="app-rec-card" onclick="openHyMusic()">
                        <div class="app-rec-icon">${m.icon}</div>
                        <div class="app-rec-info">
                            <div class="app-rec-name">${m.genre}</div>
                            <div class="app-rec-reason">${m.reason}</div>
                            <div style="font-size:9px;opacity:.4;margin-top:2px;">e.g. ${m.tracks.join(', ')}</div>
                        </div>
                        <div class="app-rec-badge">Listen</div>
                    </div>`).join('');
            } else if (this.current === 'tips') {
                const picks = [...this.tips].sort(()=>Math.random()-0.5).slice(0,3);
                el.innerHTML = picks.map(t => `
                    <div style="display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                        <span style="font-size:18px;flex-shrink:0;">${t.icon}</span>
                        <div>
                            <div style="font-size:12px;line-height:1.5;">${t.tip}</div>
                            <div style="font-size:9px;margin-top:3px;background:rgba(14,165,233,0.15);border:1px solid rgba(14,165,233,0.25);color:#7dd3fc;padding:1px 6px;border-radius:10px;display:inline-block;">${t.category}</div>
                        </div>
                    </div>`).join('');
            }
        },

        open(tab='apps') {
            const panel = document.getElementById('hyley-recommendations');
            if (panel) panel.style.display='block';
            // Restore body if was collapsed
            const body = document.getElementById('hyley-rec-body');
            const btn  = document.getElementById('hyley-rec-collapse-btn');
            const wasCollapsed = body?.dataset.collapsed === '1';
            if (!wasCollapsed && body) body.style.display = 'block';
            this.show(tab);
        },

        toggleCollapse() {
            const body = document.getElementById('hyley-rec-body');
            const btn  = document.getElementById('hyley-rec-collapse-btn');
            if (!body) return;
            const isCollapsed = body.dataset.collapsed === '1';
            if (isCollapsed) {
                body.style.display = 'block';
                body.dataset.collapsed = '0';
                if (btn) btn.textContent = '▼';
                if (btn) btn.title = 'Hide recommendations';
            } else {
                body.style.display = 'none';
                body.dataset.collapsed = '1';
                if (btn) btn.textContent = '▲';
                if (btn) btn.title = 'Show recommendations';
            }
        }
    };

    // Wire up recommendations whenever Hyley opens
    const _hrecOrigToggle = window.toggleHyley;
    window.toggleHyley = function(e) {
        if (_hrecOrigToggle) _hrecOrigToggle(e);
        setTimeout(() => {
            const hyleyPanel = document.getElementById('hyley-panel');
            if (hyleyPanel && hyleyPanel.style.display !== 'none') {
                HyleyRecs.open('apps');
            }
        }, 120);
    };

    // ── Expand processHyleyMessage with rich recommendation responses ──
    const _prevHyleyMsg = window.processHyleyMessage;
    window.processHyleyMessage = function(msg) {
        const m = msg.toLowerCase();

        // Theme recommendations
        if (m.includes('theme') || m.includes('recommend theme') || m.includes('which theme')) {
            HyleyRecs.open('themes');
            const hour = new Date().getHours();
            let suggestion = ThemeStore?.themes?.[0]?.name || 'Neon Grid';
            if (hour >= 20 || hour < 6) suggestion = 'Cyberpunk 2099';
            else if (hour >= 6 && hour < 12) suggestion = 'Aurora Borealis';
            else if (hour >= 12 && hour < 17) suggestion = 'Emerald Forest';
            else suggestion = 'Stellar Sunset';
            return `🎨 Based on the time of day, I'd suggest <strong>${suggestion}</strong>! I've pulled up some theme picks below — click any to apply instantly. You can also browse all themes in the Theme Store.`;
        }

        // Wallpaper recommendations
        if (m.includes('wallpaper') && (m.includes('recommend') || m.includes('which') || m.includes('should') || m.includes('what'))) {
            HyleyRecs.open('themes');
            openThemeStore();
            return `🖼️ Opening Theme Store for you! Head to the <strong>Wallpapers</strong> tab for standalone wallpaper presets, or the <strong>Themes</strong> tab if you want a full look including icons. I'd recommend Aurora or Starfield for something atmospheric!`;
        }

        // Music recommendations
        if (m.includes('recommend music') || m.includes('what music') || m.includes('music suggest') || m.includes('what should i listen')) {
            HyleyRecs.open('music');
            const genres = ['Lo-fi for focus 🎧', 'Synthwave for energy ⚡', 'Ambient for calm 🌿'];
            return `🎵 ${genres[Math.floor(Math.random()*genres.length)]} — check out my music picks below! You can also import your own files into HyMusic using the <strong>+ Import</strong> button.`;
        }

        // App recommendations
        if (m.includes('recommend') && (m.includes('app') || m.includes('tool'))) {
            HyleyRecs.open('apps');
            return `⭐ Here are some app picks based on what HyOS users love! Click any card to launch. You can also pin apps to your taskbar from <strong>All Apps</strong>.`;
        }

        // Productivity tips
        if (m.includes('tip') || m.includes('hint') || m.includes('productivity') || m.includes('how do i use')) {
            HyleyRecs.open('tips');
            return `💡 Here are some power-user tips for HyOS! Swipe through for more. Did you know you can snap windows with <strong>Ctrl+Shift+→/←</strong>?`;
        }

        // What apps should I try
        if (m.includes('what apps') || m.includes('apps should') || m.includes('suggest app')) {
            HyleyRecs.open('apps');
            return `📱 Good question! I picked a few apps that might be useful for you right now. Check out the recommendations below — more refresh each time you ask!`;
        }

        // Customize desktop
        if (m.includes('customize') && (m.includes('desktop') || m.includes('look') || m.includes('appearance'))) {
            HyleyRecs.open('themes');
            return `🖥️ Let's make your desktop shine! Here are some theme recommendations. You can also:\n• Change accent color in <strong>Settings → Personalization</strong>\n• Rearrange desktop icons by dragging\n• Pin your favorite apps to the taskbar\n• Use <strong>Icon Maker</strong> in Theme Store to customize individual app icons`;
        }

        // Import music help
        if (m.includes('import') && m.includes('music')) {
            openHyMusic();
            return `🎵 Opening HyMusic! Hit the <strong>+ Import</strong> button at the top right to add your own MP3, OGG, WAV, or M4A files. They'll be saved and available every time you open HyMusic.`;
        }

        // Forward to previous processor
        return _prevHyleyMsg ? _prevHyleyMsg(msg) : null;
    };

    console.log('✅ HyOS HS Feature Bundle 2.0 loaded — 25+ new features active!');

    // =====================================================
    // AGE VERIFICATION SYSTEM
    // =====================================================

    window.showAgeGateModal = function() {
        const modal = document.getElementById('age-gate-modal');
        modal.style.display = 'flex';
    };

    window.confirmAgeGate = function() {
        const input = document.getElementById('age-gate-input');
        const errDiv = document.getElementById('age-gate-error');
        const age = parseInt(input.value);
        if (!age || age < 1 || age > 120) {
            errDiv.style.display = 'block';
            input.style.borderColor = '#ef4444';
            return;
        }
        errDiv.style.display = 'none';
        input.style.borderColor = '';
        userSettings.userAge = age;
        userSettings.ageVerified = true;
        saveSettings();
        document.getElementById('age-gate-modal').style.display = 'none';
        notify('Age Set', `Age set to ${age}. Content restrictions have been applied.`);
        if (document.getElementById('drawer-win')?.style.display !== 'none') {
            setDrawerMode('installed');
        }
    };

    // Helper: can user access a given app?
    window.getAppAgeStatus = function(app) {
        const userAge = userSettings.userAge;
        // System apps are always accessible
        if (app.isSystem) return 'ok';
        // App has no age limit set → Inaccessible
        if (app.ageLimit === undefined || app.ageLimit === null || app.ageLimit === '') {
            return 'inaccessible';
        }
        const limit = parseInt(app.ageLimit);
        if (isNaN(limit) || limit === 0) return 'ok'; // 0 = no restriction
        if (userAge === null) return 'age-unknown'; // User hasn't verified
        if (userAge < limit) return 'age-blocked';
        return 'ok';
    };

    // Show the "Change age limit" dialog (for creators only)
    window._ageLimitTargetAppId = null;
    window._ageLimitTargetSrc = null;

    window.showAgeLimitModal = function(appId, src) {
        const app = src === 'cloud' ? cloudApps.find(a => a.id === appId) : installedApps.find(a => a.id === appId);
        if (!app) return;
        window._ageLimitTargetAppId = appId;
        window._ageLimitTargetSrc = src;
        document.getElementById('age-limit-app-name').textContent = `for "${app.name}"`;
        const input = document.getElementById('age-limit-input');
        input.value = (app.ageLimit !== undefined && app.ageLimit !== null) ? app.ageLimit : '';
        document.getElementById('age-limit-error').style.display = 'none';
        input.style.borderColor = '';
        document.getElementById('age-limit-modal').style.display = 'flex';
    };

    window.confirmAgeLimit = async function() {
        const input = document.getElementById('age-limit-input');
        const errDiv = document.getElementById('age-limit-error');
        const val = input.value.trim();
        const limit = val === '' ? null : parseInt(val);
        if (val !== '' && (isNaN(limit) || limit < 0 || limit > 99)) {
            errDiv.style.display = 'block';
            input.style.borderColor = '#ef4444';
            return;
        }
        errDiv.style.display = 'none';
        input.style.borderColor = '';

        const appId = window._ageLimitTargetAppId;
        const src = window._ageLimitTargetSrc;
        const finalLimit = (limit === 0 || limit === null) ? 0 : limit;

        // Update locally
        const localApp = installedApps.find(a => a.id === appId) || cloudApps.find(a => a.id === appId);
        if (localApp) localApp.ageLimit = finalLimit === 0 ? null : finalLimit;

        // Update in Supabase (cloud apps now live in Supabase, not Firebase)
        if (supabaseInitialized && (src === 'cloud' || src === 'store')) {
            const { error } = await window.sbGlobalApps.update(appId, { ageLimit: finalLimit === 0 ? null : finalLimit });
            if (error) console.warn('Could not update ageLimit in Supabase:', error);
        } else if (supabaseInitialized && src === 'installed') {
            const { error } = await supabase.from('installed').update({ age_limit: finalLimit === 0 ? null : finalLimit }).eq('id', appId);
            if (error) console.warn('ageLimit update error:', error);
        }

        saveLocalData();
        document.getElementById('age-limit-modal').style.display = 'none';
        notify('Age Limit Updated', finalLimit === 0 || !finalLimit
            ? 'Age restriction removed. App will now show as "Inaccessible" to others (no limit set means inaccessible).'
            : `Age limit set to ${finalLimit}+. Users under ${finalLimit} cannot open this app.`);

        // Refresh info panel if open
        if (document.getElementById('info-win')?.style.display !== 'none') {
            window.showInfo(appId, src);
        }
        if (document.getElementById('drawer-win')?.style.display !== 'none') {
            setDrawerMode(src === 'cloud' ? 'store' : 'installed');
        }
    };

    // ============================================================
    // AGE SETTINGS PANEL — embedded in Settings > Age tab
    // ============================================================
    let ageSettingsStream = null;
    let ageSettingsLoop = null;

    function ageSettingsRefreshStatus() {
        const card = document.getElementById('age-settings-status-card');
        const startArea = document.getElementById('age-settings-start-area');
        const manualArea = document.getElementById('age-settings-manual-area');
        if (!card) return;

        if (userSettings.ageVerified && userSettings.userAge !== null) {
            card.style.background = 'rgba(34,197,94,0.08)';
            card.style.border = '1px solid rgba(34,197,94,0.25)';
            const faceLabel = userSettings.faceScanned ? '<span style="font-size:10px;background:rgba(34,197,94,0.15);border:1px solid rgba(34,197,94,0.3);border-radius:20px;padding:1px 8px;color:#4ade80;margin-left:6px;">Face scanned ✓</span>' : '<span style="font-size:10px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:1px 8px;color:rgba(255,255,255,0.4);margin-left:6px;">Manual entry</span>';
            card.innerHTML = `
                <div style="width:48px;height:48px;background:rgba(34,197,94,0.15);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;">✅</div>
                <div style="text-align:left;flex:1;">
                    <div style="font-weight:700;font-size:14px;margin-bottom:4px;display:flex;align-items:center;">Age ${userSettings.userAge}${faceLabel}</div>
                    <div style="font-size:11px;color:rgba(255,255,255,0.4);">Content restrictions applied. Age cannot be changed manually.</div>
                </div>`;
            // Hide inputs — only show re-scan if not face scanned yet
            if (startArea) {
                if (!userSettings.faceScanned) {
                    // Was manual — allow them to upgrade to face scan
                    startArea.innerHTML = `<button onclick="ageSettingsShowPermission()" style="width:100%;background:linear-gradient(135deg,#7c3aed,#6d28d9);border:none;padding:14px;border-radius:14px;font-weight:700;font-size:13px;color:white;cursor:pointer;font-family:Outfit,sans-serif;box-shadow:0 4px 16px rgba(124,58,237,0.35);">📷 Upgrade to Face Scan</button>
                    <p style="font-size:11px;color:rgba(255,255,255,0.3);text-align:center;margin-top:8px;">Face scan unlocks Video recording, Filters, and Hyley</p>`;
                } else {
                    startArea.innerHTML = `<div style="text-align:center;padding:8px 0;font-size:11px;color:rgba(255,255,255,0.3);">🔒 Age is locked. Contact support to reset verification.</div>`;
                }
            }
            if (manualArea) manualArea.style.display = 'none';
        } else {
            card.style.background = 'rgba(239,68,68,0.08)';
            card.style.border = '1px solid rgba(239,68,68,0.2)';
            card.innerHTML = `
                <div style="width:48px;height:48px;background:rgba(239,68,68,0.12);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;flex-shrink:0;">🛡️</div>
                <div style="text-align:left;">
                    <div style="font-weight:700;font-size:14px;margin-bottom:2px;">Not Verified</div>
                    <div style="font-size:12px;color:rgba(255,255,255,0.45);">Verify to use Hyley and access age-restricted apps.</div>
                </div>`;
            if (startArea) startArea.innerHTML = `
                <button onclick="ageSettingsShowPermission()" style="width:100%;background:linear-gradient(135deg,#0ea5e9,#22d3ee);border:none;padding:15px;border-radius:14px;font-weight:700;font-size:14px;color:white;cursor:pointer;font-family:Outfit,sans-serif;box-shadow:0 4px 20px rgba(14,165,233,0.35);margin-bottom:10px;">📷 Start Face Scan</button>
                <button onclick="ageSettingsManual()" style="width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);padding:13px;border-radius:12px;font-weight:600;font-size:13px;color:rgba(255,255,255,0.55);cursor:pointer;font-family:Outfit,sans-serif;">✏️ Enter Age Manually</button>`;
        }
    }

    function ageSettingsHideAllAreas() {
        ['start','permission','denied','scan','manual'].forEach(id =>
            document.getElementById('age-settings-' + id + '-area').style.display = 'none'
        );
    }

    window.ageSettingsShowPermission = function() {
        ageSettingsHideAllAreas();
        document.getElementById('age-settings-permission-area').style.display = 'block';
    };

    window.ageSettingsCancelPermission = function() {
        ageSettingsHideAllAreas();
        document.getElementById('age-settings-start-area').style.display = 'block';
    };

    window.ageSettingsStartCamera = async function() {
        // kept for compatibility — routes through permission step
        window.ageSettingsShowPermission();
    };

    window.ageSettingsRequestCamera = async function() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            ageSettingsHideAllAreas();
            const denied = document.getElementById('age-settings-denied-area');
            denied.querySelector('div[style*="fca5a5"]').textContent = 'Camera Not Available';
            denied.querySelector('div[style*="line-height:1.7"]').innerHTML = 'Camera requires HTTPS. This page is not being served securely.<br><br>Try: drag the file onto <strong>netlify.com/drop</strong>, or run <code>npx serve .</code> locally.';
            denied.style.display = 'block';
            return;
        }
        ageSettingsHideAllAreas();
        document.getElementById('age-settings-scan-area').style.display = 'block';
        const loadingEl = document.getElementById('age-settings-loading');
        const loadingText = document.getElementById('age-settings-loading-text');
        loadingEl.style.display = 'flex';
        loadingText.textContent = 'Requesting camera…';

        // Call getUserMedia FIRST — must stay in the synchronous user-gesture call stack
        // so the browser actually shows the permission dialog
        let stream;
        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } });
        } catch(err) {
            loadingEl.style.display = 'none';
            ageSettingsHideAllAreas();
            if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                document.getElementById('age-settings-denied-area').style.display = 'block';
            } else {
                const deniedArea = document.getElementById('age-settings-denied-area');
                deniedArea.querySelector('div[style*="fca5a5"]').textContent = 'Camera Error';
                deniedArea.querySelector('div[style*="line-height:1.7"]').textContent = (err.message || err.name) + ' — please try again or enter your age manually.';
                deniedArea.style.display = 'block';
            }
            return;
        }

        // Camera granted — now load models (async is fine from here)
        ageSettingsStream = stream;
        try {
            if (!window.faceapi) {
                loadingText.textContent = 'Loading face models…';
                await new Promise((resolve, reject) => {
                    const s = document.createElement('script');
                    s.src = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/dist/face-api.js';
                    s.onload = resolve; s.onerror = reject;
                    document.head.appendChild(s);
                });
            }
            if (!window.faceApiLoaded) {
                loadingText.textContent = 'Loading face models…';
                await faceapi.nets.tinyFaceDetector.loadFromUri(window.MODELS_URL);
                await faceapi.nets.ageGenderNet.loadFromUri(window.MODELS_URL);
                window.faceApiLoaded = true;
            }

            const video = document.getElementById('age-settings-video');
            video.srcObject = stream;
            await video.play();
            loadingEl.style.display = 'none';
            document.getElementById('age-settings-scanline').style.display = 'block';
            ageSettingsStartLoop();
        } catch(err) {
            window.ageSettingsStopCamera();
            notify('Load Error', 'Could not load face models. Check your connection.');
        }
    };

    function ageSettingsStartLoop() {
        const video = document.getElementById('age-settings-video');
        const canvas = document.getElementById('age-settings-overlay');
        const statusEl = document.getElementById('age-settings-face-status');
        const scanBtn = document.getElementById('age-settings-scan-btn');

        ageSettingsLoop = setInterval(async () => {
            if (video.readyState < 2) return;
            try {
                const det = await faceapi
                    .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
                    .withAgeAndGender();
                canvas.width = video.videoWidth; canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                if (det) {
                    const { x, y, width, height } = det.detection.box;
                    ctx.strokeStyle = '#0ea5e9'; ctx.lineWidth = 3;
                    ctx.shadowColor = '#0ea5e9'; ctx.shadowBlur = 14;
                    ctx.strokeRect(x, y, width, height);
                    const c = 16; ctx.lineWidth = 4;
                    [[x,y,c,0,0,c],[x+width,y,-c,0,0,c],[x,y+height,c,0,0,-c],[x+width,y+height,-c,0,0,-c]].forEach(([px,py,a,b,d,f]) => {
                        ctx.beginPath(); ctx.moveTo(px+a,py+b); ctx.lineTo(px,py); ctx.lineTo(px+d,py+f); ctx.stroke();
                    });
                    statusEl.textContent = '✅ Face detected — click Scan to continue';
                    statusEl.style.color = '#22d3ee';
                    scanBtn.disabled = false; scanBtn.style.opacity = '1';
                } else {
                    statusEl.textContent = '🔍 No face detected — move closer';
                    statusEl.style.color = 'rgba(255,255,255,0.35)';
                    scanBtn.disabled = true; scanBtn.style.opacity = '0.4';
                }
            } catch(e) {}
        }, 400);
    }

    window.ageSettingsStopCamera = function() {
        if (ageSettingsLoop) { clearInterval(ageSettingsLoop); ageSettingsLoop = null; }
        if (ageSettingsStream) { ageSettingsStream.getTracks().forEach(t => t.stop()); ageSettingsStream = null; }
        const v = document.getElementById('age-settings-video');
        if (v) v.srcObject = null;
        ageSettingsHideAllAreas();
        document.getElementById('age-settings-start-area').style.display = 'block';
    };

    window.ageSettingsCapture = async function() {
        const video = document.getElementById('age-settings-video');
        const scanBtn = document.getElementById('age-settings-scan-btn');
        if (ageSettingsLoop) { clearInterval(ageSettingsLoop); ageSettingsLoop = null; }
        scanBtn.disabled = true; scanBtn.textContent = 'Analyzing…';
        try {
            const det = await faceapi
                .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.5 }))
                .withAgeAndGender();
            window.ageSettingsStopCamera();
            if (!det) {
                notify('Scan Failed', 'No face detected. Try again in better lighting.');
                document.getElementById('age-settings-start-area').style.display = 'block';
                return;
            }
            const age = Math.round(det.age);
            userSettings.userAge = age;
            userSettings.ageVerified = true;
            userSettings.faceScanned = true;
            saveSettings();
            ageSettingsRefreshStatus();
            document.getElementById('age-settings-start-area').style.display = 'block';
            notify('Age Verified ✅', `Age estimated at ${age}. Content restrictions applied.`);
        } catch(e) {
            window.ageSettingsStopCamera();
            notify('Scan Error', 'Something went wrong. Please try again.');
            document.getElementById('age-settings-start-area').style.display = 'block';
        }
    };

    window.ageSettingsManual = function() {
        ageSettingsHideAllAreas();
        document.getElementById('age-settings-manual-area').style.display = 'block';
    };

    window.ageSettingsConfirmManual = function() {
        if (userSettings.ageVerified) { notify('Locked', 'Age cannot be changed after verification.'); return; }
        const input = document.getElementById('age-settings-manual-input');
        const err = document.getElementById('age-settings-manual-error');
        const age = parseInt(input.value);
        if (!age || age < 1 || age > 120) { err.style.display = 'block'; return; }
        err.style.display = 'none';
        userSettings.userAge = age;
        userSettings.ageVerified = true;
        saveSettings();
        ageSettingsRefreshStatus();
        document.getElementById('age-settings-manual-area').style.display = 'none';
        document.getElementById('age-settings-start-area').style.display = 'block';
        notify('Age Set ✅', `Age set to ${age}. Content restrictions applied.`);
    };

    // Refresh status card whenever Age tab is opened
    const _origSwitchTab_age = window.switchSettingsTab;
    window.switchSettingsTab = function(tab) {
        _origSwitchTab_age(tab);
        if (tab === 'age') ageSettingsRefreshStatus();
    };

    // ============================================================
    // CAMERA APP
    // ============================================================
    const CAM_FILTERS = [
        { name: 'Normal',  css: 'none' },
        { name: 'Vivid',   css: 'contrast(1.25) saturate(1.6)' },
        { name: 'Warm',    css: 'sepia(0.35) brightness(1.08) saturate(1.2)' },
        { name: 'Cool',    css: 'hue-rotate(20deg) saturate(1.3) brightness(1.02)' },
        { name: 'B&W',     css: 'grayscale(1) contrast(1.1)' },
        { name: 'Fade',    css: 'brightness(1.12) contrast(0.82) saturate(0.7)' },
        { name: 'Drama',   css: 'contrast(1.5) saturate(1.2) brightness(0.9)' },
    ];
    let camStream = null, camMode = 'photo', camRecorder = null, camRecording = false;
    let camFacing = 'user', camZoomLevel = 1, camTimerInterval = null, camRecSeconds = 0;
    let camSelfTimerSec = 0, camSelfTimerActive = false;
    let camFilterIndex = 0, camGridOn = false, camFlashOn = false;
    let camCaptures = [];

    window.openCameraApp = function() {
        const win = document.getElementById('camera-win');
        win.style.display = 'flex';
        bringToFront('camera-win');
        if (!camStream) {
            document.getElementById('cam-permission-screen').style.display = 'flex';
            document.getElementById('cam-denied-screen').style.display = 'none';
            document.getElementById('cam-live-screen').style.display = 'none';
            document.getElementById('cam-gallery-panel').style.display = 'none';
        }
        camRefreshFaceGates();
        camBuildFilterStrip();
    };

    window.closeCameraApp = function() {
        camStopStream();
        document.getElementById('camera-win').style.display = 'none';
    };

    function camRefreshFaceGates() {
        const verified = !!userSettings.faceScanned;
        // Filter lock
        const filterLock = document.getElementById('cam-filter-lock');
        if (filterLock) filterLock.style.display = verified ? 'none' : 'flex';
        // Video lock badge
        const videoBadge = document.getElementById('cam-video-lock-badge');
        if (videoBadge) videoBadge.style.display = verified ? 'none' : 'flex';
    }

    window.camPromptFaceScan = function(featureName) {
        notify('🔒 Face Scan Required', `${featureName} requires face verification. Open Settings → Age.`);
        const settWin = document.getElementById('settings-win');
        if (settWin) settWin.style.display = 'flex';
        if (window.switchSettingsTab) switchSettingsTab('age');
    };

    function camBuildFilterStrip() {
        const row = document.getElementById('cam-filter-row');
        // Keep the lock overlay div, rebuild filter chips after it
        const lockDiv = document.getElementById('cam-filter-lock');
        // Remove old chips
        [...row.children].forEach(c => { if (c !== lockDiv) c.remove(); });
        CAM_FILTERS.forEach((f, i) => {
            const chip = document.createElement('div');
            chip.dataset.idx = i;
            chip.style.cssText = `flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:4px;cursor:pointer;`;
            const preview = document.createElement('div');
            preview.style.cssText = `width:44px;height:44px;border-radius:10px;background:#334155;overflow:hidden;border:2px solid ${i===camFilterIndex?'#0ea5e9':'transparent'};transition:0.2s;`;
            const inner = document.createElement('div');
            inner.style.cssText = `width:100%;height:100%;background:linear-gradient(135deg,#0ea5e9,#22d3ee);filter:${f.css};`;
            preview.appendChild(inner);
            const label = document.createElement('div');
            label.textContent = f.name;
            label.style.cssText = `font-size:9px;font-weight:700;color:${i===camFilterIndex?'#0ea5e9':'rgba(255,255,255,0.4)'};font-family:Outfit,sans-serif;`;
            chip.appendChild(preview); chip.appendChild(label);
            chip.onclick = () => camApplyFilter(i);
            row.appendChild(chip);
        });
    }

    window.camApplyFilter = function(idx) {
        if (!userSettings.faceScanned) { camPromptFaceScan('Filters'); return; }
        camFilterIndex = idx;
        document.getElementById('cam-video').style.filter = CAM_FILTERS[idx].css;
        document.getElementById('cam-filter-label').textContent = CAM_FILTERS[idx].name;
        camBuildFilterStrip();
    };

    window.camRequestPermission = async function() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            document.getElementById('cam-permission-screen').style.display = 'none';
            document.getElementById('cam-live-screen').style.display = 'none';
            const denied = document.getElementById('cam-denied-screen');
            denied.querySelector('div[style*="fca5a5"]').textContent = 'Camera Not Available';
            denied.querySelector('div[style*="max-width:280px"]').innerHTML = 'Camera requires HTTPS. Try serving via <strong>netlify.com/drop</strong> or <code>npx serve .</code>';
            denied.style.display = 'flex';
            return;
        }
        let stream;
        try {
            stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: camFacing, width: { ideal: 1280 }, height: { ideal: 720 } },
                audio: true
            });
        } catch(e) {
            document.getElementById('cam-permission-screen').style.display = 'none';
            document.getElementById('cam-denied-screen').style.display = 'flex';
            document.getElementById('cam-live-screen').style.display = 'none';
            return;
        }
        camStream = stream;
        const video = document.getElementById('cam-video');
        video.srcObject = stream;
        await video.play();
        document.getElementById('cam-permission-screen').style.display = 'none';
        document.getElementById('cam-denied-screen').style.display = 'none';
        document.getElementById('cam-live-screen').style.display = 'flex';
        document.getElementById('cam-gallery-panel').style.display = 'none';
        // Setup tap-to-focus
        video.onclick = camHandleTap;
        camApplyFilter(camFilterIndex);
        camRefreshFaceGates();
        camDrawGrid();
    };

    function camStopStream() {
        if (camStream) { camStream.getTracks().forEach(t => t.stop()); camStream = null; }
        if (camTimerInterval) { clearInterval(camTimerInterval); camTimerInterval = null; }
        camRecording = false; camSelfTimerActive = false;
    }

    // ---- Mode ----
    window.camSetMode = function(mode) {
        if (mode === 'video' && !userSettings.faceScanned) {
            camPromptFaceScan('Video recording'); return;
        }
        camMode = mode;
        const inner = document.getElementById('cam-shutter-inner');
        const photoBtn = document.getElementById('cam-mode-photo');
        const videoBtn = document.getElementById('cam-mode-video');
        if (mode === 'photo') {
            inner.style.background = '#fff'; inner.style.borderRadius = '50%';
            photoBtn.style.background = 'rgba(14,165,233,0.9)'; photoBtn.style.color = '#fff';
            videoBtn.style.background = 'transparent'; videoBtn.style.color = 'rgba(255,255,255,0.5)';
        } else {
            inner.style.background = '#ef4444'; inner.style.borderRadius = '50%';
            videoBtn.style.background = 'rgba(239,68,68,0.8)'; videoBtn.style.color = '#fff';
            photoBtn.style.background = 'transparent'; photoBtn.style.color = 'rgba(255,255,255,0.5)';
        }
    };

    // ---- Shutter ----
    window.camShutter = function() {
        if (camSelfTimerActive) return;
        if (camSelfTimerSec > 0 && camMode === 'photo') {
            camRunSelfTimer(); return;
        }
        if (camMode === 'photo') camTakePhoto();
        else camToggleRecord();
    };

    // ---- Self-timer ----
    window.camCycleTimer = function() {
        const options = [0, 3, 10];
        camSelfTimerSec = options[(options.indexOf(camSelfTimerSec) + 1) % options.length];
        const btn = document.getElementById('cam-timer-btn');
        btn.textContent = camSelfTimerSec === 0 ? '⏱' : camSelfTimerSec + 's';
        btn.style.background = camSelfTimerSec > 0 ? 'rgba(14,165,233,0.7)' : 'rgba(255,255,255,0.1)';
    };

    function camRunSelfTimer() {
        camSelfTimerActive = true;
        let count = camSelfTimerSec;
        const overlay = document.getElementById('cam-countdown-overlay');
        const num = document.getElementById('cam-countdown-num');
        overlay.style.display = 'flex';
        num.textContent = count;
        const t = setInterval(() => {
            count--;
            if (count <= 0) {
                clearInterval(t);
                overlay.style.display = 'none';
                camSelfTimerActive = false;
                camTakePhoto();
            } else {
                num.textContent = count;
                // pulse
                num.style.transform = 'scale(1.3)';
                setTimeout(() => num.style.transform = 'scale(1)', 150);
            }
        }, 1000);
    }

    // ---- Photo ----
    function camTakePhoto() {
        const video = document.getElementById('cam-video');
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        // Apply filter to canvas
        ctx.filter = CAM_FILTERS[camFilterIndex].css === 'none' ? 'none' : CAM_FILTERS[camFilterIndex].css;
        ctx.translate(canvas.width, 0); ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0);
        const url = canvas.toDataURL('image/jpeg', 0.95);
        const capture = { type: 'photo', url, filter: CAM_FILTERS[camFilterIndex].name, ts: Date.now() };
        camCaptures.push(capture);
        // Flash effect
        if (camFlashOn) {
            const flash = document.getElementById('cam-flash-overlay');
            flash.style.opacity = '1';
            setTimeout(() => flash.style.opacity = '0', 80);
        }
        camUpdateThumb(capture);
        camUpdateCount();
        notify('📷 Photo taken', CAM_FILTERS[camFilterIndex].name !== 'Normal' ? `Filter: ${CAM_FILTERS[camFilterIndex].name}` : 'Photo saved');
        if (window.saveToMediaLibrary) window.saveToMediaLibrary({ type: 'photo', url, name: 'Photo ' + new Date().toLocaleTimeString() });
    }

    // ---- Video ----
    function camToggleRecord() {
        if (!camRecording) {
            camRecording = true;
            camRecSeconds = 0;
            document.getElementById('cam-rec-badge').style.display = 'flex';
            document.getElementById('cam-rec-timer').style.display = 'block';
            const inner = document.getElementById('cam-shutter-inner');
            inner.style.background = '#ef4444'; inner.style.borderRadius = '4px';
            camTimerInterval = setInterval(() => {
                camRecSeconds++;
                const m = String(Math.floor(camRecSeconds/60)).padStart(2,'0');
                const s = String(camRecSeconds%60).padStart(2,'0');
                document.getElementById('cam-rec-timer').textContent = m + ':' + s;
            }, 1000);
            try {
                camRecorder = new MediaRecorder(camStream);
                const chunks = [];
                camRecorder.ondataavailable = e => chunks.push(e.data);
                camRecorder.onstop = () => {
                    const blob = new Blob(chunks, { type: 'video/webm' });
                    const url = URL.createObjectURL(blob);
                    const capture = { type: 'video', url, blob, ts: Date.now() };
                    camCaptures.push(capture);
                    camUpdateThumb(capture);
                    camUpdateCount();
                    notify('🎬 Video saved', `${String(Math.floor(camRecSeconds/60)).padStart(2,'0')}:${String(camRecSeconds%60).padStart(2,'0')}`);
                };
                camRecorder.start();
            } catch(e) { notify('Record Error', e.message); camRecording = false; }
        } else {
            camRecording = false;
            if (camTimerInterval) { clearInterval(camTimerInterval); camTimerInterval = null; }
            document.getElementById('cam-rec-badge').style.display = 'none';
            document.getElementById('cam-rec-timer').style.display = 'none';
            const inner = document.getElementById('cam-shutter-inner');
            inner.style.background = '#ef4444'; inner.style.borderRadius = '50%';
            if (camRecorder && camRecorder.state !== 'inactive') camRecorder.stop();
        }
    }

    // ---- Zoom ----
    window.camZoom = function(level) {
        camZoomLevel = level;
        const video = document.getElementById('cam-video');
        const filterCss = CAM_FILTERS[camFilterIndex].css;
        video.style.transform = `scaleX(-1) scale(${level})`;
        document.getElementById('cam-zoom-badge').textContent = level + '×';
        document.querySelectorAll('.cam-zoom-btn').forEach(b => {
            const isActive = parseFloat(b.dataset.zoom) === level;
            b.style.background = isActive ? 'rgba(14,165,233,0.7)' : 'transparent';
            b.style.color = isActive ? '#fff' : 'rgba(255,255,255,0.5)';
        });
    };

    // ---- Flip ----
    window.camFlip = async function() {
        camFacing = camFacing === 'user' ? 'environment' : 'user';
        camStopStream();
        await window.camRequestPermission();
    };

    // ---- Grid ----
    window.camToggleGrid = function() {
        camGridOn = !camGridOn;
        const btn = document.getElementById('cam-grid-btn');
        btn.style.background = camGridOn ? 'rgba(14,165,233,0.7)' : 'rgba(255,255,255,0.1)';
        camDrawGrid();
    };

    function camDrawGrid() {
        const canvas = document.getElementById('cam-grid-overlay');
        if (!camGridOn) { canvas.style.display = 'none'; return; }
        canvas.style.display = 'block';
        const w = canvas.offsetWidth, h = canvas.offsetHeight;
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.lineWidth = 1;
        [1/3, 2/3].forEach(f => {
            ctx.beginPath(); ctx.moveTo(w*f, 0); ctx.lineTo(w*f, h); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(0, h*f); ctx.lineTo(w, h*f); ctx.stroke();
        });
    }

    // ---- Flash toggle ----
    window.camToggleFlash = function() {
        camFlashOn = !camFlashOn;
        const btn = document.getElementById('cam-flash-btn');
        btn.style.background = camFlashOn ? 'rgba(255,220,0,0.3)' : 'rgba(255,255,255,0.1)';
        btn.textContent = camFlashOn ? '⚡' : '⚡';
        btn.style.color = camFlashOn ? '#ffd700' : 'white';
    };

    // ---- Tap to focus ring ----
    function camHandleTap(e) {
        const ring = document.getElementById('cam-focus-ring');
        const rect = e.currentTarget.getBoundingClientRect();
        ring.style.left = (e.clientX - rect.left) + 'px';
        ring.style.top = (e.clientY - rect.top) + 'px';
        ring.style.display = 'block';
        ring.style.animation = 'none';
        void ring.offsetWidth;
        ring.style.animation = 'camFocusPulse 0.4s ease-out forwards';
        setTimeout(() => ring.style.display = 'none', 500);
    }

    // ---- Gallery ----
    window.camOpenGallery = function() {
        if (camCaptures.length === 0) { notify('Gallery', 'No captures yet. Take a photo first!'); return; }
        document.getElementById('cam-live-screen').style.display = 'none';
        document.getElementById('cam-gallery-panel').style.display = 'flex';
        const grid = document.getElementById('cam-gallery-grid');
        const empty = document.getElementById('cam-gallery-empty');
        if (camCaptures.length === 0) { grid.style.display = 'none'; empty.style.display = 'flex'; return; }
        empty.style.display = 'none'; grid.style.display = 'grid';
        grid.innerHTML = [...camCaptures].reverse().map((c, i) => {
            const ri = camCaptures.length - 1 - i;
            if (c.type === 'photo') {
                return `<div onclick="camGalleryView(${ri})" style="aspect-ratio:1;border-radius:10px;overflow:hidden;cursor:pointer;position:relative;border:2px solid transparent;transition:0.2s;" onmouseover="this.style.borderColor='#0ea5e9'" onmouseout="this.style.borderColor='transparent'">
                    <img src="${c.url}" style="width:100%;height:100%;object-fit:cover;">
                    ${c.filter && c.filter!=='Normal' ? `<div style="position:absolute;bottom:4px;left:4px;background:rgba(0,0,0,0.6);border-radius:4px;padding:1px 5px;font-size:9px;font-weight:700;">${c.filter}</div>` : ''}
                </div>`;
            } else {
                return `<div onclick="camGalleryView(${ri})" style="aspect-ratio:1;border-radius:10px;overflow:hidden;cursor:pointer;background:#1e293b;display:flex;align-items:center;justify-content:center;border:2px solid transparent;transition:0.2s;" onmouseover="this.style.borderColor='#0ea5e9'" onmouseout="this.style.borderColor='transparent'">
                    <div style="text-align:center;"><div style="font-size:24px;">🎬</div><div style="font-size:9px;opacity:0.5;margin-top:4px;">Video</div></div>
                </div>`;
            }
        }).join('');
    };

    window.camCloseGallery = function() {
        document.getElementById('cam-gallery-panel').style.display = 'none';
        document.getElementById('cam-live-screen').style.display = 'flex';
    };

    window.camGalleryView = function(idx) {
        const c = camCaptures[idx];
        if (!c) return;
        const w = window.open('', '_blank', 'width=900,height=700');
        if (!w) return;
        if (c.type === 'photo') {
            w.document.write(`<body style="margin:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;font-family:sans-serif;">
                <img src="${c.url}" style="max-width:100%;max-height:90vh;object-fit:contain;">
                <a href="${c.url}" download="photo_${Date.now()}.jpg" style="position:fixed;bottom:20px;right:20px;background:#0ea5e9;color:#fff;padding:10px 20px;border-radius:12px;text-decoration:none;font-weight:700;">⬇ Download</a>
            </body>`);
        } else {
            w.document.write(`<body style="margin:0;background:#000;"><video src="${c.url}" controls autoplay style="width:100%;max-height:100vh;"></video></body>`);
        }
    };

    function camUpdateThumb(capture) {
        const thumb = document.getElementById('cam-last-thumb');
        if (capture.type === 'photo') {
            thumb.innerHTML = `<img src="${capture.url}" style="width:100%;height:100%;object-fit:cover;">`;
        } else {
            thumb.innerHTML = `<div style="font-size:20px;display:flex;align-items:center;justify-content:center;height:100%;">🎬</div>`;
        }
    }

    function camUpdateCount() {
        const el = document.getElementById('cam-capture-count');
        if (el) el.textContent = camCaptures.length + (camCaptures.length === 1 ? ' capture' : ' captures');
    }


    // ================================================================
    // REFRESH → LOCK SCREEN (instead of auto-login to desktop)
    // ================================================================
    window.showRefreshLockScreen = function(savedUser) {
        const loginScreen = document.getElementById('login-screen');
        loginScreen.style.display = 'flex';
        loginScreen.style.opacity = '1';

        // Show avatar / username
        document.getElementById('lock-user-info').style.display = 'block';
        document.getElementById('lock-username-display').textContent = savedUser;
        const avatarLetter = document.getElementById('lock-avatar-letter');
        const avatarImg = document.getElementById('lock-avatar-img');
        const picData = userSettings.profilePic;
        if (picData && avatarImg) {
            avatarImg.src = picData; avatarImg.style.display = 'block';
            avatarLetter.style.display = 'none';
        } else {
            avatarLetter.textContent = savedUser[0]?.toUpperCase() || '?';
            avatarLetter.style.display = 'block';
            if (avatarImg) avatarImg.style.display = 'none';
        }

        // CRITICAL: pre-fill hidden username so handleAuth validation passes
        document.getElementById('u-in').value = savedUser;

        // Hide username input (we already know who this is)
        document.getElementById('login-username-wrap').style.display = 'none';
        document.getElementById('login-hint-text').style.display = 'none';
        document.getElementById('login-guest-btn').style.display = 'none';
        document.getElementById('login-main-btn').textContent = 'Unlock';
        document.getElementById('lock-switch-user-btn').style.display = 'block';

        // Show PIN pad if PIN is set, otherwise password field
        if (userSettings.pinCode) {
            document.getElementById('pin-login-area').style.display = 'block';
            document.getElementById('password-login-area').style.display = 'none';
            pinBuffer = '';
            updatePinDots();
        } else {
            document.getElementById('pin-login-area').style.display = 'none';
            document.getElementById('password-login-area').style.display = 'block';
            setTimeout(() => document.getElementById('p-in').focus(), 100);
        }

        window._refreshLockUser = savedUser;
    };

    // Patch handleAuth to go to startOS after unlock when coming from refresh lock
    const _origHandleAuth = window.handleAuth;
    // (handleAuth already calls startOS on success — no extra patch needed)
    // But we need the PIN unlock to call startOS too when in refresh-lock mode:
    function checkPin() {
        const stored = userSettings.pinCode;
        if (pinBuffer === stored) {
            document.getElementById('login-screen').style.display = 'none';
            if (window._refreshLockUser) {
                // Coming from refresh — boot into OS
                window._refreshLockUser = null;
                loadData();
                startOS();
            } else {
                notify('Unlocked', 'Welcome back!');
            }
        } else {
            document.querySelectorAll('.pin-dot').forEach(d => d.classList.add('error'));
            document.getElementById('pin-error').style.display = 'block';
            setTimeout(() => {
                pinBuffer = '';
                updatePinDots();
                document.getElementById('pin-error').style.display = 'none';
            }, 900);
        }
    }

    // ================================================================
    // PIN LOCK SYSTEM
    // ================================================================
    let pinBuffer = '';
    window.pinKey = function(k) {
        if (k === 'del') { pinBuffer = pinBuffer.slice(0,-1); }
        else if (k === 'bio') { /* placeholder */ }
        else if (pinBuffer.length < 4) { pinBuffer += k; }
        updatePinDots();
        if (pinBuffer.length === 4) setTimeout(checkPin, 120);
    };

    function updatePinDots() {
        document.querySelectorAll('.pin-dot').forEach((d,i) => {
            d.classList.toggle('filled', i < pinBuffer.length);
            d.classList.remove('error');
        });
    }

    window.showPasswordLogin = function() {
        document.getElementById('pin-login-area').style.display = 'none';
        document.getElementById('password-login-area').style.display = 'block';
    };

    // Override lockScreen to show PIN pad if PIN is set
    const _origLockScreen = window.lockScreen;
    window.lockScreen = function() {
        _origLockScreen && _origLockScreen();
        // After original runs, switch to PIN mode if configured
        setTimeout(() => {
            if (userSettings.pinCode) {
                document.getElementById('pin-login-area').style.display = 'block';
                document.getElementById('password-login-area').style.display = 'none';
                pinBuffer = '';
                updatePinDots();
                document.getElementById('pin-error').style.display = 'none';
            }
        }, 150);
    };

    // PIN setup via Settings (expose a helper)
    window.setupPIN = function() {
        const pin = prompt('Enter a 4-digit PIN (or leave blank to remove):');
        if (pin === null) return;
        if (pin === '') {
            userSettings.pinCode = '';
            saveSettings();
            notify('PIN Removed', 'Lock screen will use password.');
            return;
        }
        if (!/^\d{4}$/.test(pin)) { notify('Invalid PIN', 'PIN must be exactly 4 digits.'); return; }
        const confirm = prompt('Confirm PIN:');
        if (pin !== confirm) { notify('Mismatch', 'PINs did not match.'); return; }
        userSettings.pinCode = pin;
        saveSettings();
        notify('PIN Set ✓', 'Your lock screen PIN is active.');
    };

    // Keyboard shortcut: Cmd/Ctrl+L to lock
    document.addEventListener('keydown', e => {
        if ((e.metaKey||e.ctrlKey) && e.key === 'l') { e.preventDefault(); lockScreen(); }
        if ((e.metaKey||e.ctrlKey) && e.key === 'k') { e.preventDefault(); openSpotlight(); }
        if (e.key === 'Escape') closeSpotlight();
    });

    // ================================================================
    // WEATHER APP
    // ================================================================
    window.openWeatherApp = function() {
        const win = document.getElementById('weather-win');
        win.style.display = 'flex';
        bringToFront('weather-win');
    };

    window.fetchWeatherAuto = function() {
        if (!navigator.geolocation) { notify('Weather', 'Geolocation not supported.'); return; }
        navigator.geolocation.getCurrentPosition(pos => {
            const q = `${pos.coords.latitude},${pos.coords.longitude}`;
            document.getElementById('weather-search').value = '';
            doFetchWeather(q);
        }, () => notify('Weather', 'Location permission denied.'));
    };

    window.fetchWeather = function() {
        const q = document.getElementById('weather-search').value.trim();
        if (!q) return;
        doFetchWeather(q);
    };

    const WX_ICONS = {
        'sunny':['☀️','clear'],
        'partly':['⛅','partly cloudy'],
        'cloudy':['☁️','cloudy'],
        'overcast':['☁️','overcast'],
        'mist':['🌫️','mist'],
        'fog':['🌫️','fog'],
        'rain':['🌧️','rain'],
        'drizzle':['🌦️','drizzle'],
        'snow':['❄️','snow'],
        'sleet':['🌨️','sleet'],
        'thunder':['⛈️','thunderstorm'],
        'blizzard':['🌨️','blizzard'],
    };
    function wxIcon(desc) {
        if (!desc) return '🌤️';
        const d = desc.toLowerCase();
        for (const [k,v] of Object.entries(WX_ICONS)) if (d.includes(k)) return v[0];
        return '🌤️';
    }

    async function doFetchWeather(q) {
        document.getElementById('weather-desc').textContent = 'Loading…';
        document.getElementById('weather-icon-big').textContent = '⏳';
        document.getElementById('weather-temp-big').textContent = '—';
        try {
            const url = `https://wttr.in/${encodeURIComponent(q)}?format=j1`;
            const res = await fetch(url);
            if (!res.ok) throw new Error('Not found');
            const data = await res.json();
            renderWeather(data, q);
        } catch(e) {
            document.getElementById('weather-desc').textContent = 'Could not load weather';
            document.getElementById('weather-icon-big').textContent = '❌';
            notify('Weather', 'City not found or offline.');
        }
    }

    function renderWeather(d, q) {
        const cur = d.current_condition[0];
        const area = d.nearest_area?.[0];
        const city = area?.areaName?.[0]?.value || q;
        const country = area?.country?.[0]?.value || '';
        const tempC = parseInt(cur.temp_C);
        const feelsC = parseInt(cur.FeelsLikeC);
        const desc = cur.weatherDesc?.[0]?.value || '';
        const humidity = cur.humidity;
        const wind = cur.windspeedKmph;
        const vis = cur.visibility;

        document.getElementById('weather-location-label').textContent = `${city}, ${country}`;
        document.getElementById('weather-icon-big').textContent = wxIcon(desc);
        document.getElementById('weather-temp-big').textContent = `${tempC}°C`;
        document.getElementById('weather-desc').textContent = desc;
        document.getElementById('weather-feelslike').textContent = `Feels like ${feelsC}°C`;

        document.getElementById('weather-stats').innerHTML = [
            { icon:'💧', label:'Humidity', val: humidity+'%' },
            { icon:'💨', label:'Wind', val: wind+' km/h' },
            { icon:'👁️', label:'Visibility', val: vis+' km' },
        ].map(s => `<div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:12px;text-align:center;">
            <div style="font-size:20px;margin-bottom:4px;">${s.icon}</div>
            <div style="font-size:13px;font-weight:700;">${s.val}</div>
            <div style="font-size:10px;opacity:0.4;">${s.label}</div>
        </div>`).join('');

        // Hourly (from first day)
        const hourly = d.weather?.[0]?.hourly || [];
        document.getElementById('weather-hourly').innerHTML = hourly.map(h => {
            const t = h.time.padStart(4,'0');
            const hr = t.slice(0,-2);
            return `<div style="flex-shrink:0;text-align:center;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:10px 12px;min-width:60px;">
                <div style="font-size:11px;opacity:0.45;margin-bottom:4px;">${hr}:00</div>
                <div style="font-size:22px;">${wxIcon(h.weatherDesc?.[0]?.value)}</div>
                <div style="font-size:12px;font-weight:700;margin-top:4px;">${h.tempC}°</div>
            </div>`;
        }).join('');

        // 3-day forecast
        const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        document.getElementById('weather-forecast').innerHTML = (d.weather||[]).slice(0,3).map(day => {
            const date = new Date(day.date);
            const dayName = days[date.getDay()];
            const icon = wxIcon(day.hourly?.[4]?.weatherDesc?.[0]?.value);
            return `<div style="display:flex;align-items:center;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:12px 16px;gap:12px;">
                <div style="min-width:40px;font-size:12px;font-weight:700;opacity:0.7;">${dayName}</div>
                <div style="font-size:24px;">${icon}</div>
                <div style="flex:1;font-size:12px;opacity:0.5;">${day.hourly?.[4]?.weatherDesc?.[0]?.value||''}</div>
                <div style="font-size:13px;font-weight:700;">${day.maxtempC}° <span style="opacity:0.4;font-weight:400;">/ ${day.mintempC}°</span></div>
            </div>`;
        }).join('');
    }

    // ================================================================
    // MUSIC PLAYER
    // ================================================================
    let musicAudio = null, musicPlaylist = [], musicIndex = 0;
    let musicShuffle = false, musicRepeat = false;
    let musicAnalyser = null, musicAnimFrame = null;

    window.openMusicApp = function() {
        const win = document.getElementById('music-win');
        win.style.display = 'flex';
        bringToFront('music-win');
    };

    window.musicAddFiles = function(files) {
        [...files].forEach(f => {
            musicPlaylist.push({ name: f.name.replace(/\.[^.]+$/,''), url: URL.createObjectURL(f), file: f });
        });
        musicRenderPlaylist();
        if (musicPlaylist.length === files.length) musicLoad(0); // first time
    };

    function musicRenderPlaylist() {
        const el = document.getElementById('music-playlist');
        el.innerHTML = musicPlaylist.map((t,i) => `
            <div onclick="musicLoad(${i})" style="padding:10px 14px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.04);display:flex;align-items:center;gap:10px;${i===musicIndex?'background:rgba(14,165,233,0.1);':''}transition:0.15s;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='${i===musicIndex?'rgba(14,165,233,0.1)':'transparent'}'">
                <span style="font-size:14px;opacity:0.4;min-width:18px;text-align:right;">${i===musicIndex?'♫':i+1}</span>
                <span style="flex:1;font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${t.name}</span>
                <button onclick="event.stopPropagation();musicRemove(${i})" style="background:none;border:none;color:rgba(255,255,255,0.2);cursor:pointer;font-size:14px;padding:0;">✕</button>
            </div>`).join('') || '<div style="padding:20px;text-align:center;opacity:0.3;font-size:12px;">Add audio files to get started</div>';
    }

    window.musicRemove = function(i) {
        musicPlaylist.splice(i, 1);
        if (musicIndex >= musicPlaylist.length) musicIndex = 0;
        musicRenderPlaylist();
    };

    window.musicLoad = function(i) {
        if (!musicPlaylist[i]) return;
        musicIndex = i;
        if (musicAudio) { musicAudio.pause(); musicAudio.src = ''; }
        musicAudio = new Audio(musicPlaylist[i].url);
        musicAudio.volume = parseFloat(document.getElementById('music-vol').value);
        musicAudio.ontimeupdate = musicUpdateProgress;
        musicAudio.onended = musicOnEnded;
        musicAudio.onloadedmetadata = () => {
            document.getElementById('music-dur').textContent = musicFmtTime(musicAudio.duration);
        };
        musicSetupVisualizer();
        musicAudio.play();
        document.getElementById('music-play-btn').textContent = '⏸';
        document.getElementById('music-title').textContent = musicPlaylist[i].name;
        document.getElementById('music-artist').textContent = 'Local file';
        musicRenderPlaylist();
    };

    function musicSetupVisualizer() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const source = ctx.createMediaElementSource(musicAudio);
            musicAnalyser = ctx.createAnalyser();
            musicAnalyser.fftSize = 128;
            source.connect(musicAnalyser);
            musicAnalyser.connect(ctx.destination);
            musicDrawVisualizer();
        } catch(e) {}
    }

    function musicDrawVisualizer() {
        const canvas = document.getElementById('music-visualizer');
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.offsetWidth * devicePixelRatio;
        canvas.height = canvas.offsetHeight * devicePixelRatio;
        const w = canvas.width, h = canvas.height;
        const buf = new Uint8Array(musicAnalyser ? musicAnalyser.frequencyBinCount : 0);

        function draw() {
            musicAnimFrame = requestAnimationFrame(draw);
            ctx.clearRect(0,0,w,h);
            if (!musicAnalyser) return;
            musicAnalyser.getByteFrequencyData(buf);
            const barW = w / buf.length * 1.5;
            buf.forEach((v,i) => {
                const barH = (v/255) * h;
                const hue = 190 + i * 1.5;
                ctx.fillStyle = `hsla(${hue},80%,60%,0.85)`;
                ctx.fillRect(i * (w/buf.length), h - barH, barW, barH);
            });
        }
        if (musicAnimFrame) cancelAnimationFrame(musicAnimFrame);
        draw();
    }

    function musicUpdateProgress() {
        if (!musicAudio) return;
        const pct = (musicAudio.currentTime / musicAudio.duration) * 100 || 0;
        document.getElementById('music-seek').value = pct;
        document.getElementById('music-cur').textContent = musicFmtTime(musicAudio.currentTime);
    }

    function musicOnEnded() {
        if (musicRepeat) { musicAudio.currentTime = 0; musicAudio.play(); return; }
        musicNext();
    }

    window.musicTogglePlay = function() {
        if (!musicAudio) return;
        if (musicAudio.paused) { musicAudio.play(); document.getElementById('music-play-btn').textContent = '⏸'; }
        else { musicAudio.pause(); document.getElementById('music-play-btn').textContent = '▶'; }
    };

    window.musicNext = function() {
        if (!musicPlaylist.length) return;
        const next = musicShuffle
            ? Math.floor(Math.random() * musicPlaylist.length)
            : (musicIndex + 1) % musicPlaylist.length;
        musicLoad(next);
    };

    window.musicPrev = function() {
        if (!musicPlaylist.length) return;
        musicLoad((musicIndex - 1 + musicPlaylist.length) % musicPlaylist.length);
    };

    window.musicSeek = function(v) {
        if (musicAudio) musicAudio.currentTime = (v/100) * musicAudio.duration;
    };

    window.musicSetVol = function(v) {
        if (musicAudio) musicAudio.volume = parseFloat(v);
    };

    window.musicToggleShuffle = function() {
        musicShuffle = !musicShuffle;
        document.getElementById('music-shuffle-btn').style.color = musicShuffle ? '#0ea5e9' : 'rgba(255,255,255,0.3)';
    };

    window.musicToggleRepeat = function() {
        musicRepeat = !musicRepeat;
        document.getElementById('music-repeat-btn').style.color = musicRepeat ? '#0ea5e9' : 'rgba(255,255,255,0.3)';
    };

    function musicFmtTime(s) {
        if (!s || isNaN(s)) return '0:00';
        return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
    }

    // ================================================================
    // SPOTLIGHT SEARCH
    // ================================================================
    let spotlightSelected = -1;


    // ================================================================
    // HYVM — Virtual Machine (v86)
    // ================================================================
    window.HyVM = (function() {
        let _emulator = null;
        let _running  = false;

        const BIOS     = 'bios/seabios.bin';
        const VGA_BIOS = 'bios/vgabios.bin';
        const PRESETS  = {
            freedos: { name: 'FreeDOS', cdrom: 'images/freedos722.img', mem: 128, fda: true },
        };

        function _setStatus(text, running) {
            const dot  = document.getElementById('vm-status-dot');
            const span = document.getElementById('vm-status-text');
            if (dot)  dot.style.background  = running ? '#22c55e' : '#374151';
            if (span) span.textContent       = text;
        }

        function _showButtons(running) {
            ['vm-btn-save','vm-btn-load','vm-btn-restart','vm-btn-stop'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.display = running ? '' : 'none';
            });
        }

        function _showScreen() {
            document.getElementById('vm-launcher').style.display    = 'none';
            document.getElementById('vm-screen-wrap').style.display = 'flex';
        }

        function _showLauncher() {
            document.getElementById('vm-launcher').style.display    = 'flex';
            document.getElementById('vm-screen-wrap').style.display = 'none';
        }

        function _loadV86(cb) {
            if (window.V86Starter) { cb(); return; }
            const SRCS = [
                'https://copy.sh/v86/libv86.js',
                'https://cdn.jsdelivr.net/gh/copy/v86/build/libv86.js',
                'https://rawcdn.githack.com/copy/v86/master/build/libv86.js',
            ];
            notify('HyVM', 'Loading v86 engine…');
            function tryNext(i) {
                if (i >= SRCS.length) { notify('HyVM', 'v86 failed to load. Check your connection.'); return; }
                const s = document.createElement('script');
                s.src = SRCS[i];
                s.onload  = () => { if (window.V86Starter || window.V86) { window.V86Starter = window.V86Starter || window.V86; cb(); } else tryNext(i + 1); };
                s.onerror = () => tryNext(i + 1);
                document.head.appendChild(s);
            }
            tryNext(0);
        }

        function _setupMobileKeyboard() {
            const wrap = document.getElementById('vm-screen-wrap');
            if (!wrap || document.getElementById('vm-mobile-input')) return;
            // Floating keyboard trigger button
            const kbdBtn = document.createElement('button');
            kbdBtn.id = 'vm-kbd-btn';
            kbdBtn.textContent = '⌨️';
            kbdBtn.style.cssText = 'position:absolute;bottom:10px;right:10px;z-index:99;background:rgba(14,165,233,0.8);border:none;border-radius:50%;width:40px;height:40px;font-size:18px;cursor:pointer;touch-action:manipulation;';
            wrap.appendChild(kbdBtn);
            // Hidden input to capture mobile keyboard
            const inp = document.createElement('input');
            inp.id = 'vm-mobile-input';
            inp.setAttribute('autocomplete', 'off');
            inp.setAttribute('autocorrect', 'off');
            inp.setAttribute('autocapitalize', 'off');
            inp.setAttribute('spellcheck', 'false');
            inp.style.cssText = 'position:absolute;opacity:0;width:1px;height:1px;top:0;left:0;pointer-events:none;';
            wrap.appendChild(inp);
            kbdBtn.addEventListener('click', () => { inp.focus(); inp.value = ''; });
            // Relay input events to emulator
            inp.addEventListener('keydown', e => {
                e.preventDefault();
                if (_emulator) _emulator.keyboard_send_scancodes([_keyToScancode(e.key, e.shiftKey)]);
            });
            inp.addEventListener('input', e => {
                const val = inp.value;
                if (!val || !_emulator) { inp.value = ''; return; }
                for (const ch of val) {
                    const code = ch.charCodeAt(0);
                    _emulator.keyboard_send_text(ch);
                }
                inp.value = '';
            });
        }

        const _SCANCODES = {
            Enter:28,Backspace:14,Tab:15,Escape:1,
            ArrowUp:72,ArrowDown:80,ArrowLeft:75,ArrowRight:77,
            Delete:83,Home:71,End:79,PageUp:73,PageDown:81,
            F1:59,F2:60,F3:61,F4:62,F5:63,F6:64,F7:65,F8:66,F9:67,F10:68,F11:87,F12:88,
        };
        function _keyToScancode(key, shift) {
            return _SCANCODES[key] || 0;
        }

        function _boot(config) {
            window.V86Starter = window.V86Starter || window.V86;
            if (!window.V86Starter) { _loadV86(() => _boot(config)); return; }
            if (_emulator) { _emulator.destroy(); _emulator = null; }

            _showScreen();
            _setStatus(`Booting ${config.name}…`, true);
            _showButtons(true);

            const canvas = document.getElementById('vm-canvas');

            _emulator = new V86Starter({
                screen_container: document.getElementById('vm-screen-wrap'),
                screen_dummy: false,
                bios:     { url: BIOS },
                vga_bios: { url: VGA_BIOS },
                ...(config.cdrom && !config.fda ? { cdrom: { url: config.cdrom, async: true } } : {}),
                ...(config.fda   ? { fda:   { url: config.cdrom, async: true } } : {}),
                ...(config.hda   ? { hda:   { buffer: config.hda } } : {}),
                memory_size:    (config.mem || 128) * 1024 * 1024,
                vga_memory_size: 8 * 1024 * 1024,
                autostart: true,
                disable_mouse: false,
                canvas,
            });

            _emulator.add_listener('emulator-ready', () => {
                _running = true;
                _setStatus(`Running: ${config.name}`, true);
                _setupMobileKeyboard();
            });

            _emulator.add_listener('emulator-stopped', () => {
                _running = false;
                _setStatus('VM stopped', false);
            });
        }

        return {
            launchPreset(id) {
                if (id === 'hyos') {
                    // HyOS-in-HyOS: iframe mode, no v86 needed
                    _showScreen();
                    _setStatus('Running: HyOS', true);
                    _showButtons(true);
                    document.getElementById('vm-screen-wrap').innerHTML =
                        '<iframe src="index.html" style="width:100%;height:100%;border:none;background:#000;"></iframe>';
                    _running = true;
                    return;
                }
                const preset = PRESETS[id];
                if (!preset) return;
                _boot(preset);
            },

            launchCustom() {
                document.getElementById('vm-iso-input').click();
            },

            loadCustomISO(input) {
                const file = input.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = e => {
                    _boot({ name: file.name, hda: e.target.result, mem: 256 });
                };
                reader.readAsArrayBuffer(file);
                input.value = '';
            },

            saveState() {
                if (!_emulator || !_running) return;
                _emulator.save_state(state => {
                    try {
                        // State can be large — store as base64
                        const arr  = new Uint8Array(state);
                        let binary = '';
                        arr.forEach(b => binary += String.fromCharCode(b));
                        localStorage.setItem('hyvm_state', btoa(binary));
                        notify('💾 VM Saved', 'State saved successfully.');
                    } catch(e) {
                        notify('HyVM', 'Save failed — state may be too large for localStorage.');
                    }
                });
            },

            loadState() {
                const saved = localStorage.getItem('hyvm_state');
                if (!saved) { notify('HyVM', 'No saved state found.'); return; }
                if (!_emulator) { notify('HyVM', 'Boot a VM first, then restore.'); return; }
                try {
                    const binary = atob(saved);
                    const arr    = new Uint8Array(binary.length);
                    for (let i = 0; i < binary.length; i++) arr[i] = binary.charCodeAt(i);
                    _emulator.restore_state(arr.buffer);
                    notify('📂 VM Restored', 'State restored.');
                } catch(e) {
                    notify('HyVM', 'Restore failed: ' + e.message);
                }
            },

            restart() {
                if (_emulator) { _emulator.restart(); _setStatus('Restarting…', true); }
            },

            stop() {
                if (_emulator) { _emulator.stop(); }
                _running = false;
                _showLauncher();
                _showButtons(false);
                _setStatus('No VM running', false);
                if (_emulator) { _emulator.destroy(); _emulator = null; }
            },

            close() {
                this.stop();
                closeApp('vm-win');
            }
        };
    })();

    window.openHyVM = function() { toggleApp('vm-win'); };


// =====================================================
// HYPROGRESS EASTER EGG — desktop overlay classic mode
// Triggered by: sudo hp start  in the Terminal
// =====================================================
(function() {

const HP_POPUPS = [
    {icon:'⚠️', title:'HyOS Update Available', msg:'HyOS 16.2.1 is ready. Restart now?', ok:'Later', cancel:'Install'},
    {icon:'🦠', title:'Virus Detected', msg:'HyProgress.exe triggered a heuristic alert.', ok:'Ignore', cancel:'Quarantine'},
    {icon:'💾', title:'Low Disk Space', msg:'Drive C: has 0.3 MB remaining.', ok:'OK', cancel:null},
    {icon:'🛑', title:'Critical Error', msg:'KERNEL_SECURITY_CHECK_FAILURE. A bar destabilized the kernel.', ok:'OK', cancel:'Details'},
    {icon:'🤖', title:'Hyley AI Suggestion', msg:'Catch the blue bars!', ok:'Got it', cancel:null},
    {icon:'🔄', title:'HyOS is Restarting…', msg:'Applying critical security patch (1 of 47).', ok:'Cancel', cancel:null},
    {icon:'📋', title:'HyClipboard Warning', msg:'An unknown process copied 4.7 GB to your clipboard.', ok:'Clear', cancel:'Keep'},
    {icon:'🌡️', title:'Thermal Warning', msg:'GPU reached 117°C. Applying thermal paste via software.', ok:'OK', cancel:null},
    {icon:'💤', title:'Idle Warning', msg:'You have been idle for 0 seconds. Logging out in 3s.', ok:'Stay logged in', cancel:null},
    {icon:'🧠', title:'HyOS Memory Leak', msg:'RAM usage: 103%. Somehow.', ok:'Ignore', cancel:'Fix'},
    {icon:'📡', title:'Satellite Signal Lost', msg:'3 satellites used for clock sync. They\'ve all resigned.', ok:'OK', cancel:null},
    {icon:'🔐', title:'Two-Factor Required', msg:'Enter the code sent to your fax machine.', ok:'I have a fax', cancel:'I don\'t'},
    {icon:'🏆', title:'Achievement Unlocked', msg:'More time dismissing popups than catching bars.', ok:'Thanks', cancel:null},
    {icon:'👾', title:'Bar Entity: Sentient', msg:'A blue bar has gained consciousness. Catch it quickly.', ok:'Catch it', cancel:'Let it go'},
    {icon:'🔮', title:'You Are Being Watched', msg:'The progress bars know you\'re playing.', ok:'OK', cancel:null},
];

let _hpState = null;

window._hyProgressStart = function() {
    if (window._hpRunning) return;
    window._hpRunning = true;

    // Inject styles
    if (!document.getElementById('_hp-styles')) {
        const s = document.createElement('style');
        s.id = '_hp-styles';
        s.textContent = `
            #_hp-overlay { position:fixed;inset:0;z-index:9000;pointer-events:none; }
            .hp-bar { position:fixed;z-index:9010;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;letter-spacing:0.5px;pointer-events:all;cursor:pointer;transition:transform 0.08s,opacity 0.08s;box-shadow:0 4px 18px rgba(0,0,0,0.5);user-select:none; }
            .hp-bar:hover { transform:scaleY(1.15); }
            .hp-bar.blue  { background:linear-gradient(90deg,#0ea5e9,#22d3ee);color:#fff; }
            .hp-bar.red   { background:linear-gradient(90deg,#ef4444,#f97316);color:#fff; }
            .hp-bar.green { background:linear-gradient(90deg,#22c55e,#16a34a);color:#fff; }
            .hp-bar.gold  { background:linear-gradient(90deg,#f59e0b,#fbbf24);color:#000; }
            .hp-bar.purple{ background:linear-gradient(90deg,#a855f7,#7c3aed);color:#fff; }
            .hp-bar.caught{ animation:_hpCatch 0.25s ease-out forwards; pointer-events:none; }
            @keyframes _hpCatch { to { transform:scale(1.4);opacity:0; } }
            #_hp-bar-dock { position:fixed;bottom:70px;left:50%;transform:translateX(-50%);z-index:9020;
                background:rgba(5,8,16,0.92);border:1px solid rgba(14,165,233,0.3);border-radius:16px;
                padding:10px 20px 12px;display:flex;flex-direction:column;align-items:center;gap:6px;
                backdrop-filter:blur(20px);box-shadow:0 8px 40px rgba(0,0,0,0.6);min-width:240px; }
            #_hp-bar-track { width:200px;height:10px;background:rgba(255,255,255,0.06);border-radius:99px;overflow:hidden;border:1px solid rgba(255,255,255,0.08); }
            #_hp-bar-fill  { height:100%;border-radius:99px;width:0%;background:linear-gradient(90deg,#0ea5e9,#22d3ee);transition:width 0.1s linear; }
            #_hp-hud { display:flex;align-items:center;gap:14px;font-size:11px;font-weight:700;color:rgba(255,255,255,0.6); }
            #_hp-hud .hp-score { color:#0ea5e9; }
            #_hp-hud .hp-lives { color:#f87171; }
            .hp-popup { position:fixed;z-index:9030;background:rgba(8,14,28,0.97);border:1px solid rgba(14,165,233,0.25);
                border-radius:12px;padding:0;width:300px;box-shadow:0 16px 50px rgba(0,0,0,0.7);
                backdrop-filter:blur(20px);pointer-events:all;animation:_hpPopIn 0.2s ease-out; }
            @keyframes _hpPopIn { from{transform:scale(0.85);opacity:0;} to{transform:scale(1);opacity:1;} }
            .hp-popup-hdr { display:flex;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,0.06);cursor:move; }
            .hp-popup-icon { font-size:16px; }
            .hp-popup-title { font-size:12px;font-weight:800;flex:1; }
            .hp-popup-body { padding:10px 14px; }
            .hp-popup-msg { font-size:11px;color:rgba(255,255,255,0.55);line-height:1.5; }
            .hp-popup-btns { display:flex;justify-content:flex-end;gap:7px;margin-top:10px; }
            .hp-popup-btn { padding:5px 14px;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;border:none;font-family:inherit; }
            .hp-popup-btn.primary { background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.4);color:#7dd3fc; }
            .hp-popup-btn.secondary { background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.5); }
            .hp-popup-btn:hover { filter:brightness(1.3); }
            #_hp-gameover { position:fixed;inset:0;z-index:9050;background:rgba(2,4,8,0.85);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(8px); }
            #_hp-gameover-box { background:rgba(8,14,28,0.98);border:1px solid rgba(14,165,233,0.3);border-radius:20px;padding:36px 44px;text-align:center;min-width:300px; }
            #_hp-win-screen { position:fixed;inset:0;z-index:9050;background:rgba(2,8,4,0.85);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(8px); }
        `;
        document.head.appendChild(s);
    }

    // Build overlay layer
    const overlay = document.createElement('div');
    overlay.id = '_hp-overlay';
    document.body.appendChild(overlay);

    // Build bar dock
    const dock = document.createElement('div');
    dock.id = '_hp-bar-dock';
    dock.innerHTML = `
        <div id="_hp-hud">
            <span>📊 HyProgress</span>
            <span class="hp-score">Score: <span id="_hp-score">0</span></span>
            <span class="hp-lives">❤️❤️❤️</span>
            <span style="font-size:10px;opacity:0.4;cursor:pointer;" onclick="window._hyProgressStop()">✕ stop</span>
        </div>
        <div id="_hp-bar-track"><div id="_hp-bar-fill"></div></div>
        <div style="font-size:10px;opacity:0.35;margin-top:2px;">Catch blue bars · avoid red · dismiss popups</div>
    `;
    document.body.appendChild(dock);

    _hpState = {
        barPct: 0, score: 0, lives: 3, level: 1, running: true,
        fallers: [], fallerId: 0, popupCounter: 0,
        spawnTimer: null, popupTimer: null, animFrame: null,
    };

    const st = _hpState;

    function updateBar() {
        document.getElementById('_hp-bar-fill').style.width = st.barPct + '%';
        document.getElementById('_hp-score').textContent = st.score;
    }

    function setLives(n) {
        const h = ['💔','❤️','❤️❤️','❤️❤️❤️'];
        const el = document.querySelector('#_hp-hud .hp-lives');
        if (el) el.textContent = h[Math.max(0,n)] || '💔';
    }

    function spawnFaller() {
        if (!st.running) return;
        const types = ['blue','blue','blue','red','red','green','gold','purple'];
        const labels = {blue:'+ FILL',red:'− DRAIN',green:'⚠ BSOD',gold:'★ MEGA',purple:'☠ CORRUPT'};
        const type = types[Math.floor(Math.random() * types.length)];
        const w = 80 + Math.floor(Math.random() * 60);
        const x = Math.random() * (window.innerWidth - w);
        const speed = 2.5 + Math.random() * 1.5 + (st.level - 1) * 0.4;
        const el = document.createElement('div');
        el.className = 'hp-bar ' + type;
        el.style.cssText = `width:${w}px;height:22px;left:${x}px;top:-30px;`;
        el.textContent = labels[type];
        document.body.appendChild(el);
        const id = st.fallerId++;
        const faller = {id, type, y: -30, x, w, speed, el};
        st.fallers.push(faller);
        el.addEventListener('click', () => catchBar(id));
        scheduleFaller();
    }

    function scheduleFaller() {
        if (!st.running) return;
        const ms = Math.max(400, 1200 - (st.level - 1) * 120);
        st.spawnTimer = setTimeout(spawnFaller, ms);
    }

    function catchBar(id) {
        const i = st.fallers.findIndex(f => f.id === id);
        if (i === -1) return;
        const f = st.fallers[i];
        f.el.classList.add('caught');
        setTimeout(() => f.el.remove(), 260);
        st.fallers.splice(i, 1);
        const gains = {blue:8, gold:25, purple:-15, green:-20, red:-12};
        const pts   = {blue:10, gold:40, purple:0,  green:0,   red:0};
        const delta = gains[f.type] ?? 0;
        if (delta > 0) {
            st.barPct = Math.min(100, st.barPct + delta);
            st.score += pts[f.type] ?? 0;
            if (st.barPct >= 100) { triggerWin(); return; }
        } else {
            st.barPct = Math.max(0, st.barPct + delta);
            takeDamage();
        }
        updateBar();
        if (st.level < 5 && st.score >= st.level * 80) { st.level++; }
    }

    function takeDamage() {
        st.lives--;
        setLives(st.lives);
        if (st.lives <= 0) triggerGameOver();
    }

    // Fall animation loop
    (function loop() {
        if (!st.running) return;
        const dockTop = document.getElementById('_hp-bar-dock')?.getBoundingClientRect().top ?? window.innerHeight - 80;
        st.fallers.forEach(f => {
            f.y += f.speed;
            f.el.style.top = f.y + 'px';
            if (f.y > dockTop) {
                // missed bar
                f.el.remove();
                if (f.type === 'blue') {
                    st.barPct = Math.max(0, st.barPct - 5);
                    updateBar();
                }
                st.fallers.splice(st.fallers.indexOf(f), 1);
            }
        });
        st.animFrame = requestAnimationFrame(loop);
    })();

    function spawnPopup() {
        if (!st.running) return;
        const data = HP_POPUPS[Math.floor(Math.random() * HP_POPUPS.length)];
        const pid = 'hp-pop-' + (st.popupCounter++);
        const d = document.createElement('div');
        d.className = 'hp-popup';
        d.id = pid;
        const x = Math.random() * (window.innerWidth - 320);
        const y = 60 + Math.random() * (window.innerHeight - 280);
        d.style.cssText = `left:${Math.max(0,x)}px;top:${Math.max(40,y)}px;`;
        const cancelBtn = data.cancel ? `<button class="hp-popup-btn secondary" onclick="document.getElementById('${pid}').remove()">${data.cancel}</button>` : '';
        d.innerHTML = `
            <div class="hp-popup-hdr">
                <span class="hp-popup-icon">${data.icon}</span>
                <span class="hp-popup-title">${data.title}</span>
            </div>
            <div class="hp-popup-body">
                <p class="hp-popup-msg">${data.msg}</p>
                <div class="hp-popup-btns">
                    ${cancelBtn}
                    <button class="hp-popup-btn primary" onclick="document.getElementById('${pid}').remove()">${data.ok}</button>
                </div>
            </div>`;
        // drag
        const hdr = d.querySelector('.hp-popup-hdr');
        let drag=false, ox=0, oy=0;
        hdr.addEventListener('mousedown', e => { drag=true; const r=d.getBoundingClientRect(); ox=e.clientX-r.left; oy=e.clientY-r.top; e.preventDefault(); });
        document.addEventListener('mousemove', e => { if(!drag) return; d.style.left=(e.clientX-ox)+'px'; d.style.top=(e.clientY-oy)+'px'; });
        document.addEventListener('mouseup', () => drag=false);
        document.body.appendChild(d);
        schedulePopup();
    }

    function schedulePopup() {
        if (!st.running) return;
        const ms = Math.max(3000, 8000 - (st.level - 1) * 800);
        st.popupTimer = setTimeout(spawnPopup, ms);
    }

    function triggerWin() {
        window._hyProgressStop(true);
        const box = document.createElement('div');
        box.id = '_hp-win-screen';
        box.innerHTML = `<div id="_hp-gameover-box">
            <div style="font-size:48px;margin-bottom:12px;">🏆</div>
            <div style="font-size:22px;font-weight:900;margin-bottom:6px;">Bar Reached 100%!</div>
            <div style="font-size:13px;opacity:0.5;margin-bottom:20px;">Score: ${_hpState?.score ?? 0}</div>
            <button onclick="document.getElementById('_hp-win-screen')?.remove()" style="background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.4);color:#7dd3fc;padding:10px 28px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">Nice!</button>
        </div>`;
        document.body.appendChild(box);
    }

    function triggerGameOver() {
        window._hyProgressStop(true);
        const box = document.createElement('div');
        box.id = '_hp-gameover';
        box.innerHTML = `<div id="_hp-gameover-box">
            <div style="font-size:48px;margin-bottom:12px;">💀</div>
            <div style="font-size:22px;font-weight:900;margin-bottom:6px;">Bar Depleted</div>
            <div style="font-size:13px;opacity:0.5;margin-bottom:20px;">Score: ${_hpState?.score ?? 0}</div>
            <button onclick="document.getElementById('_hp-gameover')?.remove();window._hyProgressStart();" style="background:rgba(14,165,233,0.2);border:1px solid rgba(14,165,233,0.4);color:#7dd3fc;padding:10px 28px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;margin-right:8px;">Try Again</button>
            <button onclick="document.getElementById('_hp-gameover')?.remove()" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.5);padding:10px 28px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;">Quit</button>
        </div>`;
        document.body.appendChild(box);
    }

    scheduleFaller();
    schedulePopup();
};

window._hyProgressStop = function(keepState) {
    window._hpRunning = false;
    if (_hpState) {
        _hpState.running = false;
        clearTimeout(_hpState.spawnTimer);
        clearTimeout(_hpState.popupTimer);
        cancelAnimationFrame(_hpState.animFrame);
        _hpState.fallers.forEach(f => f.el.remove());
        _hpState = null;
    }
    document.querySelectorAll('.hp-popup, .hp-bar').forEach(e => e.remove());
    document.getElementById('_hp-overlay')?.remove();
    document.getElementById('_hp-bar-dock')?.remove();
    if (!keepState) {
        document.getElementById('_hp-gameover')?.remove();
        document.getElementById('_hp-win-screen')?.remove();
    }
};

})();
// =====================================================
// END HYPROGRESS EASTER EGG
// =====================================================
