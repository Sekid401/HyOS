// HyNative.js — Native app runtime, IPC, system events, shared clipboard
(function (global) {
    'use strict';

    const _registry     = {};   // running apps: id → { manifest, api, container, winId }
    const _appListeners = {};   // app-to-app channels: "targetId:channel" → [fn]
    const _sysListeners = {};   // system events: "event" → [fn]

    // ── System event bus ───────────────────────────────────────────────────

    function sysOn(event, fn) {
        if (!_sysListeners[event]) _sysListeners[event] = [];
        _sysListeners[event].push(fn);
    }

    function sysOff(event, fn) {
        if (!_sysListeners[event]) return;
        _sysListeners[event] = _sysListeners[event].filter(f => f !== fn);
    }

    function sysEmit(event, payload) {
        (_sysListeners[event] || []).forEach(fn => {
            try { fn(payload, event); } catch(e) { console.error('[HyNative] sysEmit error:', e); }
        });
    }

    // ── Shared clipboard ───────────────────────────────────────────────────

    const _clip = { data: null, type: 'empty', source: null };

    const clipboard = {
        set(data, type, sourceId) {
            _clip.data = data; _clip.type = type || 'text'; _clip.source = sourceId || null;
            sysEmit('clipboard:change', { ..._clip });
        },
        get()   { return { ..._clip }; },
        clear() { _clip.data = null; _clip.type = 'empty'; _clip.source = null; sysEmit('clipboard:change', { ..._clip }); },
        get type() { return _clip.type; }
    };

    // ── App-to-app messaging ───────────────────────────────────────────────

    function send(targetId, channel, payload) {
        const entry = _registry[targetId];
        if (!entry) { console.warn(`[HyNative] send: app "${targetId}" not running`); return false; }
        const key = `${targetId}:${channel}`;
        (_appListeners[key] || []).forEach(fn => { try { fn(payload, channel); } catch(e) { console.error('[HyNative] listener error:', e); } });
        return true;
    }

    function broadcast(channel, payload) {
        Object.keys(_registry).forEach(id => send(id, channel, payload));
    }

    // ── Per-app API factory ────────────────────────────────────────────────

    function makeAppAPI(id) {
        return {
            id,
            on(channel, fn)  { const k = `${id}:${channel}`; if (!_appListeners[k]) _appListeners[k] = []; _appListeners[k].push(fn); },
            off(channel, fn) { const k = `${id}:${channel}`; if (_appListeners[k]) _appListeners[k] = _appListeners[k].filter(f => f !== fn); },
            send:      (targetId, ch, payload) => send(targetId, ch, payload),
            broadcast: (ch, payload)           => broadcast(ch, payload),
            system: {
                on:        (event, fn)  => sysOn(event, fn),
                off:       (event, fn)  => sysOff(event, fn),
                emit:      (event, pl)  => sysEmit(event, pl),
                clipboard,
            },
            apps() { return Object.keys(_registry).map(rid => ({ id: rid, manifest: _registry[rid].manifest })); },
            notify:   (title, msg) => global.notify && global.notify(title, msg),
            fs:       global.HyFS || null,
            get user()     { return global.user || 'Guest'; },
            get settings() { return { ...global.userSettings }; },
            close()        { HyNative.unload(id); }
        };
    }

    // ── Loader ────────────────────────────────────────────────────────────

    function load(hyhPackage, winId) {
        const manifest = _parseManifest(hyhPackage);
        if (!manifest) { console.error('[HyNative] load: missing or invalid manifest'); return false; }
        const id = manifest.id || manifest.name?.toLowerCase().replace(/\s+/g, '_') || ('app_' + Date.now());
        if (_registry[id]) { console.warn(`[HyNative] "${id}" already running`); return false; }
        const entry = _findEntry(hyhPackage.files || []);
        if (!entry) { console.error('[HyNative] load: no entry file'); return false; }
        const container = document.createElement('div');
        container.id = `hynative-${id}`;
        container.style.cssText = 'width:100%;height:100%;overflow:auto;position:relative;';
        const winBody = document.querySelector(`#${winId} .win-body`);
        if (!winBody) { console.error(`[HyNative] load: win-body not found in #${winId}`); return false; }
        winBody.innerHTML = '';
        winBody.appendChild(container);
        const api = makeAppAPI(id);
        _registry[id] = { manifest, api, container, winId };
        const raw = entry.content || entry.data || '';
        if (entry.name?.endsWith('.hl')) {
            const parsed = _parseHL(raw);
            _injectHTML(container, parsed.html, api);
        } else if (entry.type === 'html' || entry.name?.endsWith('.html')) {
            _injectHTML(container, raw, api);
        } else {
            _injectJS(container, raw, api);
        }
        sysEmit('app:load', { id, manifest });
        console.log(`[HyNative] loaded "${id}"`);
        return id;
    }

    function unload(id) {
        const entry = _registry[id];
        if (!entry) return;
        Object.keys(_appListeners).forEach(key => { if (key.startsWith(`${id}:`)) delete _appListeners[key]; });
        entry.container.remove();
        delete _registry[id];
        sysEmit('app:unload', { id });
        console.log(`[HyNative] unloaded "${id}"`);
    }

    // ── Internals ─────────────────────────────────────────────────────────

    function _parseManifest(pkg) {
        const mFile = (pkg.files || []).find(f => f.name === 'Mani.manifest' || f.name === 'manifest.json');
        if (!mFile) return null;
        try { return JSON.parse(mFile.content || mFile.data); } catch(e) { return null; }
    }

    function _findEntry(files) {
        return files.find(f => f.name === 'Main.html') ||
               files.find(f => f.name === 'index.html') ||
               files.find(f => f.name === 'main.html')  ||
               files.find(f => f.name === 'main.js')    ||
               files.find(f => f.name?.endsWith('.hl'))  ||
               files.find(f => f.type === 'html')        ||
               files.find(f => f.name?.endsWith('.html')) ||
               null;
    }

    function _parseHL(raw) {
        try {
            const hl = JSON.parse(raw);
            if (hl.Type1 !== 'HTML' || hl.Type2 !== 'JSON') throw new Error('Not a valid .hl file');
            return { html: Array.isArray(hl.Lines) ? hl.Lines.join('\n') : '', jsonActions: hl.JSONActions || [] };
        } catch(e) { console.error('[HyNative] .hl parse error:', e); return { html: '', jsonActions: [] }; }
    }

    function _injectHTML(container, html, api) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        container.innerHTML = doc.body.innerHTML;
        doc.querySelectorAll('style').forEach(s => { const style = document.createElement('style'); style.textContent = s.textContent; container.prepend(style); });
        doc.querySelectorAll('script').forEach(s => _runScript(s.textContent, api, container));
    }

    function _injectJS(container, code, api) { _runScript(code, api, container); }

    function _runScript(code, api, container) {
        try { const fn = new Function('HyApp', 'HyOS', 'document', 'notify', code); fn(api, global.HyNative, container, api.notify); }
        catch(e) { console.error('[HyNative] script error:', e); }
    }

    function isNative(hyhPackageOrApp) {
        if (!hyhPackageOrApp) return false;
        if (hyhPackageOrApp.files) { const m = _parseManifest(hyhPackageOrApp); return !!(m && m.native === true); }
        return !!(hyhPackageOrApp.native === true);
    }

    global.HyNative = {
        load, unload, send, broadcast, isNative, clipboard,
        on:   sysOn,
        off:  sysOff,
        emit: sysEmit,
        apps() { return Object.keys(_registry).map(id => ({ id, manifest: _registry[id].manifest })); },
        get running() { return Object.keys(_registry); }
    };

    console.log('[HyNative] runtime ready');
})(window);
