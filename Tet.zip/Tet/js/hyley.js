// hyley.js — Hyley AI assistant, memory, recommendations
    const hyleyKnowledge = {
        // Basic words and alphabet
        alphabet: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
        basicWords: ['hello', 'hi', 'hey', 'thanks', 'thank', 'you', 'please', 'help', 'yes', 'no', 'open', 'close', 'start', 'stop', 'app', 'application', 'file', 'folder', 'system', 'settings'],
        
        // App commands
        appCommands: {
            'open': ['open', 'launch', 'start', 'run'],
            'close': ['close', 'quit', 'exit', 'stop']
        },
        
        // Learned responses (can be expanded)
        learned: {}
    };
    
    // Toggle Hyley Panel
    window.toggleHyley = function(event) {
        if (event) event.stopPropagation();

        // Require face scan (not just manual age entry)
        if (!userSettings.faceScanned) {
            notify('Face Verification Required', 'Hyley requires face verification. Go to Settings → Age.');
            // Open Settings to the Age tab
            const settWin = document.getElementById('settings-win');
            if (settWin) { settWin.style.display = 'flex'; }
            if (window.switchSettingsTab) switchSettingsTab('age');
            return;
        }

        // Disable for under-13
        if (userSettings.userAge !== null && userSettings.userAge < 13) {
            notify('Hyley Disabled', 'The Hyley AI assistant is not available for users under 13.');
            return;
        }

        const panel = document.getElementById('hyley-panel');
        
        // Close other panels
        document.getElementById('services-menu').style.display = 'none';
        document.getElementById('notification-panel').style.display = 'none';
        
        if (panel.style.display === 'flex') {
            panel.style.display = 'none';
        } else {
            panel.style.display = 'flex';
        }
    };
    
    // Send message to Hyley
    // =====================================================
    // HYLEY SETTINGS
    // =====================================================
    
    let hyleySettings = {
        tips: false, // Disabled by default
        weather: false,
        news: false,
        coding: false,
        voice: false,
        suggestions: false,
        quickcmd: false
    };
    
    // Load Hyley settings
    function loadHyleySettings() {
        const saved = localStorage.getItem('hyley_settings');
        if (saved) {
            try {
                hyleySettings = { ...hyleySettings, ...JSON.parse(saved) };
            } catch(e) {
                console.error('Failed to load Hyley settings:', e);
            }
        }
        
        // Update UI toggles
        if (hyleySettings.tips) {
            document.getElementById('hyley-tips-toggle')?.classList.add('active');
        }
        if (hyleySettings.weather) {
            document.getElementById('hyley-weather-toggle')?.classList.add('active');
        }
        if (hyleySettings.news) {
            document.getElementById('hyley-news-toggle')?.classList.add('active');
        }
        if (hyleySettings.coding) {
            document.getElementById('hyley-coding-toggle')?.classList.add('active');
            // Show Hyley button in App Builder
            const codingBtn = document.getElementById('hyley-coding-btn');
            if (codingBtn) codingBtn.style.display = 'block';
        }
        if (hyleySettings.voice) {
            document.getElementById('hyley-voice-toggle')?.classList.add('active');
        }
        if (hyleySettings.suggestions) {
            document.getElementById('hyley-suggestions-toggle')?.classList.add('active');
        }
        if (hyleySettings.quickcmd) {
            document.getElementById('hyley-quickcmd-toggle')?.classList.add('active');
        }
    }
    
    function saveHyleySettings() {
        localStorage.setItem('hyley_settings', JSON.stringify(hyleySettings));
    }
    
    window.toggleHyleySettings = function() {
        const panel = document.getElementById('hyley-settings-panel');
        const hyleyPanel = document.getElementById('hyley-panel');
        
        if (panel.style.display === 'flex') {
            panel.style.display = 'none';
        } else {
            panel.style.display = 'flex';
            hyleyPanel.style.display = 'none'; // Close main panel
        }
    };
    
    window.toggleHyleySetting = function(setting, toggle) {
        hyleySettings[setting] = !hyleySettings[setting];
        
        if (hyleySettings[setting]) {
            toggle.classList.add('active');
        } else {
            toggle.classList.remove('active');
        }
        
        saveHyleySettings();
        
        // Show/hide Hyley button in App Builder when coding setting changes
        if (setting === 'coding') {
            const codingBtn = document.getElementById('hyley-coding-btn');
            if (codingBtn) {
                codingBtn.style.display = hyleySettings.coding ? 'block' : 'none';
            }
        }
        
        // Show confirmation
        const settingNames = {
            tips: 'Contextual Tips',
            weather: 'Weather System',
            news: 'News System',
            coding: 'App Builder Assistant',
            voice: 'Voice Responses',
            suggestions: 'Smart Suggestions',
            quickcmd: 'Quick Commands'
        };
        notify(settingNames[setting], hyleySettings[setting] ? 'Enabled' : 'Disabled');
    };
    
    // Load Hyley settings on init
    setTimeout(() => {
        loadHyleySettings();
    }, 500);
    
    // Clear Hyley chat history
    window.clearHyleyChat = function() {
        if (confirm('Are you sure you want to clear all chat history with Hyley?')) {
            const chat = document.getElementById('hyley-chat');
            chat.innerHTML = '';
            notify('Chat Cleared', 'Hyley chat history has been cleared');
        }
    };
    
    // Reset Hyley (clear all data and settings)
    window.resetHyley = function() {
        if (confirm('Are you sure you want to reset Hyley? This will clear all chat history, learned words, and reset all settings to default.')) {
            // Clear chat
            const chat = document.getElementById('hyley-chat');
            chat.innerHTML = '';
            
            // Clear learned words
            localStorage.removeItem('hyleyLearnedWords');
            
            // Clear context
            localStorage.removeItem('hyleyContext');
            
            // Reset settings to default
            hyleySettings = {
                tips: false,
                weather: false,
                news: false,
                coding: false,
                voice: false,
                suggestions: false,
                quickcmd: false
            };
            saveHyleySettings();
            
            // Update UI toggles
            document.querySelectorAll('[id^="hyley-"][id$="-toggle"]').forEach(toggle => {
                toggle.classList.remove('active');
            });
            
            notify('Hyley Reset', 'Hyley has been reset to factory defaults');
            
            // Close settings panel
            document.getElementById('hyley-settings-panel').style.display = 'none';
        }
    };
    
    // =====================================================
    // HYLEY ASSISTANT
    // =====================================================
    
    // ── Hyley dictionary lookup via Free Dictionary API ────────────────
    async function hyleyDefineWord(term) {
        try {
            const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(term)}`);
            if (!res.ok) return `I couldn't find a definition for <strong>${term}</strong>. You can teach me: <em>"remember that ${term} means [definition]"</em>`;
            const data = await res.json();
            const entry = data[0];
            const phonetic = entry.phonetic || entry.phonetics?.find(p=>p.text)?.text || '';
            // Gather up to 3 definitions across meanings
            const defs = [];
            for (const meaning of entry.meanings) {
                if (defs.length >= 3) break;
                const def = meaning.definitions[0];
                defs.push(`<em>${meaning.partOfSpeech}</em>: ${def.definition}${def.example ? ` <span style="opacity:.55;">— "${def.example}"</span>` : ''}`);
            }
            return `<strong>${entry.word}</strong>${phonetic ? ` <span style="opacity:.45;">${phonetic}</span>` : ''}<br>${defs.join('<br>')}`;
        } catch(e) {
            return `I couldn't reach the dictionary right now. Check your connection!`;
        }
    }

    // ── Hyley Wikipedia fallback ─────────────────────────────────────────
    async function hyleyWikiSearch(term) {
        try {
            const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(term)}`);
            if (!res.ok) return `I couldn't find anything about <strong>${term}</strong>. You can teach me: <em>"remember that ${term} means [definition]"</em>`;
            const data = await res.json();
            if (data.type === 'disambiguation') return `<strong>${data.title}</strong> could mean several things. Try being more specific!`;
            const extract = data.extract ? data.extract.split('. ').slice(0, 2).join('. ') + '.' : 'No summary available.';
            return `<strong>${data.title}</strong>${data.description ? ` <span style="opacity:.45;">— ${data.description}</span>` : ''}<br>${extract}`;
        } catch(e) {
            return `I couldn't reach Wikipedia right now. Check your connection!`;
        }
    }

    window.sendToHyley = async function() {
        const input = document.getElementById('hyley-input');
        const message = input.value.trim();
        if (!message) return;

        const chat = document.getElementById('hyley-chat');

        // Add user message
        const userMsg = document.createElement('div');
        userMsg.className = 'hyley-message user';
        userMsg.innerHTML = `<div style="font-weight:600;margin-bottom:4px;font-size:11px;opacity:0.6;">YOU</div>${message}`;
        chat.appendChild(userMsg);
        input.value = '';
        chat.scrollTop = chat.scrollHeight;

        // Show typing indicator
        const typing = document.createElement('div');
        typing.className = 'hyley-message assistant';
        typing.id = 'hyley-typing';
        typing.innerHTML = '<span style="opacity:0.5;font-style:italic;">Hyley is thinking…</span>';
        chat.appendChild(typing);
        chat.scrollTop = chat.scrollHeight;

        // Try local processing first
        let response = processHyleyMessage(message);
        const needsAI = response === null;

        if (needsAI) {
            const stripped = message.replace(/^(what is|what does|define|meaning of|search|look up)\s+/i,'').replace(/[?!.,]$/,'').trim();
            const words = stripped.split(/\s+/).filter(w => w.length > 1);

            // Build search candidates: full phrase first, then each word left to right
            const candidates = [stripped, ...words].filter((v,i,a) => a.indexOf(v) === i);

            const failed = r => r.includes("couldn't find") || r.includes("couldn't reach");

            response = null;
            for (const candidate of candidates) {
                let r = await hyleyDefineWord(candidate);
                if (!failed(r)) { response = r; break; }
                r = await hyleyWikiSearch(candidate);
                if (!failed(r)) { response = r; break; }
            }

            if (!response) {
                response = `Hmm, I'm not sure about <strong>${stripped}</strong>! You can teach me: <em>"remember that ${stripped} means [explanation]"</em>`;
            }

            _addHistory('hyley', response);
        }

        // Replace typing indicator with response
        const existing = document.getElementById('hyley-typing');
        if (existing) existing.remove();

        const assistantMsg = document.createElement('div');
        assistantMsg.className = 'hyley-message assistant';
        assistantMsg.innerHTML = response;
        chat.appendChild(assistantMsg);
        chat.scrollTop = chat.scrollHeight;
    };
    
    // Process Hyley's message
    // Short-term conversation memory (last 6 turns, session only)
    function _addHistory(role, text) {
        let h = [];
        try { h = JSON.parse(sessionStorage.getItem('hyley_history') || '[]'); } catch(e) {}
        h.push({ role, text, ts: Date.now() });
        if (h.length > 6) h = h.slice(-6);
        sessionStorage.setItem('hyley_history', JSON.stringify(h));
    }
    function _getHistory() {
        try { return JSON.parse(sessionStorage.getItem('hyley_history') || '[]'); } catch(e) { return []; }
    }
    function _lastUserMsg() {
        const h = _getHistory();
        for (let i = h.length - 1; i >= 0; i--) { if (h[i].role === 'user') return h[i].text; }
        return '';
    }

    function processHyleyMessage(message) {
        _addHistory('user', message);
        const msg = message.toLowerCase().trim();

        // ── Learned words storage ───────────────────────────────────────
        if (!localStorage.getItem('hyleyLearnedWords')) localStorage.setItem('hyleyLearnedWords', JSON.stringify({}));
        const learnedWords = JSON.parse(localStorage.getItem('hyleyLearnedWords'));
        if (!localStorage.getItem('hyleyContext')) localStorage.setItem('hyleyContext', JSON.stringify({ userName: '', lastTopic: '' }));
        const context = JSON.parse(localStorage.getItem('hyleyContext'));

        function saveContext() { localStorage.setItem('hyleyContext', JSON.stringify(context)); }
        function saveWords()   { localStorage.setItem('hyleyLearnedWords', JSON.stringify(learnedWords)); }

        function respond(text) { _addHistory('hyley', text); return text; }

        // ── Folder commands ─────────────────────────────────────────────
        if (msg.includes('create folder') || msg.includes('new folder') || msg.includes('make folder')) {
            const match = msg.match(/(?:create|new|make) folder (?:called |named )?(.+)/);
            const name = match ? match[1].trim() : null;
            if (name) {
                if (window.createDesktopFolder) { window.createDesktopFolder(undefined, undefined, name); }
                return respond(`Created a folder called "${name}" on your desktop!`);
            }
            return respond('What should I call the folder? Try: "create folder [name]"');
        }

        if ((msg.includes('open folder') || msg.includes('show folder')) && !msg.includes('open folder is')) {
            const match = msg.match(/(?:open|show) folder (.+)/);
            const name = match ? match[1].trim() : null;
            if (name && window.userSettings) {
                const idx = userSettings.desktopIcons.findIndex(i => i.type === 'folder' && i.name.toLowerCase().includes(name));
                if (idx !== -1) {
                    window.openFolder(idx, window.innerWidth / 2 - 145, window.innerHeight / 2 - 150);
                    return respond(`Opening folder "${userSettings.desktopIcons[idx].name}"!`);
                }
                return respond(`I couldn't find a folder called "${name}".`);
            }
            return respond('Which folder? Try: "open folder [name]"');
        }

        if (msg.includes('list folders') || msg.includes('show folders') || msg.includes('what folders')) {
            const folders = (userSettings?.desktopIcons || []).filter(i => i.type === 'folder');
            if (folders.length === 0) return respond("You don't have any folders yet. Say \"create folder [name]\" to make one!");
            return respond(`Your folders: ${folders.map(f => `<strong>${f.name}</strong> (${(f.apps||[]).length} apps)`).join(', ')}`);
        }

        // ── Greetings ───────────────────────────────────────────────────
        if (msg.match(/^(hello|hi|hey|sup|yo|howdy)\b/)) {
            const g = context.userName ? `Hey ${context.userName}!` : 'Hey!';
            return respond(`${g} What can I do for you?`);
        }

        // ── Name learning ───────────────────────────────────────────────
        if (msg.includes('my name is') || msg.match(/^i'?m /) || msg.match(/^i am /)) {
            const match = msg.match(/(?:my name is|i'?m|i am) (\w+)/);
            if (match) {
                context.userName = match[1].charAt(0).toUpperCase() + match[1].slice(1);
                saveContext();
                return respond(`Nice to meet you, ${context.userName}! I'll remember that.`);
            }
        }

        // ── Thanks ──────────────────────────────────────────────────────
        if (msg.match(/\bthank(s| you)\b/)) {
            return respond(['You\'re welcome!', 'Happy to help!', 'Anytime!', 'My pleasure!'][Math.floor(Math.random() * 4)]);
        }

        // ── Help ────────────────────────────────────────────────────────
        if (msg === 'help' || msg === '?') {
            return respond('I can: open/close apps, manage calendar, tell the time & date, do math, report system info, create folders, show weather, and learn new things you teach me.<br><br>Teach me: <em>"remember that [word] means [definition]"</em>');
        }

        // ── Math ────────────────────────────────────────────────────────
        if (msg.match(/\d+\s*[+\-*/]\s*\d+/)) {
            try {
                const m = msg.match(/([\d.]+)\s*([+\-*/])\s*([\d.]+)/);
                if (m) {
                    const a = parseFloat(m[1]), op = m[2], b = parseFloat(m[3]);
                    const res = op==='+' ? a+b : op==='-' ? a-b : op==='*' ? a*b : a/b;
                    return respond(`${a} ${op} ${b} = <strong>${res}</strong>`);
                }
            } catch(e) {}
        }

        // ── Time / Date ─────────────────────────────────────────────────
        if (msg.match(/\b(time|clock)\b/) && !msg.includes('timer')) return respond(`It's ${new Date().toLocaleTimeString()}.`);
        if (msg.match(/\b(date|day|today)\b/)) return respond(`Today is ${new Date().toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}.`);

        // ── System info ─────────────────────────────────────────────────
        if (msg.match(/\b(system|version|about hyos)\b/)) {
            const uptime = Math.floor((Date.now() - performance.timing.navigationStart) / 1000);
            return respond(`HyOS HS — Uptime: ${uptime}s • User: ${context.userName||'Guest'} • Apps installed: ${(installedApps||[]).length}`);
        }

        // ── Open / close app ────────────────────────────────────────────
        if (msg.match(/\b(open|launch|start|run)\b/)) {
            const appName = extractAppName(msg);
            if (appName) {
                const app = installedApps.find(a => a.name.toLowerCase().includes(appName));
                if (app) { launchApp(app); return respond(`Opening ${app.name}!`); }
                return respond(`I couldn't find an app called "${appName}". Say "list apps" to see what's installed.`);
            }
            return respond('What app would you like to open?');
        }
        if (msg.match(/\b(close|quit|exit)\b/)) {
            const appName = extractAppName(msg);
            if (appName) {
                const wins = Array.from(document.querySelectorAll('.window')).filter(w => w.querySelector('.win-title')?.textContent.toLowerCase().includes(appName));
                if (wins.length) { wins.forEach(w => { w.style.display='none'; document.querySelector(`[data-window="${w.id}"]`)?.remove(); }); return respond(`Closed ${appName}.`); }
                return respond(`"${appName}" doesn't seem to be open.`);
            }
        }

        // ── List apps ───────────────────────────────────────────────────
        if (msg.includes('list apps') || msg.includes('what apps') || msg.includes('show apps')) {
            return respond(`Installed apps: ${(installedApps||[]).slice(0,10).map(a=>a.name).join(', ')}${(installedApps||[]).length>10?' and more':''}. Double-click any desktop icon or say "open [app]" to launch.`);
        }

        // ── System controls ─────────────────────────────────────────────
        if (msg.includes('screenshot') || msg.includes('capture screen')) { takeScreenshot(); return respond('Taking a screenshot!'); }
        if (msg.includes('restart') || msg.includes('reboot')) { restartSystem(); return respond('Restarting...'); }
        if (msg.includes('shutdown') || msg.includes('shut down') || msg.includes('turn off')) { shutdownSystem(); return respond('Shutting down...'); }
        if (msg.match(/\block\b/) && !msg.includes('unlock')) { lockScreen(); return respond('Locking screen.'); }
        if (msg.includes('settings') || msg.includes('preferences')) { toggleApp('settings-win'); return respond('Opening Settings!'); }
        if (msg.includes('calendar') || msg.includes('schedule') || msg.includes('add event')) {
            Calendar.toggle();
            if (msg.includes('add') || msg.includes('create') || msg.includes('schedule')) setTimeout(() => Calendar.addEvent(), 300);
            return respond('Opening calendar!');
        }
        if (msg.includes('find file') || msg.includes('search file')) { toggleApp('hyfiles-win'); return respond('Opening File Explorer!'); }

        // ── Weather ─────────────────────────────────────────────────────
        if (msg.includes('weather')) {
            const cityMatch = msg.match(/weather\s+(?:in\s+)?(.+)/);
            return respond(getWeather(cityMatch ? cityMatch[1].trim() : 'london'));
        }

        // ── News ────────────────────────────────────────────────────────
        if (hyleySettings.news && msg.match(/\bnews\b|\bheadlines\b/)) {
            const cat = msg.match(/news\s+(?:about\s+)?(.+)/);
            return respond(getNews(cat ? cat[1].trim() : 'top'));
        }

        // ── Jokes ───────────────────────────────────────────────────────
        if (msg.match(/\b(joke|funny|laugh)\b/)) {
            const jokes = [
                "Why don't computers get tired? They have Rest APIs! 😄",
                "What's a dev's fave snack? Microchips! 🖥️",
                "Why did the dev go broke? Used up all his cache! 💸",
                "How do computers stay cool? Lots of fans! 🌬️"
            ];
            return respond(jokes[Math.floor(Math.random() * jokes.length)]);
        }

        // ── Learned word lookup (multi-word aware) ───────────────────────
        // Try progressively shorter substrings of the message
        const words = msg.replace(/[?!.,]/g, '').trim().split(/\s+/);
        for (let len = words.length; len >= 1; len--) {
            for (let start = 0; start <= words.length - len; start++) {
                const phrase = words.slice(start, start + len).join(' ');
                if (learnedWords[phrase]) {
                    return respond(`${phrase}: ${learnedWords[phrase]}`);
                }
            }
        }

        // ── Define / what is ────────────────────────────────────────────
        if (msg.match(/^(what is|what does|define|meaning of) /)) {
            const term = msg.replace(/^(what is|what does|define|meaning of) /, '').replace(/\?$/, '').trim();
            if (learnedWords[term]) return respond(`${term}: ${learnedWords[term]}`);
            return null; // hand off to AI
        }

        // ── Remember / learn ────────────────────────────────────────────
        if (msg.match(/^(remember|learn) that /)) {
            const m = msg.match(/(?:remember|learn) that (.+?) (?:is|means|=) (.+)/);
            if (m) {
                learnedWords[m[1].trim()] = m[2].trim();
                saveWords();
                return respond(`Got it! I'll remember that <strong>${m[1].trim()}</strong> means <em>${m[2].trim()}</em>.`);
            }
            return respond('Try: "remember that [word] means [definition]"');
        }

        // ── Forget ──────────────────────────────────────────────────────
        if (msg.includes('forget') && msg.match(/\b(everything|all)\b/)) {
            localStorage.setItem('hyleyLearnedWords', JSON.stringify({}));
            return respond("Cleared! I've forgotten all my learned words.");
        }
        if (msg.match(/^forget (.+)$/)) {
            const term = msg.replace(/^forget /, '').trim();
            if (learnedWords[term]) { delete learnedWords[term]; saveWords(); return respond(`Forgot "${term}".`); }
            return respond(`I don't have anything stored for "${term}".`);
        }

        // ── Show learned ─────────────────────────────────────────────────
        if (msg.match(/what (have you |did you )?learned|show learned|learned words/)) {
            const list = Object.keys(learnedWords);
            if (!list.length) return respond("I haven't learned any words yet. Teach me: \"remember that [word] means [definition]\"");
            return respond(`I know ${list.length} thing(s): <strong>${list.join(', ')}</strong>. Ask me about any of them!`);
        }

        // ── Contextual tips ──────────────────────────────────────────────
        if (hyleySettings.tips && msg.match(/\b(tip|how do i|help me)\b/)) return respond(generateContextualTip());

        // ── Unknown — hand off to Claude AI ─────────────────────────────
        context.lastTopic = msg;
        saveContext();
        return null; // signal to sendToHyley to use AI
    }
    
    // =====================================================
    // WEATHER SYSTEM
    // =====================================================
    
    function getWeather(city) {
        // Weather data JSON
        const weatherData = {
            "london": { temp: 12, condition: "Cloudy ☁️", humidity: 75, wind: 15 },
            "new york": { temp: 18, condition: "Partly Cloudy ⛅", humidity: 60, wind: 20 },
            "tokyo": { temp: 22, condition: "Sunny ☀️", humidity: 50, wind: 10 },
            "paris": { temp: 14, condition: "Rainy 🌧️", humidity: 80, wind: 12 },
            "dubai": { temp: 35, condition: "Sunny ☀️", humidity: 40, wind: 8 },
            "sydney": { temp: 25, condition: "Clear 🌤️", humidity: 55, wind: 18 },
            "moscow": { temp: -5, condition: "Snowy ❄️", humidity: 85, wind: 25 },
            "singapore": { temp: 30, condition: "Humid 🌴", humidity: 90, wind: 5 },
            "los angeles": { temp: 24, condition: "Sunny ☀️", humidity: 45, wind: 12 },
            "berlin": { temp: 10, condition: "Cloudy ☁️", humidity: 70, wind: 16 },
            "mumbai": { temp: 32, condition: "Humid 🌴", humidity: 85, wind: 10 },
            "toronto": { temp: 8, condition: "Cloudy ☁️", humidity: 65, wind: 14 },
            "mexico city": { temp: 20, condition: "Partly Cloudy ⛅", humidity: 50, wind: 8 },
            "seoul": { temp: 15, condition: "Clear 🌤️", humidity: 55, wind: 12 },
            "beijing": { temp: 18, condition: "Sunny ☀️", humidity: 45, wind: 15 },
            "cairo": { temp: 28, condition: "Sunny ☀️", humidity: 35, wind: 10 },
            "bangkok": { temp: 33, condition: "Humid 🌴", humidity: 88, wind: 6 },
            "istanbul": { temp: 16, condition: "Partly Cloudy ⛅", humidity: 60, wind: 14 },
            "rome": { temp: 19, condition: "Sunny ☀️", humidity: 50, wind: 8 },
            "miami": { temp: 28, condition: "Sunny ☀️", humidity: 70, wind: 12 }
        };
        
        const cityKey = city.toLowerCase().trim();
        const weather = weatherData[cityKey];
        
        if (weather) {
            return `<strong>Weather in ${city.charAt(0).toUpperCase() + city.slice(1)}</strong><br>
                    ${weather.condition}<br>
                    🌡️ Temperature: ${weather.temp}°C<br>
                    💧 Humidity: ${weather.humidity}%<br>
                    💨 Wind: ${weather.wind} km/h`;
        } else {
            const availableCities = Object.keys(weatherData).slice(0, 5).join(', ');
            return `Weather data not available for "${city}". Try cities like: ${availableCities}, and more!`;
        }
    }
    
    // =====================================================
    // NEWS SYSTEM
    // =====================================================
    
    function getNews(category) {
        // News data JSON
        const newsData = {
            top: [
                { title: "Tech Giants Announce AI Partnership", source: "Tech News", time: "2 hours ago" },
                { title: "Global Markets Rally on Economic Data", source: "Finance Daily", time: "3 hours ago" },
                { title: "New Space Mission Planned for 2027", source: "Space Today", time: "5 hours ago" },
                { title: "Climate Summit Reaches Historic Agreement", source: "World News", time: "6 hours ago" },
                { title: "Breakthrough in Renewable Energy Storage", source: "Science Weekly", time: "8 hours ago" }
            ],
            tech: [
                { title: "Revolutionary Quantum Computer Unveiled", source: "Tech Insider", time: "1 hour ago" },
                { title: "New Smartphone Features AI Assistant", source: "Mobile Tech", time: "4 hours ago" },
                { title: "Cybersecurity Threats Rise in 2026", source: "Security News", time: "5 hours ago" },
                { title: "Open Source Project Gains Massive Support", source: "Dev Community", time: "7 hours ago" },
                { title: "5G Network Expansion Continues Globally", source: "Telecom Today", time: "9 hours ago" }
            ],
            business: [
                { title: "Startup Raises $500M in Series C", source: "Business Journal", time: "2 hours ago" },
                { title: "Major Merger Announced in Auto Industry", source: "Corporate News", time: "4 hours ago" },
                { title: "Remote Work Trends Reshape Office Space", source: "Workplace Today", time: "6 hours ago" },
                { title: "E-commerce Sales Hit Record High", source: "Retail News", time: "7 hours ago" },
                { title: "Cryptocurrency Market Shows Volatility", source: "Crypto Watch", time: "10 hours ago" }
            ],
            sports: [
                { title: "Championship Final Set for This Weekend", source: "Sports Network", time: "1 hour ago" },
                { title: "Olympic Athletes Begin Training Camp", source: "Olympic News", time: "3 hours ago" },
                { title: "Record Broken in Marathon Event", source: "Running World", time: "5 hours ago" },
                { title: "Team Announces New Coach Signing", source: "Sports Daily", time: "6 hours ago" },
                { title: "Youth Sports Program Expands Nationwide", source: "Community Sports", time: "8 hours ago" }
            ],
            science: [
                { title: "New Exoplanet Discovered in Habitable Zone", source: "Astronomy Journal", time: "2 hours ago" },
                { title: "Medical Breakthrough in Cancer Treatment", source: "Health Science", time: "4 hours ago" },
                { title: "Ancient Fossil Reveals New Species", source: "Paleontology Today", time: "6 hours ago" },
                { title: "AI Helps Decode Ancient Languages", source: "Research News", time: "8 hours ago" },
                { title: "Ocean Depths Explored by New Submarine", source: "Marine Biology", time: "10 hours ago" }
            ],
            entertainment: [
                { title: "Blockbuster Film Breaks Box Office Records", source: "Cinema News", time: "3 hours ago" },
                { title: "Music Festival Lineup Announced", source: "Music Magazine", time: "5 hours ago" },
                { title: "Popular Series Renewed for Season 5", source: "TV Guide", time: "6 hours ago" },
                { title: "Gaming Convention Attracts Millions", source: "Gaming News", time: "7 hours ago" },
                { title: "Art Exhibition Features AI-Generated Works", source: "Art Today", time: "9 hours ago" }
            ]
        };
        
        const categoryKey = category.toLowerCase().trim();
        const news = newsData[categoryKey] || newsData.top;
        
        let response = `<strong>📰 ${categoryKey === 'top' ? 'Top Headlines' : categoryKey.charAt(0).toUpperCase() + categoryKey.slice(1) + ' News'}</strong><br><br>`;
        
        news.forEach((article, index) => {
            response += `<strong>${index + 1}.</strong> ${article.title}<br>`;
            response += `<span style="font-size: 11px; opacity: 0.6;">${article.source} • ${article.time}</span><br>`;
            if (index < news.length - 1) response += '<br>';
        });
        
        response += `<br><div style="font-size: 11px; opacity: 0.6; margin-top: 8px;">Categories: top, tech, business, sports, science, entertainment</div>`;
        
        return response;
    }
    
    // =====================================================
    // CONTEXTUAL TIPS SYSTEM
    // =====================================================
    
    function generateContextualTip() {
        // Find the currently active app window
        const activeWindows = Array.from(document.querySelectorAll('.window')).filter(win => 
            win.style.display === 'flex' || win.style.display === 'block'
        );
        
        if (activeWindows.length === 0) {
            return "💡 Tip: Try exploring the apps in the drawer! Press Ctrl+D or click the apps icon in the taskbar.";
        }
        
        // Get the most recently opened window
        const activeWindow = activeWindows[activeWindows.length - 1];
        const windowTitle = activeWindow.querySelector('.win-header span')?.textContent || '';
        
        // Get app code if available (from iframe or app data)
        let appCode = '';
        const iframe = activeWindow.querySelector('iframe');
        
        if (iframe) {
            // Try to get app code from installedApps
            const appId = iframe.dataset.appId;
            if (appId) {
                const app = installedApps.find(a => a.id === appId);
                if (app && app.code) {
                    appCode = app.code;
                }
            }
        }
        
        // Generate tip based on app type/code
        return generateSafeTip(windowTitle, appCode);
    }
    
    function generateSafeTip(appName, appCode) {
        // Generic tips if no code available
        if (!appCode) {
            const genericTips = [
                `💡 Tip: Use keyboard shortcuts to navigate ${appName} faster!`,
                `💡 Tip: Right-click on ${appName} for more options.`,
                `💡 Tip: You can resize the ${appName} window by dragging the bottom-right corner.`,
                `💡 Tip: Maximize ${appName} for a better view by clicking the square button.`,
                `💡 Tip: Ask me specific questions about ${appName} - I'm always learning!`
            ];
            return genericTips[Math.floor(Math.random() * genericTips.length)];
        }
        
        // Analyze code to generate safe, helpful tips
        const codeLower = appCode.toLowerCase();
        const tips = [];
        
        // Detect app type and give appropriate tips
        if (codeLower.includes('canvas') || codeLower.includes('ctx.') || codeLower.includes('context.')) {
            tips.push("💡 Tip: This appears to be a drawing or graphics app. Experiment with different tools and colors!");
            tips.push("💡 Tip: Most canvas apps support mouse/touch interactions. Try clicking or dragging!");
        }
        
        if (codeLower.includes('score') && (codeLower.includes('game') || codeLower.includes('play'))) {
            tips.push("💡 Tip: Practice makes perfect! Keep trying to improve your score.");
            tips.push("💡 Tip: Take breaks between sessions to stay focused.");
        }
        
        if (codeLower.includes('button') || codeLower.includes('onclick')) {
            tips.push("💡 Tip: Look for interactive buttons or controls in the app!");
        }
        
        if (codeLower.includes('input') || codeLower.includes('form')) {
            tips.push("💡 Tip: Try filling out the form fields to see what happens.");
            tips.push("💡 Tip: Press Enter after typing to submit quickly.");
        }
        
        if (codeLower.includes('timer') || codeLower.includes('countdown')) {
            tips.push("💡 Tip: Keep an eye on the timer - timing is everything!");
        }
        
        if (codeLower.includes('keydown') || codeLower.includes('keypress')) {
            tips.push("💡 Tip: This app likely uses keyboard controls. Try pressing different keys!");
        }
        
        if (codeLower.includes('audio') || codeLower.includes('sound')) {
            tips.push("💡 Tip: Make sure your volume is at a comfortable level.");
            tips.push("💡 Tip: Some apps have sound - check your audio settings!");
        }
        
        if (codeLower.includes('level') && !codeLower.includes('volume')) {
            tips.push("💡 Tip: Start with easier levels to learn the mechanics.");
        }
        
        if (codeLower.includes('drag') || codeLower.includes('drop')) {
            tips.push("💡 Tip: Try clicking and dragging elements in the app.");
        }
        
        if (codeLower.includes('calculator') || codeLower.includes('math')) {
            tips.push("💡 Tip: Double-check your calculations for accuracy.");
            tips.push("💡 Tip: Use keyboard number pad for faster input.");
        }
        
        if (codeLower.includes('todo') || codeLower.includes('task')) {
            tips.push("💡 Tip: Keep your tasks organized by priority.");
            tips.push("💡 Tip: Break down large tasks into smaller, manageable steps.");
        }
        
        if (codeLower.includes('note') || codeLower.includes('editor')) {
            tips.push("💡 Tip: Save your work frequently to avoid losing progress.");
            tips.push("💡 Tip: Use formatting tools to make your notes more readable.");
        }
        
        if (codeLower.includes('chat') || codeLower.includes('message')) {
            tips.push("💡 Tip: Clear communication is key in messaging apps.");
        }
        
        // Return a random tip from the generated list, or a fallback
        if (tips.length > 0) {
            return tips[Math.floor(Math.random() * tips.length)];
        }
        
        // Fallback generic tips
        const fallbackTips = [
            "💡 Tip: Explore the app's features by interacting with different elements.",
            "💡 Tip: Every app is unique - take your time to learn how it works!",
            "💡 Tip: If you're stuck, try clicking around or pressing different keys.",
            "💡 Tip: Have fun exploring! The best way to learn is by doing."
        ];
        
        return fallbackTips[Math.floor(Math.random() * fallbackTips.length)];
    }
    
    // Extract app name from message
    function extractAppName(message) {
        const words = message.toLowerCase().split(' ');
        const commandWords = ['open', 'launch', 'start', 'run', 'the', 'app', 'application'];
        const appWords = words.filter(w => !commandWords.includes(w));
        return appWords.join(' ');
    }
    
    // Calendar System
